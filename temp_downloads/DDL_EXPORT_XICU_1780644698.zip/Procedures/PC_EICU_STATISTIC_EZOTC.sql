
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_STATISTIC_EZOTC" 
                          ( IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_WD_DEPT_CD_NM  IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2                      
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_STATISTIC_EZOTC
*    CREATEDATE     : 2021.03.30
*    Author         : 신솔
*    Description    : 비대면 영상기록 조회
*    Change History : 2021.03.30, 신솔, 최초작성
                      2021.05.27, 한가혜, 비대면협진 통계 단일/다자간 여부 NULL 값 단일로 'N' 처리
**********************************************************************************************/
BEGIN
    IF IN_WD_DEPT_CD = 'ETC' THEN --기타
        BEGIN
            OPEN OUT_CURSOR FOR  
                /**********************
                SEARCH EZONTHECALL LIST
                ************************/
                WITH SDATA AS(
                     SELECT TO_CHAR(IN_TO_DT, 'YYYYMMDD')                                            AS UNTC_DT           --비대면일자
                          , IN_HIS_HSP_TP_CD                                                         AS HSP_TP_CD         --병원구분코드
                          , IN_WD_DEPT_CD                                                            AS PT_WD_DEPT_CD     --환자병동코드
                          , IN_WD_DEPT_CD_NM                                                         AS PT_WD_DEPT_CD_NM  --환자병동코드명
                          , TO_CHAR(IN_TO_DT, 'YYYY')                                                AS UNTC_PCTR_YY      --비대면영상년도
                          , TO_CHAR(IN_TO_DT, 'MM')                                                  AS UNTC_PCTR_MM      --비대면영상월
                          , TO_CHAR(IN_TO_DT, 'DD')                                                  AS UNTC_PCTR_DY      --비대면영상일
                          , TO_CHAR(NVL(COUNT(*), 0))                                                AS WHL_TELC_CNT      --전체통화수
                          , TO_CHAR(NVL(SUM(DECODE(A.MULTICALLYN, 'N', 1, 0)), 0))                   AS SGL_UNTC_TELC_CNT --단일비대면통화수
                          , TO_CHAR(NVL(SUM(DECODE(A.MULTICALLYN, 'Y', 1, 0)), 0))                   AS MIX_UNTC_TELC_CNT --다자간비대면통화수
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '1', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS SDY_CNSL_TM       --일요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '2', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS MDY_CNSL_TM       --월요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '3', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS UDY_CNSL_TM       --화요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '4', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS WDY_CNSL_TM       --수요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '5', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS TRDY_CNSL_TM      --목요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '6', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS FDY_CNSL_TM       --금요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '7', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS ADY_CNSL_TM       --토요일상담시간
                          , SYSDATE                                                                  AS LOD_DTM           --적재일시
                       FROM (SELECT A.ID
                                  , NVL(A.MULTICALLYN, 'N') AS MULTICALLYN                           --2021.05.27, 한가혜, 비대면협진 통계 단일/다자간 여부 NULL 값 단일로 'N' 처리
                                  , A.CALLSTARTTIME
                                  , A.CALLENDTIME
                                  , (A.CALLENDTIME - A.CALLSTARTTIME) * 24 * 60 * 60 AS CALL_CNSL_TM
                               FROM HICU.LOG_EZOTC_EICU A
                              WHERE A.STATUS        = 'CALL'
                                AND A.CALLSTARTTIME IS NOT NULL
                                AND A.CALLENDTIME   IS NOT NULL
                                AND A.CALLSTARTTIME BETWEEN TRUNC(IN_TO_DT) AND TRUNC(IN_TO_DT) + 0.99999
                                AND A.ICU           IS NULL
                                AND A.HOSPITALCODE  = IN_HIS_HSP_TP_CD) A
                )
                
                SELECT COMN_CD  AS COMN_CD
                     , DTRL1_NM AS DTRL1_NM
                  FROM SDATA
               UNPIVOT (DTRL1_NM FOR COMN_CD
                                  IN ( WHL_TELC_CNT
                                     , SGL_UNTC_TELC_CNT
                                     , MIX_UNTC_TELC_CNT
                                     , SDY_CNSL_TM
                                     , MDY_CNSL_TM
                                     , UDY_CNSL_TM
                                     , WDY_CNSL_TM
                                     , TRDY_CNSL_TM
                                     , FDY_CNSL_TM
                                     , ADY_CNSL_TM
                                     )
                       )
            ;    
        END;
    ELSE --대상 환자
        BEGIN
            OPEN OUT_CURSOR FOR  
                /**********************
                SEARCH EZONTHECALL LIST
                ************************/
                WITH SDATA AS(
                     SELECT TO_CHAR(IN_TO_DT, 'YYYYMMDD')                                            AS UNTC_DT           --비대면일자
                          , IN_HIS_HSP_TP_CD                                                         AS HSP_TP_CD         --병원구분코드
                          , IN_WD_DEPT_CD                                                            AS PT_WD_DEPT_CD     --환자병동코드
                          , IN_WD_DEPT_CD_NM                                                         AS PT_WD_DEPT_CD_NM  --환자병동코드명
                          , TO_CHAR(IN_TO_DT, 'YYYY')                                                AS UNTC_PCTR_YY      --비대면영상년도
                          , TO_CHAR(IN_TO_DT, 'MM')                                                  AS UNTC_PCTR_MM      --비대면영상월
                          , TO_CHAR(IN_TO_DT, 'DD')                                                  AS UNTC_PCTR_DY      --비대면영상일
                          , TO_CHAR(NVL(COUNT(*), 0))                                                AS WHL_TELC_CNT      --전체통화수
                          , TO_CHAR(NVL(SUM(DECODE(A.MULTICALLYN, 'N', 1, 0)), 0))                   AS SGL_UNTC_TELC_CNT --단일비대면통화수
                          , TO_CHAR(NVL(SUM(DECODE(A.MULTICALLYN, 'Y', 1, 0)), 0))                   AS MIX_UNTC_TELC_CNT --다자간비대면통화수
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '1', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS SDY_CNSL_TM       --일요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '2', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS MDY_CNSL_TM       --월요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '3', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS UDY_CNSL_TM       --화요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '4', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS WDY_CNSL_TM       --수요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '5', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS TRDY_CNSL_TM      --목요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '6', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS FDY_CNSL_TM       --금요일상담시간
                          , DECODE((TO_CHAR(IN_TO_DT, 'D')), '7', TO_CHAR(SUM(A.CALL_CNSL_TM)), '0') AS ADY_CNSL_TM       --토요일상담시간
                          , SYSDATE                                                                  AS LOD_DTM           --적재일시
                       FROM (SELECT A.ID
                                  , NVL(A.MULTICALLYN, 'N') AS MULTICALLYN                               --2021.05.27, 한가혜, 비대면협진 통계 단일/다자간 여부 NULL 값 단일로 'N' 처리
                                  , A.CALLSTARTTIME
                                  , A.CALLENDTIME
                                  , (A.CALLENDTIME - A.CALLSTARTTIME) * 24 * 60 * 60 AS CALL_CNSL_TM --단위 : 초
                               FROM HICU.LOG_EZOTC_EICU A
                              WHERE A.STATUS        = 'CALL'
                                AND A.CALLSTARTTIME IS NOT NULL
                                AND A.CALLENDTIME   IS NOT NULL
                                AND A.CALLSTARTTIME BETWEEN TRUNC(IN_TO_DT) AND TRUNC(IN_TO_DT) + 0.99999
                                AND A.ICU           = IN_WD_DEPT_CD
                                AND A.HOSPITALCODE  = IN_HIS_HSP_TP_CD) A
                )
                
                SELECT COMN_CD  AS COMN_CD
                     , DTRL1_NM AS DTRL1_NM
                  FROM SDATA
               UNPIVOT (DTRL1_NM FOR COMN_CD
                                  IN ( WHL_TELC_CNT
                                     , SGL_UNTC_TELC_CNT
                                     , MIX_UNTC_TELC_CNT
                                     , SDY_CNSL_TM
                                     , MDY_CNSL_TM
                                     , UDY_CNSL_TM
                                     , WDY_CNSL_TM
                                     , TRDY_CNSL_TM
                                     , FDY_CNSL_TM
                                     , ADY_CNSL_TM
                                     )
                       )
            ;    
        END;
    END IF;
END PC_EICU_STATISTIC_EZOTC;
