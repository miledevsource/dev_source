
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_RRS" (                    IN_FROM_DTM         IN DATE
                                                              , IN_TO_DTM           IN DATE
                                                              , IN_HSP_TP_CD        IN VARCHAR2
                                                              , IO_ERRYN            IN OUT  VARCHAR2    --  ERROR Y/N
                                                              , IO_ERRMSG           IN OUT  VARCHAR2   --  ERROR MESSAGE   
                                                            )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_RRS
*    CREATEDATE     : 2021.04.02
*    Author         : 한가혜
*    Description    : 운영통계 RRS 현황 일마감 배치
*    Change History : 2021.04.02
**********************************************************************************************/    

AS
    V_CURSOR          SYS_REFCURSOR;   
    
    V_COMN_GRP_CD	  VARCHAR2(50);
    V_COMN_CD	      VARCHAR2(50);
    V_COMN_NM	      VARCHAR2(50);
    V_COMN_EXPL	      VARCHAR2(50);
    V_DTRL1_NM	      VARCHAR2(50);
    
    N_DAYCNT          NUMBER       := 0;
    V_SEARCH_DT       VARCHAR2(8)  := TO_CHAR(IN_FROM_DTM, 'YYYYMMDD'); --TRUNC(IN_FROM_DTM);       --조회 날짜 
    W_SEARCH_DT       DATE         := TRUNC(IN_FROM_DTM);       --조회 날짜 
    
BEGIN

     N_DAYCNT := TRUNC(IN_TO_DTM) - TRUNC(IN_FROM_DTM) + 1; --조회 기간  
     
     BEGIN 
       FOR I IN 1..N_DAYCNT LOOP 
             
    /*******************************************
     * 회신부서코드 조회
     *******************************************/ 
    DECLARE CURSOR DEPT_CD_CURSOR IS           SELECT A.OCUR_DEPT_CD          AS WD_DEPT_CD
                                                    , A.OCUR_DEPT_CD_NM       AS WD_DEPT_CD_NM
                                                 FROM HICU.UICIRRSD A   --U121_UICI(ODS)_RRS
                                                WHERE A.INPT_DT        = V_SEARCH_DT
                                             GROUP BY A.OCUR_DEPT_CD, A.OCUR_DEPT_CD_NM 
                                            ;   
         
         REC  DEPT_CD_CURSOR%ROWTYPE;          
         
         BEGIN  
              OPEN DEPT_CD_CURSOR;                             
              LOOP FETCH DEPT_CD_CURSOR INTO REC;
              EXIT WHEN DEPT_CD_CURSOR%NOTFOUND; 
              
                  BEGIN  --지표조회용 
                           XICU.PC_EICU_RRS_STATISTICS (   V_SEARCH_DT         --'YYYYMMDD'
                                                         , REC.WD_DEPT_CD    --RRS발생부서    
                                                         , IN_HSP_TP_CD      --IN_HSP_TP_CD
                                                         , V_CURSOR          --SYS_REFCURSOR
                                                         );
                    END; 
                    
                   BEGIN
                        LOOP
                        FETCH V_CURSOR INTO V_COMN_GRP_CD
                                          , V_COMN_CD 
                                          , V_COMN_NM
                                          , V_COMN_EXPL
                                          , V_DTRL1_NM 
                                          ;  
                        EXIT WHEN V_CURSOR%NOTFOUND;
                  
                         /********************************************
                         * RRS(UCOSRRSD)  BATCH
                         **********************************************/ 
                          BEGIN
                                 --UPDATE OR INSERT   
                                 MERGE INTO HICU.UCOSRRSD A  --U113_UCOS(운영통계)_RRS Summary
                                          USING DUAL
                                             ON (
                                                 A.OCUR_DEPT_CD		= REC.WD_DEPT_CD                      --발생부서코드(pk) <- 환자위치코드
                                             AND A.OCUR_DT          = V_SEARCH_DT    --발생일자(pk)
                                             AND A.HSP_TP_CD        = IN_HSP_TP_CD
                                                 )   
                                                  
                                           WHEN MATCHED THEN
                                         UPDATE 
                                            SET  A.OCUR_DEPT_CD_NM = REC.WD_DEPT_CD_NM--발생부서코드명 <- 환자위치명
                                               , A.WHL_PT_CNT      = DECODE(V_COMN_CD, 'WHL_PT_CNT', TO_NUMBER(V_DTRL1_NM), A.WHL_PT_CNT)--전체환자수
                                               , A.OCUR_PT_CNT     = DECODE(V_COMN_CD, 'OCUR_PT_CNT', TO_NUMBER(V_DTRL1_NM), A.OCUR_PT_CNT)--발생환자수
                                               , A.WHL_OCUR_CNT    = DECODE(V_COMN_CD, 'WHL_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), A.WHL_OCUR_CNT)--전체발생건수
                                               , A.SBP_OCUR_CNT    = DECODE(V_COMN_CD, 'SBP_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), A.SBP_OCUR_CNT)--SBP 발생건수
                                               , A.PR_OCUR_CNT     = DECODE(V_COMN_CD, 'PR_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), A.PR_OCUR_CNT)--PR 발생건수
                                               , A.SPO2_OCUR_CNT   = DECODE(V_COMN_CD, 'SPO2_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), A.SPO2_OCUR_CNT)--SpO2 발생건수
                                               , A.LOD_DTM         = SYSDATE--적재일시
                                          
                                           --최초적재
                                           WHEN NOT MATCHED THEN
                                         INSERT(
                                                      A.OCUR_DEPT_CD			--발생부서코드(pk) <- 환자위치코드
                                                    , A.OCUR_DT					--발생일자(pk)
                                                    , A.HSP_TP_CD				--병원구분코드(pk)
                                                    , A.OCUR_DEPT_CD_NM			--발생부서코드명 <- 환자위치명
                                                    , A.OCUR_YY					--발생 년
                                                    , A.OCUR_MM					--발생 월
                                                    , A.OCUR_DY					--발생 일
                                                    , A.WHL_PT_CNT				--전체환자수
                                                    , A.OCUR_PT_CNT				--발생환자수
                                                    , A.WHL_OCUR_CNT			--전체발생건수
                                                    , A.SBP_OCUR_CNT			--SBP 발생건수
                                                    , A.PR_OCUR_CNT				--PR 발생건수
                                                    , A.SPO2_OCUR_CNT			--SpO2 발생건수
                                                    , A.LOD_DTM					--적재일시
                                         )
                                         VALUES(
                                                     REC.WD_DEPT_CD                                
                                                   , V_SEARCH_DT          
                                                   , IN_HSP_TP_CD                                 --병원코드(pk)
                                                   , REC.WD_DEPT_CD_NM                               
                                                   , TO_CHAR(W_SEARCH_DT, 'YYYY')              --발생 년
                                                   , TO_CHAR(W_SEARCH_DT, 'MM')                --발생 월
                                                   , TO_CHAR(W_SEARCH_DT, 'DD')                --발생 일
                                                   , DECODE(V_COMN_CD, 'WHL_PT_CNT', TO_NUMBER(V_DTRL1_NM), 0) --전체환자수
                                                   , DECODE(V_COMN_CD, 'OCUR_PT_CNT', TO_NUMBER(V_DTRL1_NM), 0) --발생환자수
                                                   , DECODE(V_COMN_CD, 'WHL_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), 0)--전체발생건수
                                                   , DECODE(V_COMN_CD, 'SBP_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), 0)--SBP 발생건수
                                                   , DECODE(V_COMN_CD, 'PR_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), 0)--PR 발생건수
                                                   , DECODE(V_COMN_CD, 'SPO2_OCUR_CNT', TO_NUMBER(V_DTRL1_NM), 0)--SpO2 발생건수
                                                   , SYSDATE--적재일시 
                                         ); 
                                    
                                EXCEPTION
                		        WHEN OTHERS THEN
                		            IO_ERRYN  := 'Y';
                		            IO_ERRMSG := '(XICU.PC_EICU_CENTER_BATCH_RRS): HSP_TP_CD = '|| IN_HSP_TP_CD || 'OCUR_DT = ' || TO_CHAR(V_SEARCH_DT, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
                		            RETURN ;
                		            
                            END; --U113_UCOS(운영통계)_RRS Summary BATCH END
                            
                        END LOOP;  --지표 조회
                        COMMIT;       
                      END;  --MERGE INTO USING 절                       
                      
     END LOOP; --부서코드 조회 
     CLOSE DEPT_CD_CURSOR;
     END;
           
           V_SEARCH_DT := V_SEARCH_DT + 1; 
           W_SEARCH_DT := W_SEARCH_DT + 1;
     END LOOP;     
    END;
END PC_EICU_CENTER_BATCH_RRS;
