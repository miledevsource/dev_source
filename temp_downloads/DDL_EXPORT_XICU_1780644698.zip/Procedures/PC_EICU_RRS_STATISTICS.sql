
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_RRS_STATISTICS" 
                                                    (   
                                                        IN_TO_DTM           IN VARCHAR2      --'YYYYMMDD'
                                                      , IN_WD_DEPT_CD       IN VARCHAR2 
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_RRS_STATISTICS
*    CREATEDATE     : 2021.04.02
*    Author         : 한가혜
*    Description    : 통합관제 운영통계 RRS 현황 지표 조회
*    Change History : 2021.04.02
**********************************************************************************************/    

AS
    
BEGIN
      OPEN OUT_CURSOR FOR 
                          WITH MAIN AS (
                                          SELECT A.PT_NO				--환자번호
                                               , A.PT_NM				--환자명
                                               , A.INPT_DTM			--입력일시
                                               , A.INPT_DT				--입력일자
                                               , A.ITEM_ID				--항목ID
                                               , A.ITEM_NM				--항목이름
                                               , A.FST_FGR				--최초수치
                                               , A.CUR_FGR				--현재수치
                                               , A.SEX					--성별
                                               , A.AGE					--나이
                                               , A.PT_MED_DEPT_CD		--환자진료부서코드
                                               , A.PT_MED_DEPT_NM		--환자진료부서명
                                               , A.OCUR_DEPT_CD		--환자위치코드
                                               , A.OCUR_DEPT_CD_NM		--환자위치명
                                               , A.MGMT_STS_CD			--관리상태코드
                                               , A.MGMT_STS_CD_NM		--관리상태명
                                               , A.FST_LOD_DTM			--최초적재일시
                                               , A.LST_LOD_DTM			--최종적재일시
                                            FROM HICU.UICIRRSD A   --U121_UICI(ODS)_RRS
                                           WHERE A.INPT_DT        = IN_TO_DTM
                                             AND A.OCUR_DEPT_CD   = IN_WD_DEPT_CD
                            ),
                            --연환자 기준
							SIRM_PT_DATA AS (   
											SELECT SUM(A.YY_PT_CNT)     AS YY_PT_CNT --연환자  
											  FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND A.ETRM_DT_SEQ        = IN_TO_DTM
							), 
                            BASE_TB AS (
            		                      SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                               , A.COMN_CD      AS COMN_CD
                                               , A.COMN_CD_NM   AS COMN_CD_NM
                                               , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                            FROM (  
                                                     SELECT 'RRS_OCUR'           AS COMN_GRP_CD
                                                          , 'WHL_PT_CNT'         AS COMN_CD
                                                          , '중환자실전체환자수' AS COMN_CD_NM 
                                                          , '1'                  AS COMN_CD_EXPL
                                                       FROM DUAL UNION ALL
                                                     SELECT 'RRS_OCUR', 'OCUR_PT_CNT', 'RRS발생환자수', '2' FROM DUAL UNION ALL 
                                                     SELECT 'RRS_OCUR', 'WHL_OCUR_CNT', 'RRS발생건수', '3' FROM DUAL UNION ALL
                                                     SELECT 'RRS_DETAIL_CNT', 'SBP_OCUR_CNT', 'SBP', '1' FROM DUAL UNION ALL
                                                     SELECT 'RRS_DETAIL_CNT', 'PR_OCUR_CNT', 'PR', '2' FROM DUAL UNION ALL
                                                     SELECT 'RRS_DETAIL_CNT', 'SPO2_OCUR_CNT', 'SpO2', '3' FROM DUAL 
                                                  ) A
                                           ORDER BY A.COMN_GRP_CD
                            )    
                            /********************
							* INDICATORS OUT DTO
							*********************/  

                            SELECT B.COMN_GRP_CD 
                                 , B.COMN_CD 
                                 , B.COMN_CD_NM
                                 , B.COMN_CD_EXPL
                                 , TO_CHAR(NVL(A.CNT, 0))  AS CNT
                              FROM (
                                        --전체중환자실환자수
                                        SELECT 'WHL_PT_CNT' AS TITLE
                                             , YY_PT_CNT    AS CNT
                                          FROM SIRM_PT_DATA
                        
                                     UNION ALL
                                        --발생환자수
                                        SELECT 'OCUR_PT_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                          FROM(
                                               SELECT COUNT(*)
                                                 FROM MAIN
                                             GROUP BY PT_NO
                                             )
                        
                                     UNION ALL
                                        --전체발생건수
                                        SELECT 'WHL_OCUR_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                          FROM MAIN
                                      
                                     UNION ALL
                                        --SBP 발생건수
                                        SELECT 'SBP_OCUR_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                         FROM MAIN
                                        WHERE ITEM_ID = 'SBP'
                                    
                                    UNION ALL
                                       --PR 발생건수
                                       SELECT 'PR_OCUR_CNT' AS TITLE
                                            , COUNT(*) AS CNT
                                         FROM MAIN  
                                        WHERE ITEM_ID = 'HR'
                        
                                    UNION ALL
                                       --SpO2 발생건수
                                       SELECT 'SPO2_OCUR_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                         FROM MAIN
                                        WHERE ITEM_ID = 'SPO2'
                                 ) A
                                 , BASE_TB B
                             WHERE B.COMN_CD = A.TITLE (+)
                          ORDER BY B.COMN_GRP_CD
                  ;      
        			           
  END PC_EICU_RRS_STATISTICS;
