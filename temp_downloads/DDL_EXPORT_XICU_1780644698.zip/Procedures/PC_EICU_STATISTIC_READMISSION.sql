
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_STATISTIC_READMISSION" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_STATISTIC_READMISSION
*    CREATEDATE     : 2021.02.03
*    Author         : 신솔
*    Description    : 중환자실 재입실 현황
*    Change History : 2021.02.03, 신솔, 최초작성
                    : 2021-12-23 황선영 수정  [CSR2 : 202107-00441]
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            WITH CHARTGUB AS (
                 /* 차트 구분 공통코드 */
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                   FROM (SELECT 'AGE_GRP' AS COMN_GRP_CD, '1' AS COMN_CD, '~10대' AS COMN_CD_NM FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '2', '20대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '3', '30대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '4', '40대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '5', '50대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '6', '60대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '7', '70대~' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'F', '여성' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'M', '남성' FROM DUAL UNION ALL
                         SELECT 'PRT_ETRM_TM_IN_GRP', '1', '24시간 이내' FROM DUAL UNION ALL
                         SELECT 'PRT_ETRM_TM_IN_GRP', '2', '24~48시간' FROM DUAL UNION ALL
                         SELECT 'PRT_ETRM_TM_IN_GRP', '3', '48~72시간' FROM DUAL UNION ALL
                         SELECT 'PRT_ETRM_TM_IN_GRP', '4', '72시간 초과' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '1', '1군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '2', '2군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '3', '3군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '4', '4군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '5', '5군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '6', '6군' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '10', '10' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '20', '20' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '30', '30' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '40', '40' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '50', '50' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '60', '60' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '70', '70' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '80', '80' FROM DUAL) A
                  ORDER BY A.COMN_GRP_CD
                 )
               , MONTHGUB AS (
                 /* 년간 추이 공통코드 */
                 SELECT TO_CHAR(A.YMD, 'YYYY-MM') AS DTM
                  FROM (
                        SELECT ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) AS YMD
                          FROM DUAL
                       CONNECT BY ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) >= ADD_MONTHS(IN_TO_DT, -11)
                       ) A
                 )
               , BF_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '12', 'YYYYMM'), TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM')) + 1
            
                 )
               , CUR_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYYMM'), 'YYYYMM'), TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , GOWARD_DATA AS (
                 SELECT COUNT(*) AS GOWARD_CNT
                   FROM HICU.UICICSRM A --재입실지표기본
                  WHERE A.HSP_TP_CD              = IN_HIS_HSP_TP_CD
                    AND A.TH1_ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                    AND A.TH1_CHOT_DTM           BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                    AND A.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                 )
               , RE_IN_DATA AS (
                 SELECT
                        A.CIPT_ETRM_CHOT_ID
                      , A.PACT_ID
                      , A.HSP_TP_CD
                      , A.PT_NO
                      , A.PT_NM
                      , A.ADS_DT
                      , A.DS_EXPT_DT
                      , A.SEX_TP_CD
                      , A.AGE
                      , A.ADS_PATH_CD
                      , A.ADS_PATH_NM
                      , A.MED_DEPT_CD
                      , A.MED_DEPT_CD_NM
                      , A.RPRN_MED_DEPT_CD
                      , A.RPRN_MED_DEPT_CD_NM
                      , A.TH1_ETRM_DTM
                      , A.TH1_ETRM_WD_DEPT_CD
                      , A.TH1_ETRM_WD_DEPT_CD_NM
                      , A.TH1_ETRM_PRM_NO
                      , A.TH1_ETRM_BED_NO
                      , A.TH1_EMRG_BED_YN
                      , A.TH1_ISLT_BED_YN
                      , A.TH1_ICU_ETRM_PATH_CLS_CD
                      , A.TH1_ICU_ETRM_PATH_CLS_CD_NM
                      , A.TH1_CHOT_DTM
                      , A.TH1_ICU_CHOT_PLC_TP_CD
                      , A.TH1_ICU_CHOT_PLC_TP_CD_NM
                      , A.TH1_CHOT_WD_MTD_CD
                      , A.TH1_CHOT_WD_MTD_CD_NM
                      , A.TH2_ETRM_DTM
                      , A.TH2_ETRM_WD_DEPT_CD
                      , A.TH2_ETRM_WD_DEPT_CD_NM
                      , A.TH2_ETRM_PRM_NO
                      , A.TH2_ETRM_BED_NO
                      , A.TH2_EMRG_BED_YN
                      , A.TH2_ISLT_BED_YN
                      , A.TH2_ICU_ETRM_PATH_CLS_CD
                      , A.TH2_ICU_ETRM_PATH_CLS_CD_NM
                      , A.TH2_CHOT_DTM
                      , A.TH2_ICU_CHOT_PLC_TP_CD
                      , A.TH2_ICU_CHOT_PLC_TP_CD_NM
                      , A.TH2_CHOT_WD_MTD_CD
                      , A.TH2_CHOT_WD_MTD_CD_NM
                      , A.RPT_ETRM_TM_ITVL_VAL
                      , A.APCS_REC_INPT_DTM
                      , A.APCS_REC_WRT_SEQ
                      , A.APCS_PT_STS_CD
                      , A.APCS_PT_STS_CD_NM
                      , A.APCS_SUM_SCR
                      , B.PT_SILLM_CTG_REC_ID
                      , B.PT_SILLM_CTG_REC_WRT_SEQ
                      , B.PT_SILLM_CTG_DTM
                      , B.PT_SILLM_CTG_TL_ID
                      , B.PT_SILLM_CTG_TL_NM
                      , B.PT_SILLM_CTG_TP_CD
                      , B.PT_SILLM_CTG_TP_CD_NM
                      , B.PT_SILLM_CTG_GRP_CD
                      , B.PT_SILLM_CTG_GRP_CD_NM
                      , B.PT_SILLM_CTG_SCR_SUM
                   FROM (SELECT X.HSP_TP_CD
                              , X.PACT_ID
                              , X.PT_NO
                              , X.CIPT_ETRM_CHOT_ID
                              , X.PT_NM
                              , X.ADS_DT
                              , X.DS_EXPT_DT
                              , X.SEX_TP_CD
                              , X.AGE
                              , X.ADS_PATH_CD
                              , X.ADS_PATH_NM
                              , X.MED_DEPT_CD
                              , X.MED_DEPT_CD_NM
                              , X.RPRN_MED_DEPT_CD
                              , X.RPRN_MED_DEPT_CD_NM
                              , X.TH1_ETRM_DTM
                              , X.TH1_ETRM_WD_DEPT_CD
                              , X.TH1_ETRM_WD_DEPT_CD_NM
                              , X.TH1_ETRM_PRM_NO
                              , X.TH1_ETRM_BED_NO
                              , X.TH1_EMRG_BED_YN
                              , X.TH1_ISLT_BED_YN
                              , X.TH1_ICU_ETRM_PATH_CLS_CD
                              , X.TH1_ICU_ETRM_PATH_CLS_CD_NM
                              , X.TH1_CHOT_DTM
                              , X.TH1_ICU_CHOT_PLC_TP_CD
                              , X.TH1_ICU_CHOT_PLC_TP_CD_NM
                              , X.TH1_CHOT_WD_MTD_CD
                              , X.TH1_CHOT_WD_MTD_CD_NM
                              , X.TH2_ETRM_DTM
                              , X.TH2_ETRM_WD_DEPT_CD
                              , X.TH2_ETRM_WD_DEPT_CD_NM
                              , X.TH2_ETRM_PRM_NO
                              , X.TH2_ETRM_BED_NO
                              , X.TH2_EMRG_BED_YN
                              , X.TH2_ISLT_BED_YN
                              , X.TH2_ICU_ETRM_PATH_CLS_CD
                              , X.TH2_ICU_ETRM_PATH_CLS_CD_NM
                              , X.TH2_CHOT_DTM
                              , X.TH2_ICU_CHOT_PLC_TP_CD
                              , X.TH2_ICU_CHOT_PLC_TP_CD_NM
                              , X.TH2_CHOT_WD_MTD_CD
                              , X.TH2_CHOT_WD_MTD_CD_NM
                              , X.RPT_ETRM_TM_ITVL_VAL
                              , X.APCS_REC_INPT_DTM
                              , X.APCS_REC_WRT_SEQ
                              , X.APCS_PT_STS_CD
                              , X.APCS_PT_STS_CD_NM
                              , X.APCS_SUM_SCR
                           FROM HICU.UICICSRM X --재입실지표기본
                          WHERE X.HSP_TP_CD              = IN_HIS_HSP_TP_CD
                            AND X.TH1_ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                            AND X.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                            AND X.TH1_ETRM_WD_DEPT_CD    = X.TH2_ETRM_WD_DEPT_CD
                            AND X.TH2_ETRM_DTM           BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999) A
                      , (SELECT Y.HSP_TP_CD
                              , Y.PACT_ID
                              , Y.PT_NO
                              , Y.PT_SILLM_CTG_REC_ID
                              , Y.PT_SILLM_CTG_REC_WRT_SEQ
                              , Y.PT_SILLM_CTG_DTM
                              , Y.PT_SILLM_CTG_TL_ID
                              , Y.PT_SILLM_CTG_TL_NM
                              , Y.PT_SILLM_CTG_TP_CD
                              , Y.PT_SILLM_CTG_TP_CD_NM
                              , Y.PT_SILLM_CTG_GRP_CD
                              , Y.PT_SILLM_CTG_GRP_CD_NM
                              , Y.PT_SILLM_CTG_SCR_SUM
                              , DENSE_RANK() OVER (PARTITION BY Y.PT_SILLM_CTG_REC_ID ORDER BY Y.PT_SILLM_CTG_DTM, Y.PT_SILLM_CTG_REC_WRT_SEQ) AS RANK
                           FROM HICU.UICICSRD Y --재입실중증도분류정보
                          WHERE Y.HSP_TP_CD          = IN_HIS_HSP_TP_CD
                            AND Y.PT_SILLM_CTG_TP_CD IN( '2' , '4' ) --2021-12-23 황선영 수정
                            AND Y.PT_SILLM_CTG_DTM   BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT)) B
                  WHERE A.HSP_TP_CD = B.HSP_TP_CD(+)
                    AND A.PACT_ID   = B.PACT_ID(+)
                    AND A.PT_NO     = B.PT_NO(+)
                    AND (B.PT_SILLM_CTG_DTM = (SELECT MIN(Z.PT_SILLM_CTG_DTM)
                                                      FROM HICU.UICICSRD Z
                                                     WHERE Z.HSP_TP_CD          = A.HSP_TP_CD
                                                       AND Z.PACT_ID            = A.PACT_ID
                                                       AND Z.PT_NO              = A.PT_NO
                                                       AND Z.PT_SILLM_CTG_TP_CD IN( '2' , '4' ) --2021-12-23 황선영 수정
                                                       AND Z.PT_SILLM_CTG_DTM   BETWEEN TRUNC(A.TH2_ETRM_DTM) AND TRUNC(A.TH2_CHOT_DTM))  /*재입실기간 내 첫번째 중증도*/
                     OR  B.PT_SILLM_CTG_DTM IS NULL)
                    AND (B.RANK = 1 OR B.RANK IS NULL)
                 )
               , GOWARD_DATA_FOR_ANNU AS (
                 SELECT
                        A.CIPT_ETRM_CHOT_ID
                      , A.TH1_CHOT_DTM
                   FROM HICU.UICICSRM A --재입실지표기본
                  WHERE A.HSP_TP_CD              = IN_HIS_HSP_TP_CD
                    AND A.TH1_ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                    AND A.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                    AND A.TH1_CHOT_DTM           BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '-01-01', 'YYYY-MM-DD') AND TRUNC(LAST_DAY(IN_TO_DT)) + 0.99999
                 )
               , RE_IN_DATA_FOR_ANNU AS (
                 SELECT
                        A.CIPT_ETRM_CHOT_ID
                      , A.TH2_ETRM_DTM
                   FROM HICU.UICICSRM A --재입실지표기본
                  WHERE A.HSP_TP_CD              = IN_HIS_HSP_TP_CD
                    AND A.TH1_ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                    AND A.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                    AND A.TH1_ETRM_WD_DEPT_CD    = A.TH2_ETRM_WD_DEPT_CD
                    AND A.TH2_ETRM_DTM           BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '-01-01', 'YYYY-MM-DD') AND TRUNC(LAST_DAY(IN_TO_DT)) + 0.99999
                 )
            
            
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT 'READM_RATE'     AS COMN_GRP_CD
                 , '01'             AS COMN_CD
                 , '중환자실 재입실 현황'      AS COMN_CD_NM
                 , 'RPT_ETRM_PT_CNT'      AS COMN_CD_EXPL
                 , TO_CHAR(READM_CNT) AS DTRL1_NM --재입실환자수
                 , TO_CHAR(GOWARD_CNT) AS DTRL2_NM --일반병동전동환자수
                 , RTRIM(TO_CHAR(DECODE(GOWARD_CNT, 0, 0, ROUND((READM_CNT / GOWARD_CNT) * 100 , 1)), 'FM9990.9'), '.') AS DTRL3_NM --재입실률
              FROM (SELECT COUNT(*) AS READM_CNT FROM RE_IN_DATA) A
                 , GOWARD_DATA B
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , DECODE(A.COMN_CD, 'F', 'SEX_FEML_CNT', 'SEX_MALE_CNT') AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT SEX_TP_CD AS COMN_CD
                         , COUNT(*)  AS COUNT
                      FROM RE_IN_DATA X
                     GROUP BY X.SEX_TP_CD) B
             WHERE A.COMN_GRP_CD = 'SEX_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '1' THEN 'AGE_10_GRP_BLW_CNT'
                        WHEN A.COMN_CD = '2' THEN 'AGE_20_GRP_CNT'
                        WHEN A.COMN_CD = '3' THEN 'AGE_30_GRP_CNT'
                        WHEN A.COMN_CD = '4' THEN 'AGE_40_GRP_CNT'
                        WHEN A.COMN_CD = '5' THEN 'AGE_50_GRP_CNT'
                        WHEN A.COMN_CD = '6' THEN 'AGE_60_GRP_CNT'
                        ELSE 'AGE_70_GRP_UPR_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN AGE < 20 THEN '1'
                                WHEN AGE < 30 THEN '2'
                                WHEN AGE < 40 THEN '3'
                                WHEN AGE < 50 THEN '4'
                                WHEN AGE < 60 THEN '5'
                                WHEN AGE < 70 THEN '6'
                                ELSE '7' END             AS COMN_CD
                              , COUNT(*)                 AS COUNT
                       FROM RE_IN_DATA
                      GROUP BY CASE WHEN AGE < 20 THEN '1'
                                    WHEN AGE < 30 THEN '2'
                                    WHEN AGE < 40 THEN '3'
                                    WHEN AGE < 50 THEN '4'
                                    WHEN AGE < 60 THEN '5'
                                    WHEN AGE < 70 THEN '6'
                                    ELSE '7' END) B
             WHERE A.COMN_GRP_CD = 'AGE_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '1' THEN 'PT_SILLM_CTG_1_GRP_CNT'
                        WHEN A.COMN_CD = '2' THEN 'PT_SILLM_CTG_2_GRP_CNT'
                        WHEN A.COMN_CD = '3' THEN 'PT_SILLM_CTG_3_GRP_CNT'
                        WHEN A.COMN_CD = '4' THEN 'PT_SILLM_CTG_4_GRP_CNT'
                        WHEN A.COMN_CD = '5' THEN 'PT_SILLM_CTG_5_GRP_CNT'
                        ELSE 'PT_SILLM_CTG_6_GRP_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN PT_SILLM_CTG_GRP_CD IS NULL THEN '-1'
                                WHEN PT_SILLM_CTG_GRP_CD = '1' THEN '1'
                                WHEN PT_SILLM_CTG_GRP_CD = '2' THEN '2'
                                WHEN PT_SILLM_CTG_GRP_CD = '3' THEN '3'
                                WHEN PT_SILLM_CTG_GRP_CD = '4' THEN '4'
                                WHEN PT_SILLM_CTG_GRP_CD = '5' THEN '5'
                                ELSE '6' END             AS COMN_CD
                              , COUNT(*)                 AS COUNT
                       FROM RE_IN_DATA
                      GROUP BY CASE WHEN PT_SILLM_CTG_GRP_CD IS NULL THEN '-1'
                                    WHEN PT_SILLM_CTG_GRP_CD = '1' THEN '1'
                                    WHEN PT_SILLM_CTG_GRP_CD = '2' THEN '2'
                                    WHEN PT_SILLM_CTG_GRP_CD = '3' THEN '3'
                                    WHEN PT_SILLM_CTG_GRP_CD = '4' THEN '4'
                                    WHEN PT_SILLM_CTG_GRP_CD = '5' THEN '5'
                                    ELSE '6' END ) B
             WHERE A.COMN_GRP_CD = 'PT_SILLM_CTG_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '10' THEN 'APCS_SUM_10_SCR_BLW_CNT'
                        WHEN A.COMN_CD = '20' THEN 'APCS_SUM_20_SCR_CNT'
                        WHEN A.COMN_CD = '30' THEN 'APCS_SUM_30_SCR_CNT'
                        WHEN A.COMN_CD = '40' THEN 'APCS_SUM_40_SCR_CNT'
                        WHEN A.COMN_CD = '50' THEN 'APCS_SUM_50_SCR_CNT'
                        WHEN A.COMN_CD = '60' THEN 'APCS_SUM_60_SCR_CNT'
                        WHEN A.COMN_CD = '70' THEN 'APCS_SUM_70_SCR_CNT'
                        ELSE 'APCS_SUM_80_SCR_UPR_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN APCS_SUM_SCR IS NULL THEN '-1'
                                WHEN APCS_SUM_SCR < 20 THEN '10'
                                WHEN APCS_SUM_SCR < 30 THEN '20'
                                WHEN APCS_SUM_SCR < 40 THEN '30'
                                WHEN APCS_SUM_SCR < 50 THEN '40'
                                WHEN APCS_SUM_SCR < 60 THEN '50'
                                WHEN APCS_SUM_SCR < 70 THEN '60'
                                WHEN APCS_SUM_SCR < 80 THEN '70'
                                ELSE '80' END             AS COMN_CD
                              , COUNT(*)                  AS COUNT
                       FROM (SELECT APCS_SUM_SCR
                               FROM RE_IN_DATA
                              WHERE APCS_SUM_SCR IS NOT NULL)
                       GROUP BY CASE WHEN APCS_SUM_SCR IS NULL THEN '-1'
                                     WHEN APCS_SUM_SCR < 20 THEN '10'
                                     WHEN APCS_SUM_SCR < 30 THEN '20'
                                     WHEN APCS_SUM_SCR < 40 THEN '30'
                                     WHEN APCS_SUM_SCR < 50 THEN '40'
                                     WHEN APCS_SUM_SCR < 60 THEN '50'
                                     WHEN APCS_SUM_SCR < 70 THEN '60'
                                     WHEN APCS_SUM_SCR < 80 THEN '70'
                                     ELSE '80' END ) B
             WHERE A.COMN_GRP_CD = 'APCS_SUM_SCR_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '1' THEN 'RPT_ETRM_24_TM_IN_CNT'
                        WHEN A.COMN_CD = '2' THEN 'RPT_ETRM_48_TM_IN_CNT'
                        WHEN A.COMN_CD = '3' THEN 'RPT_ETRM_72_TM_IN_CNT'
                        ELSE 'RPT_ETRM_72_TM_EXCS_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN RPT_ETRM_TM_ITVL_VAL <= 24 THEN '1'
                                WHEN RPT_ETRM_TM_ITVL_VAL <= 48 THEN '2'
                                WHEN RPT_ETRM_TM_ITVL_VAL <= 72 THEN '3'
                                ELSE '4' END              AS COMN_CD
                              , COUNT(*)                  AS COUNT
                      FROM RE_IN_DATA
                     GROUP BY CASE WHEN RPT_ETRM_TM_ITVL_VAL <= 24 THEN '1'
                                   WHEN RPT_ETRM_TM_ITVL_VAL <= 48 THEN '2'
                                   WHEN RPT_ETRM_TM_ITVL_VAL <= 72 THEN '3'
                                   ELSE '4' END ) B
             WHERE A.COMN_GRP_CD = 'PRT_ETRM_TM_IN_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT 'BY_DEPT'                   AS COMN_GRP_CD
                 , A.RPRN_MED_DEPT_CD          AS COMN_CD
                 , A.RPRN_MED_DEPT_CD_NM       AS COMN_CD_NM
                 , '진료과별 재입실환자'               AS COMN_CD_EXPL
                 , TO_CHAR(COUNT(*))           AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM RE_IN_DATA A
             GROUP BY A.RPRN_MED_DEPT_CD, A.RPRN_MED_DEPT_CD_NM
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'BF_YEAR'  AS COMN_CD
                 , '전년월평균'   AS COMN_CD_NM
                 , '재입실환자/재입실률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(NVL(CEIL(SUM(READM_CNT) / COUNT(*)), 0))  AS DTRL1_NM
                 , TO_CHAR(NVL(CEIL(SUM(GOWARD_CNT) / COUNT(*)), 0)) AS DTRL2_NM
                 , TO_CHAR(NVL(ROUND(SUM(READM_RATE) / COUNT(*), 2), 0)) AS DTRL3_NM
              FROM (SELECT A.DTM AS DTM
                         , NVL(A.GOWARD_CNT, 0) AS GOWARD_CNT
                         , NVL(B.READM_CNT, 0)  AS READM_CNT
                         , DECODE(NVL(A.GOWARD_CNT, 0), 0, 0, ROUND((NVL(B.READM_CNT, 0) / A.GOWARD_CNT) * 100, 2)) AS READM_RATE
                      FROM (SELECT X.DTM    AS DTM
                                 , COUNT(*) AS GOWARD_CNT
                              FROM BF_YEAR X
                                 , GOWARD_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH1_CHOT_DTM, 'YYYY-MM')
                             GROUP BY X.DTM) A
                         , (SELECT X.DTM    AS DTM
                                 , COUNT(*) AS READM_CNT
                              FROM BF_YEAR X
                                 , RE_IN_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH2_ETRM_DTM, 'YYYY-MM')
                             GROUP BY X.DTM) B
             WHERE A.DTM = B.DTM(+))
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'CUR_YEAR'  AS COMN_CD
                 , '당년월평균'   AS COMN_CD_NM
                 , '재입실환자/재입실률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(NVL(CEIL(SUM(READM_CNT) / COUNT(*)), 0))  AS DTRL1_NM
                 , TO_CHAR(NVL(CEIL(SUM(GOWARD_CNT) / COUNT(*)), 0)) AS DTRL2_NM
                 , TO_CHAR(NVL(ROUND(SUM(READM_RATE) / COUNT(*), 2), 0)) AS DTRL3_NM
              FROM (SELECT A.DTM AS DTM
                         , NVL(A.GOWARD_CNT, 0) AS GOWARD_CNT
                         , NVL(B.READM_CNT, 0)  AS READM_CNT
                         , DECODE(NVL(A.GOWARD_CNT, 0), 0, 0, ROUND((NVL(B.READM_CNT, 0) / A.GOWARD_CNT) * 100, 2)) AS READM_RATE
                      FROM (SELECT X.DTM    AS DTM
                                 , COUNT(*) AS GOWARD_CNT
                              FROM CUR_YEAR X
                                 , GOWARD_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH1_CHOT_DTM, 'YYYY-MM')
                             GROUP BY X.DTM) A
                         , (SELECT X.DTM    AS DTM
                                 , COUNT(*) AS READM_CNT
                              FROM CUR_YEAR X
                                 , RE_IN_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH2_ETRM_DTM, 'YYYY-MM')
                             GROUP BY X.DTM) B
             WHERE A.DTM = B.DTM(+))
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'BF_MON' AS COMN_CD
                 , '전년당월' AS COMN_CD_NM
                 , '재입실환자/재입실률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(READM_CNT) AS DTRL1_NM
                 , TO_CHAR(GOWARD_CNT) AS DTRL2_NM
                 , TO_CHAR(DECODE(GOWARD_CNT, 0, 0, ROUND((READM_CNT / GOWARD_CNT) * 100, 2))) AS DTRL3_NM
              FROM (
                    SELECT NVL(A.CNT, 0) AS READM_CNT
                         , NVL(B.CNT, 0) AS GOWARD_CNT
                      FROM (
                            SELECT COUNT(*) AS CNT
                              FROM RE_IN_DATA_FOR_ANNU X
                             WHERE TO_CHAR(X.TH2_ETRM_DTM, 'YYYY-MM') = TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM')
                           ) A
                         , (
                            SELECT COUNT(*) AS CNT
                              FROM GOWARD_DATA_FOR_ANNU X
                             WHERE TO_CHAR(X.TH1_CHOT_DTM, 'YYYY-MM') = TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM')
                           ) B
                   )
            
            UNION ALL
            
            SELECT 'ANNU_TREND' AS COMN_GRP_CD
                 , DTM AS COMN_CD
                 , DTM AS COMN_CD_NM
                 , '재입실환자/재입실률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(READM_CNT) AS DTRL1_NM
                 , TO_CHAR(GOWARD_CNT) DTRL2_NM
                 , TO_CHAR(DECODE(GOWARD_CNT, 0, 0, ROUND((READM_CNT / GOWARD_CNT) * 100, 2))) AS DTRL3_NM
              FROM (
                    SELECT A.DTM
                         , NVL(SUM(B.CNT), 0) AS READM_CNT
                         , NVL(SUM(C.CNT), 0) AS GOWARD_CNT
                      FROM MONTHGUB A
                         , (
                            SELECT X.DTM    AS DTM
                                 , COUNT(*) AS CNT
                              FROM MONTHGUB X --년간추이공통코드
                                 , RE_IN_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH2_ETRM_DTM, 'YYYY-MM')
                             GROUP BY X.DTM
                           ) B
                         , (
                            SELECT X.DTM    AS DTM
                                 , COUNT(*) AS CNT
                              FROM MONTHGUB X --년간추이공통코드
                                 , GOWARD_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.TH1_CHOT_DTM, 'YYYY-MM')
                             GROUP BY X.DTM
                           ) C
                     WHERE A.DTM = B.DTM(+)
                       AND A.DTM = C.DTM(+)
                     GROUP BY A.DTM
                     ORDER BY A.DTM
                   )
            
             ORDER BY COMN_GRP_CD, COMN_CD
        ;    
    END;
END PC_EICU_STATISTIC_READMISSION;
