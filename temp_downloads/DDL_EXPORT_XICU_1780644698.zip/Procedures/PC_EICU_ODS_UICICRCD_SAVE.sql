
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRCD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTE       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRCD_SAVE                                               
*    CREATEDATE     : 2021.03.22
*    Author         : 오지민                                                                     
*    Description    : ODS_UICICRCD(진료기록사망진단서정보)데이터 적재
*    Change History : 2021.03.22                                               
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    BEGIN        
        MERGE INTO HICU.UICICRCD A  --진료기록법정전염병정보
             USING (SELECT MDRC_ID
                         , MDRC_FOM_SEQ
                         , IN_HSP_TP_CD                  HSP_TP_CD
                         , PT_NO
                         , LST_YN
                         , REC_DTM
                         , MDF_REC_DTM                 
                         , WRT_STF_NO
                         , MDFM_CLS_DTL_CD
                         , MDFM_CLS_DTL_CD_NM
                         , MDRC_WRT_STS_CD
                         , MDRC_WRT_STS_CD_NM
                         , MDRC_DC_TP_CD
                         , MDRC_DC_TP_CD_NM
                         , FST_WRT_DTM
                         , LST_CHG_DTM
                         , FST_LOD_DTM
                         , LST_LOD_DTM
                      FROM XICU.EMEI009V
                     WHERE LST_CHG_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE 
                   ) B
                ON (    A.MDRC_ID        = B.MDRC_ID
                    AND A.MDRC_FOM_SEQ   = B.MDRC_FOM_SEQ
                    AND A.HSP_TP_CD      = B.HSP_TP_CD
                    AND A.PT_NO          = B.PT_NO
                   )
              WHEN MATCHED THEN
                   UPDATE SET A.LST_YN              = B.LST_YN
                            , A.REC_DTM             = B.MDF_REC_DTM
                            , A.MDF_REC_DTM         = B.MDF_REC_DTM
                            , A.WRT_STF_NO          = B.WRT_STF_NO
                            , A.MDFM_CLS_DTL_CD     = B.MDFM_CLS_DTL_CD
                            , A.MDFM_CLS_DTL_CD_NM  = B.MDFM_CLS_DTL_CD_NM
                            , A.MDRC_WRT_STS_CD     = B.MDRC_WRT_STS_CD
                            , A.MDRC_WRT_STS_CD_NM  = B.MDRC_WRT_STS_CD_NM
                            , A.MDRC_DC_TP_CD       = B.MDRC_DC_TP_CD
                            , A.MDRC_DC_TP_CD_NM    = B.MDRC_DC_TP_CD_NM
                            , A.FST_WRT_DTM         = B.FST_WRT_DTM
                            , A.LST_CHG_DTM         = B.LST_CHG_DTM
                            , A.LST_LOD_DTM         = SYSDATE
                            --, A.PT_NO               = B.PT_NO
               WHEN NOT MATCHED THEN
                   INSERT ( A.MDRC_ID
                          , A.MDRC_FOM_SEQ
                          , A.HSP_TP_CD
                          , A.PT_NO
                          , A.LST_YN
                          , A.REC_DTM
                          , A.MDF_REC_DTM
                          , A.WRT_STF_NO
                          , A.MDFM_CLS_DTL_CD
                          , A.MDFM_CLS_DTL_CD_NM
                          , A.MDRC_WRT_STS_CD
                          , A.MDRC_WRT_STS_CD_NM
                          , A.MDRC_DC_TP_CD
                          , A.MDRC_DC_TP_CD_NM   
                          , A.FST_WRT_DTM
                          , A.LST_CHG_DTM
                          , A.FST_LOD_DTM
                          , A.LST_LOD_DTM
                          )
                   VALUES ( B.MDRC_ID
                          , B.MDRC_FOM_SEQ
                          , B.HSP_TP_CD
                          , B.PT_NO
                          , B.LST_YN
                          , B.REC_DTM
                          , B.MDF_REC_DTM
                          , B.WRT_STF_NO
                          , B.MDFM_CLS_DTL_CD
                          , B.MDFM_CLS_DTL_CD_NM
                          , B.MDRC_WRT_STS_CD
                          , B.MDRC_WRT_STS_CD_NM
                          , B.MDRC_DC_TP_CD
                          , B.MDRC_DC_TP_CD_NM     
                          , B.FST_WRT_DTM
                          , B.LST_CHG_DTM
                          , SYSDATE
                          , SYSDATE
                          )
        ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRCD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICRCD_SAVE;
