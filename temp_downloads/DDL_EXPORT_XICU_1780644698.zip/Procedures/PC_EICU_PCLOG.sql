
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_PCLOG" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2
                            , IN_LOG_TP IN VARCHAR2
                            , IN_LOG_CNTE IN VARCHAR2)
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_PCLOG
*    CREATEDATE     : 2021.03.03
*    Author         : 이창우
*    Description    : 프로시저 실행중 사용자 로그
*    Change History : 2021.03.03, 이창우, 최초작성
**********************************************************************************************/
BEGIN
   BEGIN
      INSERT INTO HICU.UCCOBELH 
                ( SCHD_EXCT_ID
                , LOG_SEQ
                , LOG_TP
                , LOG_CNTE
                , REG_DTM)
           SELECT IN_SCHD_EXCT_ID
                , NVL(MAX(LOG_SEQ), 0) + 1
                , IN_LOG_TP
                , IN_LOG_CNTE
                , SYSDATE 
             FROM HICU.UCCOBELH
            WHERE SCHD_EXCT_ID = IN_SCHD_EXCT_ID;
   END;
END PC_EICU_PCLOG;
