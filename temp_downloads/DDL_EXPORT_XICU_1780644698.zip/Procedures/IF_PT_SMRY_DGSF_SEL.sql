
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_SMRY_DGSF_SEL" (  
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NM,
        S.ORDER_DTM,
        S.ATC_CODE_NM,
        S.DRUG_NM,
        S.DRUG_UNIT,
        S.DOSE_PER_TIME,
        S.DOSE_FREQ,
        S.DOSE_DAYS,
        S.DOSING_METHOD
    FROM PT_SMRY_DGSF_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.ORDER_DTM >= (
        SELECT MAX(ORDER_DTM)
        FROM PT_SMRY_DGSF_SEL
        ) - 3
      AND A.SEQ = IN_SEQ
 ORDER BY ORDER_DTM DESC;
END;
