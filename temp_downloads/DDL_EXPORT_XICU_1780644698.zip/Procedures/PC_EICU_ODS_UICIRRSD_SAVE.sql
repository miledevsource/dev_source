
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICIRRSD_SAVE" (  IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                                         , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                         , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                                         , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                                         , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                                         , IO_ERRMSG       IN OUT  VARCHAR2)   -- 05. ERROR MESSAGE 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICIRRSD_SAVE                                               
*    CREATEDATE     : 2021.04.02
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_RRS
*    Change History : 2021.04.02                                              
**********************************************************************************************/
 AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    /*******************************************************************************************************************
    * DELETE : HICU.UICIRRSD A  --U121_UICI(ODS)_RRS
    * FROM : HICU.RRS_VALUE
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICIRRSD A  --U121_UICI(ODS)_RRS
          WHERE EXISTS ( SELECT 1
                           FROM (SELECT A.HSP_TP_CD
                                      , B.DETL_CD
                        			  , A.PT_NO
                        			  , A.ENT_DTM
                        			  , A.REG_DTM
                        		   FROM HICU.RRS_VALUE  A
                        		      , HICU.RRS_DETAIL B
                        	      WHERE A.RRS_ITEM_CD    = B.DETL_CD_1
                                    AND A.HSP_TP_CD      = B.HSP_TP_CD
                        	        AND B.MSTR_CD        = 'VITAL'
                                    AND A.HSP_TP_CD      = IN_HSP_TP_CD
                        	        AND B.HSP_TP_CD      = IN_HSP_TP_CD
                        	  ) B
                          WHERE A.PT_NO           = B.PT_NO
                            AND A.INPT_DTM        = B.ENT_DTM
                            AND A.ITEM_ID         = B.DETL_CD
                            AND B.REG_DTM   BETWEEN IN_FROM_DTM 
                                                AND IN_TO_DTM
                      ); 
      END;
    /*******************************************
    * _환자중증도분류기록정보(UICICRSD) BATCH 
    *******************************************/
    BEGIN        
        MERGE INTO HICU.UICIRRSD A  --U121_UICI(ODS)_RRS
                 USING (
                            SELECT A.PT_NO				--환자번호
                                 , A.ENT_DT				--등록일자 
                                 , A.RRS_ITEM_CD			--RRS 항목코드
                                 , C.DETL_CD 
                                 , C.DETL_CD_NM
                                 , A.HSP_TP_CD				--병원구분코드
                                 , A.PACT_ID				--진료접수번호
                                 , A.PT_NM					--환자명
                                 , A.PT_SEX				--성병
                                 , A.PT_AGE				--나이
                                 , A.HD					--입원일
                                 , A.POD					--수술 후 경과일
                                 , A.DEPT_CD				--진료과코드
                                 , A.DEPT_NM				--진료과명
                                 , A.DOC_NO				--담당의사번
                                 , A.DOC_NM				--담당의명
                                 , A.DIAGNOSIS				--주진단명
                                 , A.WARD_NO				--병동 
                                 , X.WD_DEPT_CD_NM
                                 , A.ROOM_NO				--Room
                                 , A.BED_NO				--Bed
                                 , A.CFRM_DTM				--확인일시
                                 , A.CFRM_ID				--확인자ID
                                 , A.RRS_VALUE				--최초결과
                                 , A.CUR_VALUE				--현재결과
                                 , A.ENT_DTM				--입력일시
                                 , A.RRS_STATE_CD			--RRS상태 
                                 , S.DETL_CD_NM         AS RRS_STATE_NM
                                 , A.NEWS_SCORE			--총NEWS값
                                 , A.ITEM_NEWS_SCORE		--항목별 NEWS값
                                 , A.REG_DTM				--등록일시
                                 , A.REG_ID				--등록자ID
                                 , A.REG_IP				--등록자IP
                              FROM HICU.RRS_VALUE A
                                 , (SELECT HSP_TP_CD
                                         , DETL_CD
                                         , DETL_CD_NM
                            			 , DETL_CD_1
                            		  FROM HICU.RRS_DETAIL
                            	     WHERE MSTR_CD   = 'VITAL'
                            	       AND HSP_TP_CD = IN_HSP_TP_CD) C
                                 , (SELECT HSP_TP_CD
                                         , DETL_CD_NM
                            			 , DETL_CD
                            		  FROM HICU.RRS_DETAIL
                            		 WHERE MSTR_CD = 'STAT_CD'
                            		   AND HSP_TP_CD = IN_HSP_TP_CD) S
                                 , (SELECT DEPT_CD        AS WD_DEPT_CD
                                         , RMK_CNTE       AS WD_DEPT_CD_NM
                                      FROM HICU.UCCOCDPM X   --U111_UCCO(설정)_부서기본
                                     WHERE HSP_TP_CD        = IN_HSP_TP_CD) X
                            WHERE A.ENT_DT         BETWEEN TO_CHAR(IN_FROM_DTM, 'YYYYMMDD')
                                                       AND TO_CHAR(IN_TO_DTM, 'YYYYMMDD') 
                              AND A.HSP_TP_CD            = IN_HSP_TP_CD
                              AND A.RRS_ITEM_CD          = C.DETL_CD_1
                              AND A.HSP_TP_CD            = C.HSP_TP_CD
                              AND A.HSP_TP_CD            = S.HSP_TP_CD
                              AND A.RRS_STATE_CD         = S.DETL_CD
                              AND A.WARD_NO              = X.WD_DEPT_CD
                       ) B
                   ON (     
                            A.PT_NO             = B.PT_NO
                        AND A.INPT_DTM          = B.ENT_DTM  
                        AND A.ITEM_ID           = B.DETL_CD--B.RRS_ITEM_CD
                        --AND A.HSP_TP_CD         = B.HSP_TP_CD
                       )
                       
                 --최종 적재
                 WHEN MATCHED THEN
                        UPDATE SET
                                      A.PT_NM						= B.PT_NM--환자명
                                    , A.INPT_DT						= B.ENT_DT--입력일자
                                    , A.ITEM_NM						= B.DETL_CD_NM--항목이름
                                    , A.FST_FGR						= B.RRS_VALUE--최초수치 
                                    , A.CUR_FGR						= B.CUR_VALUE--현재수치
                                    , A.SEX					        = B.PT_SEX--성별
                                    , A.AGE					        = B.PT_AGE--나이
                                    , A.PT_MED_DEPT_CD				= B.DEPT_CD--환자진료부서코드
                                    , A.PT_MED_DEPT_NM				= B.DEPT_NM--환자진료부서명
                                    , A.OCUR_DEPT_CD				= B.WARD_NO--환자위치코드
                                    , A.OCUR_DEPT_CD_NM				= B.WD_DEPT_CD_NM--환자위치명
                                    , A.MGMT_STS_CD					= B.RRS_STATE_CD--관리상태코드
                                    , A.MGMT_STS_CD_NM				= B.RRS_STATE_NM--관리상태명
                                    , A.FST_LOD_DTM					= B.REG_DTM--최초적재일시
                                    , A.LST_LOD_DTM					= SYSDATE--최종적재일시
                
                --최초 적재    
                WHEN NOT MATCHED THEN
                               INSERT (
                                              A.PT_NO				--환자번호
                                            , A.PT_NM				--환자명
                                            , A.INPT_DTM			--입력일시
                                            , A.INPT_DT				--입력일자
                                            , A.ITEM_ID				--항목ID
                                            , A.ITEM_NM				--항목이름
                                            , A.FST_FGR				--최초수치
                                            , A.CUR_FGR				--현재수치
                                            , A.SEX					--성별
                                            , A.AGE					--나이
                                            , A.PT_MED_DEPT_CD		--환자진료부서코드
                                            , A.PT_MED_DEPT_NM		--환자진료부서명
                                            , A.OCUR_DEPT_CD		--환자위치코드
                                            , A.OCUR_DEPT_CD_NM		--환자위치명
                                            , A.MGMT_STS_CD			--관리상태코드
                                            , A.MGMT_STS_CD_NM		--관리상태명
                                            , A.FST_LOD_DTM			--최초적재일시
                                            , A.LST_LOD_DTM			--최종적재일시
                                     )
                               VALUES ( 
                                          B.PT_NO
                                        , B.PT_NM
                                        , B.ENT_DTM
                                        , B.ENT_DT
                                        , B.DETL_CD--B.RRS_ITEM_CD
                                        , B.DETL_CD_NM
                                        , B.RRS_VALUE
                                        , B.CUR_VALUE
                                        , B.PT_SEX
                                        , B.PT_AGE
                                        , B.DEPT_CD
                                        , B.DEPT_NM
                                        , B.WARD_NO
                                        , B.WD_DEPT_CD_NM
                                        , B.RRS_STATE_CD
                                        , B.RRS_STATE_NM
                                        , SYSDATE                              --최초적재일시
                                        , SYSDATE                              --최종적재일시
                                      );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICIRRSD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICIRRSD_SAVE;
