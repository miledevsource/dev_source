
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_SMRY_INFO_SEL" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_HSP_TP_CD  IN  VARCHAR2      -- 병원구분코드  
																							   , IN_SEQ  			   IN  NUMBER      -- 순번 
																							   , IN_PT_NO      IN  VARCHAR2      -- 환자번호
																							   , IN_PACT_ID  	IN  VARCHAR2     -- 접수번호
 
                          , OUT_CURSOR    OUT SYS_REFCURSOR  -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
            SELECT A.HSP_TP_CD
             , A.PT_NO
             , A.PACT_ID
             , T.HSP_NM
             , T.PT_NM
             , T.PT_BIRTH
             , T.PT_AGE
             , T.PT_BLOOD_TYPE
             , T.SEX_TP_CD
             , T.DEPT_CD
             , T.DEPT_NM
             , T.WARD_CD
             , T.WARD_NM
             , T.ROOM_NO
             , T.BED_NO
             , T.CUR_WARD_CD
             , T.CUR_WARD_NM
             , T.CUR_ROOM_NO
             , T.CUR_BED_NO
             , T.CSFM_WRT_YN
             , T.PAST_HISTORY
             , T.PT_HEIGHT
             , T.PT_WEIGHT
             , T.PT_WAIST_CIRC
             , T.DGNS_NM
             , T.MAIN_SYMPTOM
             , T.VISIT_REASON
             , T.INFECTIOUS_DISEASE
             , T.RECENT_SURGERY_YN
             , T.SURGERY_NM
             , T.SURGERY_DT
             , T.POST_SURGERY_DGNS_NM
             , T.POST_SURGERY_COMPLICATION
             , T.OXYGEN_NEED_YN
             , T.OXYGEN_FLOW_RATE
             , T.OXYGEN_DELIVERY_METHOD
             , T.SPO2
             , T.SPECIAL_NOTE
             , T.MEDICAL_DEVICE_YN
             , T.MEDICAL_DEVICE_NM
             , T.CENTRAL_LINE
             , T.IV_LINE
             , T.OTHER_LINE_DESC
             , T.BEDSORES_YN
             , T.BEDSORES_LOCATION
             , T.BEDSORES_STAGE
             , T.MOTOR_POWER_GRADE_R_L
        FROM XICU.PT_SMRY_INFO_TEST T
             , ARPA_PT_LIST A
        WHERE A.HSP_TP_CD = IN_HSP_TP_CD
          AND A.PT_NO     = IN_PT_NO
          AND A.PACT_ID 	= IN_PACT_ID
          AND A.SEQ = IN_SEQ ;
END IF_PT_SMRY_INFO_SEL;
