
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_ODS_LAUNCHER" 
                          ( IN_SCHD_NAME IN VARCHAR2 /*스케쥴이름*/
                          , IN_HSP_TP_CD IN VARCHAR2 /*병원구분코드*/
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_ODS_LAUNCHER
*    CREATEDATE     : 2021.01.01
*    Author         : 이창우
*    Description    : 배치 실행
*    Change History : 2021.01.01, 이창우, 최초작성
**********************************************************************************************/
BEGIN
   DECLARE 
      V_SCHD_EXCT_ID VARCHAR2(22);
      V_WK_STR_DTM   DATE := SYSDATE;
      V_WK_STS_TP    VARCHAR2(1) := NULL;
      V_PRMR_STR_DTM DATE;
      V_PRMR_END_DTM DATE := SYSDATE;
      V_IO_ERRYN     VARCHAR2(10);
      V_IO_ERRMSG    VARCHAR2(4000);
   BEGIN
      SELECT (TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI')|| dbms_random.string('U', 10)) AS SCHEDULE_EXEC_ID 
        INTO V_SCHD_EXCT_ID
        FROM DUAL;

      SELECT NVL(MAX(M1.SCHD_WK_STS_TP), 'F')
        INTO V_WK_STS_TP 
        FROM HICU.UCCOBELM M1
       WHERE M1.SCHD_NM = IN_SCHD_NAME
         AND M1.SCHD_WK_STR_DTM = (SELECT MAX(S1.SCHD_WK_STR_DTM)
                                     FROM HICU.UCCOBELM S1
                                    WHERE S1.SCHD_NM = M1.SCHD_NM
                                  );

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'ODS MAKE-SCHD_EXCT_ID', V_WK_STS_TP);

      IF V_WK_STS_TP = 'N' THEN
         RETURN;
      END IF;

      SELECT NVL(MAX(PRMR_END_DTM), SYSDATE - (5/(24*60)))
        INTO V_PRMR_STR_DTM
        FROM HICU.UCCOBELM
       WHERE SCHD_NM = IN_SCHD_NAME
         AND SCHD_WK_STS_TP = 'Y';

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'ODS EXECUTE-BEFORE', V_PRMR_STR_DTM);
      
      INSERT INTO HICU.UCCOBELM 
                ( SCHD_EXCT_ID
                , SCHD_NM
                , SCHD_WK_STR_DTM
                , SCHD_WK_END_DTM
                , SCHD_WK_STS_TP 
                , PRMR_STR_DTM 
                , PRMR_END_DTM
                )
         VALUES ( V_SCHD_EXCT_ID
                , IN_SCHD_NAME
                , V_WK_STR_DTM
                , NULL
                , 'N'
                , V_PRMR_STR_DTM
                , V_PRMR_END_DTM
                );
      COMMIT;
----------------------------------------------------
--실행 Procedure 시작
-- 전달 기본 파라미터 
-- V_PRMR_STR_DTM : 조회 시작 시간
-- V_PRMR_END_DTM   : 조회 종료 시간
----------------------------------------------------
   XICU.PC_EICU_BATCH_WDDEPT(V_SCHD_EXCT_ID, IN_HSP_TP_CD);

   --중환자기본     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRPM_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRPM_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRPM_SAVE', V_IO_ERRMSG);
   END IF;

   --중환자실입실퇴실시간정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRID_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRID_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRID_SAVE', V_IO_ERRMSG);
   END IF;

   --아파치스코어기록정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRAD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRAD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRAD_SAVE', V_IO_ERRMSG);
   END IF;

   --혈관조영시술일정정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICROD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICROD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICROD_SAVE', V_IO_ERRMSG);
   END IF;

   --격리병동환자기본     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICIIRPD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRPD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRPD_SAVE', V_IO_ERRMSG);
   END IF;

   --진료기록사망진단서정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRCD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRCD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRCD_SAVE', V_IO_ERRMSG);
   END IF;

   --진료분석사망정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRDD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRDD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRDD_SAVE', V_IO_ERRMSG);
   END IF;

   --환자중증도분류기록정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICICRSD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRSD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICICRSD_SAVE', V_IO_ERRMSG);
   END IF;

   --격리병동입실퇴실시간정보     -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICIIRID_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRID_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRID_SAVE', V_IO_ERRMSG);
   END IF;           
   
   --타과의뢰회신정보            -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICIIRCD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRCD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRCD_SAVE', V_IO_ERRMSG);
   END IF;    
   
   --법정감염병정보              -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICIIRED_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRED_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIIRED_SAVE', V_IO_ERRMSG);
   END IF;

   --RRS              -- 01.배치 실행 ID    -- 02.병원구분코드  -- 03.조회시작일자  -- 04.조회종료일자      -- 05. ERROR Y/N     -- 06. ERROR MESSAGE
   XICU.PC_EICU_ODS_UICIRRSD_SAVE( V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIRRSD_SAVE', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_ODS_UICIRRSD_SAVE', V_IO_ERRMSG);
   END IF;     
   
   --휴일정보             -- 01.병원구분코드  -- 02.조회시작일자  -- 03.조회종료일자      -- 04. ERROR Y/N     -- 05. ERROR MESSAGE
   XICU.PC_EICU_LD_UICIIRHD_BATCH(IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM, V_IO_ERRYN, V_IO_ERRMSG) ;
   XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_LD_UICIIRHD_BATCH', V_IO_ERRYN);
   IF V_IO_ERRYN = 'Y' THEN
      XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'PC_EICU_LD_UICIIRHD_BATCH', V_IO_ERRMSG);
   END IF;  
   
          
----------------------------------------------------
--실행 Procedure 종료
----------------------------------------------------
      UPDATE HICU.UCCOBELM 
         SET SCHD_WK_STS_TP    = 'Y'
           , SCHD_WK_END_DTM   = SYSDATE
       WHERE SCHD_NM    = IN_SCHD_NAME
         AND SCHD_EXCT_ID = V_SCHD_EXCT_ID;

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'ODS EXCUTE-FINISH', 'END');

      COMMIT;
   END;
END PC_EICU_BATCH_ODS_LAUNCHER;
