
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_CSLT_HSP_SEL" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2       -- 병원구분코드
																							   , OUT_CURSOR          OUT SYS_REFCURSOR   -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
          SELECT CDDES1 AS TARGET_HSP_CD
									     , IF_FN_CODE_SEL('TARGET_HSP_CD',CDDES1)  AS TARGET_HSP_NM
									     , CDBS   AS TARGET_DEPT_CD
									     , CDNM   AS TARGET_DEPT_NM
				      FROM ARPA_CD_LIST
								 WHERE COMKDCD = 'TARGET_DEPT_CD'
								   AND (CDDES1  = IF_FN_CODE_SEL('HSP_TP_CD',IN_HSP_TP_CD,'CDDES1') OR (CDDES1 = IF_FN_CODE_SEL('TARGET_HSP_CD',IN_HSP_TP_CD,'CDDES1')))
								   AND USE_YN  = 'Y'

								;

END IF_CSLT_HSP_SEL;
