
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_PT_STATISTICS" 
                                                    (   
                                                        IN_FROM_DTM         IN DATE 
                                                      , IN_TO_DTM           IN DATE 
                                                      , IN_WD_DEPT_CD       IN VARCHAR2   
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_PT_STATISTICS
*    CREATEDATE     : 2021.02.25
*    Author         : 한가혜
*    Description    : 통합관제 임상지표 중환자실 환자현황 데이터 조회
*    Change History : 
**********************************************************************************************/    

AS
    
BEGIN  
		OPEN OUT_CURSOR FOR
							--관제테이블 연환자 기준
							WITH MAIN AS (
											SELECT SUM(1)                                       AS  DAYS_CNT
            					                  , SUM(A.YY_PT_CNT)                            AS  YY_PT_CNT
            					                  , SUM(A.YY_BED_CNT)                           AS  YY_BED_CNT
            					                  , SUM(A.ETRM_PT_CNT)                          AS	ETRM_PT_CNT
            					                  , SUM(A.SIRM_PT_CNT)                          AS  SIRM_PT_CNT
            					                  , SUM(A.PT_SILLM_CTG_1_GRP_CNT)               AS	PT_SILLM_CTG_1_GRP_CNT
            					                  , SUM(A.PT_SILLM_CTG_2_GRP_CNT)               AS	PT_SILLM_CTG_2_GRP_CNT
            					                  , SUM(A.PT_SILLM_CTG_3_GRP_CNT)               AS	PT_SILLM_CTG_3_GRP_CNT
            					                  , SUM(A.PT_SILLM_CTG_4_GRP_CNT)               AS	PT_SILLM_CTG_4_GRP_CNT
            					                  , SUM(A.PT_SILLM_CTG_5_GRP_CNT)               AS	PT_SILLM_CTG_5_GRP_CNT
            					                  , SUM(A.PT_SILLM_CTG_6_GRP_CNT)               AS	PT_SILLM_CTG_6_GRP_CNT
            					                  , SUM(A.CHOT_PT_CNT)                          AS	CHOT_PT_CNT
            					                  , SUM(A.WHL_SIRM_DYS)                         AS	WHL_SIRM_DYS
											  FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND A.ETRM_DT_SEQ  BETWEEN TO_CHAR(IN_FROM_DTM, 'YYYYMMDD')
											                          AND TO_CHAR(IN_TO_DTM, 'YYYYMMDD')
							), 
							--병상가동률, 혈관조영응급시술 수행률, 평균재실일 
							DETAIL_MAIN AS (
							                SELECT ROUND(DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YY_BED_CNT, 0, NULL, A.YY_BED_CNT) * 100, 1)                         AS BED_MOVA  --병상가동률
										         , ROUND(DECODE(A.WHL_SIRM_DYS, 0, NULL, A.WHL_SIRM_DYS) / DECODE(A.CHOT_PT_CNT, 0, NULL, A.CHOT_PT_CNT), 1)                       AS SIRM_DYS_AVG_VAL --평균재실일
                                              FROM MAIN A
							),
							--운영테이블 재실환자 기준
							SIRM_PT_DATA AS (   
											SELECT A.CIPT_ETRM_CHOT_ID
											     , A.HSP_TP_CD
											     , A.PACT_ID
											     , A.SEX_TP_CD
											     , A.AGE
											     , A.RPRN_MED_DEPT_CD
											     , A.RPRN_MED_DEPT_CD_NM
											     , A.ETRM_DTM
											     , A.ETRM_DT
											     , A.ETRM_WD_DEPT_CD
											     , A.ETRM_WD_DEPT_CD_NM
											     , A.CHOT_DTM
											     , A.CHOT_DT
											     , A.APCS_SUM_SCR
											     , A.AGPY_AOM_CNT
											     , A.AGPY_AOM_EMRG_CNT
											  FROM XICU.UICICSPV A --U121_UICI(지표)_중환자실환자지표기본 VIEW
											 WHERE A.ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND (A.ETRM_DTM    BETWEEN IN_FROM_DTM 
											                          AND IN_TO_DTM  + 0.99999
											     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) BETWEEN IN_FROM_DTM 
											                                                                                                        AND IN_TO_DTM + 0.99999
											     OR (A.ETRM_DTM < IN_FROM_DTM 
											         AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999)
											     )
							), 
							--재실환자
							IN_DATA AS (
											SELECT SUM(PT_CNT)               AS IN_PT_CNT--재실환자수
											  FROM (
													SELECT A.PACT_ID         AS PACT_ID
													     , SUM(1)            AS PT_CNT
													  FROM SIRM_PT_DATA A
												  GROUP BY A.PACT_ID
											)  
							),
							--진료과별 재실환자
							MTD_CB_SIRM_PT_DATA AS (
											SELECT A.RPRN_MED_DEPT_CD        AS MED_DEPT_CD
											     , A.RPRN_MED_DEPT_CD_NM     AS MED_DEPT_CD_NM
											     , COUNT(A.RPRN_MED_DEPT_CD) AS CNT
											  FROM SIRM_PT_DATA A
										  GROUP BY A.RPRN_MED_DEPT_CD, A.RPRN_MED_DEPT_CD_NM
							),
							--성별/연령대별 재실환자
							SEX_AGE_TP_DATA AS (
											SELECT CASE WHEN 0  <= A.AGE AND A.AGE < 20 THEN 'AGE_10_GRP_BLW_CNT'
											            WHEN 20 <= A.AGE AND A.AGE < 30 THEN 'AGE_20_GRP_CNT'
											            WHEN 30 <= A.AGE AND A.AGE < 40 THEN 'AGE_30_GRP_CNT'
											            WHEN 40 <= A.AGE AND A.AGE < 50 THEN 'AGE_40_GRP_CNT'
											            WHEN 50 <= A.AGE AND A.AGE < 60 THEN 'AGE_50_GRP_CNT'
											            WHEN 60 <= A.AGE AND A.AGE < 70 THEN 'AGE_60_GRP_CNT'
											            WHEN 70 <= A.AGE                THEN 'AGE_70_GRP_UPR_CNT'
											       ELSE NULL END                                    AS AGE_RANGE
											     , A.SEX_TP_CD                                      AS SEX_TP_CD
											  FROM SIRM_PT_DATA A
							),
							--재실시간대별 재실환자
		                    SIRM_TYPE_DATA AS (
						                    SELECT Y.TMZN_CB                   AS TMZN_CB
							                     , NVL(COUNT(Y.TMZN_CB), 0)    AS TMZN_CB_CNT
						                     FROM( SELECT CASE WHEN X.DIS <= 6                 THEN 'SIRM_6_TM_IN_CNT'
											                   WHEN 6 < X.DIS  AND X.DIS <= 12 THEN 'SIRM_12_TM_IN_CNT'
											                   WHEN 12 < X.DIS AND X.DIS <= 18 THEN 'SIRM_18_TM_IN_CNT'
											                   WHEN 18 < X.DIS AND X.DIS <= 24 THEN 'SIRM_24_TM_IN_CNT'
											                   WHEN 24 < X.DIS AND X.DIS <= 48 THEN 'SIRM_48_TM_IN_CNT'
											                   WHEN 48 < X.DIS                 THEN 'SIRM_48_TM_EXCS_CNT'
											              ELSE NULL END                                                    AS TMZN_CB --시간대별
								                     FROM( SELECT ROUND((DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) - A.ETRM_DTM) * 24)    AS DIS
											                    , A.*
										                     FROM SIRM_PT_DATA A
									                ) X
								                ) Y
					                     GROUP BY Y.TMZN_CB
		                   ),
		                   --아파치점수별 재실환자
                    	   APACHEII_SCORE_DATA AS (
                    						SELECT X.SCR_RANGE
                    							 , DECODE(COUNT(X.SCR_RANGE), NULL, 0, COUNT(X.SCR_RANGE)) AS  CNT
                    						  FROM( SELECT CASE WHEN A.APCS_SUM_SCR <= 10 THEN 'APCS_SUM_10_SCR_BLW_CNT'
                    											WHEN 10 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 20 THEN 'APCS_SUM_20_SCR_CNT'
                    											WHEN 20 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 30 THEN 'APCS_SUM_30_SCR_CNT'
                    											WHEN 30 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 40 THEN 'APCS_SUM_40_SCR_CNT'
                    											WHEN 40 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 50 THEN 'APCS_SUM_50_SCR_CNT'
                    											WHEN 50 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 60 THEN 'APCS_SUM_60_SCR_CNT'
                    											WHEN 60 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 70 THEN 'APCS_SUM_70_SCR_CNT'
                    											WHEN 70 < A.APCS_SUM_SCR                          THEN 'APCS_SUM_80_SCR_UPR_CNT'
                    											ELSE NULL END                                                SCR_RANGE
                    								  FROM SIRM_PT_DATA A        --중환자실환자지표기본
                    							) X
                    					  GROUP BY X.SCR_RANGE
                    		),
                    		/***********************
                    		 *혈관조영실시술일정정보 
                    		************************/
                    		--CICU 응급 시술 수행률 
                    		EMRG_AOM_FMT_RTO_DATA AS ( 
                    						SELECT DECODE(SUM(A.AGPY_AOM_CNT), NULL, 0, SUM(A.AGPY_AOM_CNT))               AS AGPY_AOM_CNT           --응급 포함한 모든 시술 건수
                    							 , DECODE(SUM(A.AGPY_AOM_EMRG_CNT), NULL, 0, SUM(A.AGPY_AOM_EMRG_CNT))     AS AGPY_AOM_EMRG_CNT      --응급인 시술 건수만
                    						  FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND A.ETRM_DT_SEQ  BETWEEN TO_CHAR(IN_FROM_DTM, 'YYYYMMDD')
											                          AND TO_CHAR(IN_TO_DTM, 'YYYYMMDD')
                    		),
		                   /*******************************************************************************
                    		 *연환자, 연병상 추이 전년월별평균, 당년월평균, 전년당월평균, 이전 12개월별 평균 
                    		********************************************************************************/ 
                    	   --전년 연환자수, 전년 연병상수
                    	   BF_YEAR_MAN_DAYS AS (
                    						SELECT SUM(X.YY_PT_CNT)                AS YY_PT_CNT      --연환자
                    							 , SUM(X.YY_BED_CNT)               AS YY_BED_CNT      --연병상
                                                 , SUM(1)                          AS YEAR_CNT           --건수
                            				  FROM( SELECT SUM(A.YY_PT_CNT)                AS YY_PT_CNT      --연환자
                    							         , SUM(A.YY_BED_CNT)               AS YY_BED_CNT      --연병상
                            				          FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
        											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
        											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
        											   AND A.ETRM_DT_SEQ BETWEEN TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '0101'
                            			                                     AND TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '1231'
                    					          GROUP BY TO_CHAR(A.ETRM_YY || A.ETRM_MM)
                    					         ) X 
                    	   ), 
                    	   --당년 연환자수, 당년 연병상수
                    	   MON_YEAR_MAN_DAYS AS (
                    						SELECT SUM(X.YY_PT_CNT)                AS YY_PT_CNT      --연환자
                    							 , SUM(X.YY_BED_CNT)               AS YY_BED_CNT      --연병상
                                                 , SUM(1)                          AS YEAR_CNT           --건수
                            				  FROM( SELECT SUM(A.YY_PT_CNT)                AS YY_PT_CNT      --연환자
                    							         , SUM(A.YY_BED_CNT)               AS YY_BED_CNT      --연병상
                            				          FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
        											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
        											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
        											   AND A.ETRM_DT_SEQ BETWEEN TO_CHAR(IN_TO_DTM, 'YYYY') || '0101'
                            			                                     AND TO_CHAR(IN_TO_DTM, 'YYYY') || '1231'
                            			               AND A.ETRM_DT_SEQ      <= TO_CHAR(TRUNC(SYSDATE), 'YYYYMMDD')
                    					          GROUP BY TO_CHAR(A.ETRM_YY || A.ETRM_MM)
                    					          ) X 
                    	   ),
                    	   --전년 당월 연환자수, 연병상수
                    	   BF_MON_MAN_DAYS AS (
                    	                    SELECT TO_CHAR(A.ETRM_YY || '-' || A.ETRM_MM)  AS DATE_TYPE
                    							 , NVL(SUM(A.YY_PT_CNT), 0)                AS YY_PT_CNT      --연환자
                    							 , NVL(SUM(A.YY_BED_CNT), 0)               AS YY_BED_CNT      --연병상
                    	                      FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND A.ETRM_DT_SEQ BETWEEN TO_CHAR(TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM'), 'YYYYMMDD')
										                             AND TO_CHAR(TRUNC(LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12))), 'YYYYMMDD')
									      GROUP BY TO_CHAR(A.ETRM_YY || '-' || A.ETRM_MM)
                    	   ),
                    	   -- 12개월 별 연간 추이 X 축
                    	   FROM_TO_DATE_TYPE AS (
                    	                    SELECT TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYY-MM') AS DATE_TYPE
                                                 , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YY.MM')   AS DT_CD_NM
                                                 , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYYMM')  AS DT_CD
                                              FROM DUAL
                                        CONNECT BY LEVEL - 1 <= 11 
                    	   ),
                    	   --조회기간 부터 이전 11개월 전 연환자수, 연병상수
                    	   FROM_TO_MAN_DAYS AS (    SELECT SUM(A.YY_PT_CNT)                        AS YY_PT_CNT      --연환자
                    							         , SUM(A.YY_BED_CNT)                       AS YY_BED_CNT      --연병상
                    							         , TO_CHAR(A.ETRM_YY || '-' || A.ETRM_MM)  AS DATE_TYPE
                            				          FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
        											 WHERE A.WD_DEPT_CD	        = IN_WD_DEPT_CD--병동부서코드(pk)  
        											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
        											   AND A.ETRM_DT_SEQ BETWEEN TO_CHAR(TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM'), 'YYYYMMDD') 
                    	                                                     AND TO_CHAR(LAST_DAY(IN_TO_DTM), 'YYYYMMDD')
									              GROUP BY TO_CHAR(A.ETRM_YY || '-' || A.ETRM_MM)
                    	   ),
                    	   CHART_TYPE_TB AS (
                    		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                 , A.COMN_CD      AS COMN_CD
                                                 , A.COMN_CD_NM   AS COMN_CD_EXPL
                                              FROM ( SELECT 'AGE_TYPE'           AS COMN_GRP_CD
                                                          , 'AGE_10_GRP_BLW_CNT' AS COMN_CD
                                                          , '~10대'              AS COMN_CD_NM 
                                                       FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_20_GRP_CNT', '20대' FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_30_GRP_CNT', '30대' FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_40_GRP_CNT', '40대' FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_50_GRP_CNT', '50대' FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_60_GRP_CNT', '60대' FROM DUAL UNION ALL
                                                     SELECT 'AGE_TYPE', 'AGE_70_GRP_UPR_CNT', '70대~' FROM DUAL UNION ALL
                                                     SELECT 'SEX_TYPE', 'SEX_FEML_CNT', '여성' FROM DUAL UNION ALL
                                                     SELECT 'SEX_TYPE', 'SEX_MALE_CNT', '남성' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_1_GRP_CNT', '1군' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_2_GRP_CNT', '2군' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_3_GRP_CNT', '3군' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_4_GRP_CNT', '4군' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_5_GRP_CNT', '5군' FROM DUAL UNION ALL
                                                     SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_6_GRP_CNT', '6군' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_10_SCR_BLW_CNT', '10' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_20_SCR_CNT', '20' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_30_SCR_CNT', '30' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_40_SCR_CNT', '40' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_50_SCR_CNT', '50' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_60_SCR_CNT', '60' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_70_SCR_CNT', '70' FROM DUAL UNION ALL
                                                     SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_80_SCR_UPR_CNT', '80' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_6_TM_IN_CNT', '재실시간6시간이내수' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_12_TM_IN_CNT', '재실시간12시간이내수' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_18_TM_IN_CNT', '재실시간18시간이내수' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_24_TM_IN_CNT', '재실시간24시간이내수' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_48_TM_IN_CNT', '재실시간48시간이내수' FROM DUAL UNION ALL
                                                     SELECT 'SIRM_TM_TYPE', 'SIRM_48_TM_EXCS_CNT', '재실시간48시간초과수' FROM DUAL UNION ALL
                                                     SELECT 'AVG_FLOW', '1', '전년월평균' FROM DUAL UNION ALL
                                                     SELECT 'AVG_FLOW', '2', '당년월평균' FROM DUAL UNION ALL
                                                     SELECT 'AVG_FLOW', '3', '전년당월' FROM DUAL UNION ALL
                                                     SELECT 'AGPY_AOM_CNT' AS COMN_GRP_CD, 'AGPY_AOM_CNT' AS COMN_CD, '혈관조영시술총건수' AS COMN_CD_NM FROM DUAL UNION ALL
                                                     SELECT 'AGPY_AOM_CNT', 'AGPY_AOM_EMRG_CNT', '혈관조영응급시술건수' FROM DUAL UNION ALL
                                                     SELECT 'EMRG_AOM_FMT_RTO', 'AOM_EMRG_RTO', '혈관조영응급시술수행률' FROM DUAL
                                                     ) A
                                          ORDER BY A.COMN_GRP_CD
                    		)            

							/********************
							* INDICATORS OUT DTO
							*********************/  

							SELECT X.COMN_GRP_CD            AS COMN_GRP_CD
							     , X.COMN_CD                AS COMN_CD
							     , X.COMN_CD_EXPL           AS COMN_CD_EXPL 
							     , TO_CHAR(NVL(X.DTRL1_NM, 0))      AS DTRL1_NM 
							     , TO_CHAR(NVL(X.DTRL2_NM, 0))      AS DTRL2_NM
							  FROM (
										SELECT 'PT_CRCCM'  AS COMN_GRP_CD
										     , COMN_CD     AS COMN_CD
										     , DECODE(COMN_CD, 'YY_PT_CNT', '연환자수'
										                     , 'YY_BED_CNT', '연병상수'
										                     , 'ETRM_PT_CNT', '입실환자수')  AS COMN_CD_EXPL
										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM
										     , NULL                AS DTRL2_NM
										  FROM MAIN
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (YY_PT_CNT          --연환자
										                    , YY_BED_CNT         --연병상
										                    , ETRM_PT_CNT        --입실환자
										                    )
										)    
										
									 UNION ALL
									 
									    SELECT 'PT_CRCCM'  AS COMN_GRP_CD
										     , COMN_CD     AS COMN_CD
										     , DECODE(COMN_CD, 'SIRM_DYS_AVG_VAL', '재실일수평균값'
										                     , 'BED_MOVA', '병상가동률')  AS COMN_CD_EXPL
										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM
										     , NULL                AS DTRL2_NM
										  FROM DETAIL_MAIN
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (SIRM_DYS_AVG_VAL   --평균재실일
										                    , BED_MOVA           --병상가동률
										                    )
										)	

								     UNION ALL    
                                        
                                        --재실환자 수
										SELECT 'PT_CRCCM'                   AS COMN_GRP_CD
										     , 'SIRM_PT_CNT'                AS COMN_CD
										     , '재실환자수'                 AS COMN_CD_EXPL
										     , NVL(A.IN_PT_CNT, 0)          AS DTRL1_NM
										     , NULL                         AS DTRL2_NM
										  FROM IN_DATA     A

									 UNION ALL

										--2.진료과별 재실환자
										SELECT 'MED_DEPT_TYPE'              AS COMN_GRP_CD
										     , A.MED_DEPT_CD                AS COMN_CD         /*진료과코드*/
										     , A.MED_DEPT_CD_NM             AS COMN_CD_EXPL      /*진료과코드명*/
										     , NVL(A.CNT, 0)                AS DTRL1_NM 
										     , NULL                         AS DTRL2_NM       
										  FROM MTD_CB_SIRM_PT_DATA A 
									     
										--당년 월별 연환자, 병상가동률 평균 
								 	 UNION ALL
								 	 
										SELECT 'AVG_MSTS'                            AS COMN_GRP_CD
										     , A.DT_CD                               AS COMN_CD  
										     , A.DT_CD_NM                            AS COMN_CD_EXPL
										     , NVL(B.YY_PT_CNT, 0)                                                                  AS DTRL1_NM       --당년 월별 연환자 평균
                                             , NVL(ROUND(DECODE(B.YY_PT_CNT, 0, NULL, B.YY_PT_CNT) / DECODE(B.YY_BED_CNT, 0, NULL, B.YY_BED_CNT) * 100, 1), 0)    AS DTRL2_NM       --당년 월별 병상가동률 평균
										  FROM FROM_TO_DATE_TYPE A
										     , FROM_TO_MAN_DAYS  B
										 WHERE A.DATE_TYPE = B.DATE_TYPE(+)
										
							      ) X
							      
						 UNION ALL
						    
						    SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
							     , B.COMN_CD                AS COMN_CD
							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL 
							     , TO_CHAR(NVL(A.DTRL1_NM, 0))      AS DTRL1_NM 
							     , TO_CHAR(NVL(A.DTRL2_NM, 0))      AS DTRL2_NM
							  FROM (
                                        SELECT 'SILLM_TYPE'         AS COMN_GRP_CD
										     , COMN_CD
										     , NULL                 AS COMN_CD_EXPL
										     , DTRL1_NM
										     , NULL                 AS DTRL2_NM
										  FROM MAIN
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN ( PT_SILLM_CTG_1_GRP_CNT
										                     , PT_SILLM_CTG_2_GRP_CNT
										                     , PT_SILLM_CTG_3_GRP_CNT
										                     , PT_SILLM_CTG_4_GRP_CNT
										                     , PT_SILLM_CTG_5_GRP_CNT
										                     , PT_SILLM_CTG_6_GRP_CNT)
										)

									 UNION ALL
									 
										--혈관조영시술 건수 및 응급시술 수행률
										SELECT 'AGPY_AOM_CNT'            AS COMN_GRP_CD
										     , COMN_CD
										     , DECODE(COMN_CD, 'AGPY_AOM_CNT', '혈관조영시술건수'
										                     , 'AGPY_AOM_EMRG_CNT', '혈관조영응급시술건수')   AS COMN_CD_EXPL
										     , NVL(DTRL1_NM, 0)                                               AS DTRL1_NM 
									         , NULL                         AS DTRL2_NM
										  FROM EMRG_AOM_FMT_RTO_DATA 
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN ( AGPY_AOM_CNT
										                     , AGPY_AOM_EMRG_CNT)
										       )
										       	
									 UNION ALL

										SELECT 'EMRG_AOM_FMT_RTO'            AS COMN_GRP_CD
										     , 'AOM_EMRG_RTO'                AS COMN_CD
										     , '혈관조영시술시행률'          AS COMN_CD_EXPL
										     , ROUND((DECODE(AGPY_AOM_EMRG_CNT, 0, NULL, AGPY_AOM_EMRG_CNT) / DECODE(AGPY_AOM_CNT, 0, NULL, AGPY_AOM_CNT)) * 100, 1)  AS DTRL1_NM
									         , NULL                         AS DTRL2_NM
										  FROM EMRG_AOM_FMT_RTO_DATA	 
                                    
                                     UNION ALL 
                                    
                                        --재실시간대별 재실환자 
						                SELECT 'SIRM_TM_TYPE'         AS COMN_GRP_CD
							                 , A.TMZN_CB              AS COMN_CD
							                 , NULL                   AS COMN_CD_EXPL
							                 , A.TMZN_CB_CNT          AS DTRL1_NM
										     , NULL                   AS DTRL2_NM
						                  FROM SIRM_TYPE_DATA A

									 UNION ALL
										
										--3.성별 재실환자
										SELECT 'SEX_TYPE'                                            AS COMN_GRP_CD
										     , DECODE(A.VAL_1, 'F', 'SEX_FEML_CNT', 'SEX_MALE_CNT')  AS COMN_CD                           
										     , NULL                                                  AS COMN_CD_EXPL
										     , A.VAL_2                                               AS DTRL1_NM
										     , NULL                                                  AS DTRL2_NM
										  FROM( SELECT S.SEX_TP_CD                                              VAL_1
										             , DECODE(COUNT(S.SEX_TP_CD), NULL, 0, COUNT(S.SEX_TP_CD))  VAL_2
										          FROM SEX_AGE_TP_DATA S
										      GROUP BY S.SEX_TP_CD
											) A  

									 UNION ALL

										--3.연령대별 재실환자 
										SELECT 'AGE_TYPE'           AS COMN_GRP_CD
										     , A.VAL_1              AS COMN_CD
										     , NULL                 AS COMN_CD_EXPL
										     , A.VAL_2              AS DTRL1_NM
										     , NULL                 AS DTRL2_NM
										  FROM( SELECT S.AGE_RANGE                                              VAL_1--연령대
										             , DECODE(COUNT(S.AGE_RANGE), NULL, 0, COUNT(S.AGE_RANGE))  VAL_2--환자수 
										          FROM SEX_AGE_TP_DATA S
										      GROUP BY S.AGE_RANGE
											) A
									 
									 UNION ALL
									 
									    -- 아파치 점수 별 재실환자
									    SELECT 'APACHEII_SCR_TYPE'  AS COMN_GRP_CD
										     , A.SCR_RANGE          AS COMN_CD
										     , NULL                 AS COMN_CD_EXPL
										     , A.CNT                AS DTRL1_NM
										     , NULL                 AS DTRL2_NM
									      FROM APACHEII_SCORE_DATA A
									      		
										--전년 월, 당년 월, 전년 당월 연환자, 병상가동률 평균 
									 UNION ALL
									 
									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
										     , '1'            AS COMN_CD  
										     , '전년월평균'   AS COMN_CD_EXPL
										     , ROUND((DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YEAR_CNT, 0, NULL, A.YEAR_CNT)), 0)             AS DTRL1_NM       --전년 연환자 평균
                                             , ROUND(DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YY_BED_CNT, 0, NULL, A.YY_BED_CNT) * 100, 1)     AS DTRL2_NM       --전년 병상가동률 평균
									      FROM BF_YEAR_MAN_DAYS A
									 
									 UNION ALL
									 
									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
										     , '2'            AS COMN_CD  
										     , '당년월평균'   AS COMN_CD_EXPL
										     , ROUND(DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YEAR_CNT, 0, NULL, A.YEAR_CNT),0)               AS DTRL1_NM       --당년 연환자 평균
                                             , ROUND(DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YY_BED_CNT, 0, NULL, A.YY_BED_CNT) * 100, 1)    AS DTRL2_NM       --당년 병상가동률 평균
									      FROM MON_YEAR_MAN_DAYS A
									      
									 UNION ALL
									 
									    SELECT 'AVG_FLOW'        AS COMN_GRP_CD
										     , '3'               AS COMN_CD  
										     , '전년당월'        AS COMN_CD_EXPL
										     , NVL(A.YY_PT_CNT, 0)                                                                  AS DTRL1_NM       --전년 당월 연환자 
                                             , NVL(ROUND(DECODE(A.YY_PT_CNT, 0, NULL, A.YY_PT_CNT) / DECODE(A.YY_BED_CNT, 0, NULL, A.YY_BED_CNT) * 100, 1), 0)    AS DTRL2_NM       --전년 당월 병상가동률 
									      FROM BF_MON_MAN_DAYS A
						       
							       ) A
							       , CHART_TYPE_TB B
							   WHERE B.COMN_GRP_CD = A.COMN_GRP_CD (+)
							     AND B.COMN_CD     = A.COMN_CD (+)   
							     
							--GROUP BY COMN_CD, COMN_CD_EXPL, COMN_GRP_CD
							ORDER BY COMN_GRP_CD, COMN_CD, COMN_CD_EXPL
		;                  
        		  
END PC_EICU_CENTER_PT_STATISTICS;
