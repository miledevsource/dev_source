
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ISOLATE_PAT_STATICS" 
                          ( IN_FROM_DTE    IN  DATE
                          , IN_TO_DTE      IN  DATE
                          , IN_WD_DEPT_CD  IN VARCHAR2
                          , IN_HSP_TP_CD   IN VARCHAR2
                          , OUT_CURSOR    OUT SYS_REFCURSOR
                          )

IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ISOLATE_PAT_STATICS                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표>>격리병동현황 조회
*    Change History : 2021.03.15                                                
**********************************************************************************************/
BEGIN
    BEGIN 
	    OPEN OUT_CURSOR FOR   
	        WITH SDATA AS(
               SELECT A.PACT_ID PACT_ID
            	    , A.HSP_TP_CD
            	    , A.PT_NO
            	    , A.ETRM_WD_DEPT_CD
            	    , A.RPRN_MED_DEPT_CD 
            	    , A.RPRN_MED_DEPT_CD_NM
            	    , A.ETRM_DTM
            	    , A.CHOT_DTM
            	    , A.ADS_DT
            	    , A.DS_EXPT_DT
            	    , EMRG_PACT_ID                                                 --응급원무접수ID
            	    , EMRM_ARVL_DTM                                                --응급실도착일시
            	    , SEX_TP_CD
            	    , AGE
            	    , INFC_MCB_TP_CD
                FROM HICU.UICIISPM A --격리병동환자지표기본
                WHERE A.HSP_TP_CD = IN_HSP_TP_CD
                  AND (ETRM_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE  OR 
                       DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN IN_FROM_DTE AND IN_TO_DTE OR 
                       (A.ETRM_DTM < IN_FROM_DTE AND A.CHOT_DTM > IN_TO_DTE)))
            , BED_DAYS AS (
             /*연병상*/
                 SELECT SUM(BED_CNT) BED_DAYS
				   FROM HICU.UICIWBCD
 				  WHERE BED_CFMT_DT BETWEEN IN_FROM_DTE AND IN_TO_DTE
				    AND HSP_TP_CD = IN_HSP_TP_CD
--				    AND WD_DEPT_CD =  IN_WD_DEPT_CD
                    AND WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
                	        )
             , AVG_STAY AS
             (
                 SELECT COUNT(*) CNT
                      , NVL(SUM(TRUNC(NVL(A.CHOT_DTM, SYSDATE)) - TRUNC(NVL(A.ETRM_DTM, SYSDATE))  + 1), 0)   STAY_DAY
                   FROM HICU.UICIISPM A --격리병동환자지표기본                       
               WHERE A.HSP_TP_CD = IN_HSP_TP_CD
                 AND A.CHOT_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE
             )
             , STAY_PAT AS
             (
                 SELECT PACT_ID
                      , A.ETRM_DTM
                      , NVL(TRUNC(NVL(A.CHOT_DTM, SYSDATE)) - TRUNC(NVL(A.ETRM_DTM, SYSDATE))  + 1, 0)   STAY_DAY
                   FROM HICU.UICIISPM A --격리병동환자지표기본                       
               WHERE A.HSP_TP_CD = IN_HSP_TP_CD
                 AND A.CHOT_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE
             )
	    SELECT  '01'                                                                          LARGE_CATEGORY
	          , '01'                                                                          SMALL_CATEGORY
	          , '격리병동 환자현황'                                                                TITLE
	          , '입실환자'                                                                      VALUE01_NAME
	          , 'C'                                                                         VALUE01_TYPE
	          , NVL(TO_CHAR(A.NEW_IN), '0')                                                    VALUE01  --입실
	          , '재실환자'                                                                      VALUE02_NAME
	          , 'C'                                                                         VALUE02_TYPE
	          , NVL(TO_CHAR(B.CNT), '0')                                                                 VALUE02  --재실
	          , '평균재실일'                                                                      VALUE03_NAME
	          , 'C'                                                                         VALUE03_TYPE
	          , NVL(TO_CHAR(ROUND(C.STAY_DAY / DECODE((C.CNT), 0, NULL,(C.CNT)),1)),0)          VALUE03  --평균재실일
	          , '연환자'                                                                         VALUE04_NAME
	          , 'C'                                                                         VALUE04_TYPE
	          , NVL(TO_CHAR(A.IN_DAYS), '0')                                                      VALUE04  --연환자
	          , '연병상'                                                                         VALUE05_NAME
	          , 'C'                                                                         VALUE05_TYPE
	          , NVL(TO_CHAR(B.BED_DAYS), '0')                                                      VALUE05  --연병상
	          , '병상가동률(%)'                                                                    VALUE06_NAME
	          , 'C'                                                                          VALUE06_TYPE
	          , NVL(TRIM(TO_CHAR((DECODE(A.IN_DAYS,NULL,0,A.IN_DAYS) /DECODE(B.BED_DAYS,0,NULL,B.BED_DAYS))*100,'99990.9')), '0')   VALUE06  --병상가동률
	       FROM (
				SELECT CASE WHEN (TRUNC(SYSDATE) < IN_TO_DTE AND TRUNC(SYSDATE) < IN_FROM_DTE ) THEN
				                 0
				             ELSE
				                 NVL(SUM(CASE WHEN IN_TO_DTE < NVL(CHOT_DTM, SYSDATE) THEN
				                                   IN_TO_DTE
				                              ELSE
				                                   TRUNC(NVL(CHOT_DTM, SYSDATE))
				                              END
				                            - CASE WHEN ETRM_DTM <  IN_FROM_DTE  THEN
				                                         IN_FROM_DTE
				                                   ELSE
				                                        TRUNC(ETRM_DTM)
				                              END + 1), 0)
				        END    IN_DAYS  --"연인원"
				      , NVL(SUM(CASE WHEN ETRM_DTM  BETWEEN IN_FROM_DTE AND IN_TO_DTE THEN
						                  1
						             ELSE
						                  0
						             END), 0)   NEW_IN --입실					 
				  FROM SDATA) A                             
				, ( SELECT SUM(CNT) CNT FROM (SELECT 1 CNT FROM SDATA GROUP BY PACT_ID)) B
	       , BED_DAYS B
	       , AVG_STAY C     	 
	  UNION ALL
     SELECT '02'                                                                          LARGE_CATEGORY
          , '01'                                                                          SMALL_CATEGORY
          , '재실시간별 재실환자'                   TITLE
	      , DAY_RANGE                      VALUE01_NAME
	      , 'D0'                           VALUE01_TYPE
	      , SUM_CNT                        VALUE01
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	   FROM (
        	   SELECT B.COMN_CD_NM DAY_RANGE
                    , TO_CHAR(NVL(SUM(CNT), 0)) SUM_CNT
                    , SORT_SEQ 
                 FROM (  SELECT CASE WHEN 0 <= STAY_DAY AND STAY_DAY <= 5  THEN '1'
            		             WHEN 5 < STAY_DAY AND STAY_DAY <= 10 THEN '2'
            		             WHEN 10 < STAY_DAY AND STAY_DAY <= 15 THEN '3'
            		             WHEN 15 < STAY_DAY  AND STAY_DAY <= 20 THEN '4'
            		             WHEN 20 < STAY_DAY  AND STAY_DAY <= 25 THEN '5'
            		             WHEN 25 < STAY_DAY  THEN '6'
            		             ELSE NULL END       DAY_RANGE
            		         , 1 CNT
        	               FROM STAY_PAT) A
                   , HICU.UCCOCSTE  B
        	   WHERE B.COMN_CD = A.DAY_RANGE(+)    
        	     AND B.COMN_GRP_CD = 'IC017'
        	     AND B.USE_YN = 'Y'
               GROUP BY B.COMN_CD_NM, SORT_SEQ
               ORDER BY SORT_SEQ )		   
	  UNION ALL       	  
     SELECT LARGE_CATEGORY
          , SMALL_CATEGORY
          , TITLE
          , VALUE01_NAME
          , VALUE01_TYPE
          , VALUE01
          , VALUE02_NAME
          , VALUE02_TYPE
          , VALUE02
          , ''
          , ''
    	  , ''
          , ''
          , ''
          , ''
          , ''
          , ''
          , ''
          , ''
          , ''
          , ''
      FROM (
            SELECT '03'                                         LARGE_CATEGORY
                 , '01'                                         SMALL_CATEGORY
                 , '성별/연령대별 재실환자'                              TITLE
                 ,  TYPE_CD                                     VALUE01_NAME
                 , 'D0'                                         VALUE01_TYPE
                 ,  NVL(TO_CHAR(sum(cnt)), '0')                           VALUE01
                 ,  TYPE_CD2                                    VALUE02_NAME
                 ,  'D1'                                        VALUE02_TYPE
                 ,  NVL(TO_CHAR(sum(cnt2)), '0')                          VALUE02
                 ,  1                                           SEQ
             FROM (
                     SELECT SEX_TP_CD     TYPE_CD
                          , 1 CNT
                          , 'F'            TYPE_CD2
                          , 0            CNT2
                      FROM SDATA
                      WHERE SEX_TP_CD = 'M'
                      UNION ALL
                     SELECT 'M'          TYPE_CD
                          , 0            CNT
                          , SEX_TP_CD     TYPE_CD2
                          , 1 CNT2
                      FROM SDATA
                      WHERE SEX_TP_CD = 'F')  
      GROUP BY TYPE_CD, TYPE_CD2
      UNION ALL
     SELECT '03'                                         LARGE_CATEGORY
          , '02'                                         SMALL_CATEGORY
          , '성별/연령대별 재실환자'                              TITLE
          , COMN_CD_NM    VALUE01_NAME
          , 'D0'          VALUE01_TYPE
          , TO_CHAR(NVL(SUM(CNT), 0))        VALUE01
          , ''             VALUE02_NAME
          , ''             VALUE02_TYPE
          , '0'             VALUE02
          , SORT_SEQ SEQ
      FROM (
             SELECT B.COMN_CD_NM
                  , CNT
                  , B.SORT_SEQ
               FROM (
                      SELECT CASE WHEN 0 <= AGE AND AGE < 20  THEN '1'
            		             WHEN 20 <= AGE AND AGE < 30 THEN '2'
            		             WHEN 30 <= AGE AND AGE < 40 THEN '3'
            		             WHEN 40 <= AGE  AND AGE < 50 THEN '4'
            		             WHEN 50 <= AGE AND AGE < 60 THEN '5'
            		             WHEN 60 <= AGE AND AGE  < 70 THEN '6'
            		             WHEN 70 <= AGE  THEN '7'
            		             ELSE NULL END       AGE_RANGE
            		      , 1 CNT
            		   FROM SDATA) A
            	  , HICU.UCCOCSTE  B
              WHERE A.AGE_RANGE(+) = B.COMN_CD
                AND B.COMN_GRP_CD = 'IC016'
                AND B.USE_YN = 'Y'
            )
      GROUP BY COMN_CD_NM, SORT_SEQ
      ORDER BY SMALL_CATEGORY, SEQ)
	  UNION ALL
	 SELECT '04'      LARGE_CATEGORY
	      , '01'     SMALL_CATEGORY
	      , '환자분류별 재실환자' TITLE
	      , COMN_CD_NM VALUE01_NAME
	      , 'D0'       VALUE01_TYPE
 	      , NVL(TO_CHAR(VALUE01), 0) VALUE01
  	      , COMN_CD_NM VALUE02_NAME
	      , 'D1'       VALUE02_TYPE
	      , NVL(TRIM(TO_CHAR(RATIO_TO_REPORT(VALUE01) OVER()*100, '99990.9')), '0')||'%' VALUE02
	      , ''
	      , ''
	      , ''
	      , ''
 	      , ''
  	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	      , ''
	   FROM (  SELECT C.COMN_CD_NM
				     , NVL(TO_CHAR(VALUE01), 0) VALUE01
				  FROM ( SELECT PT_SILLM_CTG_GRP_CD
				              , COUNT(*) VALUE01
				          FROM (
				        		SELECT M.PT_SILLM_CTG_TP_CD
				        		      , NVL(M.WD_DEPT_CD, IN_WD_DEPT_CD )  WD_DEPT_CD
				        		      , M.PT_SILLM_CTG_GRP_CD
				        		      , NVL(M.HSP_TP_CD, IN_HSP_TP_CD) HSP_TP_CD
				        		      , S.DT CTG_DTM
				        		      , M.PT_SILLM_CTG_SCR_SUM
				        		      , M.PT_SILLM_CTG_TL_ID
				        		   FROM (
				        		        SELECT A.PT_SILLM_CTG_TP_CD
				        		             , A.WD_DEPT_CD
				        		             , A.PT_SILLM_CTG_GRP_CD
				        		             , A.HSP_TP_CD
				        		             , A.PT_SILLM_CTG_DTM
				        		             , A.PT_SILLM_CTG_SCR_SUM
				        		             , A.PT_SILLM_CTG_TL_ID
				        		          FROM HICU.UICIISPD A
				        		             , SDATA B
				        		         WHERE A.PACT_ID = B.PACT_ID
				        		           AND A.HSP_TP_CD = B.HSP_TP_CD     
--				        		           AND A.WD_DEPT_CD         = B.ETRM_WD_DEPT_CD 
				        		           AND A.PT_SILLM_CTG_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE
				        		           AND A.PT_SILLM_CTG_DTM BETWEEN B.ETRM_DTM AND B.CHOT_DTM
				        		           AND A.HSP_TP_CD  = IN_HSP_TP_CD
				        		        ) M
				        		       , (
				        			          SELECT IN_FROM_DTE + LEVEL - 1  DT
				        			            FROM DUAL
				        			         CONNECT BY LEVEL - 1 <= IN_TO_DTE -  IN_FROM_DTE
				        			        ) S
				        		   WHERE S.DT = M.PT_SILLM_CTG_DTM(+)
				        		 ) A
				         GROUP BY PT_SILLM_CTG_GRP_CD) B
				      , ( SELECT COMN_CD
				               , COMN_CD_NM
				               , SORT_SEQ SCRN_MRK_SEQ
				           FROM HICU.UCCOCSTE
				          WHERE COMN_GRP_CD = 'IC010'
				            AND USE_YN = 'Y') C
				      WHERE B.PT_SILLM_CTG_GRP_CD(+) = C.COMN_CD
				      ORDER BY C.SCRN_MRK_SEQ)  --화면표시순번      
     UNION ALL					      
    SELECT '05'                            LARGE_CATEGORY
         , '01'                            SMALL_CATEGORY
         , '감염미생물별 재실환자'                   TITLE
         , COMN_CD_NM                  VALUE01_NAME
         , 'D0'                            VALUE01_TYPE
         , NVL(TO_CHAR(NVL(CNT, 0)), 0)        VALUE01
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
         , ''
      FROM (
                 SELECT  B.COMN_CD_NM
                      , SUM(DECODE(INFC_MCB_TP_CD, NULL, 0, 1)) CNT
                      , B.SORT_SEQ 
    	          FROM  SDATA   A
                      , HICU.UCCOCSTE B
    	      WHERE B.COMN_CD = A.INFC_MCB_TP_CD(+)
    	        AND B.HSP_TP_CD = A.HSP_TP_CD (+)
    	        AND B.COMN_GRP_CD = 'IC015' 
    	        AND B.USE_YN = 'Y'
    	      GROUP BY B.COMN_CD, B.COMN_CD_NM, B.SORT_SEQ
    	      ORDER BY B.SORT_SEQ)
	    ;         
  END;

END PC_EICU_ISOLATE_PAT_STATICS;
