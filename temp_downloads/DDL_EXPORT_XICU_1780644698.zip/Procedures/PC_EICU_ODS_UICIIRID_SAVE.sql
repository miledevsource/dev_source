
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICIIRID_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICIIRID_SAVE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : UICIIRID(격리병동입실퇴실시간정보)데이터 적재
*    Change History : 2021.03.15                                                
**********************************************************************************************/
 AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    BEGIN        
        MERGE INTO HICU.UICIIRID A  --격리병동입실퇴실시간정보
             USING ( SELECT PACT_ID
                          , PT_NO
                          , ETRM_DTM
                          , MED_DEPT_CD
                          , MED_DEPT_CD_NM
                          , RPRN_MED_DEPT_CD
                          , RPRN_MED_DEPT_CD_NM
                          , ETRM_WD_DEPT_CD
                          , ETRM_WD_DEPT_CD_NM
                          , CHOT_DTM
                          , CHOT_WD_DEPT_CD
                          , CHOT_WD_DEPT_CD_NM
                          , FST_WRT_DTM
                          , LST_CHG_DTM
                          , PT_NM
                          , ADS_DT
                          , DS_EXPT_DT
                          , DS_DT
                          , SEX_TP_CD
                          , AGE
                          , AGE_MRK_NM
                          , ADS_PATH_CD
                          , ADS_PATH_CD_NM
                          , EMRG_PACT_ID
                          , EMRM_ARVL_DTM
                          , ADS_ACPT_BSC_FST_WRT_DTM
                          , ADS_ACPT_BSC_LST_WRT_DTM
                          , CASE WHEN ACP_APCN_YN = 'Y' THEN 'Y'
                                 ELSE APCN_YN           END APCN_YN   /*입원접수 취소가 된 환자의 경우, 전과전동정보도 취소가 됬다고 판단한다.*/
                       FROM XICU.EMEI007V
                      WHERE LST_CHG_DTM BETWEEN IN_FROM_DTM  AND IN_TO_DTM
                         OR ADS_ACPT_BSC_LST_WRT_DTM BETWEEN IN_FROM_DTM  AND IN_TO_DTM  /*전과전동 변동 없이 취소된 환자를 알수 없어서 조건 추가*/
                   ) B
                ON (    A.PACT_ID   = B.PACT_ID
                    AND A.ETRM_DTM  = B.ETRM_DTM
                   )
              WHEN MATCHED THEN
                   UPDATE SET A.PT_NO                = B.PT_NO
                            , A.MED_DEPT_CD          = B.MED_DEPT_CD
                            , A.MED_DEPT_CD_NM       = B.MED_DEPT_CD_NM
                            , A.RPRN_MED_DEPT_CD     = B.RPRN_MED_DEPT_CD
                            , A.RPRN_MED_DEPT_CD_NM  = B.RPRN_MED_DEPT_CD_NM
                            , A.ETRM_WD_DEPT_CD      = B.ETRM_WD_DEPT_CD
                            , A.ETRM_WD_DEPT_CD_NM   = B.ETRM_WD_DEPT_CD_NM
                            , A.CHOT_DTM             = B.CHOT_DTM
                            , A.CHOT_WD_DEPT_CD      = B.CHOT_WD_DEPT_CD
                            , A.CHOT_WD_DEPT_CD_NM   = B.CHOT_WD_DEPT_CD_NM
                            , A.FST_WRT_DTM          = B.FST_WRT_DTM
                            , A.LST_CHG_DTM          = B.LST_CHG_DTM
                            , A.APCN_YN              = B.APCN_YN
                            , A.LST_LOD_DTM          = SYSDATE
--                            , A.PACT_ID              = B.PACT_ID
--                            , A.ETRM_DTM             = B.ETRM_DTM
              WHEN NOT MATCHED THEN
                   INSERT ( HSP_TP_CD
                          , PACT_ID
                          , PT_NO
                          , MED_DEPT_CD
                          , MED_DEPT_CD_NM
                          , RPRN_MED_DEPT_CD
                          , RPRN_MED_DEPT_CD_NM
                          , ETRM_DTM
                          , ETRM_WD_DEPT_CD
                          , ETRM_WD_DEPT_CD_NM
                          , CHOT_DTM
                          , CHOT_WD_DEPT_CD
                          , CHOT_WD_DEPT_CD_NM
                          , APCN_YN
                          , FST_WRT_DTM
                          , LST_CHG_DTM
                          , FST_LOD_DTM
                          , LST_LOD_DTM
                          )
                   VALUES ( IN_HSP_TP_CD
                          , B.PACT_ID
                          , B.PT_NO
                          , B.MED_DEPT_CD
                          , B.MED_DEPT_CD_NM
                          , B.RPRN_MED_DEPT_CD
                          , B.RPRN_MED_DEPT_CD_NM
                          , B.ETRM_DTM
                          , B.ETRM_WD_DEPT_CD
                          , B.ETRM_WD_DEPT_CD_NM
                          , B.CHOT_DTM
                          , B.CHOT_WD_DEPT_CD
                          , B.CHOT_WD_DEPT_CD_NM
                          , B.APCN_YN
                          , B.FST_WRT_DTM
                          , B.LST_CHG_DTM
                          , SYSDATE
                          , SYSDATE
                          )
        ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICIIRID_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICIIRID_SAVE;
