
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRID_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRID_SAVE                                               
*    CREATEDATE     : 2021.03.24
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_중환자실입실퇴실시간정보 데이터 적재
*    Change History : 2021.03.24                                               
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    /*******************************************************************************************************************
    * DELETE : HICU.UICICRPM --U121_UICI(ODS)_중환자기본
    * FROM : XICU.EMEI003V
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICICRID A  --U121_UICI(ODS)_중환자실입실퇴실시간정보
          WHERE EXISTS (SELECT 1
                          FROM XICU.EMEI003V B
                         WHERE A.CIPT_ETRM_CHOT_ID       = B.CIPT_ETRM_CHOT_ID
                           AND A.HST_SEQ                 = B.HST_SEQ 
                           AND B.LST_CHG_DTM       BETWEEN IN_FROM_DTM 
                                                       AND IN_TO_DTM
                      ); 
      END; 
    /*******************************************
    * _중환자실입실퇴실시간정보(UICICRID) BATCH 
    *******************************************/  
    BEGIN        
        MERGE INTO HICU.UICICRID A  --U121_UICI(ODS)_중환자실입실퇴실시간정보
             USING ( SELECT CIPT_ETRM_CHOT_ID                  --중환자입실퇴실ID 
                          , HST_SEQ                            --이력순번
                          , USE_YN                             --사용여부
                          , LST_YN                             --최종여부
                          , PACT_ID                            --원무접수ID
                          , PACT_TP_CD                         --원무접수구분코드
                          , PT_NO                              --환자번호
                          , MED_DEPT_CD                        --진료부서코드(센터포함)
                          , MED_DEPT_CD_NM                     --진료부서코드명
                          , ETRM_DTM                           --입실일시
                          , ETRM_WD_DEPT_CD                    --입실병동부서코드
                          , ETRM_WD_DEPT_CD_NM                 --입실병동부서코드명
                          , ETRM_PRM_NO                        --입실병실번호
                          , ETRM_BED_NO                        --입실병상번호
                          , EMRG_BED_YN                        --응급병상여부
                          , ISLT_BED_YN                        --격리병상여부
                          , ICU_ETRM_PATH_CLS_CD               --중환자실입실경로유형코드
                          , ICU_ETRM_PATH_CLS_CD_NM            --중환자실입실경로유형코드명
                          , CHOT_DTM                           --퇴실일시
                          , ICU_CHOT_PLC_TP_CD                 --중환자실퇴실장소구분코드
                          , ICU_CHOT_PLC_TP_CD_NM              --중환자실퇴실장소구분코드명
                          , CHOT_WD_MTD_CD                     --퇴실병동진료과코드
                          , CHOT_WD_MTD_CD_NM                  --퇴실병동진료과코드명
                          , FST_WRT_DTM                        --최초작성일시
                          , LST_CHG_DTM                        --최종변경일시  
                          , PT_NM                              --환자명
                          , ADS_DT                             --입원일자
                          , DS_EXPT_DT                         --퇴원예정일자
                          , DS_DT                              --퇴원일자
                          , SEX_TP_CD                          --성별구분코드
                          , AGE                                --연령
                          , AGE_MRK_NM                         --연령표시명
                          , ADS_PATH_CD                        --입원경로코드
                          , ADS_PATH_CD_NM                     --입원경로코드명
                          , FST_ACP_DTM                        --입원접수기본최초작성일시
                          , LST_ACP_DTM                        --입원접수기본최종작성일시
                          , APCN_YN                            --접수취소여부
                          , RPRN_MED_DEPT_CD                   --대표진료부서코드
                          , RPRN_MED_DEPT_CD_NM                --대표진료부서코드명 
				       FROM XICU.EMEI003V
				      WHERE LST_CHG_DTM BETWEEN IN_FROM_DTM 
				                            AND IN_TO_DTM
                   ) B
                ON (    A.CIPT_ETRM_CHOT_ID              = B.CIPT_ETRM_CHOT_ID
                    AND A.HSP_TP_CD                      = IN_HSP_TP_CD--B.HSP_TP_CD 
                    AND A.HST_SEQ                        = B.HST_SEQ 
                    --AND A.PACT_ID                        = B.PACT_ID
                    --AND A.PT_NO                          = B.PT_NO
                   )     
              WHEN MATCHED THEN
                   --최종 적재
                   UPDATE SET --A.HST_SEQ                  = B.HST_SEQ                  --이력순번
                              A.USE_YN                   = B.USE_YN                   --사용여부
                            , A.LST_YN                   = B.LST_YN                   --최종여부
                            , A.PACT_TP_CD               = B.PACT_TP_CD               --원무접수구분코드
                            , A.MED_DEPT_CD              = B.MED_DEPT_CD              --진료부서코드(센터포함)
                            , A.MED_DEPT_CD_NM           = B.MED_DEPT_CD_NM           --진료부서코드명
                            , A.ETRM_DTM                 = B.ETRM_DTM                 --입실일시    
                            , A.RPRN_MED_DEPT_CD	     = B.RPRN_MED_DEPT_CD         --대표진료부서코드
                            , A.RPRN_MED_DEPT_CD_NM	     = B.RPRN_MED_DEPT_CD_NM      --대표진료부서코드명 
                            , A.ETRM_WD_DEPT_CD          = B.ETRM_WD_DEPT_CD          --입실병동부서코드
                            , A.ETRM_WD_DEPT_CD_NM       = B.ETRM_WD_DEPT_CD_NM       --입실병동부서코드명
                            , A.ETRM_PRM_NO              = B.ETRM_PRM_NO              --입실병실번호
                            , A.ETRM_BED_NO              = B.ETRM_BED_NO              --입실병상번호
                            , A.EMRG_BED_YN              = B.EMRG_BED_YN              --응급병상여부
                            , A.ISLT_BED_YN              = B.ISLT_BED_YN              --격리병상여부
                            , A.ICU_ETRM_PATH_CLS_CD     = B.ICU_ETRM_PATH_CLS_CD     --중환자실입실경로유형코드
                            , A.ICU_ETRM_PATH_CLS_CD_NM  = B.ICU_ETRM_PATH_CLS_CD_NM  --중환자실입실경로유형코드명
                            , A.CHOT_DTM                 = B.CHOT_DTM                 --퇴실일시
                            , A.ICU_CHOT_PLC_TP_CD       = B.ICU_CHOT_PLC_TP_CD       --중환자실퇴실장소구분코드
                            , A.ICU_CHOT_PLC_TP_CD_NM    = B.ICU_CHOT_PLC_TP_CD_NM    --중환자실퇴실장소구분코드명
                            , A.CHOT_WD_MTD_CD           = B.CHOT_WD_MTD_CD           --퇴실병동진료과코드
                            , A.CHOT_WD_MTD_CD_NM        = B.CHOT_WD_MTD_CD_NM        --퇴실병동진료과코드명
                            , A.FST_WRT_DTM              = B.FST_WRT_DTM              --최초작성일시
                            , A.LST_CHG_DTM              = B.LST_CHG_DTM              --최종변경일시  
                            , A.LST_LOD_DTM              = SYSDATE                    --최종적재일시
                --최초 적재    
                WHEN NOT MATCHED THEN
                     INSERT ( A.CIPT_ETRM_CHOT_ID
                            , A.HSP_TP_CD
                            , A.HST_SEQ
                            , A.USE_YN
                            , A.LST_YN
                            , A.PACT_ID
                            , A.PACT_TP_CD
                            , A.PT_NO
                            , A.MED_DEPT_CD
                            , A.MED_DEPT_CD_NM
                            , A.RPRN_MED_DEPT_CD	    --대표진료부서코드
                            , A.RPRN_MED_DEPT_CD_NM	    --대표진료부서코드명 
                            , A.ETRM_DTM
                            , A.ETRM_WD_DEPT_CD
                            , A.ETRM_WD_DEPT_CD_NM
                            , A.ETRM_PRM_NO
                            , A.ETRM_BED_NO
                            , A.EMRG_BED_YN
                            , A.ISLT_BED_YN
                            , A.ICU_ETRM_PATH_CLS_CD
                            , A.ICU_ETRM_PATH_CLS_CD_NM
                            , A.CHOT_DTM
                            , A.ICU_CHOT_PLC_TP_CD
                            , A.ICU_CHOT_PLC_TP_CD_NM
                            , A.CHOT_WD_MTD_CD
                            , A.CHOT_WD_MTD_CD_NM
                            , A.FST_WRT_DTM
                            , A.LST_CHG_DTM
                            , A.FST_LOD_DTM
                            , A.LST_LOD_DTM
                            )
                     VALUES ( B.CIPT_ETRM_CHOT_ID           --중환자입실퇴실ID 
                            , IN_HSP_TP_CD                  --병원구분코드
                            , B.HST_SEQ                     --이력순번
                            , B.USE_YN                      --사용여부
                            , B.LST_YN                      --최종여부
                            , B.PACT_ID                     --원무접수ID
                            , B.PACT_TP_CD                  --원무접수구분코드
                            , B.PT_NO                       --환자번호
                            , B.MED_DEPT_CD                 --진료부서코드(센터포함)
                            , B.MED_DEPT_CD_NM              --진료부서코드명  
                            , B.RPRN_MED_DEPT_CD
                            , B.RPRN_MED_DEPT_CD_NM
                            , B.ETRM_DTM                    --입실일시
                            , B.ETRM_WD_DEPT_CD             --입실병동부서코드
                            , B.ETRM_WD_DEPT_CD_NM          --입실병동부서코드명
                            , B.ETRM_PRM_NO                 --입실병실번호
                            , B.ETRM_BED_NO                 --입실병상번호
                            , B.EMRG_BED_YN                 --응급병상여부
                            , B.ISLT_BED_YN                 --격리병상여부
                            , B.ICU_ETRM_PATH_CLS_CD        --중환자실입실경로유형코드
                            , B.ICU_ETRM_PATH_CLS_CD_NM     --중환자실입실경로유형코드명
                            , B.CHOT_DTM                    --퇴실일시
                            , B.ICU_CHOT_PLC_TP_CD          --중환자실퇴실장소구분코드
                            , B.ICU_CHOT_PLC_TP_CD_NM       --중환자실퇴실장소구분코드명
                            , B.CHOT_WD_MTD_CD              --퇴실병동진료과코드
                            , B.CHOT_WD_MTD_CD_NM           --퇴실병동진료과코드명
                            , B.FST_WRT_DTM                 --최초작성일시
                            , B.LST_CHG_DTM                 --최종변경일시 
                            , SYSDATE                       --최초적재일시
                            , SYSDATE                       --최종적재일시
                            );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';   
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRID_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICRID_SAVE;
