
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_SMRY_INO_SEL" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NM,
        S.IO_RECORD_TIME,
				S.INTAKE_AMT,
				S.OUTPUT_AMT
    FROM PT_SMRY_INO_SEL	S,
    		 ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID     
      AND A.SEQ = IN_SEQ 
      AND S.IO_RECORD_TIME >= (
        SELECT MAX(IO_RECORD_TIME)
        FROM PT_SMRY_INO_SEL
        ) - 3
    ORDER BY S.IO_RECORD_TIME DESC;
END;
