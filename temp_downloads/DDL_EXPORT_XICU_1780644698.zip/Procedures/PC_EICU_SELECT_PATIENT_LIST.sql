
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_PATIENT_LIST" 
                          ( IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , IN_PT_NO          IN  VARCHAR2
                          , IN_PT_NM          IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_PATIENT_LIST
*    CREATEDATE     : 2021.03.18
*    Author         : 신솔
*    Description    : 환자 조회
*    Change History : 2021.03.18, 신솔, 최초작성     
                      2021.06.24, 86병동추가 : 집중치료실조건
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            SELECT A.PT_NO            AS PT_NO
                 , A.PT_NM            AS PT_NM
                 , A.SEX_TP_CD        AS SEX_TP_CD
                 , TO_NUMBER(A.AGE)   AS AGE
                 , A.PACT_ID          AS PACT_ID
                 , A.ADS_DT           AS ADS_DT
                 , A.MED_DEPT_CD      AS PT_MED_DEPT_CD
                 , A.MED_DEPT_CD_NM   AS PT_MED_DEPT_NM
                 , A.PT_CUR_PSTN_CD   AS WD_DEPT_CD
                 , A.PT_CUR_PSTN_NM   AS WD_DEPT_CD_NM
                 , A.MAIN_DGNS_DT     AS MAIN_DGNS_DT
                 , A.MAIN_DGNS_CD     AS DGNS_VOC_ID
                 , A.MAIN_DGNS_NM     AS DGNS_VOC_NM                 
                 , A.SPCT_NM          AS SPCT_NM                    
                 , A.ANDR_NM          AS ANDR_NM                   
                 , A.NRS_NM           AS NRS_NM                  
                 , B.HSP_TP_CD        AS HSP_TP_CD
              FROM XICU.EMEI012V A
                 , HICU.UCCOCDPM B
             WHERE A.PT_CUR_PSTN_CD = B.DEPT_CD  
               AND A.UNTC_CSLT_YN  != 'Y'   -- 2021-06-24, 김국경 : 86W, 집중치료실인지여부 (View에서 여부판단)
               AND B.HSP_TP_CD      = IN_HIS_HSP_TP_CD
               -- 2021.03.30, 신솔, TA팀 이현경 책임님 요청으로 PT_NO, PT_NM 조건절 추가
               AND (A.PT_NO         LIKE NVL2(IN_PT_NO, '%' || IN_PT_NO || '%', '')
                OR  A.PT_NM         LIKE NVL2(IN_PT_NM, '%' || IN_PT_NM || '%', '')) 
                
             UNION ALL
            /* 2021-06-24, 김국경 :  e-icu 비대면협진여부추가(환자정보 현재병실이 집중치료실인지여부 ex.86병동) */
            SELECT A.PT_NO            AS PT_NO
                 , A.PT_NM            AS PT_NM
                 , A.SEX_TP_CD        AS SEX_TP_CD
                 , TO_NUMBER(A.AGE)   AS AGE
                 , A.PACT_ID          AS PACT_ID
                 , A.ADS_DT           AS ADS_DT
                 , A.MED_DEPT_CD      AS PT_MED_DEPT_CD
                 , A.MED_DEPT_CD_NM   AS PT_MED_DEPT_NM
                 , A.PT_CUR_PSTN_CD   AS WD_DEPT_CD
                 , A.PT_CUR_PSTN_NM   AS WD_DEPT_CD_NM
                 , A.MAIN_DGNS_DT     AS MAIN_DGNS_DT
                 , A.MAIN_DGNS_CD     AS DGNS_VOC_ID
                 , A.MAIN_DGNS_NM     AS DGNS_VOC_NM                 
                 , A.SPCT_NM          AS SPCT_NM                    
                 , A.ANDR_NM          AS ANDR_NM                   
                 , A.NRS_NM           AS NRS_NM                  
                 , A.HSP_TP_CD        AS HSP_TP_CD
              FROM XICU.EMEI012V A
             WHERE A.UNTC_CSLT_YN   = 'Y'  -- 2021-06-24, 김국경 : 86W, 집중치료실인지여부
               AND A.HSP_TP_CD      = IN_HIS_HSP_TP_CD
               AND (A.PT_NO         LIKE NVL2(IN_PT_NO, '%' || IN_PT_NO || '%', '')
                OR  A.PT_NM         LIKE NVL2(IN_PT_NM, '%' || IN_PT_NM || '%', ''))  
            ;
    END;
END PC_EICU_SELECT_PATIENT_LIST;
