
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_DEPTLIST" 
                          ( IN_HSP_TP_CD  IN  VARCHAR2       /*병원코드 */
                          , IN_USE_YN  IN  VARCHAR2       /*사용여부*/
                          , OUT_CURSOR OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_DEPTLIST
*    CREATEDATE     : 2021.01.11
*    Author         : 이창우
*    Description    : 병원코드에 포함된 부서코드를 조회한다.
*    Change History : 
**********************************************************************************************/
BEGIN
  BEGIN
    OPEN OUT_CURSOR FOR    
         SELECT CDPM.HSP_TP_CD, CDPM.DEPT_CD, CDPM.DEPT_NM
           FROM HICU.UCCOCDPM CDPM
          WHERE CDPM.HSP_TP_CD = NVL(IN_HSP_TP_CD, CDPM.HSP_TP_CD )
            AND CDPM.USE_YN = NVL(IN_USE_YN, CDPM.USE_YN)
          ORDER BY CDPM.HSP_TP_CD, CDPM.SORT_SEQ
         ;
  END;
END PC_EICU_SELECT_DEPTLIST;
