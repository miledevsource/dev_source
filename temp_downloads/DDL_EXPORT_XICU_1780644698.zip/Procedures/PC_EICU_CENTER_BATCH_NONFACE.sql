
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_NONFACE" 
                          ( IN_PRMR_STR_DTM   IN  DATE
                          , IN_PRMR_END_DTM   IN  DATE
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , IO_ERR_YN         IN OUT  VARCHAR2    --  ERROR Y/N
                          , IO_ERR_MSG        IN OUT  VARCHAR2    --  ERROR MESSAGE
                          )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_NONFACE
*    CREATEDATE     : 2021.03.30
*    Author         : 신솔
*    Description    : 비대면 협진현황
*    Change History : 2021.03.03, 신솔, 최초작성
                      2021.07.08, 황선영, 039병동 부서 HICU.UCCOCDPM 테이블에 추가되며 관련 부분 주석 처리 
**********************************************************************************************/
AS
    V_CURSOR          SYS_REFCURSOR; 
    V_COMN_GRP_CD     VARCHAR(500);
    V_COMN_CD         VARCHAR(500);
    V_COMN_CD_NM      VARCHAR(500);
    V_COMN_CD_EXPL    VARCHAR(500);
    V_DTRL1_NM        VARCHAR(500);
    V_DTRL2_NM        VARCHAR(500);
    V_DTRL3_NM        VARCHAR(500);
BEGIN
    DECLARE CURSOR DTM_CURSOR IS SELECT DISTINCT TRUNC(X.CSLT_STR_DTM) AS UNTC_DTM
                                   FROM HICU.UCOMCNSM X --관제센터협진기본
                                  WHERE X.RER_HSP_CD   = IN_HIS_HSP_TP_CD
                                    AND X.CSLT_STR_DTM IS NOT NULL
                                    AND X.LSH_DTM      BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                    
                                  UNION 
                                  
                                  SELECT TRUNC(A.INSERTDATE) AS UNTC_DTM
                                    FROM HICU.LOG_EZOTC_EICU A
                                   WHERE A.HOSPITALCODE = IN_HIS_HSP_TP_CD
                                     AND A.INSERTDATE   IS NOT NULL
                                     AND A.INSERTDATE   BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                  ORDER BY UNTC_DTM
                                 ;
    DTM DTM_CURSOR%ROWTYPE;
    BEGIN
        OPEN DTM_CURSOR;
        LOOP FETCH DTM_CURSOR INTO DTM;
        EXIT WHEN DTM_CURSOR%NOTFOUND;
            BEGIN
                /*******************************************
                 * 병원 별 중환자실 코드 조회
                 *******************************************/
                DECLARE CURSOR DEPT_CD_CURSOR IS SELECT X.DEPT_CD  AS WD_DEPT_CD
                                                      , X.RMK_CNTE AS WD_DEPT_CD_NM
                                                      , X.SORT_SEQ AS SORT_SEQ
                                                   FROM HICU.UCCOCDPM X
                                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD  
--2021-07-08 황선영 [039병동 추가되며, 주석 처리] 
--                                                 UNION 
--                                                 SELECT Y.COMN_CD    AS WD_DEPT_CD
--                                                      , Y.COMN_CD_NM AS WD_DEPT_CD_NM
--                                                      , 99           AS SORT_SEQ
--                                                   FROM HICU.UCCOCSTE Y
--                                                  WHERE Y.HSP_TP_CD   = IN_HIS_HSP_TP_CD
--                                                    AND Y.COMN_GRP_CD = 'IC018'
--                                                  ORDER BY SORT_SEQ
                                                 ;
                REC DEPT_CD_CURSOR%ROWTYPE;
                BEGIN
                    OPEN DEPT_CD_CURSOR;
                    LOOP FETCH DEPT_CD_CURSOR INTO REC;
                    EXIT WHEN DEPT_CD_CURSOR%NOTFOUND;
                
                        /********************************************
                         * 비대면 협진기록 조회 (1)
                         **********************************************/ 
                        BEGIN
                            XICU.PC_EICU_STATISTIC_NONFACE( DTM.UNTC_DTM
                                                          , REC.WD_DEPT_CD
                                                          , REC.WD_DEPT_CD_NM
                                                          , IN_HIS_HSP_TP_CD
                                                          , V_CURSOR
                                                          )
                                                          ;
                                                         
                        END;
                        
                        /********************************************
                         * 비대면 협진기록 BATCH (1)
                         **********************************************/
                        BEGIN
                            LOOP
                            FETCH V_CURSOR 
                             INTO V_COMN_CD
                                , V_DTRL1_NM    
                                ;
                            EXIT WHEN V_CURSOR%NOTFOUND;
                                BEGIN
                                    --비대면 협진기록 ( UCOSCNSD ) UPDATE OR INSERT
                                    MERGE INTO HICU.UCOSCNSD A
                                         USING DUAL
                                            ON (       A.UNTC_REC_DT   = TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                 AND   A.HSP_TP_CD     = IN_HIS_HSP_TP_CD
                                                 AND   A.RER_DEPT_CD   = REC.WD_DEPT_CD
                                               )
                                        WHEN MATCHED
                                        THEN UPDATE SET A.WHL_CSLT_CNT    = DECODE(V_COMN_CD, 'WHL_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), A.WHL_CSLT_CNT)
                                                      , A.SGL_CSLT_CNT    = DECODE(V_COMN_CD, 'SGL_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), A.SGL_CSLT_CNT)
                                                      , A.MIX_CSLT_CNT    = DECODE(V_COMN_CD, 'MIX_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), A.MIX_CSLT_CNT)
                                                      , A.OTDP_RPLY_CNT   = DECODE(V_COMN_CD, 'OTDP_RPLY_CNT', TO_NUMBER(V_DTRL1_NM), A.OTDP_RPLY_CNT)
                                                      , A.SMP_IQRY_CNT    = DECODE(V_COMN_CD, 'SMP_IQRY_CNT', TO_NUMBER(V_DTRL1_NM), A.SMP_IQRY_CNT)
                                                      , A.PT_STS_INSP_CNT = DECODE(V_COMN_CD, 'PT_STS_INSP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_STS_INSP_CNT)
                                                      , A.MNTR_CNT        = DECODE(V_COMN_CD, 'MNTR_CNT', TO_NUMBER(V_DTRL1_NM), A.MNTR_CNT)
                                                      , A.ETC_CNT         = DECODE(V_COMN_CD, 'ETC_CNT', TO_NUMBER(V_DTRL1_NM), A.ETC_CNT)                                                      
                                        WHEN NOT MATCHED
                                        THEN INSERT ( A.UNTC_REC_DT 
                                                    , A.HSP_TP_CD
                                                    , A.RER_DEPT_CD
                                                    , A.RER_DEPT_CD_NM
                                                    , A.UNTC_REC_YY
                                                    , A.UNTC_REC_MM
                                                    , A.UNTC_REC_DY
                                                    , A.WHL_CSLT_CNT
                                                    , A.SGL_CSLT_CNT
                                                    , A.MIX_CSLT_CNT
                                                    , A.OTDP_RPLY_CNT
                                                    , A.SMP_IQRY_CNT
                                                    , A.PT_STS_INSP_CNT
                                                    , A.MNTR_CNT
                                                    , A.ETC_CNT
                                                    , A.LOD_DTM
                                                    )
                                             VALUES ( TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                    , IN_HIS_HSP_TP_CD
                                                    , REC.WD_DEPT_CD
                                                    , REC.WD_DEPT_CD_NM
                                                    , TO_CHAR(DTM.UNTC_DTM, 'YYYY')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'MM')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'DD')
                                                    , DECODE(V_COMN_CD, 'WHL_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SGL_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MIX_CSLT_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'OTDP_RPLY_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SMP_IQRY_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'PT_STS_INSP_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MNTR_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'ETC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , SYSDATE
                                                    )
                                    ;
                                    
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            IO_ERR_YN  := 'Y';
                                            IO_ERR_MSG := '1) 비대면 협진기록 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                        RETURN;
                                END; --비대면 협진기록 ( UCOSCNSD )  BATCH END        
                            END LOOP;
                            COMMIT;
                        END;
                        
                        /********************************************
                         * 비대면 영상 조회 (2)
                         **********************************************/ 
                        BEGIN
                            XICU.PC_EICU_STATISTIC_EZOTC( DTM.UNTC_DTM
                                                        , REC.WD_DEPT_CD
                                                        , REC.WD_DEPT_CD_NM
                                                        , IN_HIS_HSP_TP_CD
                                                        , V_CURSOR
                                                        )
                                                        ;
                                                         
                        END;
                        
                        /********************************************
                         * 비대면 영상 BATCH (2)
                         **********************************************/
                        BEGIN
                            LOOP
                            FETCH V_CURSOR 
                             INTO V_COMN_CD
                                , V_DTRL1_NM    
                                ;
                            EXIT WHEN V_CURSOR%NOTFOUND;
                                BEGIN
                                    --비대면 영상 ( UCOSNFLD ) UPDATE OR INSERT
                                    MERGE INTO HICU.UCOSNFLD A
                                         USING DUAL
                                            ON (       A.UNTC_DT         = TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                 AND   A.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                                                 AND   A.PT_WD_DEPT_CD   = REC.WD_DEPT_CD
                                               )
                                        WHEN MATCHED
                                        THEN UPDATE SET A.WHL_TELC_CNT      = DECODE(V_COMN_CD, 'WHL_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.WHL_TELC_CNT)
                                                      , A.SGL_UNTC_TELC_CNT = DECODE(V_COMN_CD, 'SGL_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.SGL_UNTC_TELC_CNT)
                                                      , A.MIX_UNTC_TELC_CNT = DECODE(V_COMN_CD, 'MIX_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.MIX_UNTC_TELC_CNT)
                                                      , A.SDY_CNSL_TM       = DECODE(V_COMN_CD, 'SDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.SDY_CNSL_TM)
                                                      , A.MDY_CNSL_TM       = DECODE(V_COMN_CD, 'MDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.MDY_CNSL_TM)
                                                      , A.UDY_CNSL_TM       = DECODE(V_COMN_CD, 'UDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.UDY_CNSL_TM)
                                                      , A.WDY_CNSL_TM       = DECODE(V_COMN_CD, 'WDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.WDY_CNSL_TM)
                                                      , A.TRDY_CNSL_TM      = DECODE(V_COMN_CD, 'TRDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.TRDY_CNSL_TM)                                                      
                                                      , A.FDY_CNSL_TM       = DECODE(V_COMN_CD, 'FDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.FDY_CNSL_TM)                                                      
                                                      , A.ADY_CNSL_TM       = DECODE(V_COMN_CD, 'ADY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.ADY_CNSL_TM)                                                      
                                        WHEN NOT MATCHED
                                        THEN INSERT ( A.UNTC_DT
                                                    , A.HSP_TP_CD
                                                    , A.PT_WD_DEPT_CD
                                                    , A.PT_WD_DEPT_CD_NM
                                                    , A.UNTC_PCTR_YY
                                                    , A.UNTC_PCTR_MM
                                                    , A.UNTC_PCTR_DY
                                                    , A.WHL_TELC_CNT
                                                    , A.SGL_UNTC_TELC_CNT
                                                    , A.MIX_UNTC_TELC_CNT
                                                    , A.SDY_CNSL_TM
                                                    , A.MDY_CNSL_TM
                                                    , A.UDY_CNSL_TM
                                                    , A.WDY_CNSL_TM
                                                    , A.TRDY_CNSL_TM
                                                    , A.FDY_CNSL_TM
                                                    , A.ADY_CNSL_TM
                                                    , A.LOD_DTM
                                                    )
                                             VALUES ( TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                    , IN_HIS_HSP_TP_CD
                                                    , REC.WD_DEPT_CD
                                                    , REC.WD_DEPT_CD_NM
                                                    , TO_CHAR(DTM.UNTC_DTM, 'YYYY')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'MM')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'DD')
                                                    , DECODE(V_COMN_CD, 'WHL_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SGL_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MIX_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'UDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'WDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'TRDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'FDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'ADY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , SYSDATE
                                                    )
                                    ;
                                    
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            IO_ERR_YN  := 'Y';
                                            IO_ERR_MSG := '2) 비대면 영상 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                        RETURN;
                                END; --비대면 영상 ( UCOSNFLD )  BATCH END
                            END LOOP;
                            COMMIT;
                        END;
                    END LOOP; --DEPT_CD_CURSOR 종료
                    CLOSE DEPT_CD_CURSOR;
                    
                    BEGIN
                        /********************************************
                         * 비대면 영상 조회 (3 : ETC) 
                         **********************************************/ 
                        BEGIN
                            XICU.PC_EICU_STATISTIC_EZOTC( DTM.UNTC_DTM
                                                        , 'ETC'
                                                        , 'ETC'
                                                        , IN_HIS_HSP_TP_CD
                                                        , V_CURSOR
                                                        )
                                                        ;
                                                         
                        END;
                        
                        /********************************************
                         * 비대면 영상 BATCH (3)
                         **********************************************/
                        BEGIN
                            LOOP
                            FETCH V_CURSOR 
                             INTO V_COMN_CD
                                , V_DTRL1_NM    
                                ;
                            EXIT WHEN V_CURSOR%NOTFOUND;
                                BEGIN
                                    --비대면 영상 ( UCOSNFLD : ETC ) UPDATE OR INSERT
                                    MERGE INTO HICU.UCOSNFLD A
                                         USING DUAL
                                            ON (       A.UNTC_DT         = TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                 AND   A.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                                                 AND   A.PT_WD_DEPT_CD   = 'ETC'
                                               )
                                        WHEN MATCHED
                                        THEN UPDATE SET A.WHL_TELC_CNT      = DECODE(V_COMN_CD, 'WHL_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.WHL_TELC_CNT)
                                                      , A.SGL_UNTC_TELC_CNT = DECODE(V_COMN_CD, 'SGL_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.SGL_UNTC_TELC_CNT)
                                                      , A.MIX_UNTC_TELC_CNT = DECODE(V_COMN_CD, 'MIX_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), A.MIX_UNTC_TELC_CNT)
                                                      , A.SDY_CNSL_TM       = DECODE(V_COMN_CD, 'SDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.SDY_CNSL_TM)
                                                      , A.MDY_CNSL_TM       = DECODE(V_COMN_CD, 'MDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.MDY_CNSL_TM)
                                                      , A.UDY_CNSL_TM       = DECODE(V_COMN_CD, 'UDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.UDY_CNSL_TM)
                                                      , A.WDY_CNSL_TM       = DECODE(V_COMN_CD, 'WDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.WDY_CNSL_TM)
                                                      , A.TRDY_CNSL_TM      = DECODE(V_COMN_CD, 'TRDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.TRDY_CNSL_TM)                                                      
                                                      , A.FDY_CNSL_TM       = DECODE(V_COMN_CD, 'FDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.FDY_CNSL_TM)                                                      
                                                      , A.ADY_CNSL_TM       = DECODE(V_COMN_CD, 'ADY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), A.ADY_CNSL_TM)                                                      
                                        WHEN NOT MATCHED
                                        THEN INSERT ( A.UNTC_DT
                                                    , A.HSP_TP_CD
                                                    , A.PT_WD_DEPT_CD
                                                    , A.PT_WD_DEPT_CD_NM
                                                    , A.UNTC_PCTR_YY
                                                    , A.UNTC_PCTR_MM
                                                    , A.UNTC_PCTR_DY
                                                    , A.WHL_TELC_CNT
                                                    , A.SGL_UNTC_TELC_CNT
                                                    , A.MIX_UNTC_TELC_CNT
                                                    , A.SDY_CNSL_TM
                                                    , A.MDY_CNSL_TM
                                                    , A.UDY_CNSL_TM
                                                    , A.WDY_CNSL_TM
                                                    , A.TRDY_CNSL_TM
                                                    , A.FDY_CNSL_TM
                                                    , A.ADY_CNSL_TM
                                                    , A.LOD_DTM
                                                    )
                                             VALUES ( TO_CHAR(DTM.UNTC_DTM, 'YYYYMMDD')
                                                    , IN_HIS_HSP_TP_CD
                                                    , 'ETC'
                                                    , 'ETC'
                                                    , TO_CHAR(DTM.UNTC_DTM, 'YYYY')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'MM')
                                                    , TO_CHAR(DTM.UNTC_DTM, 'DD')
                                                    , DECODE(V_COMN_CD, 'WHL_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SGL_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MIX_UNTC_TELC_CNT', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'SDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'MDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'UDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'WDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'TRDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'FDY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , DECODE(V_COMN_CD, 'ADY_CNSL_TM', TO_NUMBER(V_DTRL1_NM), 0)
                                                    , SYSDATE
                                                    )
                                    ;
                                    
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            IO_ERR_YN  := 'Y';
                                            IO_ERR_MSG := '3) 비대면 영상(ETC) 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                        RETURN;
                                END; --비대면 영상 ( UCOSNFLD : ETC )  BATCH END
                            END LOOP;
                            COMMIT;
                        END;
                    END;
                END;
            END; -- 변경일자 데이터 BATCH END
        END LOOP; --DTM_CURSOR 종료
        CLOSE DTM_CURSOR;
    END;
END PC_EICU_CENTER_BATCH_NONFACE;
