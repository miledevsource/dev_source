
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_DAY_INCR_BATCH" (    IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                        , IO_ERRYN        IN OUT  VARCHAR2    -- 05. ERROR Y/N
                                        , IO_ERRMSG       IN OUT  VARCHAR2   -- 06. ERROR MESSAGE 
                                        ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_DAY_INCR_BATCH
*    CREATEDATE     : 2021.09.15
*    Author         : 황선영
*    Description    : KHF 전시회 시연기 작업을 위해 모든 ICU 테이블과 관련된 날짜 + 1 증가 
*    Change History : 2021.09.15, 황선영, 최초작성
**********************************************************************************************/
 AS
 BEGIN
     -- 1 ) RRS_VALUE UPDATE
      BEGIN
            UPDATE RRS_VALUE
               SET ENT_DT = TO_CHAR(TO_DATE(ENT_DT,'YYYY-MM-DD') +1,'YYYYMMDD')
                  , ENT_DTM = ENT_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- RRS_VALUE UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;  
      -- 2) RRS_VALUE_H UPDATE
      BEGIN
            UPDATE RRS_VALUE_H
               SET ENT_DT = TO_CHAR(TO_DATE(ENT_DT,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , ENT_DTM = ENT_DTM +1
                 , REG_DTM = REG_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- RRS_VALUE_H UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 3) UCCICSDD UPDATE
      BEGIN
            UPDATE UCCICSDD
               SET CHOT_DT_SEQ = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , LOD_DTM     = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSDD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 4) UCCICSDM UPDATE
      BEGIN
            UPDATE UCCICSDM
               SET CHOT_DT_SEQ = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , CHOT_YY     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'YYYY')
                 , CHOT_MM     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'MM')
                 , CHOT_DY     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM     = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSDM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;	 
      -- 5) UCCICSOD UPDATE
      BEGIN
            UPDATE UCCICSOD
               SET CHOT_DT_SEQ = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , CHOT_YY     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'YYYY')
                 , CHOT_MM     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'MM')
                 , CHOT_DY     = TO_CHAR(TO_DATE(CHOT_DT_SEQ,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM     = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSOD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 6) UCCICSPD UPDATE
      BEGIN
            UPDATE UCCICSPD
               SET ETRM_DT_SEQ = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , LOD_DTM     = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSPD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 7) UCCICSPM UPDATE
      BEGIN
            UPDATE UCCICSPM
               SET ETRM_DT_SEQ = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , ETRM_YY     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYY')
                 , ETRM_MM     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'MM')
                 , ETRM_DY     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM     = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSPM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 8) UCCICSRD UPDATE
      BEGIN
            UPDATE UCCICSRD
              SET TH2_ETRM_DT_SEQ = TO_CHAR(TO_DATE(TH2_ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , LOD_DTM         = LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSRD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 9) UCCICSRM UPDATE
      BEGIN
            UPDATE UCCICSRM
               SET TH2_ETRM_DT_SEQ = TO_CHAR(TO_DATE(TH2_ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , TH2_ETRM_YY     = TO_CHAR(TO_DATE(TH2_ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYY')
                 , TH2_ETRM_MM     = TO_CHAR(TO_DATE(TH2_ETRM_DT_SEQ,'YYYY-MM-DD') +1,'MM')
                 , TH2_ETRM_DY     = TO_CHAR(TO_DATE(TH2_ETRM_DT_SEQ,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM         = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCICSRM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 10) UCCIISPM UPDATE
      BEGIN
            UPDATE UCCIISPM
               SET ETRM_DT_SEQ = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , ETRM_YY     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'YYYY')
                 , ETRM_MM     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'MM')
                 , ETRM_DY     = TO_CHAR(TO_DATE(ETRM_DT_SEQ,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM     = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCCIISPM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 11) UCOSCNSD UPDATE
      BEGIN
            UPDATE UCOSCNSD
               SET UNTC_REC_DT = TO_CHAR(TO_DATE(UNTC_REC_DT,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , UNTC_REC_YY = TO_CHAR(TO_DATE(UNTC_REC_DT,'YYYY-MM-DD') +1,'YYYY')
                 , UNTC_REC_MM = TO_CHAR(TO_DATE(UNTC_REC_DT,'YYYY-MM-DD') +1,'MM')
                 , UNTC_REC_DY = TO_CHAR(TO_DATE(UNTC_REC_DT,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM     = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCOSCNSD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 12) UCOSCOSD UPDATE
      BEGIN
            UPDATE UCOSCOSD
               SET RPLY_DT = TO_CHAR(RPLY_DT +1,'YYYYMMDD')
                 , RPLY_YY = TO_CHAR(RPLY_DT +1,'YYYY')
                 , RPLY_MM = TO_CHAR(RPLY_DT +1,'MM')
                 , RPLY_DY = TO_CHAR(RPLY_DT +1,'DD')
                 , LOD_DTM = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCOSCOSD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;  
      -- 13) UCOSNFLD UPDATE
      BEGIN
            UPDATE UCOSNFLD
               SET UNTC_DT       = TO_CHAR(TO_DATE(UNTC_DT,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , UNTC_PCTR_YY  = TO_CHAR(TO_DATE(UNTC_DT,'YYYY-MM-DD') +1,'YYYY')
                 , UNTC_PCTR_MM  = TO_CHAR(TO_DATE(UNTC_DT,'YYYY-MM-DD') +1,'MM')
                 , UNTC_PCTR_DY  = TO_CHAR(TO_DATE(UNTC_DT,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM       = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCOSNFLD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;  
      -- 14) UCOSRRSD UPDATE
      BEGIN
            UPDATE UCOSRRSD
               SET OCUR_DT = TO_CHAR(TO_DATE(OCUR_DT,'YYYY-MM-DD') +1,'YYYYMMDD')
                 , OCUR_YY = TO_CHAR(TO_DATE(OCUR_DT,'YYYY-MM-DD') +1,'YYYY')
                 , OCUR_MM = TO_CHAR(TO_DATE(OCUR_DT,'YYYY-MM-DD') +1,'MM')
                 , OCUR_DY = TO_CHAR(TO_DATE(OCUR_DT,'YYYY-MM-DD') +1,'DD')
                 , LOD_DTM = LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UCOSRRSD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 15) UICICRAD UPDATE
      BEGIN
            UPDATE UICICRAD
               SET INPT_DTM      = INPT_DTM+1
                 , ICU_ETRM_DTM  = ICU_ETRM_DTM+1
                 , FST_WRT_DTM   = FST_WRT_DTM+1
                 , LST_CHG_DTM   = LST_CHG_DTM+1
                 , FST_LOD_DTM   = FST_LOD_DTM+1
                 , LST_LOD_DTM   = LST_LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRAD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 16) UICICRCD UPDATE
      BEGIN
            UPDATE UICICRCD
               SET REC_DTM      = REC_DTM +1
                 , MDF_REC_DTM  = MDF_REC_DTM +1
                 , FST_WRT_DTM  = FST_WRT_DTM +1
                 , LST_CHG_DTM  = LST_CHG_DTM +1
                 , FST_LOD_DTM  = FST_LOD_DTM +1
                 , LST_LOD_DTM  = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRCD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 17) UICICRDD UPDATE
      BEGIN
            UPDATE UICICRDD
               SET DS_DT         = DS_DT +1
                 , FST_WRT_DTM   = FST_WRT_DTM +1
                 , LST_CHG_DTM   = LST_CHG_DTM +1
                 , FST_LOD_DTM   = FST_LOD_DTM +1
                 , LST_LOD_DTM   = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRDD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 18) UICICRID UPDATE
      BEGIN
            UPDATE UICICRID
               SET ETRM_DTM     = ETRM_DTM +1
                 , CHOT_DTM     = CHOT_DTM +1
                 , FST_WRT_DTM  = FST_WRT_DTM +1
                 , LST_CHG_DTM  = LST_CHG_DTM +1
                 , FST_LOD_DTM  = FST_LOD_DTM +1
                 , LST_LOD_DTM  = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRID UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;          
      -- 19) UICICROD UPDATE
      BEGIN
            UPDATE UICICROD
               SET OP_EXPT_DT   = OP_EXPT_DT +1
                 , AOM_DTM      = AOM_DTM +1
                 , FST_WRT_DTM  = FST_WRT_DTM +1
                 , LST_CHG_DTM  = LST_CHG_DTM +1
                 , FST_LOD_DTM  = FST_LOD_DTM +1
                 , LST_LOD_DTM  = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICROD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 20) UICICRPM UPDATE
      BEGIN
            UPDATE UICICRPM
               SET ADS_DT       = ADS_DT +1
                 , DS_EXPT_DT   = DS_EXPT_DT +1
                 , FST_WRT_DTM  = FST_WRT_DTM +1
                 , LST_CHG_DTM  = LST_CHG_DTM +1
                 , FST_LOD_DTM  = FST_LOD_DTM +1
                 , LST_LOD_DTM  = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRPM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 21) UICICRSD UPDATE
      BEGIN
            UPDATE UICICRSD
               SET CTG_DTM     = CTG_DTM+1
                 , FST_WRT_DTM = FST_WRT_DTM+1
                 , LST_CHG_DTM = LST_CHG_DTM+1
                 , FST_LOD_DTM = FST_LOD_DTM+1
                 , LST_LOD_DTM = LST_LOD_DTM+1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICRSD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 22) UICICSDD UPDATE
      BEGIN
            UPDATE UICICSDD
               SET PT_SILLM_CTG_DTM  = PT_SILLM_CTG_DTM +1
                 , FST_LOD_DTM       = FST_LOD_DTM +1
                 , LST_LOD_DTM       = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSDD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;     
      -- 23) UICICSDM UPDATE
      BEGIN
            UPDATE UICICSDM
               SET ADS_DT             = ADS_DT +1
                 , DS_EXPT_DT         = DS_EXPT_DT +1
                 , ETRM_DTM           = ETRM_DTM +1
                 , CHOT_DTM           = CHOT_DTM +1
                 , APCS_REC_INPT_DTM  = APCS_REC_INPT_DTM +1
                 , DTH_DGCT_WRT_DTM   = DTH_DGCT_WRT_DTM +1
                 , DTH_DT             = DTH_DT +1
                 , FST_LOD_DTM        = FST_LOD_DTM +1
                 , LST_LOD_DTM        = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSDM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 24) UICICSPD UPDATE
      BEGIN
            UPDATE UICICSPD
               SET PT_SILLM_CTG_DTM = PT_SILLM_CTG_DTM +1
                 , FST_LOD_DTM      = FST_LOD_DTM +1
                 , LST_LOD_DTM      = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSPD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 25) UICICSPM UPDATE
      BEGIN
            UPDATE UICICSPM
               SET ADS_DT           = ADS_DT +1
                 , DS_EXPT_DT       = DS_EXPT_DT +1
                 , ETRM_DTM         = ETRM_DTM +1
                 , CHOT_DTM         = CHOT_DTM  +1
                 , FST_LOD_DTM      = FST_LOD_DTM +1
                 , LST_LOD_DTM      = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSPM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;   
      -- 26) UICICSRD UPDATE
      BEGIN
            UPDATE UICICSRD
               SET PT_SILLM_CTG_DTM = PT_SILLM_CTG_DTM +1
                 , FST_LOD_DTM      = FST_LOD_DTM +1
                 , LST_LOD_DTM      = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSRD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;    
      -- 27) UICICSRM UPDATE
      BEGIN
            UPDATE UICICSRM
               SET ADS_DT      = ADS_DT + 1
                 , DS_EXPT_DT  = DS_EXPT_DT + 1
                 , TH1_ETRM_DTM  = TH1_ETRM_DTM + 1
                 , TH2_ETRM_DTM  = TH2_ETRM_DTM + 1
                 , TH1_CHOT_DTM  = TH1_CHOT_DTM + 1
                 , TH2_CHOT_DTM  = TH2_CHOT_DTM + 1
                 , APCS_REC_INPT_DTM = APCS_REC_INPT_DTM + 1
                 , FST_LOD_DTM = FST_LOD_DTM + 1
                 , LST_LOD_DTM = LST_LOD_DTM + 1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICICSRM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;   
      -- 28) UICIIRCD UPDATE
      BEGIN
            UPDATE UICIIRCD
               SET ODRER_DT   = ODRER_DT +1
                 , ODRER_DTM  = ODRER_DTM +1
                 , RPLY_DT    = RPLY_DT +1
                 , RPLY_DTM   = RPLY_DTM +1
                 , ODRER_REP_CRE_DTM = ODRER_REP_CRE_DTM +1
                 , FSR_DTM       = FSR_DTM +1
                 , LSH_DTM       = LSH_DTM +1
                 , FST_LOD_DTM   = FST_LOD_DTM +1
                 , LST_LOG_DTM   = LST_LOG_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIIRCD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;  
      -- 29) UICIIRED UPDATE
      BEGIN
            UPDATE UICIIRED
               SET REC_DTM      = REC_DTM +1
                 , MDF_REC_DTM  = MDF_REC_DTM +1
                 , FST_WRT_DTM  = FST_WRT_DTM +1
                 , LST_CHG_DTM  = LST_CHG_DTM +1
                 , FST_LOD_DTM  = FST_LOD_DTM +1
                 , LST_LOD_DTM  = LST_LOD_DTM +1
            ;  
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIIRED UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;    
      -- 30) UICIIRHD UPDATE
      BEGIN
            MERGE INTO HICU.UICIIRHD A  --휴일정
			     USING (
			            SELECT DT_CD + 1                                                                                      DT_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'년 '||TO_CHAR(DT_CD + 1,'MM')||'월 '||TO_CHAR(DT_CD + 1,'DD')||'일' DT_NM
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'-'||TO_CHAR(DT_CD + 1,'MM')||'-'||TO_CHAR(DT_CD + 1,'DD')          YMD_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')                                                                      YY_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'년'                                                                YY_NM
			                 , CASE WHEN TO_CHAR(DT_CD + 1,'MM') < 7 THEN TO_CHAR(DT_CD + 1,'YYYY') || '-1'
			                        WHEN TO_CHAR(DT_CD + 1,'MM') >= 7 THEN TO_CHAR(DT_CD + 1,'YYYY') || '-2'
			                   END                                                                                            HTERM_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'년'||(CASE WHEN TO_CHAR(DT_CD + 1,'Q') IN ('1','2') THEN ' 상'
			                                                          WHEN TO_CHAR(DT_CD + 1,'Q') IN ('3','4') THEN ' 하'
			                                                     END)||'반기'                                                  HTERM_NM
			                 , SUBSTR(TO_CHAR(DT_CD + 1,'YYYYQ'),1,4)||'-'||SUBSTR(TO_CHAR(DT_CD + 1,'YYYYQ'),5,1)            QUT_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'년 '||TO_CHAR(DT_CD + 1,'Q')||'분기'                                QUT_NM
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'-'||TO_CHAR(DT_CD + 1,'MM')                                        YYMM_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'년 '||TO_CHAR(DT_CD + 1,'MM')||'월'                                 YYMM_NM
			                 , TO_CHAR(DT_CD + 1,'YYYY')||'-'||TO_CHAR(DT_CD + 1,'MM')||'-'|| ((TRUNC (DT_CD + 1, 'D') - TRUNC (TRUNC (DT_CD + 1, 'MM'), 'D')) / 7 + 1) YMW_CD
			                 , TO_CHAR(DT_CD + 1,'YYYY') ||'년 ' || TO_CHAR(DT_CD + 1,'MM') ||'월 ' || ((TRUNC (DT_CD + 1, 'D') - TRUNC (TRUNC (DT_CD + 1, 'MM'), 'D')) / 7 + 1) || '주' YMW_NM
			                 , TO_CHAR(DT_CD + 1, 'DY', 'NLS_DATE_LANGUAGE=KOREAN')                                      DOW_NM
			                 , TO_CHAR(DT_CD + 1,'DD')                                                                   DAY_CD
			                 , TO_CHAR(DT_CD + 1,'DD') || '일'                                                           DAY_NM
			                 , (SELECT DECODE(COUNT(Z.HDY_DT),0,NULL,'Y')
			                      FROM CCCCCHOD  Z
			                     WHERE Z.HDY_DT = D.DT_CD + 1)                                                           HLDY_YN
			                 , NVL((SELECT FSR_DTM
			                          FROM CCCCCHOD  Z
			                         WHERE Z.HDY_DT = D.DT_CD + 1),  D.FSR_DTM )                                         FSR_DTM   -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경 - 20210408 임정립 팀장 요청으로 공휴일 정보로 변경
			                 , NVL((SELECT LSH_DTM
			                          FROM CCCCCHOD  Z
			                         WHERE Z.HDY_DT = D.DT_CD + 1),  D.LSH_DTM )                                         LSH_DTM   -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경 - 20210408 임정립 팀장 요청으로 공휴일 정보로 변경
			              FROM UICIIRHD  D
			             WHERE DT_CD = TO_DATE(TO_CHAR(SYSDATE,'YYYY-MM-DD')) ) B
			             ON (     A.DT_CD                        = B.DT_CD )
			   WHEN MATCHED THEN
			       UPDATE SET
			                   A.DT_NM	     = B.DT_NM
			                 , A.YMD_CD	     = B.YMD_CD
			                 , A.YY_CD	     = B.YY_CD
			                 , A.YY_NM	     = B.YY_NM
			                 , A.HTERM_CD	 = B.HTERM_CD
			                 , A.HTERM_NM	 = B.HTERM_NM
			                 , A.QUT_CD	     = B.QUT_CD
			                 , A.QUT_NM	     = B.QUT_NM
			                 , A.YYMM_CD	 = B.YYMM_CD
			                 , A.YYMM_NM	 = B.YYMM_NM
			                 , A.YMW_CD	     = B.YMW_CD
			                 , A.YMW_NM	     = B.YMW_NM
			                 , A.DOW_NM	     = B.DOW_NM
			                 , A.DAY_CD	     = B.DAY_CD
			                 , A.DAY_NM	     = B.DAY_NM
			                 , A.HLDY_YN	 = B.HLDY_YN
--			                 , A.FSR_DTM	 = B.FSR_DTM
			                 , A.LSH_DTM     = B.LSH_DTM
--			                 , A.FST_LOD_DTM = SYSDATE
			                 , A.LST_LOG_DTM = SYSDATE

			  WHEN NOT MATCHED THEN
			      INSERT (
			                 A.DT_CD
			               ,  A.DT_NM
			               , A.YMD_CD
			               , A.YY_CD
			               , A.YY_NM
			               , A.HTERM_CD
			               , A.HTERM_NM
			               , A.QUT_CD
			               , A.QUT_NM
			               , A.YYMM_CD
			               , A.YYMM_NM
			               , A.YMW_CD
			               , A.YMW_NM
			               , A.DOW_NM
			               , A.DAY_CD
			               , A.DAY_NM
			               , A.HLDY_YN
			               , A.FSR_DTM
			               , A.LSH_DTM
			               , A.FST_LOD_DTM
			               , A.LST_LOG_DTM
			        )
			      VALUES (
			                 B.DT_CD
			               , B.DT_NM
			               , B.YMD_CD
			               , B.YY_CD
			               , B.YY_NM
			               , B.HTERM_CD
			               , B.HTERM_NM
			               , B.QUT_CD
			               , B.QUT_NM
			               , B.YYMM_CD
			               , B.YYMM_NM
			               , B.YMW_CD
			               , B.YMW_NM
			               , B.DOW_NM
			               , B.DAY_CD
			               , B.DAY_NM
			               , B.HLDY_YN
			               , B.FSR_DTM
			               , B.LSH_DTM
			               , SYSDATE
			               , SYSDATE
			          );
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIIRHD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;   
      -- 31) UICIIRID UPDATE
      BEGIN
             UPDATE UICIIRID
                SET ETRM_DTM  = ETRM_DTM +1
                  , CHOT_DTM  = CHOT_DTM +1
                  , FST_WRT_DTM  = FST_WRT_DTM +1
                  , LST_CHG_DTM  = LST_CHG_DTM +1
                  , FST_LOD_DTM  = FST_LOD_DTM +1
                  , LST_LOD_DTM  = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIIRID UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 32) UICIIRPD UPDATE
      BEGIN
             UPDATE UICIIRPD
                SET ADS_DT       = ADS_DT +1
                  , DS_EXPT_DT   = DS_EXPT_DT +1
                  , EMRM_ARVL_DTM = EMRM_ARVL_DTM +1
                  , FST_WRT_DTM   = FST_WRT_DTM +1
                  , LST_CHG_DTM   = LST_CHG_DTM +1
                  , FST_LOD_DTM   = FST_LOD_DTM +1
                  , LST_LOD_DTM   = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIIRPD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END; 
      -- 33) UICIISPD UPDATE
      BEGIN
             UPDATE UICIISPD
                SET PT_SILLM_CTG_DTM = PT_SILLM_CTG_DTM +1
                  , FST_LOD_DTM      = FST_LOD_DTM +1
                  , LST_LOD_DTM      = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIISPD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
      -- 34) UICIISPM UPDATE
      BEGIN
             UPDATE UICIISPM
                SET ETRM_DTM  = ETRM_DTM +1
                  , ADS_DT    = ADS_DT +1
                  , DS_EXPT_DT = DS_EXPT_DT +1
                  , CHOT_DTM   = CHOT_DTM +1
                  , EMRM_ARVL_DTM = EMRM_ARVL_DTM +1
                  , FST_LOD_DTM   = FST_LOD_DTM +1
                  , LST_LOD_DTM   = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIISPM UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;  
      -- 35) UICIRRSD UPDATE
      BEGIN
             UPDATE UICIRRSD
                SET INPT_DTM   = INPT_DTM +1
                  , INPT_DT    = INPT_DT +1
                  , FST_LOD_DTM = FST_LOD_DTM +1
                  , LST_LOD_DTM = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIRRSD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;   
      -- 36) UICISROD UPDATE
      BEGIN
             UPDATE UICISROD
                SET OP_EXPT_DT  = OP_EXPT_DT +1
                  , FST_LOD_DTM = FST_LOD_DTM +1
                  , LST_LOD_DTM = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICISROD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;   
      -- 36) UICIWBCD UPDATE
      BEGIN
             UPDATE UICIWBCD
                SET BED_CFMT_DT = BED_CFMT_DT +1
                  , FST_LOD_DTM = FST_LOD_DTM +1
                  , LST_LOD_DTM = LST_LOD_DTM +1

			     ;
            COMMIT; 
            EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_DAY_INCR_BATCH- UICIWBCD UPDATE)' || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
      END;
 END PC_EICU_DAY_INCR_BATCH;
