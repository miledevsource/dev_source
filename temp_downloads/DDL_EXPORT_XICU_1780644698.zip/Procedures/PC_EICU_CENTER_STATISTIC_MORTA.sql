
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_STATISTIC_MORTA" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_STATISTIC_MORTA
*    CREATEDATE     : 2021.03.05
*    Author         : 신솔
*    Description    : 통합관제 중환자실 사망률
*    Change History : 2021.03.05, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            /**********************
            INDICATORS OUT DTO
            ************************/
            WITH CHARTGUB AS (
                 /* 차트 구분 공통코드 */
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                      , A.COMN_CD_EXPL AS COMN_CD_EXPL
                   FROM (SELECT 'AGE_GRP' AS COMN_GRP_CD, '1' AS COMN_CD, '~10대' AS COMN_CD_NM, 'AGE_10_GRP_BLW_CNT' AS COMN_CD_EXPL FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '2', '20대', 'AGE_20_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '3', '30대', 'AGE_30_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '4', '40대', 'AGE_40_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '5', '50대', 'AGE_50_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '6', '60대', 'AGE_60_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '7', '70대~', 'AGE_70_GRP_UPR_CNT' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'F', '여성', 'SEX_FEML_CNT' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'M', '남성', 'SEX_MALE_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '1', '1군', 'PT_SILLM_CTG_1_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '2', '2군', 'PT_SILLM_CTG_2_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '3', '3군', 'PT_SILLM_CTG_3_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '4', '4군', 'PT_SILLM_CTG_4_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '5', '5군', 'PT_SILLM_CTG_5_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '6', '6군', 'PT_SILLM_CTG_6_GRP_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '10', '10', 'APCS_SUM_10_SCR_BLW_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '20', '20', 'APCS_SUM_20_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '30', '30', 'APCS_SUM_30_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '40', '40', 'APCS_SUM_40_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '50', '50', 'APCS_SUM_50_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '60', '60', 'APCS_SUM_60_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '70', '70', 'APCS_SUM_70_SCR_CNT' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '80', '80', 'APCS_SUM_80_SCR_UPR_CNT' FROM DUAL) A
                  ORDER BY A.COMN_GRP_CD
                 )
               , MONTHGUB AS (
                 /* 년간 추이 공통코드 */
                 SELECT TO_CHAR(A.YMD, 'YYYY-MM') AS DTM
                  FROM (
                        SELECT ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) AS YMD
                          FROM DUAL
                       CONNECT BY ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) >= ADD_MONTHS(IN_TO_DT, -11)
                       ) A
                 )
               , BF_MONTH AS (
                 SELECT TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM') AS DTM
                   FROM DUAL            
                 )
               , BF_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '12', 'YYYYMM'), TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , CUR_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYYMM'), 'YYYYMM'), TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , SDATA AS (
                 /* 통합중환자실사망지표기본 */
                 SELECT SUM(A.DTH_PT_CNT)                AS DTH_PT_CNT
                      , SUM(A.CHOT_PT_CNT)               AS CHOT_PT_CNT
                      , SUM(A.SEX_MALE_CNT)              AS SEX_MALE_CNT
                      , SUM(A.SEX_FEML_CNT)              AS SEX_FEML_CNT
                      , SUM(A.AGE_10_GRP_BLW_CNT)        AS AGE_10_GRP_BLW_CNT
                      , SUM(A.AGE_20_GRP_CNT)            AS AGE_20_GRP_CNT
                      , SUM(A.AGE_30_GRP_CNT)            AS AGE_30_GRP_CNT
                      , SUM(A.AGE_40_GRP_CNT)            AS AGE_40_GRP_CNT
                      , SUM(A.AGE_50_GRP_CNT)            AS AGE_50_GRP_CNT
                      , SUM(A.AGE_60_GRP_CNT)            AS AGE_60_GRP_CNT
                      , SUM(A.AGE_70_GRP_UPR_CNT)        AS AGE_70_GRP_UPR_CNT
                      , SUM(A.PT_SILLM_CTG_1_GRP_CNT)    AS PT_SILLM_CTG_1_GRP_CNT
                      , SUM(A.PT_SILLM_CTG_2_GRP_CNT)    AS PT_SILLM_CTG_2_GRP_CNT
                      , SUM(A.PT_SILLM_CTG_3_GRP_CNT)    AS PT_SILLM_CTG_3_GRP_CNT
                      , SUM(A.PT_SILLM_CTG_4_GRP_CNT)    AS PT_SILLM_CTG_4_GRP_CNT
                      , SUM(A.PT_SILLM_CTG_5_GRP_CNT)    AS PT_SILLM_CTG_5_GRP_CNT
                      , SUM(A.PT_SILLM_CTG_6_GRP_CNT)    AS PT_SILLM_CTG_6_GRP_CNT
                      , SUM(A.APCS_SUM_10_SCR_BLW_CNT)   AS APCS_SUM_10_SCR_BLW_CNT
                      , SUM(A.APCS_SUM_20_SCR_CNT)       AS APCS_SUM_20_SCR_CNT
                      , SUM(A.APCS_SUM_30_SCR_CNT)       AS APCS_SUM_30_SCR_CNT
                      , SUM(A.APCS_SUM_40_SCR_CNT)       AS APCS_SUM_40_SCR_CNT
                      , SUM(A.APCS_SUM_50_SCR_CNT)       AS APCS_SUM_50_SCR_CNT
                      , SUM(A.APCS_SUM_60_SCR_CNT)       AS APCS_SUM_60_SCR_CNT
                      , SUM(A.APCS_SUM_70_SCR_CNT)       AS APCS_SUM_70_SCR_CNT
                      , SUM(A.APCS_SUM_80_SCR_UPR_CNT)   AS APCS_SUM_80_SCR_UPR_CNT
                   FROM HICU.UCCICSDM A
                  WHERE A.WD_DEPT_CD  = IN_WD_DEPT_CD
                    AND A.CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                    AND A.HSP_TP_CD   = IN_HIS_HSP_TP_CD
                 )
               , SDATA_FOR_ANNU AS (
                 /* 년간추이 조회용 통합중환자실사망지표기본 */
                 SELECT TO_CHAR(TO_DATE(A.CHOT_DT_SEQ, 'YYYY-MM-DD'), 'YYYY-MM')               AS CHOT_DTM
                      , SUM(A.DTH_PT_CNT)                AS DIE_CNT
                      , SUM(A.CHOT_PT_CNT)               AS OUT_CNT
                   FROM HICU.UCCICSDM A
                  WHERE A.WD_DEPT_CD  = IN_WD_DEPT_CD
                    AND A.CHOT_DT_SEQ BETWEEN TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '0101' AND TO_CHAR(LAST_DAY(IN_TO_DT), 'YYYYMMDD')
                    AND A.HSP_TP_CD   = IN_HIS_HSP_TP_CD
                  GROUP BY TO_CHAR(TO_DATE(A.CHOT_DT_SEQ, 'YYYY-MM-DD'), 'YYYY-MM')
                 )
               , DTHTABLE AS (
                 /* 사망률 현황 */
                 SELECT 'DTH_RATE' AS COMN_GRP_CD
                      , '01'       AS COMN_CD
                      , '사망률 현황'  AS COMN_CD_NM
                      , 'PT_CNT'   AS COMN_CD_EXPL
                      , TO_CHAR(NVL((SELECT DTH_PT_CNT FROM SDATA), 0))  AS DTRL1_NM
                      , TO_CHAR(NVL((SELECT CHOT_PT_CNT FROM SDATA), 0)) AS DTRL2_NM
                      , RTRIM(TO_CHAR(NVL(DECODE((SELECT CHOT_PT_CNT FROM SDATA), 0, 0
                              , ROUND(((SELECT DTH_PT_CNT FROM SDATA) / (SELECT CHOT_PT_CNT FROM SDATA)) * 100, 1)), 0), 'FM9990.9'), '.') AS DTRL3_NM
                   FROM DUAL
                 )
               , DEPTTABLE AS (
                 /* 진료과별 사망환자 */
                 SELECT 'BY_DEPT'             AS COMN_GRP_CD
                      , A.RPRN_MED_DEPT_CD    AS COMN_CD
                      , A.RPRN_MED_DEPT_CD_NM AS COMN_CD_NM
                      , '진료과별 사망환자'          AS COMN_CD_EXPL
                      , TO_CHAR(SUM(A.SIRM_PT_CNT))   AS DTRL1_NM
                      , '' AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM HICU.UCCICSDD A
                  WHERE A.WD_DEPT_CD  = IN_WD_DEPT_CD
                    AND A.CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                    AND A.HSP_TP_CD   = IN_HIS_HSP_TP_CD
                  GROUP BY A.RPRN_MED_DEPT_CD, A.RPRN_MED_DEPT_CD_NM
                 )
               , GUBDATA AS (
                 /* 차트구분별 사망환자 */
                 SELECT 'AGE_GRP'    AS COMN_GRP_CD
                      , COMN_CD_EXPL AS COMN_CD_EXPL
                      , DTRL1_NM     AS DTRL1_NM
                      , ''     AS DTRL2_NM
                      , ''     AS DTRL3_NM
                   FROM SDATA
                UNPIVOT (DTRL1_NM FOR COMN_CD_EXPL
                                   IN ( AGE_10_GRP_BLW_CNT
                                      , AGE_20_GRP_CNT
                                      , AGE_30_GRP_CNT
                                      , AGE_40_GRP_CNT
                                      , AGE_50_GRP_CNT
                                      , AGE_60_GRP_CNT
                                      , AGE_70_GRP_UPR_CNT
                                      )
                        )            

                 UNION ALL            

                 SELECT 'APCS_SUM_SCR_GRP'    AS COMN_GRP_CD
                      , COMN_CD_EXPL AS COMN_CD_EXPL
                      , DTRL1_NM     AS DTRL1_NM
                      , ''     AS DTRL2_NM
                      , ''     AS DTRL3_NM
                   FROM SDATA
                UNPIVOT (DTRL1_NM FOR COMN_CD_EXPL
                                   IN ( APCS_SUM_10_SCR_BLW_CNT
                                      , APCS_SUM_20_SCR_CNT
                                      , APCS_SUM_30_SCR_CNT
                                      , APCS_SUM_40_SCR_CNT
                                      , APCS_SUM_50_SCR_CNT
                                      , APCS_SUM_60_SCR_CNT
                                      , APCS_SUM_70_SCR_CNT
                                      , APCS_SUM_80_SCR_UPR_CNT
                                      )
                        )            

                 UNION ALL            

                 SELECT 'PT_SILLM_CTG_GRP'    AS COMN_GRP_CD
                      , COMN_CD_EXPL AS COMN_CD_EXPL
                      , DTRL1_NM     AS DTRL1_NM
                      , ''     AS DTRL2_NM
                      , ''     AS DTRL3_NM
                   FROM SDATA
                UNPIVOT (DTRL1_NM FOR COMN_CD_EXPL
                                   IN ( PT_SILLM_CTG_1_GRP_CNT
                                      , PT_SILLM_CTG_2_GRP_CNT
                                      , PT_SILLM_CTG_3_GRP_CNT
                                      , PT_SILLM_CTG_4_GRP_CNT
                                      , PT_SILLM_CTG_5_GRP_CNT
                                      , PT_SILLM_CTG_6_GRP_CNT
                                      )
                        )            

                 UNION ALL            

                 SELECT 'SEX_GRP'    AS COMN_GRP_CD
                      , COMN_CD_EXPL AS COMN_CD_EXPL
                      , DTRL1_NM     AS DTRL1_NM
                      , ''     AS DTRL2_NM
                      , ''     AS DTRL3_NM
                   FROM SDATA
                UNPIVOT (DTRL1_NM FOR COMN_CD_EXPL
                                   IN ( SEX_FEML_CNT
                                      , SEX_MALE_CNT
                                      )
                        )
                 )
               , GUBTABLE AS (
                 SELECT A.COMN_GRP_CD       AS COMN_GRP_CD
                      , A.COMN_CD           AS COMN_CD
                      , A.COMN_CD_NM        AS COMN_CD_NM
                      , A.COMN_CD_EXPL      AS COMN_CD_EXPL
                      , TO_CHAR(B.DTRL1_NM) AS DTRL1_NM
                      , TO_CHAR(B.DTRL2_NM) AS DTRL2_NM
                      , TO_CHAR(B.DTRL3_NM) AS DTRL3_NM
                   FROM CHARTGUB A
                      , GUBDATA  B
                  WHERE A.COMN_GRP_CD  = B.COMN_GRP_CD
                    AND A.COMN_CD_EXPL = B.COMN_CD_EXPL
                  ORDER BY A.COMN_GRP_CD, A.COMN_CD
                 )
               , AVGTABLE AS (
                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'BF_YEAR'  AS COMN_CD
                      , '전년월평균'   AS COMN_CD_NM
                      , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(CEIL(SUM(DIE_CNT) / COUNT(*)))  AS DTRL1_NM
                      , TO_CHAR(CEIL(SUM(OUT_CNT) / COUNT(*)))  AS DTRL2_NM
                      , TO_CHAR(ROUND(SUM(DTH_RATE) / COUNT(*), 2)) AS DTRL3_NM
                   FROM (
                         SELECT DTM
                              , DIE_CNT
                              , OUT_CNT
                              , DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2)) AS DTH_RATE
                           FROM (
                                 SELECT A.DTM
                                      , NVL(SUM(B.DIE_CNT), 0) AS DIE_CNT
                                      , NVL(SUM(B.OUT_CNT), 0) AS OUT_CNT
                                   FROM BF_YEAR A
                                      , (
                                         SELECT X.DTM          AS DTM
                                              , SUM(Y.DIE_CNT) AS DIE_CNT
                                              , SUM(Y.OUT_CNT) AS OUT_CNT
                                           FROM BF_YEAR X --년간추이공통코드
                                              , SDATA_FOR_ANNU Y
                                          WHERE X.DTM = Y.CHOT_DTM
                                          GROUP BY X.DTM
                                        ) B
                                  WHERE A.DTM = B.DTM(+)
                                  GROUP BY A.DTM
                                  ORDER BY A.DTM
                                )
                        )            

                 UNION ALL            

                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'CUR_YEAR' AS COMN_CD
                      , '당년월평균'   AS COMN_CD_NM
                      , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(CEIL(SUM(DIE_CNT) / COUNT(*)))  AS DTRL1_NM
                      , TO_CHAR(CEIL(SUM(OUT_CNT) / COUNT(*)))  AS DTRL2_NM
                      , TO_CHAR(ROUND(SUM(DTH_RATE) / COUNT(*), 2)) AS DTRL3_NM
                   FROM (
                         SELECT DTM
                              , DIE_CNT
                              , OUT_CNT
                              , DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2)) AS DTH_RATE
                           FROM (
                                 SELECT A.DTM
                                      , NVL(SUM(B.DIE_CNT), 0) AS DIE_CNT
                                      , NVL(SUM(B.OUT_CNT), 0) AS OUT_CNT
                                   FROM CUR_YEAR A
                                      , (
                                         SELECT X.DTM          AS DTM
                                              , SUM(Y.DIE_CNT) AS DIE_CNT
                                              , SUM(Y.OUT_CNT) AS OUT_CNT
                                           FROM CUR_YEAR X --년간추이공통코드
                                              , SDATA_FOR_ANNU Y
                                          WHERE X.DTM = Y.CHOT_DTM
                                          GROUP BY X.DTM
                                        ) B
                                  WHERE A.DTM = B.DTM(+)
                                  GROUP BY A.DTM
                                  ORDER BY A.DTM
                                )
                        )            

                 UNION ALL            

                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'BF_MON' AS COMN_CD
                      , '전년당월' AS COMN_CD_NM
                      , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(A.DIE_CNT) AS DTRL1_NM
                      , TO_CHAR(A.OUT_CNT) AS DTRL2_NM
                      , TO_CHAR(DECODE(A.OUT_CNT, 0, 0, ROUND((A.DIE_CNT / A.OUT_CNT) * 100, 2))) AS DTRL3_NM
                   FROM (
                         SELECT X.DTM AS DTM
                              , NVL(Y.DIE_CNT, 0) AS DIE_CNT
                              , NVL(Y.OUT_CNT, 0) AS OUT_CNT
                           FROM BF_MONTH       X
                              , SDATA_FOR_ANNU Y
                          WHERE X.DTM = TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM')
                            AND X.DTM = Y.CHOT_DTM(+)
                        ) A
                 )
               , TRENDTABLE AS (
                 SELECT 'ANNU_TREND' AS COMN_GRP_CD
                      , DTM AS COMN_CD
                      , DTM AS COMN_CD_NM
                      , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(DIE_CNT) AS DTRL1_NM
                      , TO_CHAR(OUT_CNT) AS DTRL2_NM
                      , TO_CHAR(DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2))) AS DTRL3_NM
                   FROM (
                         SELECT A.DTM
                              , NVL(SUM(B.DIE_CNT), 0) AS DIE_CNT
                              , NVL(SUM(B.OUT_CNT), 0) AS OUT_CNT
                           FROM MONTHGUB A
                              , (
                                 SELECT X.DTM           AS DTM
                                      , TO_CHAR(SUM(TO_NUMBER(Y.DIE_CNT)))       AS DIE_CNT
                                      , TO_CHAR(SUM(TO_NUMBER(Y.OUT_CNT)))       AS OUT_CNT
                                   FROM MONTHGUB X --년간추이공통코드
                                      , SDATA_FOR_ANNU Y
                                  WHERE X.DTM = Y.CHOT_DTM
                                  GROUP BY X.DTM
                                ) B
                          WHERE A.DTM = B.DTM(+)
                          GROUP BY A.DTM
                          ORDER BY A.DTM
                        )
                 )
            

            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM DTHTABLE   A
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM DEPTTABLE  B
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM GUBTABLE   C
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM AVGTABLE   D
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM TRENDTABLE E
        ;
    END;
END PC_EICU_CENTER_STATISTIC_MORTA;
