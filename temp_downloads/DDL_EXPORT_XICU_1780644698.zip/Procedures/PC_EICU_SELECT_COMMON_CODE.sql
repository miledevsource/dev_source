
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_COMMON_CODE" 
                                                    (   
                                                        IN_COMN_GRP_CD      IN VARCHAR2   
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    )
IS   
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_COMMON_CODE
*    CREATEDATE     : 2021.02.04
*    Author         : 한가혜
*    Description    : 중환자실 공통코드 조회
*    Change History : 
**********************************************************************************************/
BEGIN 
     BEGIN   
          OPEN OUT_CURSOR FOR 
                             SELECT * 
                               FROM HICU.UCCOCSTE 
                              WHERE COMN_GRP_CD  =  IN_COMN_GRP_CD
                                AND HSP_TP_CD    =  IN_HSP_TP_CD
                                AND USE_YN       =  'Y'
                           ORDER BY COMN_GRP_CD, DTRL1_NM, SORT_SEQ
                               ;
          
       END;
END PC_EICU_SELECT_COMMON_CODE;
