
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_MED_RFFM_UPD" (    
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       			   	IN NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																					     , IN_PACT_ID            	 IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD     IN  VARCHAR2
																							   , IN_REFERRAL_DOC_REG_DT  IN  VARCHAR2
																							   , IN_LSH_DTM             	IN  VARCHAR2
																							   , IN_LSH_IP_ADDR         	IN  VARCHAR2
																							   , IN_LSH_STF_NO           IN  VARCHAR2
																							   , IN_LSH_STF_NM           IN  VARCHAR2
																							   , IN_LSH_PRGM_NM          IN  VARCHAR2
																							   , OUT_CURSOR              OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000); 
    V_RESULT VARCHAR2(1000); 
/**********************************************************************************************
*    SERVICENAME    : PC_MED_RFFM_UPD
*    CREATEDATE     : 2025.08.18
*    Author         : 윤재림
*    Description    : EICU 진료의뢰서 등록
*    Change History : 
**********************************************************************************************/
BEGIN
    BEGIN 

  
       UPDATE ARPA_PT_LIST
          SET TRNF_PRGR_STS_CD 		= IN_TRNF_PRGR_STS_CD
					      	, REFERRAL_DOC_REG_DT = TO_DATE(IN_REFERRAL_DOC_REG_DT,'YYYYMMDDHH24:MI:SS')
					       , LSH_DTM             = TO_DATE(IN_LSH_DTM,'YYYYMMDDHH24:MI:SS')
	           , LSH_IP_ADDR         = IN_LSH_IP_ADDR
	           , LSH_STF_NO          = IN_LSH_STF_NO
	           , LSH_STF_NM          = IN_LSH_STF_NM
	           , LSH_PRGM_NM         = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ =  IN_SEQ
       AND PT_NO = IN_PT_NO
       AND PACT_ID = IN_PACT_ID;

      
  		   	 IS_SUCCESS := 'Y';
									ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
				
				
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;

END;
