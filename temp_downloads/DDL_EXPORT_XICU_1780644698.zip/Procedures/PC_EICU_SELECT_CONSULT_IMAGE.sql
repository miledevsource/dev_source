
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_CONSULT_IMAGE" 
                          ( IN_EPCN_CSLT_ID        IN  VARCHAR2
                          , IN_EPCN_CSLT_FOM_SEQ   IN  NUMBER                       
                          , OUT_CURSOR             OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_CONSULT_IMAGE
*    CREATEDATE     : 2021.04.01
*    Author         : 신솔
*    Description    : 협진 이미지 조회
*    Change History : 2021.04.01, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH CONSULT IMAGE
            ************************/ 
            SELECT
                   A.EPCN_CNSL_ID
                 , A.FOM_SEQ
                 , A.CMPS_SEQ
                 , A.IMG_FILE_PATH_NM
                 , A.RMK_CNTE
                 , A.DEL_YN
              FROM HICU.UCOMCNIE A
                 , HICU.UCOMCNSM B
             WHERE A.EPCN_CNSL_ID      = IN_EPCN_CSLT_ID
               AND A.FOM_SEQ           = IN_EPCN_CSLT_FOM_SEQ
               AND B.EPCN_CSLT_ID      = A.EPCN_CNSL_ID
               AND B.EPCN_CSLT_FOM_SEQ = A.FOM_SEQ
               AND B.LST_YN            = 'Y'
             ORDER BY A.CMPS_SEQ
        ;    
    END;
END PC_EICU_SELECT_CONSULT_IMAGE;
