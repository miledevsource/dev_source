
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_TRNF_STS_SEL" (
    IN_HSP_TP_CD           IN  VARCHAR2,
    IN_PT_NO               IN  VARCHAR2,
    IN_PACT_ID             IN  VARCHAR2,
    IN_TRNF_PRGR_STS_CD    IN  VARCHAR2,
    IN_STATUS_CNFM				 IN  VARCHAR2,
    IN_SEQ				         IN  NUMBER,
    OUT_CURSOR             OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
        SELECT HSP_TP_CD
             , PT_NO
             , PACT_ID
             , TRNF_PRGR_STS_CD
             , STATUS_CNFM
             , SEQ
        FROM ARPA_PT_LIST
        WHERE HSP_TP_CD = IN_HSP_TP_CD
	        AND SEQ       = IN_SEQ
	        AND PT_NO     = IN_PT_NO
	        AND PACT_ID   = IN_PACT_ID;
END PC_TRNF_STS_SEL;
