
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRAD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRAD_SAVE                                               
*    CREATEDATE     : 2021.03.24
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_아파치스코어기록정보 데이터 적재
*    Change History : 2021.03.24                                               
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    /*******************************************************************************************************************
    * DELETE : HICU.UICICRAD   --U121_UICI(ODS)_아파치스코어기록정보
    * FROM : XICU.EMEI004V
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICICRAD A  --U121_UICI(ODS)_아파치스코어기록정보
          WHERE EXISTS ( SELECT 1
                           FROM XICU.EMEI004V B
                          WHERE A.PACT_ID                 = B.PACT_ID
                            AND A.HSP_TP_CD               = B.HSP_CD
                            AND A.PT_NO                   = B.PT_NO
                            AND A.PACT_TP_CD              = B.PACT_TP_CD
                            AND A.INPT_DTM                = B.INPT_DTM
                            AND A.WD_DEPT_CD              = B.WD_DEPT_CD
                            AND A.WRT_SEQ                 = B.WRT_SEQ 
                            AND B.LST_CHG_DTM       BETWEEN IN_FROM_DTM 
                                                        AND IN_TO_DTM
                      ); 
      END;
    /*******************************************
    * _아파치스코어기록정보(UICICRAD) BATCH 
    *******************************************/    
    BEGIN
        MERGE INTO HICU.UICICRAD A  --U121_UICI(ODS)_아파치스코어기록정보
             USING (SELECT PT_NO
                         , PACT_ID
                         , HSP_CD
                         , PACT_TP_CD
                         , INPT_DTM
                         , WD_DEPT_CD
                         , WD_DEPT_CD_NM
                         , WRT_SEQ
                         , USE_YN
                         , LST_YN
                         , ICU_ETRM_DTM
                         , APCS_PT_STS_CD
                         , APCS_PT_STS_CD_NM
                         , SUM_SCR
                         , FST_WRT_DTM
                         , LST_CHG_DTM
                      FROM XICU.EMEI004V
                     WHERE LST_CHG_DTM BETWEEN IN_FROM_DTM  AND IN_TO_DTM
                   ) B
                ON (    A.PACT_ID                  = B.PACT_ID
                    AND A.HSP_TP_CD                = B.HSP_CD
                    AND A.PT_NO                    = B.PT_NO
                    AND A.PACT_TP_CD               = B.PACT_TP_CD
                    AND A.INPT_DTM                 = B.INPT_DTM
                    AND A.WD_DEPT_CD               = B.WD_DEPT_CD
                    AND A.WRT_SEQ                  = B.WRT_SEQ
                   )     
              WHEN MATCHED THEN
                   --최종 적재
                   UPDATE SET A.USE_YN             = B.USE_YN
                            , A.LST_YN             = B.LST_YN
                            , A.ICU_ETRM_DTM       = B.ICU_ETRM_DTM
                            , A.APCS_PT_STS_CD     = B.APCS_PT_STS_CD
                            , A.APCS_PT_STS_CD_NM  = B.APCS_PT_STS_CD_NM
                            , A.SUM_SCR            = B.SUM_SCR
                            , A.FST_WRT_DTM        = B.FST_WRT_DTM
                            , A.LST_CHG_DTM        = B.LST_CHG_DTM
                            , A.FST_LOD_DTM        = B.LST_CHG_DTM  --최초적재일시
                            , A.LST_LOD_DTM        = SYSDATE        --최종적재일시
                
              WHEN NOT MATCHED THEN
                   --최초 적재    
                   INSERT ( A.PT_NO                              --환자번호
                          , A.PACT_ID                            --원무접수ID
                          , A.HSP_TP_CD                          --병원구분코드
                          , A.PACT_TP_CD                         --원무접수구분코드
                          , A.INPT_DTM                           --입력일시
                          , A.WD_DEPT_CD                         --병동부서코드
                          , A.WD_DEPT_CD_NM                      --병동부서코드명
                          , A.WRT_SEQ                            --작성순번
                          , A.USE_YN                             --사용여부
                          , A.LST_YN                             --최종여부
                          , A.ICU_ETRM_DTM                       --중환자실입실일시
                          , A.APCS_PT_STS_CD                     --아파치스코어환자상태코드
                          , A.APCS_PT_STS_CD_NM                  --아파치스코어환자상태코드명
                          , A.SUM_SCR                            --합계점수
                          , A.FST_WRT_DTM                        --최초작성일시
                          , A.LST_CHG_DTM                        --최종변경일시
                          , A.FST_LOD_DTM                        --최초적재일시
                          , A.LST_LOD_DTM                        --최종적재일시
                          )
                   VALUES ( B.PT_NO
                          , B.PACT_ID
                          , IN_HSP_TP_CD--B.HSP_TP_CD
                          , B.PACT_TP_CD
                          , B.INPT_DTM
                          , B.WD_DEPT_CD
                          , B.WD_DEPT_CD_NM
                          , B.WRT_SEQ
                          , B.USE_YN
                          , B.LST_YN
                          , B.ICU_ETRM_DTM
                          , B.APCS_PT_STS_CD
                          , B.APCS_PT_STS_CD_NM
                          , B.SUM_SCR
                          , B.FST_WRT_DTM
                          , B.LST_CHG_DTM  
                          , SYSDATE                              --최초적재일시
                          , SYSDATE                              --최종적재일시
                          );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRAD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICRAD_SAVE;
