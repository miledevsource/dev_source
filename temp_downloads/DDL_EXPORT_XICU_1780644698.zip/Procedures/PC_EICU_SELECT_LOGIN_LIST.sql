
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_LOGIN_LIST" 
                          ( IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_LOGIN_LIST
*    CREATEDATE     : 2021.03.26
*    Author         : 신솔
*    Description    : 로그인 이력 조회
*    Change History : 2021.03.26, 신솔, 최초작성                     
                      2021-05-03  오지민 관제자는 같은 사번일 경우, 한번만 리스트에 뜰 수 있게 해달라는 요청에 의해 
                                  관제와 중환자실 쿼리를 나눔
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
--            SELECT
--                   A.EPCN_YN                              AS EPCN_YN
--                 , A.HSP_TP_CD                            AS HSP_TP_CD
--                 , B.HSP_NM                               AS HSP_NM
--                 , A.USR_NM                               AS USR_NM
--                 , A.USR_SID                              AS USR_SID
--                 , A.HIS_USR_SID                          AS HIS_USR_SID
--                 , A.HIS_STF_NO                           AS HIS_STF_NO
--                 , A.WD_DEPT_CD                           AS WD_DEPT_CD
--                 , (SELECT X.AOA_DEPT_NM
--                      FROM XICU.EMEI013V X
--                     WHERE X.STF_NO     = A.HIS_STF_NO
--                       AND X.AADP_CD    = A.WD_DEPT_CD)   AS WD_DEPT_NM
--              FROM HICU.UCCOCULH A
--                 , HICU.UCCOCHPM B
--             WHERE A.HSP_TP_CD = IN_HIS_HSP_TP_CD
--               AND A.LGOT_DTM  IS NULL
--               AND A.HSP_TP_CD = B.HSP_TP_CD
--               AND B.USE_YN    = 'Y'
            SELECT DISTINCT
                   A.EPCN_YN                              AS EPCN_YN
                 , A.HSP_TP_CD                            AS HSP_TP_CD
                 , B.HSP_NM                               AS HSP_NM
                 , A.USR_NM                               AS USR_NM
                 , A.USR_SID                              AS USR_SID
                 , A.HIS_USR_SID                          AS HIS_USR_SID
                 , A.HIS_STF_NO                           AS HIS_STF_NO
                 , A.WD_DEPT_CD                           AS WD_DEPT_CD
                 , (SELECT X.AOA_DEPT_NM
                      FROM XICU.EMEI013V X
                     WHERE X.STF_NO     = A.HIS_STF_NO
                       AND X.AADP_CD    = A.WD_DEPT_CD)   AS WD_DEPT_NM
              FROM HICU.UCCOCULH A
                 , HICU.UCCOCHPM B
             WHERE A.HSP_TP_CD = IN_HIS_HSP_TP_CD
               AND A.LGOT_DTM  IS NULL
               AND A.HSP_TP_CD = B.HSP_TP_CD
               AND B.USE_YN    = 'Y'
               AND A.EPCN_YN   = 'Y'
             UNION ALL
             SELECT
                   A.EPCN_YN                              AS EPCN_YN
                 , A.HSP_TP_CD                            AS HSP_TP_CD
                 , B.HSP_NM                               AS HSP_NM
                 , A.USR_NM                               AS USR_NM
                 , A.USR_SID                              AS USR_SID
                 , A.HIS_USR_SID                          AS HIS_USR_SID
                 , A.HIS_STF_NO                           AS HIS_STF_NO
                 , A.WD_DEPT_CD                           AS WD_DEPT_CD
                 , (SELECT X.AOA_DEPT_NM
                      FROM XICU.EMEI013V X
                     WHERE X.STF_NO     = A.HIS_STF_NO
                       AND X.AADP_CD    = A.WD_DEPT_CD)   AS WD_DEPT_NM
              FROM HICU.UCCOCULH A
                 , HICU.UCCOCHPM B
             WHERE A.HSP_TP_CD = IN_HIS_HSP_TP_CD
               AND A.LGOT_DTM  IS NULL
               AND A.HSP_TP_CD = B.HSP_TP_CD
               AND B.USE_YN    = 'Y'
               AND A.EPCN_YN   = 'N'
            ;
    END;
END PC_EICU_SELECT_LOGIN_LIST;
