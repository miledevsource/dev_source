
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_EMPLOYEE_LIST" 
                          ( IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , IN_PRTP_STF_NM    IN  VARCHAR2
                          , IN_PRTP_STF_NO    IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_EMPLOYEE_LIST
*    CREATEDATE     : 2021.03.04
*    Author         : 신솔
*    Description    : 의료진 조회
*    Change History : 2021.03.04, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            SELECT A.HSP_TP_CD                                         AS PRTP_HSP_CD
                 , CASE WHEN A.HSP_TP_CD = '09' THEN '이천의료원' 
                        WHEN A.HSP_TP_CD = '11' THEN '성남의료원'                     
                        ELSE '분당서울대학교병원'END                   AS PRTP_HSP_NM
                 , A.STF_IFY_ID                                        AS PRTP_SID
                 , A.STF_NO                                            AS PRTP_STF_NO
                 , A.STF_NM                                            AS PRTP_STF_NM
                 , A.TEL_NO                                            AS PRTP_TEL_NO
                 , A.AOA_WRK_DEPT_CD                                   AS PRTP_DEPT_CD
                 , A.AOA_WRK_DEPT_NM                                   AS PRTP_DEPT_NM
              FROM XICU.EMEI013V A
             WHERE A.USE_GRP_CD IN('DO', 'NU')
               AND A.HSP_TP_CD = IN_HIS_HSP_TP_CD
               AND (A.STF_NM LIKE NVL2(IN_PRTP_STF_NM, '%' || IN_PRTP_STF_NM || '%', '')
                OR A.STF_NO LIKE NVL2(IN_PRTP_STF_NO, '%' || IN_PRTP_STF_NO || '%', ''))
            ;
    END;
END PC_EICU_SELECT_EMPLOYEE_LIST;
