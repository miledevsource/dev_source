
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_MAIN_ALARM_SEL" 
                          (
                            IN_STATUS_STS_CD    IN  VARCHAR2
                          , OUT_CURSOR          OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_MAIN_ALARM_SEL
*    CREATEDATE     : 2025.09.12
*    Author         : 윤재림
*    Description    : EICU 이송요청 환자리스트 조회
*    Change History :
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
SELECT  A.HSP_TP_CD									                    HSP_TP_CD
      , A.SEQ									                          SEQ
      , A.PT_NO						                              PT_NO
			, A.PACT_ID                                       PACT_ID
			, NVL(
					    IF_FN_CODE_SEL('HSP_TP_CD', A.HSP_TP_CD),
					    IF_FN_CODE_SEL('TARGET_HSP_CD', '08')
					  ) 																				  HSP_NM
			, A.PT_NM																					PT_NM
			, A.CONSULT_REQ_DT                                CONSULT_REQ_DT   
      , '010-1234-5678'                               AS PHONE_NUMBER
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRAAM C
     , (
        SELECT *
        FROM (
            SELECT D.*
                 , ROW_NUMBER() OVER (
                      PARTITION BY D.PACT_ID
                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
                   ) AS RN
              FROM MOPPCCFD D
        )
        WHERE RN = 1
     ) D
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.PACT_ID = D.PACT_ID


UNION ALL
  SELECT A.HSP_TP_CD									                    HSP_TP_CD
  , A.SEQ									                          SEQ
  , A.PT_NO						                              PT_NO
	, A.PACT_ID                                       PACT_ID
	, NVL(
			    IF_FN_CODE_SEL('HSP_TP_CD', A.HSP_TP_CD),
			    IF_FN_CODE_SEL('TARGET_HSP_CD', '08')
 			  ) 																				  HSP_NM
	, A.PT_NM																					PT_NM
	, A.CONSULT_REQ_DT                                CONSULT_REQ_DT 
  , '010-1234-5678'                               AS PHONE_NUMBER
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  ;

END IF_TRNF_MAIN_ALARM_SEL;
