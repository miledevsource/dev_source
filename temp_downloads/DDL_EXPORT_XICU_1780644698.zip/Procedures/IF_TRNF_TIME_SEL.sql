
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_TIME_SEL" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																										,	IN_CDBS			          IN  VARCHAR2
																										,	OUT_CURSOR	         OUT SYS_REFCURSOR
	)
	IS
	BEGIN
		OPEN OUT_CURSOR FOR
			SELECT IF_FN_CODE_SEL('HSP_TRAN_TIME', IN_CDBS, 'CDDES1')    AS     CDDES1
			FROM DUAL;
	END;
