
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_PT_STTS_SUMMARY" 
                                                    (   
                                                        IN_FROM_DTM         IN DATE 
                                                      , IN_TO_DTM           IN DATE 
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_PT_STTS_SUMMARY
*    CREATEDATE     : 2021.03.09
*    Author         : 한가혜
*    Description    : 통합관제 임상지표 중환자실 환자현황 SUMMARY DATA 조회
*    Change History : 
**********************************************************************************************/    

AS
    
BEGIN
      OPEN OUT_CURSOR FOR
							--중환자실 리스트 조회
							WITH WD_DEPT_DATA AS (
							                SELECT X.DEPT_CD        AS WD_DEPT_CD
                                                 , X.RMK_CNTE       AS WD_DEPT_CD_NM
                                              FROM HICU.UCCOCDPM X   --U111_UCCO(설정)_부서기본
                                             WHERE HSP_TP_CD        = IN_HSP_TP_CD
                                          ORDER BY SORT_SEQ
							),
							--관제테이블 연환자 기준
							MAIN AS (
											SELECT B.WD_DEPT_CD             --병동부서코드
											     , NVL(SUM(A.YY_PT_CNT), 0)              AS YY_PT_CNT--연환자
											     , NVL(SUM(A.YY_BED_CNT), 0)             AS YY_BED_CNT--연병상
											     , NVL(SUM(A.ETRM_PT_CNT), 0)            AS ETRM_PT_CNT--입실환자
											     , NVL(SUM(A.CHOT_PT_CNT), 0)            AS CHOT_PT_CNT --퇴실환자수
											     , NVL(SUM(A.WHL_SIRM_DYS), 0)           AS WHL_SIRM_DYS --전체재실일수
											     , NVL(SUM(1), 0)                        AS DAYS_CNT
											  FROM HICU.UCCICSPM A  --통합중환자실환자지표기본
											     , WD_DEPT_DATA  B
											 WHERE B.WD_DEPT_CD         = A.WD_DEPT_CD (+)
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND A.ETRM_DT_SEQ  BETWEEN TO_CHAR(IN_FROM_DTM, 'YYYYMMDD')
											                          AND TO_CHAR(IN_TO_DTM, 'YYYYMMDD') 
							              GROUP BY B.WD_DEPT_CD 
							),
							--운영테이블 재실환자 기준
							SIRM_PT_DATA AS (   
											SELECT A.CIPT_ETRM_CHOT_ID
											     , A.HSP_TP_CD
											     , A.PACT_ID
											     , A.SEX_TP_CD
											     , A.AGE
											     , A.RPRN_MED_DEPT_CD
											     , A.RPRN_MED_DEPT_CD_NM
											     , A.ETRM_DTM
											     , A.ETRM_DT
											     , A.ETRM_WD_DEPT_CD
											     , A.ETRM_WD_DEPT_CD_NM
											     , A.CHOT_DTM
											     , A.CHOT_DT
											  FROM XICU.UICICSPV A --U121_UICI(지표)_중환자실환자지표기본 VIEW
											     , WD_DEPT_DATA   B
											 WHERE B.WD_DEPT_CD         = A.ETRM_WD_DEPT_CD (+)
											   AND A.HSP_TP_CD          = IN_HSP_TP_CD
											   AND (A.ETRM_DTM    BETWEEN IN_FROM_DTM 
											                          AND IN_TO_DTM  + 0.99999
											     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) BETWEEN IN_FROM_DTM 
											                                                                                                        AND IN_TO_DTM  + 0.99999
											     OR (A.ETRM_DTM < IN_FROM_DTM 
											         AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999)
											     )
							), 
							--재실환자
							IN_DATA AS (
											SELECT NVL(SUM(PT_CNT), 0)       AS IN_PT_CNT--재실환자수
											     , ETRM_WD_DEPT_CD           AS ETRM_WD_DEPT_CD
											  FROM (
													SELECT A.PACT_ID         AS PACT_ID
													     , NVL(SUM(1), 0)    AS PT_CNT
													     , B.WD_DEPT_CD      AS ETRM_WD_DEPT_CD
													  FROM SIRM_PT_DATA A
													     , WD_DEPT_DATA B
													 WHERE B.WD_DEPT_CD  = A.ETRM_WD_DEPT_CD (+)
												  GROUP BY A.PACT_ID, B.WD_DEPT_CD
											)
									 	  GROUP BY ETRM_WD_DEPT_CD   
							),
							--실시간 데이터
							REALTIME_DATA AS (
        							        SELECT B.WD_DEPT_CD                       --병동구분코드
        							             , NVL((A.USE_WD_CNT + A.EMPT_WD_CNT), 0)           AS TOTAL_BED_CNT       --총 병상수
        							             , NVL((A.ISLT_USE_WD_CNT + A.ISLT_EMPT_WD_CNT), 0) AS TOTAL_ISLT_BED_CNT  --총 격리병상
        							             , NVL(A.USE_WD_CNT, 0)           AS USE_WD_CNT            --사용병상수
        							             , NVL(A.ISLT_USE_WD_CNT, 0)      AS ISLT_USE_WD_CNT            --격리병상 사용수
        							             , NVL(A.EMPT_WD_CNT, 0)          AS EMPT_WD_CNT           --공병상수
        							             , NVL(A.ISLT_EMPT_WD_CNT, 0)     AS ISLT_EMPT_WD_CNT            --격리병상 공병상수
        							             , NVL(A.IN_WD_CNT, 0)            AS IN_WD_CNT            --입실예정 환자수
        							             , NVL(A.OUT_WD_CNT, 0)           AS OUT_WD_CNT           --퇴실예정 환자수
        							          FROM XICU.EMEI001V A --XICU.EICUISLV A
        							             , WD_DEPT_DATA  B
        							         WHERE B.WD_DEPT_CD  = A.WD_DEPT_CD (+)
		                    )

							/********************
							* INDICATORS OUT DTO
							*********************/  
                            SELECT D.DEPT_CD                        AS WD_DEPT_CD--병동부서코드
							     , NVL(A.YY_PT_CNT, 0)              AS YY_PT_CNT--연환자                                           
							     , NVL(A.YY_BED_CNT, 0)             AS YY_BED_CNT--연병상
					             , NVL(ROUND(A.YY_PT_CNT / DECODE(A.YY_BED_CNT, 0, NULL, A.YY_BED_CNT) * 100, 1), 0)   AS BED_MOVA  --병상가동률
							     , NVL(A.ETRM_PT_CNT, 0)            AS ETRM_PT_CNT--입실환자
							     , NVL(B.IN_PT_CNT, 0)              AS IN_PT_CNT--재실환자
					             , NVL(ROUND(A.WHL_SIRM_DYS / DECODE(A.CHOT_PT_CNT, 0, NULL, A.CHOT_PT_CNT), 1), 0)    AS SIRM_DYS_AVG_VAL --평균 재실일
							     , NVL(C.TOTAL_BED_CNT, 0)          AS TOTAL_BED_CNT         --총 병상수  (연병상수랑 동일)
							     , NVL(C.USE_WD_CNT, 0)             AS USE_WD_CNT          --사용병상수
							     , NVL(C.TOTAL_ISLT_BED_CNT, 0)     AS TOTAL_ISLT_BED_CNT          --총 격리병상
        			             , NVL(C.ISLT_USE_WD_CNT, 0)        AS ISLT_USE_WD_CNT         --격리병상 사용수
        			             , NVL(C.EMPT_WD_CNT, 0)            AS EMPT_WD_CNT         --공병상수
        			             , NVL(C.ISLT_EMPT_WD_CNT, 0)       AS ISLT_EMPT_WD_CNT         --격리병상 공병상수
        			             , NVL(C.IN_WD_CNT, 0)              AS IN_WD_CNT        --입실예정 환자수
        			             , NVL(C.OUT_WD_CNT, 0)             AS OUT_WD_CNT        --퇴실예정 환자수
        			             , SYSDATE                          AS SEARCH_REAL_TIME
        			             , IN_FROM_DTM                      AS SEARCH_IN_FROM_DTM
        			             , IN_TO_DTM                        AS SEARCH_IN_TO_DTM
							  FROM MAIN    A
							     , IN_DATA B
							     , REALTIME_DATA C 
							     , HICU.UCCOCDPM D
							 WHERE D.DEPT_CD     = B.ETRM_WD_DEPT_CD (+)
							   AND D.DEPT_CD     = C.WD_DEPT_CD (+)
							   AND D.DEPT_CD     = A.WD_DEPT_CD (+)
							   AND D.HSP_TP_CD   = IN_HSP_TP_CD
					      ORDER BY DECODE(D.DEPT_CD, 'MICU', 1, 'CICU', 2, 'SICU', 3, 'NICU', 4, 'NICU2', 5, 'NCU', 6, 'EICU', 7, 'EICU2', 8)
							;   
							    
        			           
  END PC_EICU_CENTER_PT_STTS_SUMMARY;
