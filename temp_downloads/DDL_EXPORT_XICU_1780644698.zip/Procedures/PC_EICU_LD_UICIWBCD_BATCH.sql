
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_UICIWBCD_BATCH" ( IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                        , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                                        , IN_TO_DTE       IN DATE             -- 04.조회종료일자
                                        , IO_ERRYN        IN OUT  VARCHAR2    -- 05. ERROR Y/N
                                        , IO_ERRMSG       IN OUT  VARCHAR2   -- 06. ERROR MESSAGE 
                                        ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_UICIWBCD_BATCH
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민
*    Description    : UICIWBCD 일자별로 병동별 운영병상수를 적재함(연병상 구할 때 사용함)
*    Change History : 2021.03.15, 오지민, 최초작성
                      2021-07-08 황선영, PRM_NO = 00 조건에서 COMN_GRP_CD = 'N0000540' 로 수정
**********************************************************************************************/
 AS     
    D_START_DTE DATE := TRUNC(IN_FROM_DTE)- 1;
    N_DAYCOUNT NUMBER := 0;
BEGIN       
    
    N_DAYCOUNT := TRUNC(IN_TO_DTE) - TRUNC(IN_FROM_DTE);
    
    BEGIN 
        FOR I IN 0..N_DAYCOUNT LOOP
            D_START_DTE := D_START_DTE + 1;
            
            BEGIN
	            MERGE INTO HICU.UICIWBCD A  --병실정보
			     USING (
			            SELECT D_START_DTE                                               AS DT
			                 , WD_DEPT_CD
			                 , COUNT(WD_DEPT_CD)                                         AS TOT_COUNT
			                 , HSP_TP_CD
						  FROM ( SELECT A.*
                                   FROM HICU.UCCOWDBD A --병실기본정보
                                  WHERE D_START_DTE BETWEEN A.APY_STR_DT AND A.APY_END_DT
                                    AND A.PRM_NO =(CASE WHEN (SELECT NVL(B.DTRL1_NM,'N')
                                                                FROM CCCCCSTE B
                                                               WHERE B.COMN_GRP_CD = 'N0000540'
                                                                 AND A.WD_DEPT_CD = B.COMN_CD) = 'Y' THEN '00' ELSE A.PRM_NO END) 
							   )
						GROUP BY WD_DEPT_CD, HSP_TP_CD ) B 
                ON (     A.WD_DEPT_CD                       = B.WD_DEPT_CD
			         AND A.HSP_TP_CD                        = B.HSP_TP_CD
			         AND A.BED_CFMT_DT                      = B.DT )
			   WHEN MATCHED THEN
			       UPDATE SET
			           A.BED_CNT                       = B.TOT_COUNT
			         , A.LST_LOD_DTM                   = SYSDATE
			
			  WHEN NOT MATCHED THEN
			      INSERT (
			                 WD_DEPT_CD
			               , HSP_TP_CD
			               , BED_CFMT_DT
			               , BED_CNT
                           , FST_LOD_DTM
			               , LST_LOD_DTM
			        )
			      VALUES (
			                 B.WD_DEPT_CD
			               , B.HSP_TP_CD
			               , D_START_DTE
			               , B.TOT_COUNT 
			               , SYSDATE             
			               , SYSDATE
			          );       			
		    COMMIT;	   
		    EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_LD_UICIWBCD_BATCH): HSP_TP_CD = '|| IN_HSP_TP_CD || 'BED_CFMT_DT = ' || TO_CHAR(D_START_DTE, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
		    END;	    
        END LOOP;
    END;     
END PC_EICU_LD_UICIWBCD_BATCH;
