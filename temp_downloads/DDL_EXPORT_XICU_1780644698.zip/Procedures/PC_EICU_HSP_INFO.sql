
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_HSP_INFO" 
                          ( IN_HSP_TP_CD IN  VARCHAR2 /*병원코드*/
                          , OUT_CURSOR   OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_HSP_INFO
*    CREATEDATE     : 2021.02.05
*    Author         : 이창우
*    Description    : 병원정보 조회
*    Change History : 
**********************************************************************************************/

BEGIN
   BEGIN 
      OPEN OUT_CURSOR FOR
           SELECT CHPM.HSP_TP_CD, CHPM.HSP_NM, CHPM.RMK_CNTE
             FROM HICU.UCCOCHPM CHPM
            --WHERE CHPM.HSP_TP_CD = IN_HSP_TP_CD;
            -- 2021.02.16, 신솔, 병원코드 파라미터 없을 경우 전체 병원정보 조회하도록 수정
            WHERE CHPM.HSP_TP_CD = NVL(IN_HSP_TP_CD, CHPM.HSP_TP_CD);
   END;
END PC_EICU_HSP_INFO;
