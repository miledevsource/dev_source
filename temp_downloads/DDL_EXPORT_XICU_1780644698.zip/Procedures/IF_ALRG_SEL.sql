
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_ALRG_SEL" (    
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2      -- 병원구분코드
																							   , IN_SEQ       	      IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2      -- 환자번호  
																							   , IN_PACT_ID          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
      SELECT S.REG_DT
           , S.ALLERGY_SOURCE
           , S.ALLERGY_NM
           , S.ALLERGY_REACTION
        FROM ALRG_SEL	S
        	 , ARPA_PT_LIST	A
       WHERE A.HSP_TP_CD = IN_HSP_TP_CD
         AND A.PT_NO     = IN_PT_NO
      	 AND A.SEQ = IN_SEQ;
END IF_ALRG_SEL;
