
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_PT_DATALISTS" 
                                                    (   IN_FROM_DTM                     IN DATE 
                                                      , IN_TO_DTM                       IN DATE 
                                                      , IN_WD_DEPT_CD                   IN VARCHAR2   
                                                      , IN_HSP_TP_CD                    IN VARCHAR2
                                                      , IN_SEX_TP_CD                    IN VARCHAR2 
                                                      , IN_PT_SILLM_CTG_GRP_CD          IN VARCHAR2 
                                                      , OUT_CURSOR                      OUT SYS_REFCURSOR 
                                                    )
IS   
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_PT_DATALISTS
*    CREATEDATE     : 2021.01.27
*    Author         : 한가혜
*    Description    : 중환자실 환자 데이터 조회
*    Change History : 
**********************************************************************************************/
BEGIN 
     IF IN_WD_DEPT_CD = 'CICU' THEN
     BEGIN   
          OPEN OUT_CURSOR FOR 
                              WITH MAIN AS (SELECT DISTINCT A.HSP_TP_CD
                                                 , A.PACT_ID
                                                 , A.PT_NO
                                                 , A.PT_NM 
                                                 , A.ADS_DT
                                                 , A.SEX_TP_CD
                                                 , A.AGE
                                                 , A.AGE_MRK_NM
                                                 , A.MED_DEPT_CD_NM
                                                 , A.ETRM_DTM
                                                 , A.ETRM_BED_NO
                                                 , A.CHOT_DTM
                                                 , A.APCS_REC_INPT_DTM
                                                 , A.APCS_SUM_SCR
                                                 , DECODE(A.AGPY_AOM_CNT, NULL, NULL, 0, NULL, 'Y')            AS AGPY_AOM_YN             --혈관조용시술여부   
                                                 , DECODE(A.AGPY_AOM_EMRG_CNT, NULL, NULL, 0, NULL, 'Y')       AS AGPY_AOM_ER_YN          --혈관조영시술응급여부
                                                 , A.SIRM_TM
                                                 , B.PT_SILLM_CTG_DTM
                                                 , B.PT_SILLM_CTG_GRP_CD
                                                 , B.PT_SILLM_CTG_GRP_CD_NM
                    						  FROM (SELECT A.HSP_TP_CD
                                                         , A.PACT_ID
                                                         , A.PT_NO
                                                         , SUBSTR(A.PT_NM, 1, 1) || '*' || SUBSTR(A.PT_NM, 3)     AS PT_NM 
                                                         , A.ADS_DT
                                                         , A.SEX_TP_CD
                                                         , A.AGE
                                                         , A.AGE_MRK_NM
                                                         , A.MED_DEPT_CD
                                                         , A.MED_DEPT_CD_NM
                                                         , A.RPRN_MED_DEPT_CD
                                                         , A.RPRN_MED_DEPT_CD_NM
                                                         , A.ETRM_DTM
                                                         , A.ETRM_WD_DEPT_CD
                                                         , A.ETRM_WD_DEPT_CD_NM
                                                         , A.ETRM_PRM_NO
                                                         , A.ETRM_BED_NO
                                                         , A.EMRG_BED_YN
                                                         , A.ISLT_BED_YN
                                                         , A.CHOT_DTM
                                                         , A.APCS_REC_INPT_DTM
                                                         , A.APCS_REC_WRT_SEQ
                                                         , A.APCS_PT_STS_CD
                                                         , A.APCS_PT_STS_CD_NM
                                                         , A.APCS_SUM_SCR
                                                         , ( SELECT MAX(X.PT_SILLM_CTG_DTM)
                                                               FROM HICU.UICICSPD X
                                                              WHERE X.PACT_ID                = A.PACT_ID
                                                                AND X.HSP_TP_CD              = A.HSP_TP_CD
                                                                AND X.WD_DEPT_CD             = IN_WD_DEPT_CD 
                                                                AND X.HSP_TP_CD              = IN_HSP_TP_CD
                                                                AND X.PT_SILLM_CTG_DTM BETWEEN TRUNC(A.ETRM_DTM) 
                                                                                           AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM)) 
        				                                   )                                                                                                                                                AS PT_SILLM_CTG_DTM      --분류일시 
                                                         , B.AGPY_AOM_CNT              --혈관조영시술수
                                                         , B.AGPY_AOM_EMRG_CNT         --혈관조영응급시술수
                                                         , CASE WHEN (A.CHOT_DTM IS NULL OR A.CHOT_DTM = TO_DATE('9999-12-31', 'YYYY-MM-DD')) THEN '재실 중'
                                                                ELSE RTRIM(TO_CHAR(ROUND((DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) - A.ETRM_DTM) * 24, 1), 'FM999990.9'), '.') END AS SIRM_TM
                    						          FROM HICU.UICICSPM A    --중환자실환자지표기본 
                    						             , HICU.UICISROD B    --혈관조영시술건수정보
                    						         WHERE B.PT_NO(+)            = A.PT_NO 
                    						           AND B.HSP_TP_CD(+)        = A.HSP_TP_CD
                                                       AND B.OP_EXPT_DT(+) BETWEEN TRUNC(A.ETRM_DTM) 
                                                                               AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM)) 
                                                       AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드                 
        				                               AND A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD 
                            						   AND (A.ETRM_DTM     BETWEEN IN_FROM_DTM 
                                						                       AND IN_TO_DTM + 0.99999 
                                						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) BETWEEN IN_FROM_DTM 
                                						                                                                                                        AND IN_TO_DTM + 0.99999
                                						     OR (A.ETRM_DTM < IN_FROM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
                                						   )
                    						     ) A
                    						     , HICU.UICICSPD B   --중환자실환자중증도분류정보
                    						 WHERE A.PACT_ID                  = B.PACT_ID (+)
                    						   AND A.HSP_TP_CD                = B.HSP_TP_CD (+)
                    						   AND A.PT_SILLM_CTG_DTM         = B.PT_SILLM_CTG_DTM (+)
                        				   )  
                                                 
                                                 SELECT X.PT_NO                              PT_NO                    --환자번호
                                                      , X.PT_NM                                       PT_NM                    --환자명
                                                      , X.SEX_TP_CD                                   SEX_TP_CD                --성별
                                                      , TO_CHAR(NVL(X.AGE_MRK_NM, X.AGE))             PT_AGE                   --연령
                                                      , TO_CHAR(X.ADS_DT, 'YYYY-MM-DD')               ADS_DT                   --입원일자
                                                      , TO_CHAR(X.ETRM_DTM, 'YYYY-MM-DD HH:MI:SS')    ETRM_DTM                 --입실일시
                                                      , TO_CHAR(X.CHOT_DTM, 'YYYY-MM-DD HH:MI:SS')    CHOT_DTM                 --퇴실일시
                                                      , X.MED_DEPT_CD_NM                              MED_DEPT_CD_NM           --진료과
                                                      , X.ETRM_BED_NO                                 ETRM_BED_NO              --병상
                                                      , TO_CHAR(X.PT_SILLM_CTG_DTM, 'YYYY-MM-DD')     PT_SILLM_CTG_DTM         --분류일시
                                                      , X.PT_SILLM_CTG_GRP_CD                         PT_SILLM_CTG_GRP_CD      --중환자분류
                                                      , X.PT_SILLM_CTG_GRP_CD_NM                      PT_SILLM_CTG_GRP_CD_NM   --중환자분류명
                                                      , TO_CHAR(X.APCS_REC_INPT_DTM, 'YYYY-MM-DD')    APCS_REC_INPT_DTM        --APACHEII Score 입력일시
                                                      , X.APCS_SUM_SCR                                APCS_SUM_SCR             --APACHEII Score 합계점수
                                                      , X.SIRM_TM                                     SIRM_TM                  --재실한시간          
                                                      , X.AGPY_AOM_YN                                 AGPY_AOM_YN             --혈관조용시술여부
                                                      , X.AGPY_AOM_ER_YN                              AGPY_AOM_ER_YN          --혈관조영시술응급여부
                                                   FROM MAIN X
            								   ORDER BY X.PT_NM, X.PT_NO, X.ETRM_DTM, X.PT_SILLM_CTG_DTM, X.PT_SILLM_CTG_GRP_CD
            								       ;
           --CLOSE OUT_CURSOR;  
       END;
            
    ELSE
     BEGIN
          OPEN OUT_CURSOR FOR 
                              WITH MAIN AS (SELECT DISTINCT A.HSP_TP_CD
                                                 , A.PACT_ID
                                                 , A.PT_NO
                                                 , A.PT_NM 
                                                 , A.ADS_DT
                                                 , A.SEX_TP_CD
                                                 , A.AGE
                                                 , A.AGE_MRK_NM
                                                 , A.MED_DEPT_CD_NM
                                                 , A.ETRM_DTM
                                                 , A.ETRM_BED_NO
                                                 , A.CHOT_DTM
                                                 , A.APCS_REC_INPT_DTM
                                                 , A.APCS_SUM_SCR
                                                 , A.SIRM_TM
                                                 , B.PT_SILLM_CTG_DTM
                                                 , B.PT_SILLM_CTG_GRP_CD
                                                 , B.PT_SILLM_CTG_GRP_CD_NM
                    						  FROM (SELECT A.HSP_TP_CD
                                                         , A.PACT_ID
                                                         , A.PT_NO
                                                         , SUBSTR(A.PT_NM, 1, 1) || '*' || SUBSTR(A.PT_NM, 3)     AS PT_NM 
                                                         , A.ADS_DT
                                                         , A.SEX_TP_CD
                                                         , A.AGE
                                                         , A.AGE_MRK_NM
                                                         , A.MED_DEPT_CD
                                                         , A.MED_DEPT_CD_NM
                                                         , A.RPRN_MED_DEPT_CD
                                                         , A.RPRN_MED_DEPT_CD_NM
                                                         , A.ETRM_DTM
                                                         , A.ETRM_WD_DEPT_CD
                                                         , A.ETRM_WD_DEPT_CD_NM
                                                         , A.ETRM_PRM_NO
                                                         , A.ETRM_BED_NO
                                                         , A.EMRG_BED_YN
                                                         , A.ISLT_BED_YN
                                                         , A.CHOT_DTM
                                                         , A.APCS_REC_INPT_DTM
                                                         , A.APCS_REC_WRT_SEQ
                                                         , A.APCS_PT_STS_CD
                                                         , A.APCS_PT_STS_CD_NM
                                                         , A.APCS_SUM_SCR
                                                         , ( SELECT MAX(X.PT_SILLM_CTG_DTM)
                                                               FROM HICU.UICICSPD X
                                                              WHERE X.PACT_ID                = A.PACT_ID
                                                                AND X.HSP_TP_CD              = A.HSP_TP_CD
                                                                AND X.WD_DEPT_CD             = IN_WD_DEPT_CD 
                                                                AND X.HSP_TP_CD              = IN_HSP_TP_CD
                                                                AND X.PT_SILLM_CTG_DTM BETWEEN TRUNC(A.ETRM_DTM) 
                                                                                           AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM)) 
        				                                   )                                                                                                                                                AS PT_SILLM_CTG_DTM      --분류일시 
                                                         , CASE WHEN (A.CHOT_DTM IS NULL OR A.CHOT_DTM = TO_DATE('9999-12-31', 'YYYY-MM-DD')) THEN '재실 중'
                                                                ELSE RTRIM(TO_CHAR(ROUND((DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) - A.ETRM_DTM) * 24, 1), 'FM999990.9'), '.') END AS SIRM_TM
                    						          FROM HICU.UICICSPM A    --중환자실환자지표기본 
                    						         WHERE A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드                 
        				                               AND A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD 
                            						   AND (A.ETRM_DTM     BETWEEN IN_FROM_DTM 
                                						                       AND IN_TO_DTM + 0.99999 
                                						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) BETWEEN IN_FROM_DTM 
                                						                                                                                                        AND IN_TO_DTM + 0.99999
                                						     OR (A.ETRM_DTM < IN_FROM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
                                						   )
                    						     ) A
                    						     , HICU.UICICSPD B   --중환자실환자중증도분류정보
                    						 WHERE A.PACT_ID                  = B.PACT_ID (+)
                    						   AND A.HSP_TP_CD                = B.HSP_TP_CD (+)
                    						   AND A.PT_SILLM_CTG_DTM         = B.PT_SILLM_CTG_DTM (+)
                        				   )  
                                                 
                                                 SELECT X.PT_NO                              PT_NO                    --환자번호
                                                      , X.PT_NM                                       PT_NM                    --환자명
                                                      , X.SEX_TP_CD                                   SEX_TP_CD                --성별
                                                      , TO_CHAR(NVL(X.AGE_MRK_NM, X.AGE))             PT_AGE                   --연령
                                                      , TO_CHAR(X.ADS_DT, 'YYYY-MM-DD')               ADS_DT                   --입원일자
                                                      , TO_CHAR(X.ETRM_DTM, 'YYYY-MM-DD HH:MI:SS')    ETRM_DTM                 --입실일시
                                                      , TO_CHAR(X.CHOT_DTM, 'YYYY-MM-DD HH:MI:SS')    CHOT_DTM                 --퇴실일시
                                                      , X.MED_DEPT_CD_NM                              MED_DEPT_CD_NM           --진료과
                                                      , X.ETRM_BED_NO                                 ETRM_BED_NO              --병상
                                                      , TO_CHAR(X.PT_SILLM_CTG_DTM, 'YYYY-MM-DD')     PT_SILLM_CTG_DTM         --분류일시
                                                      , X.PT_SILLM_CTG_GRP_CD                         PT_SILLM_CTG_GRP_CD      --중환자분류
                                                      , X.PT_SILLM_CTG_GRP_CD_NM                      PT_SILLM_CTG_GRP_CD_NM   --중환자분류명
                                                      , TO_CHAR(X.APCS_REC_INPT_DTM, 'YYYY-MM-DD')    APCS_REC_INPT_DTM        --APACHEII Score 입력일시
                                                      , X.APCS_SUM_SCR                                APCS_SUM_SCR             --APACHEII Score 합계점수
                                                      , X.SIRM_TM                                     SIRM_TM                  --재실한시간          
                                                      , NULL                                          AGPY_AOM_YN             --혈관조용시술여부
                                                      , NULL                                          AGPY_AOM_ER_YN          --혈관조영시술응급여부
                                                   FROM MAIN X
            								   ORDER BY X.PT_NM, X.PT_NO, X.ETRM_DTM, X.PT_SILLM_CTG_DTM, X.PT_SILLM_CTG_GRP_CD
            								       ;
           --CLOSE OUT_CURSOR;  
       END;
    END IF;   
END PC_EICU_PT_DATALISTS;
