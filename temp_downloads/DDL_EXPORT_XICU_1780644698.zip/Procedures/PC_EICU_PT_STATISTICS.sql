
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_PT_STATISTICS" 
                                                    (   
                                                        IN_FROM_DTM         IN DATE 
                                                      , IN_TO_DTM           IN DATE 
                                                      , IN_WD_DEPT_CD       IN VARCHAR2   
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_PT_STATISTICS
*    CREATEDATE     : 2021.01.28
*    Author         : 한가혜
*    Description    : 중환자실 환자현황 조회
*    Change History : 2021-06-24 황선영 수정
**********************************************************************************************/    

AS

   V_TO_YEAR     VARCHAR2(5)     := TO_CHAR(IN_TO_DTM, 'YYYY');  
   V_BF_YEAR     VARCHAR2(5)     := TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12) , 'YYYY'); 
      
   
BEGIN    
	OPEN OUT_CURSOR FOR 
		--재실환자
		WITH IN_DATA AS (
						SELECT SUM(PT_CNT)                   IN_PT_CNT--재실환자수
						  FROM (SELECT A.PACT_ID
									 , SUM(1)               PT_CNT
								  FROM HICU.UICICSPM A --중환자실환자지표기본
        						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
        						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
        						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
            						                       AND IN_TO_DTM  + 0.99999
            						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
            						                                                                                                                      AND IN_TO_DTM + 0.99999 
            						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
            						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
            						   )
							   GROUP BY A.PACT_ID
							  )  
		),
		--입실환자 
		NEW_IN_DATA AS (
						SELECT NVL(SUM(DECODE(A.ICU_ETRM_PATH_CLS_CD, '02', 1)), 0)  CNT_NEWIN    /* 신입(입원)환자수   */   --중환자실입실경로유형
							 , NVL(SUM(DECODE(A.ICU_ETRM_PATH_CLS_CD, '01', 1)), 0)  CNT_MOVEIN   /* 전입환자수   */
						  FROM HICU.UICICSPM A --중환자실환자지표기본
						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
    						                       AND IN_TO_DTM  + 0.99999
    						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
    						                                                                                                                      AND IN_TO_DTM + 0.99999 
    						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
    						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
    						   )
						   AND A.ETRM_DTM BETWEEN IN_FROM_DTM
											  AND IN_TO_DTM + 0.99999
		), 
		--퇴실환자
		CHOT_DATA AS(
						SELECT NVL(SUM(TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM))-TRUNC(A.ETRM_DTM)+1), 0)           CNT_ICUSTAY  /* 중환자실재원일수 */
							 , NVL(SUM(1), 0)                                               CNT_OUT      /* 퇴실환자수*/
						  FROM HICU.UICICSPM A --중환자실환자지표기본
						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
    						                       AND IN_TO_DTM  + 0.99999
    						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
    						                                                                                                                      AND IN_TO_DTM + 0.99999 
    						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
    						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
    						   )
						   AND A.CHOT_DTM BETWEEN IN_FROM_DTM
											  AND IN_TO_DTM + 0.99999 
		),
		--연환자
		MAN_DAYS AS (   SELECT SUM(X.IN_DAYS_24) AS IN_DAYS_24
		                  FROM (SELECT TRUNC(CASE WHEN (TRUNC(SYSDATE) < IN_TO_DTM AND TRUNC(SYSDATE) < IN_FROM_DTM) THEN 0
        				                          ELSE NVL(SUM(CASE WHEN IN_TO_DTM < DECODE(TRUNC(A.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(A.CHOT_DTM)) THEN IN_TO_DTM
        				                                            ELSE DECODE(TRUNC(A.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(A.CHOT_DTM))
        				                                        END
        				                                     - CASE WHEN TRUNC(A.ETRM_DTM) < IN_FROM_DTM THEN IN_FROM_DTM
        				                                            ELSE TRUNC(A.ETRM_DTM)
        				                                        END + 1), 0)
        				               END)                 AS IN_DAYS_24       --24시간 기준 재실 일수  (연환자)
        						  FROM HICU.UICICSPM A --중환자실환자지표기본
        						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
        						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
        						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
            						                       AND IN_TO_DTM  + 0.99999
            						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
            						                                                                                                                      AND IN_TO_DTM + 0.99999 
            						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
            						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
            						   )
        					   GROUP BY A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM
        					   ) X
		),
		--연병상
		BED_DAYS AS(
						SELECT SUM(A.BED_CNT)      AS BED_DAYS
                          FROM HICU.UICIWBCD A  --U121_UICI(지표)_중환자실 일자별 병상수
                         WHERE A.HSP_TP_CD	        = IN_HSP_TP_CD
                           AND A.WD_DEPT_CD         = IN_WD_DEPT_CD
                           AND A.BED_CFMT_DT  BETWEEN IN_FROM_DTM 
                                                  AND IN_TO_DTM
		),
		--진료과별 재실환자
		MTD_CB_SIRM_PT_DATA AS (
						SELECT A.RPRN_MED_DEPT_CD                     MED_DEPT_CD
							 , A.RPRN_MED_DEPT_CD_NM                  MED_DEPT_CD_NM
							 , NVL(COUNT(A.RPRN_MED_DEPT_CD), 0)      CNT
						  FROM HICU.UICICSPM A --중환자실환자지표기본
						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
    						                       AND IN_TO_DTM  + 0.99999
    						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
    						                                                                                                                      AND IN_TO_DTM + 0.99999 
    						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
    						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
    						   )
					  GROUP BY A.RPRN_MED_DEPT_CD, A.RPRN_MED_DEPT_CD_NM
		),
		--성별/연령대별 재실환자
		SEX_AGE_TP_DATA AS (
						SELECT CASE WHEN 0  <= A.AGE AND A.AGE < 20 THEN 'AGE_10_GRP_BLW_CNT'
									WHEN 20 <= A.AGE AND A.AGE < 30 THEN 'AGE_20_GRP_CNT'
									WHEN 30 <= A.AGE AND A.AGE < 40 THEN 'AGE_30_GRP_CNT'
									WHEN 40 <= A.AGE AND A.AGE < 50 THEN 'AGE_40_GRP_CNT'
									WHEN 50 <= A.AGE AND A.AGE < 60 THEN 'AGE_50_GRP_CNT'
									WHEN 60 <= A.AGE AND A.AGE < 70 THEN 'AGE_60_GRP_CNT'
									WHEN 70 <= A.AGE                THEN 'AGE_70_GRP_UPR_CNT'
									ELSE NULL END                                                                   AGE_RANGE
							 , A.SEX_TP_CD                                                                          SEX_TP_CD
							 , A.PACT_ID
						  FROM HICU.UICICSPM A --중환자실환자지표기본
						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
    						                       AND IN_TO_DTM  + 0.99999
    						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
    						                                                                                                                      AND IN_TO_DTM + 0.99999 
    						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
    						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
    						   )
		),
		--환자중증도분류별 재실환자
		SILLM_CTG_DATA AS (
						SELECT CASE WHEN A.PT_SILLM_CTG_GRP_CD = '1' THEN 'PT_SILLM_CTG_1_GRP_CNT'
						            WHEN A.PT_SILLM_CTG_GRP_CD = '2' THEN 'PT_SILLM_CTG_2_GRP_CNT'
						            WHEN A.PT_SILLM_CTG_GRP_CD = '3' THEN 'PT_SILLM_CTG_3_GRP_CNT'
						            WHEN A.PT_SILLM_CTG_GRP_CD = '4' THEN 'PT_SILLM_CTG_4_GRP_CNT'
						            WHEN A.PT_SILLM_CTG_GRP_CD = '5' THEN 'PT_SILLM_CTG_5_GRP_CNT'
						            WHEN A.PT_SILLM_CTG_GRP_CD = '6' THEN 'PT_SILLM_CTG_6_GRP_CNT'
						            ELSE NULL END                              AS  PT_SILLM_CTG_GRP_CD
							 , DECODE(COUNT(*), NULL, 0, COUNT(*))   AS  CNT 
						  FROM HICU.UICICSPD A   --중환자실환자중증도분류정보
							 , (SELECT A.PACT_ID, A.CIPT_ETRM_CHOT_ID, A.PT_NO, A.HSP_TP_CD, A.ETRM_DTM, A.CHOT_DTM 
							      FROM HICU.UICICSPM A --중환자실환자지표기본
        						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
        						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
        						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
            						                       AND IN_TO_DTM  + 0.99999
            						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
            						                                                                                                                      AND IN_TO_DTM + 0.99999 
            						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
            						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
            						   )
    						   ) B             --중환자실환자지표기본
						 WHERE A.PACT_ID                  = B.PACT_ID
						   AND A.CIPT_ETRM_CHOT_ID        = B.CIPT_ETRM_CHOT_ID
						   AND A.PT_NO                    = B.PT_NO
						   AND A.HSP_TP_CD                = B.HSP_TP_CD
						   AND A.PT_SILLM_CTG_TP_CD       = '2'       --중환자실 중증도분류구분코드로 COUNT하자고 하여 수정
						   --AND B.ETRM_WD_DEPT_CD          = A.WD_DEPT_CD
						   AND A.PT_SILLM_CTG_DTM BETWEEN IN_FROM_DTM
						                              AND IN_TO_DTM 
						   AND A.PT_SILLM_CTG_DTM BETWEEN TRUNC(B.ETRM_DTM)
													  AND TRUNC(DECODE(B.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, B.CHOT_DTM)) 
					  GROUP BY A.PT_SILLM_CTG_GRP_CD
		),
		--아파치점수별 재실환자
		APACHEII_SCORE_DATA AS (
						SELECT X.SCR_RANGE
							 , DECODE(COUNT(X.SCR_RANGE), NULL, 0, COUNT(X.SCR_RANGE)) AS  CNT
						  FROM( SELECT CASE WHEN A.APCS_SUM_SCR <= 10 THEN 'APCS_SUM_10_SCR_BLW_CNT'
											WHEN 10 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 20 THEN 'APCS_SUM_20_SCR_CNT'
											WHEN 20 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 30 THEN 'APCS_SUM_30_SCR_CNT'
											WHEN 30 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 40 THEN 'APCS_SUM_40_SCR_CNT'
											WHEN 40 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 50 THEN 'APCS_SUM_50_SCR_CNT'
											WHEN 50 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 60 THEN 'APCS_SUM_60_SCR_CNT'
											WHEN 60 < A.APCS_SUM_SCR AND A.APCS_SUM_SCR <= 70 THEN 'APCS_SUM_70_SCR_CNT'
											WHEN 70 < A.APCS_SUM_SCR THEN 'APCS_SUM_80_SCR_UPR_CNT'
											ELSE NULL END                                               AS SCR_RANGE
								     , A.PACT_ID
								  FROM HICU.UICICSPM A --중환자실환자지표기본
        						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
        						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
        						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
            						                       AND IN_TO_DTM  + 0.99999
            						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
            						                                                                                                                      AND IN_TO_DTM + 0.99999 
            						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
            						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
            						   )
							) X
					  GROUP BY X.SCR_RANGE
		),
		--CICU 재실시간대별 재실환자
		SIRM_TYPE_DATA AS (
						SELECT Y.TMZN_CB                   TMZN_CB
							 , DECODE(COUNT(Y.TMZN_CB), NULL, 0, COUNT(Y.TMZN_CB))     AS  TMZN_CB_CNT
						  FROM( SELECT CASE WHEN X.DIS <= 6                 THEN 'SIRM_6_TM_IN_CNT'
											WHEN 6 < X.DIS  AND X.DIS <= 12 THEN 'SIRM_12_TM_IN_CNT'
											WHEN 12 < X.DIS AND X.DIS <= 18 THEN 'SIRM_18_TM_IN_CNT'
											WHEN 18 < X.DIS AND X.DIS <= 24 THEN 'SIRM_24_TM_IN_CNT'
											WHEN 24 < X.DIS AND X.DIS <= 48 THEN 'SIRM_48_TM_IN_CNT'
											WHEN 48 < X.DIS THEN 'SIRM_48_TM_EXCS_CNT'
											ELSE NULL END                            TMZN_CB --시간대별
								  FROM( SELECT ROUND((DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) - A.ETRM_DTM) * 24)    DIS
											 , A.PACT_ID
										  FROM HICU.UICICSPM A --중환자실환자지표기본
                						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
                						   AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
                						   AND (    A.ETRM_DTM BETWEEN IN_FROM_DTM 
                    						                       AND IN_TO_DTM  + 0.99999
                    						     OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN IN_FROM_DTM 
                    						                                                                                                                      AND IN_TO_DTM + 0.99999 
                    						     OR (A.ETRM_DTM < IN_FROM_DTM AND 
                    						         DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM) > IN_TO_DTM + 0.99999 )
                    						   )
									  ) X
								) Y
					  GROUP BY Y.TMZN_CB
		),
		/***********************
		 *혈관조영실시술일정정보 
		************************/
		--CICU 응급 시술 수행률 
		EMRG_AOM_FMT_RTO_DATA AS ( 
						SELECT DECODE(SUM(A.AGPY_AOM_CNT), NULL, 0, SUM(A.AGPY_AOM_CNT))               AS TOTAL_AGPY_AOM_CNT           --응급 포함한 모든 시술 건수
							 , DECODE(SUM(A.AGPY_AOM_EMRG_CNT), NULL, 0, SUM(A.AGPY_AOM_EMRG_CNT))     AS TOTAL_AGPY_AOM_EMRG_CNT      --응급인 시술 건수만
						  FROM HICU.UICISROD A --혈관조영시술건수정보
						 WHERE A.HSP_TP_CD        = IN_HSP_TP_CD            --병원구분코드 
						   AND A.OP_EXPT_DT BETWEEN IN_FROM_DTM
						                        AND IN_TO_DTM
		),
		/*******************************************************************************
		 *연환자, 연병상 추이 전년월별평균, 당년월평균, 전년당월평균, 이전 12개월별 평균 
		********************************************************************************/  
		--당년 월별 (기간: V_TO_YEAR||'-01-01' ~ V_TO_YEAR||'-12-31')
		MON_FROM_TO_DTM AS (
		                SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DATE_TYPE
                          FROM DUAL
                    CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYYMM'), 'YYYYMM'), TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '01', 'YYYYMM')) + 1
		),
		--당년 연환자수
		MON_MAN_DAYS AS (
						SELECT X.DATE_TYPE           AS DATE_TYPE
							 , SUM(X.IN_DAYS_24)     AS IN_DAYS_24
							 , SUM(1)                AS CNT
						  FROM( SELECT TO_CHAR(C.DT_CD, 'YYYY-MM')  AS DATE_TYPE
									 , TRUNC(CASE WHEN DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM)) - LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  
							                THEN LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							           ELSE DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM)) END
							         - CASE WHEN TRUNC(B.ETRM_DTM) - TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 
							                THEN TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
			   		                   ELSE TRUNC(B.ETRM_DTM) END + 1)                                                           AS IN_DAYS_24
        						  FROM (SELECT B.PACT_ID, B.ETRM_DTM, B.CHOT_DTM, TO_CHAR(B.ETRM_DTM, 'YYYY') AS ETRM_DT
        						          FROM HICU.UICICSPM B --중환자실환자지표기본
        						         WHERE B.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
        						           AND B.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
        						           AND ( B.ETRM_DTM BETWEEN TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-01-01' ,'YYYY-MM-DD') 
            						                            AND TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999
        				                      OR DECODE(B.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, B.CHOT_DTM) BETWEEN TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-01-01' ,'YYYY-MM-DD') 
        				                                                                                                                         AND TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999 
        				                     OR (B.ETRM_DTM < TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND B.CHOT_DTM > TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999)
        				                   )  
        						     ) B
        						     , HICU.UICIIRHD C --U121_UICI(ODS)_휴일정보
        					     WHERE 1=1--B.ETRM_DT     = C.YY_CD
        						   AND C.DT_CD BETWEEN TRUNC(B.ETRM_DTM) 
        						                   AND DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM))
						           AND C.DT_CD     <= TRUNC(SYSDATE)
						           AND C.YY_CD      = TO_CHAR(IN_TO_DTM, 'YYYY')
						      GROUP BY TO_CHAR(C.DT_CD, 'YYYY-MM'), B.PACT_ID, B.ETRM_DTM, B.CHOT_DTM
        				     ) X
					  GROUP BY X.DATE_TYPE    
		),
		--당년 연병상수
		MON_BED_DAYS AS (
		                SELECT SUM(A.BED_CNT)                     AS BED_DAYS
                             , TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')  AS DATE_TYPE
							 , SUM(1)                             AS CNT
                          FROM HICU.UICIWBCD A  --U121_UICI(지표)_중환자실 일자별 병상수
                         WHERE A.HSP_TP_CD	        = IN_HSP_TP_CD
                           AND A.WD_DEPT_CD         = IN_WD_DEPT_CD
                           AND A.BED_CFMT_DT  BETWEEN TO_DATE(V_TO_YEAR || '-01-01' ,'YYYY-MM-DD')
                                                  AND TO_DATE(V_TO_YEAR || '-12-31' ,'YYYY-MM-DD')
                           AND A.BED_CFMT_DT       <= TRUNC(SYSDATE)
                      GROUP BY TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')
		),
		--전년 월별
		BF_FROM_TO_DTM AS (
		                SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DATE_TYPE
                          FROM DUAL
                    CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '12', 'YYYYMM'), TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '01', 'YYYYMM')) + 1
		),
		--전년 연환자수   (기간: V_BF_YEAR||'-01-01' ~ V_BF_YEAR||'-12-31')
		BF_YEAR_MAN_DAYS AS (
						SELECT X.DATE_TYPE           AS DATE_TYPE
							 , SUM(X.IN_DAYS_24)     AS IN_DAYS_24
							 , SUM(1)                AS CNT
						  FROM( SELECT TO_CHAR(C.DT_CD, 'YYYY-MM')  AS DATE_TYPE
									 , TRUNC(CASE WHEN DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM)) - LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  
							                THEN LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							           ELSE DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM)) END
							         - CASE WHEN TRUNC(B.ETRM_DTM) - TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 
							                THEN TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
			   		                   ELSE TRUNC(B.ETRM_DTM) END + 1)                                                           AS IN_DAYS_24
        						  FROM HICU.UICICSPM B        --중환자실환자지표기본
        						     , HICU.UICIIRHD C        --U121_UICI(ODS)_휴일정보
        					     WHERE B.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						           AND B.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						           AND (B.ETRM_DTM BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') 
							                           AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999
				                     OR DECODE(B.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), B.CHOT_DTM) BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') 
				                                                                                                                                      AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM,-12), 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999
				                     OR (B.ETRM_DTM < TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND B.CHOT_DTM > TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD') + 0.99999)
				                   )
							       AND C.DT_CD BETWEEN TRUNC(B.ETRM_DTM) 
							                       AND DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM))
						      GROUP BY TO_CHAR(C.DT_CD, 'YYYY-MM'), B.PACT_ID, B.ETRM_DTM, B.CHOT_DTM
        				     ) X
					  GROUP BY X.DATE_TYPE    
		),
		--전년 연병상수   (기간: V_BF_YEAR||'-01-01' ~ V_BF_YEAR||'-12-31')
		BF_YEAR_BED_DAYS AS (
		                SELECT SUM(A.BED_CNT)                     AS BED_DAYS  
                             , TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')  AS DATE_TYPE
							 , SUM(1)                             AS CNT
                          FROM HICU.UICIWBCD A  --U121_UICI(지표)_중환자실 일자별 병상수
                         WHERE A.HSP_TP_CD	        = IN_HSP_TP_CD
                           AND A.WD_DEPT_CD         = IN_WD_DEPT_CD
                           AND A.BED_CFMT_DT  BETWEEN TO_DATE(V_BF_YEAR || '-01-01' ,'YYYY-MM-DD')
                                                  AND TO_DATE(V_BF_YEAR || '-12-31' ,'YYYY-MM-DD')
                      GROUP BY TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')
		),
		--전년 당월 연환자수
		BF_MON_MAN_DAYS AS (SELECT X.DATE_TYPE           AS DATE_TYPE
							     , SUM(X.IN_DAYS_24)     AS IN_DAYS_24
							     , SUM(1)                AS CNT
						      FROM (SELECT TO_CHAR(C.DT_CD, 'YYYY-MM')  AS DATE_TYPE
									     , TRUNC(CASE WHEN DECODE(TRUNC(A.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(A.CHOT_DTM)) - LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  
            						            THEN LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
            						            ELSE DECODE(TRUNC(A.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(A.CHOT_DTM))
            						        END
            						     - CASE WHEN TRUNC(A.ETRM_DTM) - TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 
            						            THEN TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
            						            ELSE TRUNC(A.ETRM_DTM)
            						        END + 1)                                                        AS IN_DAYS_24  
            						  FROM HICU.UICICSPM A        --중환자실환자지표기본
            						     , HICU.UICIIRHD C        --U121_UICI(ODS)_휴일정보
            						 WHERE A.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD          --입실병동부서코드
						               AND A.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						               AND ( A.ETRM_DTM BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM') 
            						                        AND LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12)) + 0.99999
            		                      OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), A.CHOT_DTM) BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM') 
            		                                                                                                                                       AND LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12) + 0.99999)
            		                      OR (A.ETRM_DTM < TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM') AND A.CHOT_DTM > LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12)) + 0.99999)
            						    )
            						   AND C.DT_CD BETWEEN TRUNC(A.ETRM_DTM) 
            						                   AND DECODE(TRUNC(A.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(A.CHOT_DTM))
            		              GROUP BY TO_CHAR(C.DT_CD, 'YYYY-MM'), A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM
		                         ) X
		                   GROUP BY X.DATE_TYPE
		),
		--전년 당월 연병상수
		BF_MON_BED_DAYS AS (
						SELECT SUM(A.BED_CNT)                     AS BED_DAYS
                             , TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')  AS DATE_TYPE
                          FROM HICU.UICIWBCD A  --U121_UICI(지표)_중환자실 일자별 병상수
                         WHERE A.HSP_TP_CD	        = IN_HSP_TP_CD
                           AND A.WD_DEPT_CD         = IN_WD_DEPT_CD
                           AND A.BED_CFMT_DT  BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM')
                                                  AND LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12))
                      GROUP BY TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')
		), 
		-- 12개월 별 연간 추이 X 축
		FROM_TO_DTM AS (
						SELECT TO_CHAR(X.YMD, 'YYYY-MM')                                 DTM_NM
							 , SUBSTR(TO_CHAR(X.YMD, 'YYYY.MM'), 3)                      DAY_NM
							 , SUBSTR(TO_CHAR(X.YMD, 'YYYYMM'), 3)                       DAY_CD
							 , TO_DATE(TO_CHAR(X.YMD, 'YYYY-MM') || '-01', 'YYYY-MM-DD') FROM_DTM
							 , X.YMD                                                     TO_DTM
						  FROM( SELECT ADD_MONTHS(IN_TO_DTM,- (LEVEL-1)) AS YMD
								  FROM DUAL
							CONNECT BY ADD_MONTHS(IN_TO_DTM,- (LEVEL-1)) >= ADD_MONTHS(IN_TO_DTM,-11)
							 ) X
		),
		--12개월 월별 연환자수
		FROM_TO_MAN_DAYS AS (
						SELECT X.DATE_TYPE            DATE_TYPE
							 , SUM(X.IN_DAYS_24)      IN_DAYS_24
						  FROM( SELECT TO_CHAR(C.DT_CD, 'YYYY-MM')  AS DATE_TYPE
									 , TRUNC(CASE WHEN DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM)) - LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  
							                THEN LAST_DAY(TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							                ELSE DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM))
							            END
							         - CASE WHEN TRUNC(B.ETRM_DTM) - TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 
							                THEN TO_DATE(TO_CHAR(C.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
			   		                        ELSE TRUNC(B.ETRM_DTM)
							            END + 1)                                                                             AS IN_DAYS_24
								  FROM HICU.UICICSPM B    --중환자실환자지표기본
        						     , HICU.UICIIRHD C    --U121_UICI(ODS)_휴일정보
								 WHERE B.ETRM_WD_DEPT_CD     = IN_WD_DEPT_CD           --입실병동부서코드
						           AND B.HSP_TP_CD           = IN_HSP_TP_CD            --병원구분코드 
						           AND (B.ETRM_DTM BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM') 
								                       AND LAST_DAY(IN_TO_DTM) + 0.99999
				                     OR DECODE(B.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), B.CHOT_DTM) BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM') 
				                                                                                                                                      AND LAST_DAY(IN_TO_DTM) + 0.99999
				                     OR (B.ETRM_DTM < TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM') AND B.CHOT_DTM > LAST_DAY(IN_TO_DTM) + 0.99999)
							        )
							       AND C.DT_CD BETWEEN TRUNC(B.ETRM_DTM)
						                           AND DECODE(TRUNC(B.CHOT_DTM), TO_DATE('9999-12-31', 'YYYY-MM-DD'), TRUNC(SYSDATE), NULL, TRUNC(SYSDATE), TRUNC(B.CHOT_DTM))
						           AND C.DT_CD      <= TRUNC(SYSDATE)
							  GROUP BY TO_CHAR(C.DT_CD, 'YYYY-MM'), B.PACT_ID, B.ETRM_DTM, B.CHOT_DTM
							 ) X
					  GROUP BY X.DATE_TYPE
		),
		--12개월 월별 연병상수
		FROM_TO_BED_DAYS AS ( 
		                SELECT SUM(A.BED_CNT)                     AS BED_DAYS
                             , TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')  AS DATE_TYPE
                          FROM HICU.UICIWBCD A  --U121_UICI(지표)_중환자실 일자별 병상수
                         WHERE A.HSP_TP_CD	        = IN_HSP_TP_CD
                           AND A.WD_DEPT_CD         = IN_WD_DEPT_CD
                           AND A.BED_CFMT_DT  BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM')
                                                  AND LAST_DAY(IN_TO_DTM)
                      GROUP BY TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM')
		),
		PT_CRCCM_TB AS (  
		                SELECT 'PT_CRCCM'     AS COMN_GRP_CD
                             , A.COMN_CD      AS COMN_CD
                             , A.COMN_CD_NM   AS COMN_CD_NM
                             , '환자현황'     AS COMN_CD_EXPL
                          FROM ( SELECT 'ETRM_PT_CNT'   AS COMN_CD
                                      , '입실환자수'    AS COMN_CD_NM 
                                   FROM DUAL UNION ALL
                                 SELECT 'SIRM_PT_CNT', '재실환자수' FROM DUAL UNION ALL
                                 SELECT 'CHOT_PT_CNT', '퇴실환자수' FROM DUAL UNION ALL
                                 SELECT 'WHL_SIRM_DYS', '전체재실일수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_DYS_AVG_VAL', '평균재실일' FROM DUAL UNION ALL
                                 SELECT 'BED_MOVA', '병상가동률' FROM DUAL UNION ALL
                                 SELECT 'YY_PT_CNT', '연환자' FROM DUAL UNION ALL
                                 SELECT 'YY_BED_CNT', '연병상' FROM DUAL 
                                 ) A
		),
		CHART_TYPE_TB AS (
		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                             , A.COMN_CD      AS COMN_CD
                             , A.COMN_CD_NM   AS COMN_CD_NM
                          FROM (SELECT 'AGE_TYPE' AS COMN_GRP_CD, 'AGE_10_GRP_BLW_CNT' AS COMN_CD, '~10대' AS COMN_CD_NM FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_20_GRP_CNT', '20대' FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_30_GRP_CNT', '30대' FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_40_GRP_CNT', '40대' FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_50_GRP_CNT', '50대' FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_60_GRP_CNT', '60대' FROM DUAL UNION ALL
                                 SELECT 'AGE_TYPE', 'AGE_70_GRP_UPR_CNT', '70대~' FROM DUAL UNION ALL
                                 SELECT 'SEX_TYPE', 'F', '여성' FROM DUAL UNION ALL
                                 SELECT 'SEX_TYPE', 'M', '남성' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_1_GRP_CNT', '1군' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_2_GRP_CNT', '2군' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_3_GRP_CNT', '3군' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_4_GRP_CNT', '4군' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_5_GRP_CNT', '5군' FROM DUAL UNION ALL
                                 SELECT 'SILLM_TYPE', 'PT_SILLM_CTG_6_GRP_CNT', '6군' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_10_SCR_BLW_CNT', '10' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_20_SCR_CNT', '20' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_30_SCR_CNT', '30' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_40_SCR_CNT', '40' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_50_SCR_CNT', '50' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_60_SCR_CNT', '60' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_70_SCR_CNT', '70' FROM DUAL UNION ALL
                                 SELECT 'APACHEII_SCR_TYPE', 'APCS_SUM_80_SCR_UPR_CNT', '80' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_6_TM_IN_CNT', 'CICU_재실시간6시간이내수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_12_TM_IN_CNT', 'CICU_재실시간12시간이내수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_18_TM_IN_CNT', 'CICU_재실시간18시간이내수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_24_TM_IN_CNT', 'CICU_재실시간24시간이내수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_48_TM_IN_CNT', 'CICU_재실시간48시간이내수' FROM DUAL UNION ALL
                                 SELECT 'SIRM_TM_TYPE', 'SIRM_48_TM_EXCS_CNT', 'CICU_재실시간48시간초과수' FROM DUAL 
                                 ) A
                      ORDER BY A.COMN_GRP_CD
		),
		AGPY_TB AS ( 
		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                             , A.COMN_CD      AS COMN_CD
                             , A.COMN_CD_NM   AS COMN_CD_NM
                          FROM (
                                 SELECT 'AGPY_AOM_CNT'       AS COMN_GRP_CD
                                      , 'AGPY_AOM_CNT'       AS COMN_CD
                                      , 'CICU_혈관조영시술총건수' AS COMN_CD_NM 
                                   FROM DUAL UNION ALL
                                 SELECT 'AGPY_AOM_CNT', 'AGPY_AOM_EMRG_CNT', 'CICU_혈관조영응급시술건수' FROM DUAL UNION ALL
                                 SELECT 'EMRG_AOM_FMT_RTO', 'AOM_EMRG_RTO', 'CICU_혈관조영응급시술수행률' FROM DUAL
                                 ) A
                      ORDER BY A.COMN_GRP_CD
		)
		

						/***************************
						* COMMON INDICATORS OUT DTO
						****************************/
				SELECT S.COMN_GRP_CD
				     , S.COMN_CD
				     , S.COMN_CD_NM
				     , S.COMN_CD_EXPL
				     , TO_CHAR(NVL(S.DTRL1_NM, 0))            AS DTRL1_NM
				     , TO_CHAR(NVL(S.DTRL2_NM, 0))            AS DTRL2_NM
				     , IN_WD_DEPT_CD                  AS DTRL4_NM
				     , TO_CHAR(IN_TO_DTM, 'YYYYMMDD') AS DTRL5_NM
				  FROM (		
						--1.환자현황
						SELECT B.COMN_GRP_CD
						     , B.COMN_CD
						     , B.COMN_CD_NM
						     , B.COMN_CD_EXPL
						     , NVL(A.DTRL1_NM, '0')     AS DTRL1_NM 
						     , NULL                     AS DTRL2_NM
						  FROM (
								SELECT 'ETRM_PT_CNT'           COMN_CD
									 , '입실환자'              COMN_CD_NM
									 , TO_CHAR(DECODE(B.CNT_MOVEIN + B.CNT_NEWIN, NULL, 0, B.CNT_MOVEIN + B.CNT_NEWIN))                          DTRL1_NM
								  FROM NEW_IN_DATA B

							 UNION ALL

								SELECT 'SIRM_PT_CNT'           COMN_CD
									 , '재실환자'              COMN_CD_NM
									 , TO_CHAR(DECODE(E.IN_PT_CNT, NULL, 0, E.IN_PT_CNT))            DTRL1_NM
								  FROM IN_DATA     E

							 UNION ALL

								SELECT 'SIRM_DYS_AVG_VAL'      COMN_CD
									 , '평균재실일'            COMN_CD_NM
									 , TO_CHAR(NVL(ROUND(C.CNT_ICUSTAY / DECODE((C.CNT_OUT), 0, NULL,(C.CNT_OUT)),1), 0))                    DTRL1_NM 
								  FROM CHOT_DATA   C     
								  
						     UNION ALL
                                
						        --21.03.12 관제의 평균재실일 지표를 위한 추가
								SELECT 'CHOT_PT_CNT'           COMN_CD
									 , '퇴실환자수'            COMN_CD_NM
									 , TO_CHAR(DECODE(C.CNT_OUT, NULL, 0, C.CNT_OUT))        DTRL1_NM
								  FROM CHOT_DATA   C
								  
							 UNION ALL
                                
                                --21.03.12 관제의 평균재실일 지표를 위한 추가
								SELECT 'WHL_SIRM_DYS'          COMN_CD
									 , '전체재실일수'          COMN_CD_NM
									 , TO_CHAR(DECODE(C.CNT_ICUSTAY, NULL, 0, C.CNT_ICUSTAY))        DTRL1_NM
								  FROM CHOT_DATA   C
								
							 UNION ALL

								SELECT 'YY_PT_CNT'             COMN_CD
									 , '연환자'                COMN_CD_NM
									 , TRIM(TO_CHAR(DECODE(A.IN_DAYS_24, NULL, 0, A.IN_DAYS_24), 'FM99999')) DTRL1_NM
								  FROM MAN_DAYS    A

							 UNION ALL

								SELECT 'YY_BED_CNT'            COMN_CD
									 , '연병상'                COMN_CD_NM
									 , TO_CHAR(DECODE(D.BED_DAYS, NULL, 0, D.BED_DAYS))              DTRL1_NM
								  FROM BED_DAYS     D

							 UNION ALL
                             
							    SELECT 'BED_MOVA'              COMN_CD
									 , '병상가동률'            COMN_CD_NM
									 , RTRIM(TO_CHAR((DECODE(A.IN_DAYS_24, NULL, 0, A.IN_DAYS_24) / DECODE(D.BED_DAYS, NULL, 0 , D.BED_DAYS))*100, 'FM9990.9'), '.')           DTRL1_NM
                                  FROM MAN_DAYS    A
        						  	 , BED_DAYS    D
							 ) A
						     , PT_CRCCM_TB B
                         WHERE B.COMN_CD = A.COMN_CD 

                     UNION ALL
					 
						--2.진료과별 재실환자
						SELECT 'MED_DEPT_TYPE'               COMN_GRP_CD
							 , A.MED_DEPT_CD                 COMN_CD         
							 , A.MED_DEPT_CD_NM              COMN_CD_NM      
							 , '진료과별 분포'               COMN_CD_EXPL
							 , TO_CHAR(DECODE(A.CNT, NULL, 0, A.CNT))                               DTRL1_NM        
							 , NULL                                                                 DTRL2_NM 
						  FROM MTD_CB_SIRM_PT_DATA A 

					 UNION ALL

						--3.성별 재실환자
						SELECT B.COMN_GRP_CD                                                      COMN_GRP_CD
							 , DECODE(A.VAL_1, 'F', 'SEX_FEML_CNT', 'SEX_MALE_CNT')               COMN_CD
							 , DECODE(A.VAL_1, 'F', '성별여수', '성별남수')                       COMN_CD_NM
							 , '성별 분포'                                                        COMN_CD_EXPL
							 , DECODE(A.VAL_2, NULL, '0', A.VAL_2)                                DTRL1_NM
							 , NULL                                                               DTRL2_NM
						  FROM( SELECT S.SEX_TP_CD                                                VAL_1
									 , DECODE(COUNT(S.SEX_TP_CD), NULL, '0', COUNT(S.SEX_TP_CD))  VAL_2
								  FROM SEX_AGE_TP_DATA S
							  GROUP BY S.SEX_TP_CD
							 ) A
							 , CHART_TYPE_TB B
						 WHERE B.COMN_GRP_CD = 'SEX_TYPE'
						   AND B.COMN_CD     = A.VAL_1 (+)  

					 UNION ALL
						   
						--3.연령대별 재실환자 
						SELECT B.COMN_GRP_CD        COMN_GRP_CD
							 , B.COMN_CD            COMN_CD
							 , B.COMN_CD_NM         COMN_CD_NM
							 , '연령대별 분포'      COMN_CD_EXPL
							 , NVL(A.VAL_2, '0')    DTRL1_NM
							 , NULL                 DTRL2_NM
						  FROM( SELECT S.AGE_RANGE                                                VAL_1--연령대
									 , DECODE(COUNT(S.AGE_RANGE), NULL, '0', COUNT(S.AGE_RANGE))  VAL_2--환자수 
								  FROM SEX_AGE_TP_DATA S
							  GROUP BY S.AGE_RANGE
							 ) A
							 , CHART_TYPE_TB B
						 WHERE B.COMN_GRP_CD = 'AGE_TYPE'
						   AND B.COMN_CD     = A.VAL_1 (+)

					 UNION ALL

						--4.중증도분류별 재실환자 
						SELECT B.COMN_GRP_CD           COMN_GRP_CD
							 , B.COMN_CD               COMN_CD
							 , B.COMN_CD_NM            COMN_CD_NM
							 , '중증도분류별 분포'            COMN_CD_EXPL
							 , TO_CHAR(NVL(A.CNT, 0))         DTRL1_NM
							 , NULL                           DTRL2_NM
						  FROM SILLM_CTG_DATA A
						     , CHART_TYPE_TB B
						 WHERE B.COMN_GRP_CD = 'SILLM_TYPE'
						   AND B.COMN_CD     = A.PT_SILLM_CTG_GRP_CD (+)

					 UNION ALL

						--5.아파치점수별 재실환자 
						SELECT B.COMN_GRP_CD           COMN_GRP_CD
							 , B.COMN_CD               COMN_CD
							 , B.COMN_CD_NM            COMN_CD_NM
							 , 'APACHE II Score별 분포'     COMN_CD_EXPL
							 , TO_CHAR(NVL(A.CNT, 0))       DTRL1_NM
							 , NULL                         DTRL2_NM
						  FROM APACHEII_SCORE_DATA A
						     , CHART_TYPE_TB B
						 WHERE B.COMN_GRP_CD = 'APACHEII_SCR_TYPE'
						   AND B.COMN_CD     = A.SCR_RANGE (+)

					 UNION ALL

						/***************************
						 * CICU INDICATORS OUT DTO
						****************************/ 
						--재실시간대별 재실환자 
						SELECT B.COMN_GRP_CD           COMN_GRP_CD
							 , B.COMN_CD               COMN_CD
							 , B.COMN_CD_NM            COMN_CD_NM
							 , '재실시간대별 분포'                 COMN_CD_EXPL
							 , DECODE(IN_WD_DEPT_CD, 'CICU', TO_CHAR(NVL(A.TMZN_CB_CNT, 0)), '0')  AS  DTRL1_NM
							 , NULL                                DTRL2_NM
						  FROM SIRM_TYPE_DATA A  
						     , CHART_TYPE_TB B
						 WHERE B.COMN_GRP_CD = 'SIRM_TM_TYPE'
						   AND B.COMN_CD     = A.TMZN_CB (+)  

					 UNION ALL 
					    
					    --CICU일경우에만 넣어주기
                        SELECT Y.COMN_GRP_CD
                             , Y.COMN_CD
                             , Y.COMN_CD_NM                 AS COMN_CD_NM
        					 , '응급시술수행률'             AS COMN_CD_EXPL
        					 , DECODE(IN_WD_DEPT_CD, 'CICU', TO_CHAR(NVL(X.DTRL1_NM, 0)), '0')  AS DTRL1_NM
        					 , NULL                         AS DTRL2_NM    
                          FROM (                          
        						--응급 시술 수행률
        						SELECT 'AGPY_AOM_CNT'           COMN_GRP_CD
        							 , 'AGPY_AOM_CNT'           COMN_CD
        							 , A.TOTAL_AGPY_AOM_CNT     DTRL1_NM    --혈관조영시술 총 건수(응급시술건수포함)
        						  FROM EMRG_AOM_FMT_RTO_DATA A
        						  
        					 UNION ALL
        
        						--응급 시술 수행률
        						SELECT 'AGPY_AOM_CNT'             COMN_GRP_CD
        							 , 'AGPY_AOM_EMRG_CNT'        COMN_CD
        							 , A.TOTAL_AGPY_AOM_EMRG_CNT  DTRL1_NM    ----응급시술 건수  
        						  FROM EMRG_AOM_FMT_RTO_DATA A 
        						  
        					 UNION ALL
        
        						--응급 시술 수행률
        						SELECT 'EMRG_AOM_FMT_RTO'           COMN_GRP_CD
        							 , 'AOM_EMRG_RTO'               COMN_CD
        							 , ROUND(DECODE(A.TOTAL_AGPY_AOM_EMRG_CNT, 0, NULL, A.TOTAL_AGPY_AOM_EMRG_CNT) / DECODE(A.TOTAL_AGPY_AOM_CNT, 0, NULL, A.TOTAL_AGPY_AOM_CNT) * 100, 1)        DTRL1_NM  
        						  FROM EMRG_AOM_FMT_RTO_DATA A 
        						) X
        						, AGPY_TB Y
        			  	    WHERE Y.COMN_GRP_CD = X.COMN_GRP_CD 
        			  	      AND Y.COMN_CD     = X.COMN_CD 

					 UNION ALL

						--6.전년 월 평균
						SELECT 'AVG_FLOW'                   COMN_GRP_CD
							 , '1'                          COMN_CD
							 , '전년월평균'                 COMN_CD_NM
							 , '연환자/가동률 년간추이'     COMN_CD_EXPL
							 , TRIM(TO_CHAR((DECODE(X.IN_DAYS_24, NULL, 0, X.IN_DAYS_24) / DECODE(X.CNT, NULL, 0, X.CNT)),'FM99999'))                              AS DTRL1_NM     --연환자
							 , RTRIM(TO_CHAR((DECODE(X.IN_DAYS_24, NULL, 0, X.IN_DAYS_24) / DECODE(X.BED_DAYS, 0, NULL, X.BED_DAYS))*100,'FM9990.9'), '.')         AS DTRL2_NM     --병상가동률
						  FROM (SELECT A.IN_DAYS_24
						             , A.BED_DAYS
						             , A.CNT
						          FROM(SELECT SUM(B.IN_DAYS_24)   AS IN_DAYS_24 --연인원
        		                            , SUM(C.BED_DAYS)     AS BED_DAYS   --연병상
        		                            , SUM(1)              AS CNT
        						         FROM BF_FROM_TO_DTM     A        --전년 월별 
        						            , BF_YEAR_MAN_DAYS   B        --전년 연환자수
        							        , BF_YEAR_BED_DAYS   C        --전년 연병상수
        						        WHERE A.DATE_TYPE  = B.DATE_TYPE(+)
        						          AND A.DATE_TYPE  = C.DATE_TYPE(+) 
        						  ) A
						     ) X

					 UNION ALL

						--6.당년 월 평균
						SELECT 'AVG_FLOW'                    COMN_GRP_CD
							 , '2'                           COMN_CD
							 , '당년월평균'                  COMN_CD_NM
							 , '연환자/가동률 년간추이'      COMN_CD_EXPL
							 , CASE WHEN NVL(X.CNT,0) = 0 THEN '0' ELSE TRIM(TO_CHAR((DECODE(X.IN_DAYS_24, NULL, 0, X.IN_DAYS_24) / DECODE(X.CNT, NULL, 0, X.CNT)),'FM99999'))   END           AS DTRL1_NM     --연환자  -- 2021-06-24 황선영 수정[39병동 6월 11일 이전 데이터가 없기때문에, 배치 될때 오류 발생 따라서, 조건문을 추가함)
							 , RTRIM(TO_CHAR((DECODE(X.IN_DAYS_24, NULL, 0, X.IN_DAYS_24) / DECODE(X.BED_DAYS, 0, NULL, X.BED_DAYS))*100,'FM9990.9'), '.')         AS DTRL2_NM     --병상가동률
						  FROM (SELECT A.IN_DAYS_24
						             , A.BED_DAYS
						             , A.CNT
						          FROM(SELECT SUM(B.IN_DAYS_24)   AS IN_DAYS_24 --연인원
        		                            , SUM(C.BED_DAYS)     AS BED_DAYS   --연병상
        		                            , SUM(1)              AS CNT
        						         FROM MON_MAN_DAYS   B            --당년 연환자수
        							        , MON_BED_DAYS   C            --당년 연병상수
        						        --WHERE B.DATE_TYPE  = C.DATE_TYPE
        						    ) A
						     ) X

					 UNION ALL

						--6.전년 당월
						SELECT 'AVG_FLOW'                  COMN_GRP_CD
							 , '3'                         COMN_CD
							 , '전년당월'                  COMN_CD_NM
							 , '연환자/가동률 년간추이'    COMN_CD_EXPL
							 , TRIM(TO_CHAR(DECODE(A.IN_DAYS_24, NULL, 0, A.IN_DAYS_24),'FM99999'))                               DTRL1_NM   --연환자수
							 , RTRIM(TO_CHAR((A.IN_DAYS_24 / DECODE(B.BED_DAYS, 0, NULL, B.BED_DAYS))*100,'FM9990.9'), '.')       DTRL2_NM   --병상가동률
						  FROM BF_MON_MAN_DAYS A           --전년 당월 연환자수
							 , BF_MON_BED_DAYS B           --전년 당월 연병상수   
						 WHERE A.DATE_TYPE =  TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12),  'YYYY-MM')

					 UNION ALL

						--6.당년 월별 
						SELECT 'AVG_MSTS'                    COMN_GRP_CD
							 , Y.DAY_CD                      COMN_CD
							 , Y.DAY_NM                      COMN_CD_NM
							 , '연환자/가동률 년간추이'      COMN_CD_EXPL
							 , TRIM(TO_CHAR(DECODE(X.IN_DAYS_24, NULL, 0, X.IN_DAYS_24),'FM99999'))                             DTRL1_NM     --연환자
							 , RTRIM(TO_CHAR((X.IN_DAYS_24 / DECODE(Z.BED_DAYS, 0, NULL, Z.BED_DAYS))*100,'FM9990.9'), '.')     DTRL2_NM     --병상가동률
						  FROM FROM_TO_MAN_DAYS X
							 , FROM_TO_DTM Y
							 , FROM_TO_BED_DAYS Z
						 WHERE Y.DTM_NM = X.DATE_TYPE (+)
						   AND Y.DTM_NM = Z.DATE_TYPE (+)
						         
                      ) S
                      ORDER BY COMN_GRP_CD, COMN_CD
						;
--CLOSE OUT_CURSOR; 
        		   
END PC_EICU_PT_STATISTICS;
