
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_CONSULT_CONTENT" 
                          ( IN_EPCN_CSLT_ID        IN  VARCHAR2
                          , IN_EPCN_CSLT_FOM_SEQ   IN  NUMBER                       
                          , OUT_CURSOR             OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_CONSULT_CONTENT
*    CREATEDATE     : 2021.02.18
*    Author         : 신솔
*    Description    : 상담 내용 조회
*    Change History : 2021.02.18, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH CONSULT CONTENT
            ************************/ 
            SELECT
                   A.EPCN_CNSL_ID   AS EPCN_CNSL_ID
                 , A.FOM_SEQ        AS FOM_SEQ
                 , A.CMPS_SEQ       AS CMPS_SEQ
                 , A.CNSL_CNTE      AS CNSL_CNTE
                 , A.DEL_YN         AS DEL_YN
                 , B.RER_HSP_CD     AS RER_HSP_CD
                 , B.CSLT_CLS_CD    AS CSLT_CLS_CD
                 , B.PT_NM          AS PT_NM
                 , B.PT_NO          AS PT_NO
                 , B.SEX_TP_CD      AS SEX_TP_CD
                 , B.AGE            AS AGE
                 , B.WD_DEPT_CD     AS WD_DEPT_CD
                 , B.WRT_DTM        AS WRT_DTM
                 , B.WRTR_ID        AS WRTR_ID
                 , B.CSLT_STR_DTM   AS CSLT_STR_DTM
                 , B.CSLT_END_DTM   AS CSLT_END_DTM
              FROM HICU.UCOMCNSE A
                 , HICU.UCOMCNSM B
             WHERE A.EPCN_CNSL_ID      = IN_EPCN_CSLT_ID
               AND A.FOM_SEQ           = IN_EPCN_CSLT_FOM_SEQ
               AND B.EPCN_CSLT_ID      = A.EPCN_CNSL_ID
               AND B.EPCN_CSLT_FOM_SEQ = A.FOM_SEQ
               AND B.LST_YN            = 'Y'
             ORDER BY A.CMPS_SEQ
        ;    
    END;
END PC_EICU_SELECT_CONSULT_CONTENT;
