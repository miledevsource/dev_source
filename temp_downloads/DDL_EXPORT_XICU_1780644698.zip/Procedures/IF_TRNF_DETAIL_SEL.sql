
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_DETAIL_SEL" 
                          ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
                          , IN_SEQ              IN  NUMBER
                          , IN_PT_NO            IN  VARCHAR2
                          , IN_PACT_ID          IN  VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_DETAIL_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송요청 환자 리스트 상세 조회
*    Change History : 2025.07.16, 장인수, 최초작성
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
									SELECT HSP_TP_CD
									     , TRNF_PRGR_STS_CD
									     , STATUS_STS_CD
									     , CONSULT_REQ_DT
									     , CO_TREAT_PROGRESS_DT
									     , XFER_DECISION_DT
									     , REFERRAL_DOC_REG_DT
									     , XFER_INFO_REG_DT 
									     , XFER_START_DT
									     , XFER_ARVL_PLAN_DT
									     , XFER_ARVL_DT
									     , XFER_END_DT
									     , PACT_ID
									     , PT_NO
									     , PT_NM 
									     , CO_TREAT_REASON
									     , SEQ
									     
									  FROM ARPA_PT_LIST
									 WHERE HSP_TP_CD = IN_HSP_TP_CD
									   AND PT_NO = IN_PT_NO
									   AND PACT_ID = IN_PACT_ID
									   AND SEQ = IN_SEQ

									;

END IF_TRNF_DETAIL_SEL;
