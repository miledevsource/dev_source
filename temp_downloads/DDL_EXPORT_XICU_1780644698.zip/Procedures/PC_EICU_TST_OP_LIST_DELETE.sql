
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_TST_OP_LIST_DELETE" ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HIST_SEQ          IN    VARCHAR2      /* 순번 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   SYS_REFCURSOR
                                         )
IS

BEGIN
    BEGIN

           DELETE FROM BB_TEST_OP_INFO
            WHERE HSP_TP_CD  = IN_HSP_TP_CD
              AND PT_NO      = IN_PT_NO
              AND ITEM_TP_CD = IN_ITEM_TP_CD
              AND HIST_SEQ   = IN_HIST_SEQ
          ;

    END;
END PC_EICU_TST_OP_LIST_DELETE;
