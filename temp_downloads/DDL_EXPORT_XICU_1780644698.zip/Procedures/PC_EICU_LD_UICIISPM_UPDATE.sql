
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_UICIISPM_UPDATE" (   IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
		                                   , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
		                                   , IN_TO_DTE       IN DATE             -- 03.조회종료일자                                         
		                                   , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
		                                   , IO_ERRMSG       IN OUT  VARCHAR2)   -- 05. ERROR MESSAGE 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_UICIISPM_UPDATE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표 관련 UICIISPM의 INFC_MCB_TP_CD 업데이트
*    Change History : 2021.02.24, 오지민, 최초작성                                                
**********************************************************************************************/
AS
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    /* ODS-HICU.UICIIRED(진료기록법정전염병정보)가 신규 생성되거나 업데이트 시, UICIISPM(격리병동환자지표기본)의 INFC_MCB_TP_CD를 업데이트를 한다.
     * 우선순위가 있어서 입실 이전의 데이터가 있어도 입실일자와 퇴실일자 사이에 생성된 서식 값으로 변경되어야 하기에 업데이트를 함.*/
    BEGIN
        /* FST_REC_DTM, SND_REC_DTM은 법정감염병서식 조회 기준일자로 사용.
         * FST_REC_DTM : 격리병동에 입실일자부터 퇴실 일자 사이에  첫번째로 작성 된 법정감염병신고서 작성 일자
         * SND_REC_DMT : FST_REC_DTM이 없을 사용 할 작성 일자로 입원일자부터 입실일자 사이에 마지막으로 작성된 법정 감염병 신고서 작성일자
         *               혹 응급실 접수 ID가 있다면 응급실도착일시부터 입실일자 사이에 마지막으로 작성된 법정 감염병 신고서 작성일자를 조회한다.*/

          MERGE INTO HICU.UICIISPM A  --격리병동환자지표기본
			USING (
			        WITH SDATA AS(
			            SELECT  /*+ NO_MERGE */ 
			                   PACT_ID
			                 , EMRG_PACT_ID
			                 , PT_NO
			                 , HSP_TP_CD
			                 , ETRM_DTM
			                 , ( SELECT MIN(REC_DTM)
			                          FROM HICU.UICIIRED X
			                         WHERE D1.PACT_ID = X.PACT_ID
			                           AND D1.HSP_TP_CD = X.HSP_TP_CD
			                           AND X.LST_YN = 'Y'
			                           AND X.MDRC_DC_TP_CD = 'C'
			                           AND X.REC_DTM BETWEEN D1.ETRM_DTM AND D1.CHOT_DTM + 0.99999
			                           AND X.INFC_DCLR_CMPL_CD IN ('H','N')) FST_REC_DTM
			                   , ( SELECT MAX(REC_DTM)
			                         FROM HICU.UICIIRED X
			                        WHERE X.PACT_ID IN (D1.PACT_ID, D1.EMRG_PACT_ID)
			                          AND X.HSP_TP_CD  = D1.HSP_TP_CD
			                          AND X.LST_YN = 'Y'
			                          AND X.MDRC_DC_TP_CD = 'C'
			                          AND X.REC_DTM BETWEEN DECODE(D1.EMRG_PACT_ID, NULL, D1.ADS_DT, TRUNC(D1.EMRM_ARVL_DTM)) AND D1.CHOT_DTM + 0.99999
			                          AND X.INFC_DCLR_CMPL_CD IN ('H','N')) SND_REC_DTM
			             FROM HICU.UICIISPM D1
			            WHERE D1.HSP_TP_CD = IN_HSP_TP_CD
			              AND (D1.PACT_ID IN (SELECT PACT_ID
			                                   FROM HICU.UICIIRED DATA2
			                                  WHERE LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE
			                                    AND HSP_TP_CD = D1.HSP_TP_CD) OR
			                   D1.EMRG_PACT_ID IN (SELECT PACT_ID
			                                   FROM HICU.UICIIRED DATA2
			                                  WHERE LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE
			                                    AND HSP_TP_CD = D1.HSP_TP_CD)))
				     SELECT DATA.PACT_ID
				          , DATA.PT_NO
				          , DATA.HSP_TP_CD
				          , DATA.ETRM_DTM
				          , CASE WHEN DATA2.STTT_INFC_ILNS_CD IN ('158') THEN '3'        /*에볼라*/  
				                 WHEN DATA2.STTT_INFC_ILNS_CD IN ('53','153') THEN '2'   /*메르스*/
				                 WHEN DATA2.STTT_INFC_ILNS_CD IN ('52','152') THEN '1'  /*신종감염병증후군*/
				                 ELSE '4' END INFC_MCB_TP_CD
				      FROM SDATA DATA
				         , HICU.UICIIRED DATA2
				     WHERE DATA2.PACT_ID IN (DATA.PACT_ID, DATA.EMRG_PACT_ID)
				       AND DATA2.HSP_TP_CD = DATA.HSP_TP_CD
				       AND DATA2.REC_DTM = NVL(DATA.FST_REC_DTM, DATA.SND_REC_DTM)
				       AND DATA2.LST_YN = 'Y'
				       AND DATA2.MDRC_DC_TP_CD = 'C'
				       AND DATA2.INFC_DCLR_CMPL_CD IN ('H','N')) B
			 ON (       A.ETRM_DTM                        = B.ETRM_DTM
			      AND   A.HSP_TP_CD                       = B.HSP_TP_CD
			      AND   A.PACT_ID                         = B.PACT_ID
			      AND   A.PT_NO                           = B.PT_NO )
			 WHEN MATCHED THEN
			      UPDATE SET
			          A.INFC_MCB_TP_CD                = B.INFC_MCB_TP_CD
			        , A.LST_LOD_DTM                   = SYSDATE
			;
			COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_LD_UICIISPM_UPDATE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_LD_UICIISPM_UPDATE;
