
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_REG_INFO_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
SELECT
    T.HSP_NM
  , A.PT_NM
  , T.PT_BIRTH
  , T.PT_AGE
  , T.SEX_TP_CD
  , T.DEPT_NM
  , T.DEPT_CD
  , CASE
       WHEN A.XFER_START_DT IS NULL THEN SYSDATE
       ELSE A.XFER_START_DT
     END AS XFER_START_DT
	, CASE
	    WHEN A.XFER_ARVL_PLAN_DT IS NULL THEN
	         SYSDATE
	       + NUMTODSINTERVAL(
	             TO_NUMBER(
	               NVL(REGEXP_SUBSTR(IF_FN_CODE_SEL('HSP_TRAN_TIME', A.HSP_TP_CD, 'CDDES1'), '^-?\d+'), '0')
	             )
	         , 'MINUTE')
	    ELSE A.XFER_ARVL_PLAN_DT
	  END AS XFER_ARVL_PLAN_DT
	, CASE
	    WHEN A.XFER_ARVL_DT IS NULL THEN
	         SYSDATE
	       + NUMTODSINTERVAL(
	             TO_NUMBER(
	               NVL(REGEXP_SUBSTR(IF_FN_CODE_SEL('HSP_TRAN_TIME', A.HSP_TP_CD, 'CDDES1'), '^-?\d+'), '0')
	             )
	         , 'MINUTE')
	    ELSE A.XFER_ARVL_DT
	  END AS XFER_ARVL_DT
  , A.MED_STAFF_ACCOMP_YN
  , A.EQUIP_YN	 PT_EQUIP_YN
  , A.EQUIP_NM		EQUIP_NM
  , A.XFER_REF_MEMO
FROM TRNF_REG_INFO T
   , ARPA_PT_LIST   A
WHERE A.HSP_TP_CD = IN_HSP_TP_CD
  AND A.SEQ       = IN_SEQ
  AND A.PT_NO     = IN_PT_NO;
END IF_TRNF_REG_INFO_SEL;
