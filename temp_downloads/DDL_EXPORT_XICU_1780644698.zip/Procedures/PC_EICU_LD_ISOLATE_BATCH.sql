
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_ISOLATE_BATCH" (  IN_SCHD_EXCT_ID IN VARCHAR2         -- 01. 실행 배치 ID
                                        , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                        , IN_FROM_DTE     IN DATE             -- 04.조회시작일자
                                        , IN_TO_DTE       IN DATE             -- 05.조회종료일자
                                        ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_ISOLATE_BATCH
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민
*    Description    : 운영시스템>임상지표 관련 UICIISPM, UICIISPD 데이터 적재 BATCH 프로그램
*    Change History : 2021.03.15, 오지민, 최초작성
**********************************************************************************************/
 AS
    V_ERRYN VARCHAR2(1) := 'N';
    V_ERRMSG VARCHAR2(4000) := '';
BEGIN   
    /*국가지정격리병동 조회*/
    DECLARE 
        CURSOR WD_DEPT_CD_CURSOR IS SELECT COMN_CD 
                                      FROM HICU.UCCOCSTE 
                                     WHERE COMN_GRP_CD = 'IC018' 
                                       AND USE_YN = 'Y'
                                       AND HSP_TP_CD = IN_HSP_TP_CD
                                     ORDER BY SORT_SEQ;
  
        
    CUR_RECORD WD_DEPT_CD_CURSOR%ROWTYPE;
    
    BEGIN 
        OPEN WD_DEPT_CD_CURSOR;
        LOOP 
            EXIT WHEN WD_DEPT_CD_CURSOR%NOTFOUND;
            
            FETCH WD_DEPT_CD_CURSOR INTO CUR_RECORD;            
            
            /*UICIISPM(격리병동지표) 데이터 적재*/
            BEGIN
               XICU.PC_EICU_LD_UICIISPM_SAVE ( IN_HSP_TP_CD
                                             , CUR_RECORD.COMN_CD
                                             , IN_FROM_DTE
                                             , IN_TO_DTE
                                             , V_ERRYN
                                             , V_ERRMSG);
            EXCEPTION
                WHEN OTHERS THEN                    
                    V_ERRYN := 'Y';
            END;                  
            
            BEGIN
                XICU.PC_EICU_PCLOG( IN_SCHD_EXCT_ID
                                  , 'PC_EICU_LD_UICIISPM_SAVE'
                                  , V_ERRMSG);    
            EXCEPTION
                WHEN OTHERS THEN   
                    NULL;
            END;               
            COMMIT;

            /*UICIISPM(격리병동지표) 데이터 중 감염미생물 구분 정보 관련 데이터 업데이트*/            
            BEGIN
               XICU.PC_EICU_LD_UICIISPM_UPDATE ( IN_HSP_TP_CD
                                               , IN_FROM_DTE
                                               , IN_TO_DTE
                                               , V_ERRYN
                                               , V_ERRMSG);
            EXCEPTION
                WHEN OTHERS THEN                    
                    V_ERRYN := 'Y';
            END;                  
            
            BEGIN
                XICU.PC_EICU_PCLOG( IN_SCHD_EXCT_ID
                                  , 'PC_EICU_LD_UICIISPM_UPDATE'
                                  , 'IO_ERRYN:' || V_ERRYN  ||'-' ||V_ERRMSG);    
            EXCEPTION
                WHEN OTHERS THEN   
                    NULL;
            END;               
            COMMIT;
            
            /*UICIISPD(격리병동환자중증도분류정보) 데이터 적재*/            
            BEGIN
               XICU.PC_EICU_LD_UICIISPD_SAVE  ( IN_HSP_TP_CD       
                                               , CUR_RECORD.COMN_CD
                                               , IN_FROM_DTE
                                               , IN_TO_DTE
                                               , V_ERRYN
                                               , V_ERRMSG);
            EXCEPTION
                WHEN OTHERS THEN                    
                    V_ERRYN := 'Y';
            END;                  
            
            BEGIN
                XICU.PC_EICU_PCLOG( IN_SCHD_EXCT_ID
                                  , 'PC_EICU_LD_UICIISPD_SAVE'
                                  , 'IO_ERRYN:' || V_ERRYN  ||'-' ||V_ERRMSG);    
            EXCEPTION
                WHEN OTHERS THEN   
                    NULL;
            END;               
            COMMIT;
        END LOOP;   
        
        CLOSE WD_DEPT_CD_CURSOR;
    END;    
END PC_EICU_LD_ISOLATE_BATCH;
