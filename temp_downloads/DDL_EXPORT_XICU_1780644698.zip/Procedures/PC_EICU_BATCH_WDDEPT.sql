
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_WDDEPT" 
                          (IN_SCHD_EXCT_ID IN VARCHAR2,  --스케쥴 실행 ID
                           IN_HSP_TP_CD    IN VARCHAR2   --병원구분코드
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_WDDEPT
*    CREATEDATE     : 2021.03.04
*    Author         : 이창우
*    Description    : 병원 병동 정보 적재
*    Change History : 2021.03.04, 이창우, 최초작성
                      2021.06.24, 황선영, 039 주석 처리 (중복 발생하여, 배치시 오류 발생)
**********************************************************************************************/
BEGIN
   BEGIN 
      MERGE INTO HICU.UCCOWDBD WDBD
         USING (SELECT CDPM.DEPT_CD    WD_DEPT_CD
                     , V011.WD_DEPT_CD HIS_WD_DEPT_CD 
                     , V011.PRM_NO
                     , V011.BED_NO
                     , V011.APY_STR_DT
                     , V011.HSP_TP_CD
                     , V011.APY_END_DT
                     , V011.BED_CNT
                     , V011.FSR_DTM
                     , V011.LSH_DTM
                  FROM XICU.EMEI011V V011 --HBIL.ACPPERMM ERMM
                     , (SELECT M.DEPT_CD, M.HIS_DEPT_CD, M.HSP_TP_CD
                          FROM HICU.UCCOCDPM M
--                        UNION ALL
--                        SELECT '039', '039', IN_HSP_TP_CD FROM DUAL
                       ) CDPM
                     , HICU.UCCOWDBD WDBD
                 WHERE V011.WD_DEPT_CD = CDPM.HIS_DEPT_CD 
                   AND V011.HSP_TP_CD  = CDPM.HSP_TP_CD 
                   AND CDPM.HSP_TP_CD  = IN_HSP_TP_CD
                   AND V011.HSP_TP_CD  = WDBD.HSP_TP_CD (+)
                   AND V011.WD_DEPT_CD = WDBD.HIS_WD_DEPT_CD (+)
                   AND V011.PRM_NO     = WDBD.PRM_NO (+)
                   AND V011.BED_NO     = WDBD.BED_NO (+)
                   AND V011.APY_STR_DT = WDBD.APY_STR_DT(+)
                   AND V011.LSH_DTM BETWEEN NVL(WDBD.LST_LOD_DTM, V011.LSH_DTM) AND SYSDATE
               ) SRC
              ON (    WDBD.WD_DEPT_CD = SRC.WD_DEPT_CD
                  AND WDBD.HIS_WD_DEPT_CD = SRC.HIS_WD_DEPT_CD
                  AND WDBD.PRM_NO = SRC.PRM_NO
                  AND WDBD.BED_NO = SRC.BED_NO
                  AND WDBD.APY_STR_DT = SRC.APY_STR_DT
                  AND WDBD.HSP_TP_CD = SRC.HSP_TP_CD
                 )
            WHEN MATCHED THEN 
                 UPDATE SET WDBD.APY_END_DT  = SRC.APY_END_DT
                          , WDBD.BED_CNT     = SRC.BED_CNT
                          , WDBD.LSH_DTM     = SRC.LSH_DTM
                          , WDBD.LST_LOD_DTM = SYSDATE 
            WHEN NOT MATCHED THEN
                 INSERT ( WD_DEPT_CD
                        , PRM_NO
                        , BED_NO
                        , APY_STR_DT
                        , HSP_TP_CD
                        , HIS_WD_DEPT_CD
                        , APY_END_DT
                        , BED_CNT
                        , FSR_DTM
                        , LSH_DTM
                        , FST_LOD_DTM
                        , LST_LOD_DTM
                        )
                 VALUES ( SRC.WD_DEPT_CD
                        , SRC.PRM_NO
                        , SRC.BED_NO
                        , SRC.APY_STR_DT
                        , SRC.HSP_TP_CD
                        , SRC.HIS_WD_DEPT_CD
                        , SRC.APY_END_DT
                        , SRC.BED_CNT
                        , SRC.FSR_DTM
                        , SRC.LSH_DTM
                        , SYSDATE
                        , SYSDATE
                        )
      ;
      XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'PC_EICU_BATCH_WDDEPT-MERGE Count', SQL%ROWCOUNT);

   END;
END PC_EICU_BATCH_WDDEPT;
