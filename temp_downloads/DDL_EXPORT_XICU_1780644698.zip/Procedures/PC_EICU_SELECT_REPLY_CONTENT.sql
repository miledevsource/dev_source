
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_REPLY_CONTENT" 
                          ( IN_EPCN_CSLT_FOM_SEQ   IN  NUMBER                       
                          , OUT_CURSOR             OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_REPLY_CONTENT
*    CREATEDATE     : 2021.03.30
*    Author         : 신솔
*    Description    : 타과회신내용 조회
*    Change History : 2021.03.30, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH REPLY CONTENT
            ************************/ 
            SELECT
                   A.RPLY_DEPT_CD     AS PRTP_DEPT_NM
                 , A.RPLY_MEDR_STF_NO AS PRTP_STF_NM
                 , A.RPLY_CONTENTS    AS CNSL_CNTE
              FROM HICU.UICIIRCD A
             WHERE A.MDRC_ID      = IN_EPCN_CSLT_FOM_SEQ
               AND A.APCN_YN      = 'N'
        ;    
    END;
END PC_EICU_SELECT_REPLY_CONTENT;
