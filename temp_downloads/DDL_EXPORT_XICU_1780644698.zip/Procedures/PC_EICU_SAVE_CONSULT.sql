
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SAVE_CONSULT" 
                          ( IN_EPCN_CSLT_ID       IN  VARCHAR2 -- 관제센터협진ID
                          , IN_EPCN_CSLT_FOM_SEQ  IN  NUMBER   -- 관제센터협진개정순번
                          , IN_RER_HSP_CD         IN  VARCHAR2 -- 의뢰병원코드
                          , IN_RER_DEPT_CD        IN  VARCHAR2 -- 의뢰부서코드
                          , IN_RER_STF_NO         IN  VARCHAR2 -- 의뢰직원번호
                          , IN_RER_STF_NM         IN  VARCHAR2 -- 의뢰직원이름
                          , IN_CSLT_STR_DTM       IN  DATE     -- 협진시작일시
                          , IN_CSLT_END_DTM       IN  DATE     -- 협진종료일시
                          , IN_CSLT_CLS_CD        IN  VARCHAR2 -- 협진유형코드
                          , IN_PT_NO              IN  VARCHAR2 -- 환자번호
                          , IN_PT_NM              IN  VARCHAR2 -- 환자명
                          , IN_PACT_ID            IN  VARCHAR2 -- 원무접수ID
                          , IN_PACT_DTM           IN  DATE     -- 원무접수일시
                          , IN_ADS_DT             IN  DATE     -- 입원일자
                          , IN_ETRM_DTM           IN  DATE     -- 입실일시
                          , IN_PT_MED_DEPT_CD     IN  VARCHAR2 -- 환자진료부서코드
                          , IN_PT_MED_DEPT_NM     IN  VARCHAR2 -- 환자진료부서명
                          , IN_SEX_TP_CD          IN  VARCHAR2 -- 성별구분코드
                          , IN_AGE                IN  NUMBER   -- 연령
                          , IN_MAIN_DGNS_DT       IN  DATE     -- 주진단일자
                          , IN_DGNS_VOC_ID        IN  VARCHAR2 -- 진단용어ID
                          , IN_ICD10_CD           IN  VARCHAR2 -- ICD10코드
                          , IN_DGNS_VOC_NM        IN  VARCHAR2 -- 진단용어명
                          , IN_WD_DEPT_CD         IN  VARCHAR2 -- 병동부서코드
                          , IN_WD_DEPT_CD_NM      IN  VARCHAR2 -- 병동부서코드명
                          , IN_LST_YN             IN  VARCHAR2 -- 최종여부
                          , IN_SV_STS_CD          IN  VARCHAR2 -- 저장상태코드
                          , IN_WRT_DTM            IN  DATE     -- 작성일시
                          , IN_WRTR_ID            IN  VARCHAR2 -- 작성자직원식별ID
                          , IN_PRTP_SEQ           IN  NUMBER   -- 참여순번
                          , IN_PRTP_HSP_CD        IN  VARCHAR2 -- 참여병원코드
                          , IN_PRTP_HSP_NM        IN  VARCHAR2 -- 참여병원명
                          , IN_PRTP_DEPT_CD       IN  VARCHAR2 -- 참여부서코드
                          , IN_PRTP_DEPT_NM       IN  VARCHAR2 -- 참여부서명
                          , IN_PRTP_SID           IN  VARCHAR2 -- 참여직원식별ID
                          , IN_PRTP_STF_NM        IN  VARCHAR2 -- 참여직원명
                          , IN_EPCN_CNSL_ID       IN  VARCHAR2 -- 관제센터상담ID
                          , IN_FOM_SEQ            IN  NUMBER   -- 개정순번
                          , IN_BF_CMPS_SEQ        IN  VARCHAR2 -- 구성순번
                          , IN_CMPS_SEQ           IN  NUMBER   -- 구성순번
                          , IN_CNSL_CNTE          IN  VARCHAR2 -- 상담내용
                          , IN_DEL_YN             IN  VARCHAR2 -- 삭제여부
                          , IN_UPD_YN             IN  VARCHAR2 -- 갱신여부
                          , IN_IMG_FILE_PATH_NM   IN  VARCHAR2 -- 이미지파일경로명
                          , IN_RMK_CNTE           IN  VARCHAR2 -- 비고내용
                          , IN_FILE_BF_CMPS_SEQ   IN  VARCHAR2 -- 협진 이미지 구성순번
                          , IN_FILE_DEL_YN        IN  VARCHAR2 -- 협진 이미지 삭제여부
                          , IN_FILE_UPD_YN        IN  VARCHAR2 -- 협진 이미지 갱신여부
                          , IN_HIS_HSP_TP_CD      IN  VARCHAR2 -- Session 병원코드
                          , IN_HIS_STF_NO         IN  VARCHAR2 -- 사용자 사번
                          , IN_HIS_PRGM_NM        IN  VARCHAR2 -- 사용프로그램 명
                          , IN_HIS_IP_ADDR        IN  VARCHAR2 -- 사용자 PC IP 
                          , IO_ERR_YN             OUT VARCHAR2
                          , IO_ERR_MSG            OUT VARCHAR2
                          )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SAVE_CONSULT
*    CREATEDATE     : 2021.02.16
*    Author         : 신솔
*    Description    : 운영협진관리 신규/저장
*    Change History : 2021.02.16, 신솔, 최초작성
**********************************************************************************************/
AS
    V_EPCN_CSLT_ID          NUMBER(22)     := 0;
    V_EPCN_CSLT_FOM_SEQ     NUMBER(22)     := 0;
BEGIN
    -- 관제센터협진ID 생성
    IF IN_EPCN_CSLT_ID IS NOT NULL THEN
        V_EPCN_CSLT_ID := IN_EPCN_CSLT_ID;
    ELSE
        BEGIN
            SELECT NVL(MAX(TO_NUMBER(EPCN_CSLT_ID)), 0) + 1
              INTO V_EPCN_CSLT_ID
              FROM HICU.UCOMCNSM
            ;
    
            EXCEPTION
                WHEN OTHERS THEN
                    IO_ERR_YN  := 'Y';
                    IO_ERR_MSG := '1) 관제센터협진ID 생성 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                RETURN;
        END;
    END IF;
    
    -- 관제센터협진개정순번 생성
    BEGIN
        SELECT NVL(MAX(EPCN_CSLT_FOM_SEQ), 0) + 1
          INTO V_EPCN_CSLT_FOM_SEQ
          FROM HICU.UCOMCNSM
         WHERE EPCN_CSLT_ID = V_EPCN_CSLT_ID
        ;
        
        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '2) 관제센터협진개정순번 생성 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
            RETURN;
    END;
    
    /**********************
    SAVE CONSULT
    ************************/
    BEGIN
        INSERT 
          INTO HICU.UCOMCNSM
             ( EPCN_CSLT_ID
             , EPCN_CSLT_FOM_SEQ
             , RER_HSP_CD
             , RER_DEPT_CD
             , RER_STF_NO
             , RER_STF_NM
             , CSLT_STR_DTM
             , CSLT_END_DTM
             , CSLT_CLS_CD
             , PT_NO
             , PT_NM
             , PACT_ID
             , PACT_DTM
             , ADS_DT
             , ETRM_DTM
             , PT_MED_DEPT_CD
             , PT_MED_DEPT_NM
             , SEX_TP_CD
             , AGE
             , MAIN_DGNS_DT
             , DGNS_VOC_ID
             , ICD10_CD
             , DGNS_VOC_NM
             , WD_DEPT_CD
             , WD_DEPT_CD_NM
             , LST_YN
             , SV_STS_CD
             , WRT_DTM
             , WRTR_ID
             , FSR_STF_NO
             , FSR_DTM
             , FSR_PRGM_NM
             , FSR_IP_ADDR
             , LSH_STF_NO
             , LSH_DTM
             , LSH_PRGM_NM
             , LSH_IP_ADDR
             )
        VALUES 
             ( V_EPCN_CSLT_ID
             , V_EPCN_CSLT_FOM_SEQ
             , IN_RER_HSP_CD
             , IN_RER_DEPT_CD
             , IN_RER_STF_NO
             , IN_RER_STF_NM
             , IN_CSLT_STR_DTM
             , IN_CSLT_END_DTM
             , IN_CSLT_CLS_CD
             , IN_PT_NO
             , IN_PT_NM
             , IN_PACT_ID
             , IN_PACT_DTM
             , TO_DATE(IN_ADS_DT)
             , IN_ETRM_DTM
             , IN_PT_MED_DEPT_CD
             , IN_PT_MED_DEPT_NM
             , IN_SEX_TP_CD
             , IN_AGE
             , TO_DATE(IN_MAIN_DGNS_DT)
             , IN_DGNS_VOC_ID
             , IN_ICD10_CD
             , IN_DGNS_VOC_NM
             , IN_WD_DEPT_CD
             , IN_WD_DEPT_CD_NM
             , 'Y'
             , IN_SV_STS_CD
             , IN_WRT_DTM
             , IN_WRTR_ID
             , IN_HIS_STF_NO
             , SYSDATE
             , IN_HIS_PRGM_NM
             , IN_HIS_IP_ADDR
             , IN_HIS_STF_NO
             , SYSDATE
             , IN_HIS_PRGM_NM
             , IN_HIS_IP_ADDR
             );

        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '3) 관제센터협진기본 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
            RETURN;          
    END;
    
    IF V_EPCN_CSLT_FOM_SEQ <> '1' THEN
        BEGIN
            UPDATE HICU.UCOMCNSM A
               SET A.LST_YN            = 'N'
                 , A.LSH_STF_NO        = IN_HIS_STF_NO 
                 , A.LSH_DTM           = SYSDATE
                 , A.LSH_PRGM_NM       = IN_HIS_PRGM_NM
                 , A.LSH_IP_ADDR       = IN_HIS_IP_ADDR
             WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID
               AND A.EPCN_CSLT_FOM_SEQ = TO_CHAR(TO_NUMBER(V_EPCN_CSLT_FOM_SEQ) - 1)
            ;
    
            EXCEPTION
                WHEN OTHERS THEN
                    IO_ERR_YN  := 'Y';
                    IO_ERR_MSG := '4) 관제센터협진기본 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                RETURN;
        END;
    END IF;
    
    /**********************
    SAVE CONSULT EMPLOYEE
    ************************/
    FOR REC IN (SELECT A.ROW_NUM        AS PRTP_SEQ
                     , A.PRTP_DEPT_CD   AS PRTP_DEPT_CD
                     , B.PRTP_DEPT_NM   AS PRTP_DEPT_NM
                     , C.PRTP_SID       AS PRTP_SID
                     , D.PRTP_STF_NM    AS PRTP_STF_NM
                     , E.PRTP_HSP_CD    AS PRTP_HSP_CD
                     , F.PRTP_HSP_NM    AS PRTP_HSP_NM
                  FROM (SELECT TRIM(COLUMN_VALUE) AS PRTP_DEPT_CD, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_DEPT_CD, '◎'))) A
                     , (SELECT TRIM(COLUMN_VALUE) AS PRTP_DEPT_NM, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_DEPT_NM, '◎'))) B
                     , (SELECT TRIM(COLUMN_VALUE) AS PRTP_SID, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_SID, '◎')))         C
                     , (SELECT TRIM(COLUMN_VALUE) AS PRTP_STF_NM, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_STF_NM, '◎')))   D
                     , (SELECT TRIM(COLUMN_VALUE) AS PRTP_HSP_CD, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_HSP_CD, '◎')))   E
                     , (SELECT TRIM(COLUMN_VALUE) AS PRTP_HSP_NM, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_PRTP_HSP_NM, '◎')))   F
                 WHERE A.ROW_NUM = B.ROW_NUM
                   AND B.ROW_NUM = C.ROW_NUM
                   AND C.ROW_NUM = D.ROW_NUM
                   AND D.ROW_NUM = E.ROW_NUM
                   AND E.ROW_NUM = F.ROW_NUM
                 ORDER BY A.ROW_NUM)
    LOOP
        BEGIN
            INSERT 
              INTO HICU.UCOMCNRD
                 ( EPCN_CSLT_ID
                 , EPCN_CSLT_FOM_SEQ
                 , PRTP_SEQ
                 , PRTP_HSP_CD
                 , PRTP_HSP_NM
                 , PRTP_DEPT_CD
                 , PRTP_DEPT_NM
                 , PRTP_SID
                 , PRTP_STF_NM
                 , FSR_STF_NO
                 , FSR_DTM
                 , FSR_PRGM_NM
                 , FSR_IP_ADDR
                 , LSH_STF_NO
                 , LSH_DTM
                 , LSH_PRGM_NM
                 , LSH_IP_ADDR
                 )
            VALUES 
                 ( V_EPCN_CSLT_ID
                 , V_EPCN_CSLT_FOM_SEQ
                 , REC.PRTP_SEQ
                 , REC.PRTP_HSP_CD
                 , REC.PRTP_HSP_NM    
                 , REC.PRTP_DEPT_CD
                 , REC.PRTP_DEPT_NM
                 , REC.PRTP_SID
                 , REC.PRTP_STF_NM
                 , IN_HIS_STF_NO
                 , SYSDATE
                 , IN_HIS_PRGM_NM
                 , IN_HIS_IP_ADDR
                 , IN_HIS_STF_NO
                 , SYSDATE
                 , IN_HIS_PRGM_NM
                 , IN_HIS_IP_ADDR
                 );
    
            EXCEPTION
                WHEN OTHERS THEN
                    IO_ERR_YN  := 'Y';
                    IO_ERR_MSG := '5) 협진참여자정보 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                RETURN; 
        END;
    END LOOP;  
    
    /**********************
    SAVE CONSULT CONTENTS
    ************************/
    FOR REC IN (SELECT A.ROW_NUM        AS CMPS_SEQ
                     , A.CNSL_CNTE      AS CNSL_CNTE
                     , B.DEL_YN         AS DEL_YN
                     , C.UPD_YN         AS UPD_YN
                     , D.BF_CMPS_SEQ    AS BF_CMPS_SEQ
                  FROM (SELECT TRIM(COLUMN_VALUE) AS CNSL_CNTE, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_CNSL_CNTE, '◎')))      A
                     , (SELECT TRIM(COLUMN_VALUE) AS DEL_YN, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_DEL_YN, '◎')))            B
                     , (SELECT TRIM(COLUMN_VALUE) AS UPD_YN, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_UPD_YN, '◎')))            C
                     , (SELECT TRIM(COLUMN_VALUE) AS BF_CMPS_SEQ, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_BF_CMPS_SEQ, '◎')))  D
                 WHERE A.ROW_NUM = B.ROW_NUM
                   AND B.ROW_NUM = C.ROW_NUM
                   AND C.ROW_NUM = D.ROW_NUM
                 ORDER BY A.ROW_NUM)
    LOOP
        IF REC.UPD_YN = 'Y' THEN        
            BEGIN
                INSERT 
                  INTO HICU.UCOMCNSE
                     ( EPCN_CNSL_ID
                     , FOM_SEQ
                     , CMPS_SEQ
                     , CNSL_CNTE
                     , DEL_YN
                     , FST_WRT_DTM
                     , FST_WRTR_SID
                     , LST_MDF_DTM
                     , LST_MDF_SID
                     , FSR_STF_NO
                     , FSR_DTM
                     , FSR_PRGM_NM
                     , FSR_IP_ADDR
                     , LSH_STF_NO
                     , LSH_DTM
                     , LSH_PRGM_NM
                     , LSH_IP_ADDR
                     )
                SELECT V_EPCN_CSLT_ID
                     , V_EPCN_CSLT_FOM_SEQ
                     , REC.CMPS_SEQ
                     , REC.CNSL_CNTE
                     , REC.DEL_YN
                     , A.FST_WRT_DTM
                     , A.FST_WRTR_SID
                     , CASE WHEN REC.DEL_YN = A.DEL_YN THEN A.LST_MDF_DTM ELSE IN_WRT_DTM END
                     , CASE WHEN REC.DEL_YN = A.DEL_YN THEN A.LST_MDF_SID ELSE IN_WRTR_ID END
                     , A.FSR_STF_NO
                     , A.FSR_DTM
                     , A.FSR_PRGM_NM
                     , A.FSR_IP_ADDR
                     , CASE WHEN REC.DEL_YN = A.DEL_YN THEN A.LSH_STF_NO ELSE IN_HIS_STF_NO END
                     , SYSDATE
                     , CASE WHEN REC.DEL_YN = A.DEL_YN THEN A.LSH_PRGM_NM ELSE IN_HIS_PRGM_NM END
                     , CASE WHEN REC.DEL_YN = A.DEL_YN THEN A.LSH_IP_ADDR ELSE IN_HIS_IP_ADDR END
                  FROM HICU.UCOMCNSE A
                 WHERE A.EPCN_CNSL_ID = V_EPCN_CSLT_ID
                   AND A.FOM_SEQ      = TO_CHAR(TO_NUMBER(V_EPCN_CSLT_FOM_SEQ) - 1)
                   AND A.CMPS_SEQ     = REC.BF_CMPS_SEQ
                   AND A.CNSL_CNTE    = REC.CNSL_CNTE
                ;
            
                EXCEPTION
                    WHEN OTHERS THEN
                        IO_ERR_YN  := 'Y';
                        IO_ERR_MSG := '6) 기존 상담내용 갱신 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                        RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                    RETURN;
            END;
        ELSE
            BEGIN
                INSERT 
                  INTO HICU.UCOMCNSE
                     ( EPCN_CNSL_ID
                     , FOM_SEQ
                     , CMPS_SEQ
                     , CNSL_CNTE
                     , DEL_YN
                     , FST_WRT_DTM
                     , FST_WRTR_SID
                     , LST_MDF_DTM
                     , LST_MDF_SID
                     , FSR_STF_NO
                     , FSR_DTM
                     , FSR_PRGM_NM
                     , FSR_IP_ADDR
                     , LSH_STF_NO
                     , LSH_DTM
                     , LSH_PRGM_NM
                     , LSH_IP_ADDR
                     )
                VALUES 
                     ( V_EPCN_CSLT_ID
                     , V_EPCN_CSLT_FOM_SEQ
                     , REC.CMPS_SEQ
                     , REC.CNSL_CNTE
                     , REC.DEL_YN
                     , IN_WRT_DTM
                     , IN_WRTR_ID
                     , IN_WRT_DTM
                     , IN_WRTR_ID
                     , IN_HIS_STF_NO
                     , SYSDATE
                     , IN_HIS_PRGM_NM
                     , IN_HIS_IP_ADDR
                     , IN_HIS_STF_NO
                     , SYSDATE
                     , IN_HIS_PRGM_NM
                     , IN_HIS_IP_ADDR
                     )
                ;
            
                EXCEPTION
                    WHEN OTHERS THEN
                        IO_ERR_YN  := 'Y';
                        IO_ERR_MSG := '7) 협진상담상세 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                        RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                    RETURN; 
            END;
        END IF;
    END LOOP;

    /**********************
    SAVE IMAGES
    ************************/
    IF IN_IMG_FILE_PATH_NM IS NOT NULL THEN
        BEGIN
            FOR REC IN (SELECT A.ROW_NUM            AS CMPS_SEQ
                             , A.IMG_FILE_PATH_NM   AS IMG_FILE_PATH_NM
                             , B.RMK_CNTE           AS RMK_CNTE
                             , C.FILE_BF_CMPS_SEQ   AS FILE_BF_CMPS_SEQ
                             , D.FILE_UPD_YN        AS FILE_UPD_YN
                             , E.FILE_DEL_YN        AS FILE_DEL_YN
                          FROM (SELECT TRIM(COLUMN_VALUE) AS IMG_FILE_PATH_NM, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_IMG_FILE_PATH_NM, '◎')))      A
                             , (SELECT TRIM(COLUMN_VALUE) AS RMK_CNTE, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_RMK_CNTE, '◎')))                      B
                             , (SELECT TRIM(COLUMN_VALUE) AS FILE_BF_CMPS_SEQ, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_FILE_BF_CMPS_SEQ, '◎')))      C
                             , (SELECT TRIM(COLUMN_VALUE) AS FILE_UPD_YN, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_FILE_UPD_YN, '◎')))                D
                             , (SELECT TRIM(COLUMN_VALUE) AS FILE_DEL_YN, ROWNUM AS ROW_NUM FROM TABLE(XICU.FT_EICU_STRING_TABLE(IN_FILE_DEL_YN, '◎')))                E
                         WHERE A.ROW_NUM = B.ROW_NUM
                           AND B.ROW_NUM = C.ROW_NUM
                           AND C.ROW_NUM = D.ROW_NUM
                           AND D.ROW_NUM = E.ROW_NUM
                         ORDER BY A.ROW_NUM)
            LOOP     
                IF REC.FILE_UPD_YN = 'Y' THEN
                    BEGIN
                        INSERT 
                          INTO HICU.UCOMCNIE
                             ( EPCN_CNSL_ID
                             , FOM_SEQ
                             , CMPS_SEQ
                             , IMG_FILE_PATH_NM
                             , RMK_CNTE
                             , DEL_YN
                             , REG_DTM
                             , REG_SID
                             , FSR_STF_NO
                             , FSR_DTM
                             , FSR_PRGM_NM
                             , FSR_IP_ADDR
                             , LSH_STF_NO
                             , LSH_DTM
                             , LSH_PRGM_NM
                             , LSH_IP_ADDR
                             )
                        SELECT V_EPCN_CSLT_ID
                             , V_EPCN_CSLT_FOM_SEQ
                             , REC.CMPS_SEQ
                             , REC.IMG_FILE_PATH_NM
                             , REC.RMK_CNTE
                             , REC.FILE_DEL_YN
                             , CASE WHEN REC.FILE_DEL_YN = A.DEL_YN THEN A.REG_DTM ELSE IN_WRT_DTM END
                             , CASE WHEN REC.FILE_DEL_YN = A.DEL_YN THEN A.REG_SID ELSE IN_WRTR_ID END
                             , A.FSR_STF_NO
                             , A.FSR_DTM
                             , A.FSR_PRGM_NM
                             , A.FSR_IP_ADDR
                             , CASE WHEN REC.FILE_DEL_YN = A.DEL_YN THEN A.LSH_STF_NO ELSE IN_HIS_STF_NO END
                             , SYSDATE
                             , CASE WHEN REC.FILE_DEL_YN = A.DEL_YN THEN A.LSH_PRGM_NM ELSE IN_HIS_PRGM_NM END
                             , CASE WHEN REC.FILE_DEL_YN = A.DEL_YN THEN A.LSH_IP_ADDR ELSE IN_HIS_IP_ADDR END 
                          FROM HICU.UCOMCNIE A
                         WHERE A.EPCN_CNSL_ID = V_EPCN_CSLT_ID
                           AND A.FOM_SEQ      = TO_CHAR(TO_NUMBER(V_EPCN_CSLT_FOM_SEQ) - 1)
                           AND A.CMPS_SEQ     = REC.FILE_BF_CMPS_SEQ
                        ;
                    
                        EXCEPTION
                            WHEN OTHERS THEN
                                IO_ERR_YN  := 'Y';
                                IO_ERR_MSG := '8) 협진이미지상세 데이터 갱신 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                            RETURN;
                    END;
                ELSE
                    BEGIN
                        INSERT 
                          INTO HICU.UCOMCNIE
                             ( EPCN_CNSL_ID
                             , FOM_SEQ
                             , CMPS_SEQ
                             , IMG_FILE_PATH_NM
                             , RMK_CNTE
                             , DEL_YN
                             , REG_DTM
                             , REG_SID
                             , FSR_STF_NO
                             , FSR_DTM
                             , FSR_PRGM_NM
                             , FSR_IP_ADDR
                             , LSH_STF_NO
                             , LSH_DTM
                             , LSH_PRGM_NM
                             , LSH_IP_ADDR
                             )
                        VALUES 
                             ( V_EPCN_CSLT_ID
                             , V_EPCN_CSLT_FOM_SEQ
                             , REC.CMPS_SEQ
                             , REC.IMG_FILE_PATH_NM
                             , REC.RMK_CNTE
                             , REC.FILE_DEL_YN
                             , IN_WRT_DTM
                             , IN_WRTR_ID
                             , IN_HIS_STF_NO
                             , SYSDATE
                             , IN_HIS_PRGM_NM
                             , IN_HIS_IP_ADDR
                             , IN_HIS_STF_NO
                             , SYSDATE
                             , IN_HIS_PRGM_NM
                             , IN_HIS_IP_ADDR
                             )
                        ;
                    
                        EXCEPTION
                            WHEN OTHERS THEN
                                IO_ERR_YN  := 'Y';
                                IO_ERR_MSG := '9) 협진이미지상세 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);
                            RETURN;
                    END;
                END IF;
            END LOOP;
        END;
    END IF;

    BEGIN
        IO_ERR_YN  := 'N';
        IO_ERR_MSG := V_EPCN_CSLT_ID || '◎' || V_EPCN_CSLT_FOM_SEQ;
    END;
END PC_EICU_SAVE_CONSULT;
