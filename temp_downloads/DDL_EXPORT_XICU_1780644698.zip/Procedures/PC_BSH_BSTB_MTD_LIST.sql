
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_BSH_BSTB_MTD_LIST" 
(
  IN_SQL_ID    IN  VARCHAR2
  , IN_STF_NO    IN  VARCHAR2
  , IN_IP_ADDR  IN  VARCHAR2
  , IN_HSP_TP_CD  IN  VARCHAR2
  , OUT_CURSOR  OUT  SYS_REFCURSOR
)
IS
BEGIN
  OPEN OUT_CURSOR FOR
    SELECT     '' "IP_ADDR"
          , dept.DEPT_CD "ISTL_DEPT_CD"
          , dept.DEPT_NM "ISTL_DEPT_NM"
          , ROWNUM "SORT_SEQ"
          , '' "SCRN_TP_CD"
          , '' "ISTL_PSTN_NM"
          , '' "LIST_DSP_YN"
          , '' "AUTO_LGOT_USE_YN"
          , '' "AUTO_LGOT_STU_CHR_VAL"
          , '' "SCSV_USE_YN"
          , '' "SCSV_STU_CHR_VAL"
    FROM     IFMSTVW_RRSDEPT dept;

END PC_BSH_BSTB_MTD_LIST;
