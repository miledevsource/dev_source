
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_BSH_USR_LGIN" ( IN_SQL_ID        IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2       /* 직원번호 */
                                         , IN_IP_ADDR        IN    VARCHAR2       /* DEVICE ID */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병원구분코드 */
                                         , IN_LGIN_PWD      IN    VARCHAR2       /* 일반   비밀번호 */
                                         , IN_SEC_LGIN_PWD  IN    VARCHAR2       /* 일반   비밀번호 */
                                         , OUT_CURSOR       OUT   SYS_REFCURSOR )
IS

    V_SEC_LGIN_PWD       VARCHAR2(1000);
    V_DAMO_HASH_STR_DATA VARCHAR2(1000);
    V_SRCH_CNTE          VARCHAR2(4000);
    
    V_OCTY_TP_CD         VARCHAR2(1000);
    V_AOA_WKDP_CD        VARCHAR2(1000);       -- 2015-09-22 이강호  재원파트 관리를 위해 추가 
    V_LGIN_CHK_CD        VARCHAR2(1000);
    V_LOGIN_AUTHORITY    VARCHAR2(1000);
    V_DO_YN              VARCHAR2(1000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_LGIN_PWD  || '''' ||
                       ',:C);';
    END;
    
    BEGIN
        SELECT A.SEC_LGIN_PWD
             , DAMO.HASH_STR_DATA(IN_LGIN_PWD)
             -- 2023-10-11 Evolvesoft 이태우 : 로그인 제한 처리 조건 추가 변경 (SR: 202310-00196)
             --, SUBSTR(XGAB.FT_RPP_CHKLOGIN(IN_STF_NO, '08'),1,1)
             --------------------------------------------------
             , XGAB.FT_RPP_CHKLOGIN(IN_STF_NO, '08')
             , CASE WHEN A.USE_GRP_CD = 'DO' THEN 'Y' -- 의사
                    WHEN A.USE_GRP_CD = 'NU' THEN 'Y' -- 간호사
                    WHEN A.USE_GRP_CD = 'PT' THEN 'Y' -- 보건직
                    WHEN A.USE_GRP_CD = 'PH' THEN 'Y' -- 약무직
                    WHEN B.OCTY_TP_CD = '45' THEN 'Y' -- 연구직
                    WHEN A.AOA_WKDP_CD = 'ICM' THEN 'Y' -- 재원관리 파트
                    ELSE 'N'
               END
             , CASE WHEN A.USE_GRP_CD = 'DO' THEN 'Y'
                    ELSE 'N'
               END -- 의사여부
          INTO V_SEC_LGIN_PWD
             , V_DAMO_HASH_STR_DATA
             , V_LGIN_CHK_CD 
             , V_LOGIN_AUTHORITY
             , V_DO_YN
          FROM XCOM.BSHRRUSV A
             , CNLRRUSD B
         WHERE A.STF_NO = B.STF_NO
           AND A.STF_NO = IN_STF_NO
           AND ROWNUM = 1
        ; 
        
        -- 2023-08-29 Evolvesoft 이태우 : 휴직자 로그인 제한 처리 조건 변경 (SR: 202308-00405)
        -- IF V_LGIN_CHK_CD = 'E' THEN
        --------------------------------------------------
        -- 2023-10-11 Evolvesoft 이태우 : 로그인 제한 처리 조건 추가 변경 (SR: 202310-00196)
        -- IF V_LGIN_CHK_CD != 'Y' THEN
        --------------------------------------------------
        -- 2024-05-16 Evolvesoft 이태우 : 로그인 제한 처리 조건 추가 변경 (연수 추가, 의사직군만 예외 되도록 수정) (SR: 202310-00196)
        -- IF SUBSTR(V_LGIN_CHK_CD, 1, 1) != 'Y' AND (V_LGIN_CHK_CD NOT IN ('N출장', 'N학회', 'N국외여행/연가')) THEN
        --------------------------------------------------
        IF (V_DO_YN = 'Y' AND SUBSTR(V_LGIN_CHK_CD, 1, 1) != 'Y' AND V_LGIN_CHK_CD NOT IN ('N출장', 'N학회', 'N국외여행/연가', 'N연수')) OR
           (V_DO_YN = 'N' AND SUBSTR(V_LGIN_CHK_CD, 1, 1) != 'Y') THEN
           BEGIN
               OPEN OUT_CURSOR FOR
               SELECT '3'                                      ERR_YN         -- 0.에러 여부
                    , '인사상의 사유로 로그인이 제한됩니다.'   ERMSG          -- 1.에러메시지
                    , IN_STF_NO                                STF_NO         -- 2.사용자 사번
                    , IN_LGIN_PWD                              LGIN_PWD       -- 3.사용자 비밀번호
                    , ''                                       KOR_SRNM_NM    -- 4.사용자 성명
                    , ''                                       AADP_CD        -- 5.부서코드
                    , ''                                       AOA_WKDP_CD    -- 6.배치된 진료부서코드
                    , ''                                       AADP_CD_NM     -- 7.부서코드 명
                    , ''                                       AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                    , ''                                       USE_GRP_CD     -- 9.사용그룹코드
                    , ''                                       USE_GRP_DTL_CD -- 10.사용그룹상세코드
                    , ''                                       NP_YN          -- 11.정신과권한여부
                    , ''                                       SEC_LGIN_PWD   -- 12.암호화 비밀번호
                    , ''                                       SID            -- 13.사용자SID
                 FROM DUAL;
                RETURN;
           END;
        END IF;  
        
        IF V_LOGIN_AUTHORITY = 'N' THEN
           BEGIN
               OPEN OUT_CURSOR FOR
               SELECT '3'                                      ERR_YN         -- 0.에러 여부
                    , '사용 권한이 없는 계정입니다.'           ERMSG          -- 1.에러메시지
                    , IN_STF_NO                                STF_NO         -- 2.사용자 사번
                    , IN_LGIN_PWD                              LGIN_PWD       -- 3.사용자 비밀번호
                    , ''                                       KOR_SRNM_NM    -- 4.사용자 성명
                    , ''                                       AADP_CD        -- 5.부서코드
                    , ''                                       AOA_WKDP_CD    -- 6.배치된 진료부서코드
                    , ''                                       AADP_CD_NM     -- 7.부서코드 명
                    , ''                                       AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                    , ''                                       USE_GRP_CD     -- 9.사용그룹코드
                    , ''                                       USE_GRP_DTL_CD -- 10.사용그룹상세코드
                    , ''                                       NP_YN          -- 11.정신과권한여부
                    , ''                                       SEC_LGIN_PWD   -- 12.암호화 비밀번호
                    , ''                                       SID            -- 13.사용자SID
                 FROM DUAL;
                RETURN;
           END;
        END IF;        

        EXCEPTION  --예외처리 
            WHEN NO_DATA_FOUND THEN
                BEGIN
                    OPEN OUT_CURSOR FOR
                        SELECT '1'                       ERR_YN         -- 0.에러 여부
--                             , '사용자 정보가 없습니다.' ERMSG          -- 1.에러메시지
                           , 'ID 혹은 패스워드가 틀렸습니다.' ERMSG          -- 1.에러메시지 --20210527 모바일취약점 문구 변경
                             , IN_STF_NO                 STF_NO         -- 2.사용자 사번
                             , IN_LGIN_PWD               LGIN_PWD       -- 3.사용자 비밀번호
                             , ''                        KOR_SRNM_NM    -- 4.사용자 성명
                             , ''                        AADP_CD        -- 5.부서코드
                             , ''                        AOA_WKDP_CD    -- 6.배치된 진료부서코드
                             , ''                        AADP_CD_NM     -- 7.부서코드 명
                             , ''                        AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                             , ''                        USE_GRP_CD     -- 9.사용그룹코드
                             , ''                        USE_GRP_DTL_CD -- 10.사용그룹상세코드
                             , ''                        NP_YN          -- 11.정신과권한여부
                             , ''                        SEC_LGIN_PWD   -- 12.암호화 비밀번호
                             , ''                        SID            -- 13.사용자SID
                          FROM DUAL
                        ;
                        RETURN;
                    END;
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN : 로그인 사용자 비밀 번호 조회중 에러발생 ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
    BEGIN
      SELECT OCTY_TP_CD
              , AOA_WKDP_CD   -- 2015-09-22 이강호  재원파트 관리를 위해 추가 
          INTO V_OCTY_TP_CD
             , V_AOA_WKDP_CD  -- 2015-09-22 이강호  재원파트 관리를 위해 추가 
          FROM CNLRRUSD
         WHERE STF_NO = IN_STF_NO
           AND ROWNUM = 1
        ;
    END;

    --2025//IF V_SEC_LGIN_PWD = V_DAMO_HASH_STR_DATA THEN
     IF 1=1 THEN
--      IF IN_STF_NO = '1000945' OR IN_STF_NO = '1001902' OR IN_STF_NO = '1000851' OR IN_STF_NO = '1002998' OR IN_STF_NO = '1000757' THEN
        IF V_OCTY_TP_CD = '45' THEN
        BEGIN
            OPEN OUT_CURSOR FOR
              SELECT /*+ XMOB.PKG_BSH_ME.PC_BSH_USR_LGIN */
                         '0'            ERR_YN         -- 0.에러 여부
                       , ''             ERMSG          -- 1.에러메시지
                       , IN_STF_NO      STF_NO         -- 2.사용자 사번
                       , IN_LGIN_PWD    LGIN_PWD       -- 3.사용자 비밀번호
                       , KOR_SRNM_NM    KOR_SRNM_NM    -- 4.사용자 성명
                       , AADP_CD        AADP_CD        -- 5.부서코드
                       , AOA_WKDP_CD    AOA_WKDP_CD    -- 6.배치된 진료부서코드
                       , AADP_CD_NM     AADP_CD_NM     -- 7.부서코드 명
                       , AOA_WKDP_CD_NM AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                       , 'DO'     USE_GRP_CD     -- 9.사용그룹코드
                       , USE_GRP_DTL_CD USE_GRP_DTL_CD -- 10.사용그룹상세코드
                       , ( SELECT DECODE(COUNT(*), 0, 'N', 'Y')
                             FROM CNLMRUDD
                            WHERE USE_SID     = A.SID
                              AND MED_DEPT_CD = 'NP'
                              AND ROWNUM = 1 )                      NP_YN         -- 11.정신과권한여부 (201212 - 수정필요)
                       , SEC_LGIN_PWD                               SEC_LGIN_PWD  -- 12.암호화 비밀번호
                       , SID                                        SID           -- 13.사용자SID
                    FROM XCOM.BSHRRUSV A
                   WHERE STF_NO = IN_STF_NO
                     AND ROWNUM = 1
                  ;
                  EXCEPTION  --예외처리
                      WHEN OTHERS THEN
                          RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
          END;                    
    ELSIF V_AOA_WKDP_CD = 'ICM' THEN
          BEGIN
            OPEN OUT_CURSOR FOR
              SELECT /*+ XMOB.PKG_BSH_ME.PC_BSH_USR_LGIN */
                         '0'            ERR_YN         -- 0.에러 여부
                       , ''             ERMSG          -- 1.에러메시지
                       , IN_STF_NO      STF_NO         -- 2.사용자 사번
                       , IN_LGIN_PWD    LGIN_PWD       -- 3.사용자 비밀번호
                       , KOR_SRNM_NM    KOR_SRNM_NM    -- 4.사용자 성명
                       , AADP_CD        AADP_CD        -- 5.부서코드
                       , AOA_WKDP_CD    AOA_WKDP_CD    -- 6.배치된 진료부서코드
                       , AADP_CD_NM     AADP_CD_NM     -- 7.부서코드 명
                       , AOA_WKDP_CD_NM AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                       , 'PT'     USE_GRP_CD     -- 9.사용그룹코드
                       , USE_GRP_DTL_CD USE_GRP_DTL_CD -- 10.사용그룹상세코드
                       , ( SELECT DECODE(COUNT(*), 0, 'N', 'Y')
                             FROM CNLMRUDD
                            WHERE USE_SID     = A.SID
                              AND MED_DEPT_CD = 'NP'
                              AND ROWNUM = 1 )                      NP_YN         -- 11.정신과권한여부 (201212 - 수정필요)
                       , SEC_LGIN_PWD                               SEC_LGIN_PWD  -- 12.암호화 비밀번호
                       , SID                                        SID           -- 13.사용자SID
                    FROM XCOM.BSHRRUSV A
                   WHERE STF_NO = IN_STF_NO
                     AND ROWNUM = 1
                  ;
                  EXCEPTION  --예외처리
                      WHEN OTHERS THEN
                          RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
          END;       
      ELSE 
          BEGIN
              OPEN OUT_CURSOR FOR
                  SELECT /*+ XMOB.PKG_BSH_ME.PC_BSH_USR_LGIN */
                         '0'            ERR_YN         -- 0.에러 여부
                       , ''             ERMSG          -- 1.에러메시지
                       , IN_STF_NO      STF_NO         -- 2.사용자 사번
                       , IN_LGIN_PWD    LGIN_PWD       -- 3.사용자 비밀번호
                       , KOR_SRNM_NM    KOR_SRNM_NM    -- 4.사용자 성명
                       , AADP_CD        AADP_CD        -- 5.부서코드
                       , AOA_WKDP_CD    AOA_WKDP_CD    -- 6.배치된 진료부서코드
                       , AADP_CD_NM     AADP_CD_NM     -- 7.부서코드 명
                       , AOA_WKDP_CD_NM AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                       , USE_GRP_CD     USE_GRP_CD     -- 9.사용그룹코드
                       , USE_GRP_DTL_CD USE_GRP_DTL_CD -- 10.사용그룹상세코드
                       , ( SELECT DECODE(COUNT(*), 0, 'N', 'Y')
                             FROM CNLMRUDD
                            WHERE USE_SID     = A.SID
                              AND MED_DEPT_CD = 'NP'
                              AND ROWNUM = 1 )                      NP_YN         -- 11.정신과권한여부 (201212 - 수정필요)
                       , SEC_LGIN_PWD                               SEC_LGIN_PWD  -- 12.암호화 비밀번호
                       , SID                                        SID           -- 13.사용자SID
                    FROM XCOM.BSHRRUSV A
                   WHERE STF_NO = IN_STF_NO
                     AND ROWNUM = 1
                  ;
                  EXCEPTION  --예외처리
                      WHEN OTHERS THEN
                          RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
          END;
        END IF;

        BEGIN
            -- BESTCARELink 사용 로그 저장.
            XMOB.PC_BSH_SV_LOG('M', IN_STF_NO, IN_SQL_ID, '08', IN_IP_ADDR, '', V_SRCH_CNTE);
        END;
    ELSE
        BEGIN
            OPEN OUT_CURSOR FOR
                SELECT '2'                       ERR_YN         -- 0.에러 여부
--                     , '비밀번호를 확인하세요.'  ERMSG          -- 1.에러메시지
                     , 'ID 혹은 패스워드가 틀렸습니다.' ERMSG          -- 1.에러메시지 --20210527 모바일취약점 문구 변경
                     , IN_STF_NO                 STF_NO         -- 2.사용자 사번
                     , IN_LGIN_PWD               LGIN_PWD       -- 3.사용자 비밀번호
                     , ''                        KOR_SRNM_NM    -- 4.사용자 성명
                     , ''                        AADP_CD        -- 5.부서코드
                     , ''                        AOA_WKDP_CD    -- 6.배치된 진료부서코드
                     , ''                        AADP_CD_NM     -- 7.부서코드 명
                     , ''                        AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                     , ''                        USE_GRP_CD     -- 9.사용그룹코드
                     , ''                        USE_GRP_DTL_CD -- 10.사용그룹상세코드
                     , ''                        NP_YN          -- 11.정신과권한여부
                     , ''                        SEC_LGIN_PWD   -- 12.암호화 비밀번호
                     , ''                        SID            -- 13.사용자SID
                  FROM DUAL
                ;
        END;
    END IF;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
END PC_BSH_USR_LGIN;
