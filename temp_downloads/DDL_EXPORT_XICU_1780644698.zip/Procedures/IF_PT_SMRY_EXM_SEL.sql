
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_SMRY_EXM_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , IN_EXAM_CD          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NO,
        A.PT_NM,
        S.EXAM_DT,
        S.EXAM_ITEM_NM,
        S.EXAM_NM,
        S.EXAM_RESULT_VAL,
        S.EXAM_REF_RANGE
    FROM PT_SMRY_EXM_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.EXAM_CD = IN_EXAM_CD
      AND S.EXAM_DT >= (
        SELECT MAX(EXAM_DT)
        FROM PT_SMRY_EXM_SEL
        ) - 3
      AND A.SEQ = IN_SEQ;

END;
