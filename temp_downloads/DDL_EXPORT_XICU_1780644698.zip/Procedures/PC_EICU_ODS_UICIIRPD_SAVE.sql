
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICIIRPD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTE       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICIIRPD_SAVE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : ODS_UICIIRPD(격리병동환자기본)데이터 적재
*    Change History : 2021.03.15                                                
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    BEGIN        
        MERGE INTO HICU.UICIIRPD A  --격리병동환자기본
             USING ( SELECT DISTINCT IN_HSP_TP_CD  HSP_TP_CD
                          , PACT_ID
                          , PT_NO   
                          , PT_NM
                          , ADS_DT
                          , DS_EXPT_DT
                          , AGE
                          , AGE_MRK_NM 
                          , SEX_TP_CD
                          , ADS_PATH_CD
                          , ADS_PATH_CD_NM
                          , EMRG_PACT_ID
                          , EMRM_ARVL_DTM
                          , ADS_ACPT_BSC_FST_WRT_DTM
                          , ADS_ACPT_BSC_LST_WRT_DTM   
                       FROM XICU.EMEI007V
                      WHERE LST_CHG_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE 
                   ) B
                ON ( A.PACT_ID = B.PACT_ID)
              WHEN MATCHED THEN
                   UPDATE SET A.HSP_TP_CD                     = B.HSP_TP_CD
                            , A.PT_NO                         = B.PT_NO
                            , A.PT_NM                         = B.PT_NM
                            , A.ADS_DT                        = B.ADS_DT
                            , A.DS_EXPT_DT                    = B.DS_EXPT_DT
                            , A.AGE                           = B.AGE 
                            , A.AGE_MRK_NM                    = B.AGE_MRK_NM
                            , A.ADS_PATH_CD                   = B.ADS_PATH_CD
                            , A.ADS_PATH_CD_NM                = B.ADS_PATH_CD_NM
                            , A.EMRG_PACT_ID                  = B.EMRG_PACT_ID
                            , A.EMRM_ARVL_DTM                 = B.EMRM_ARVL_DTM    
                            , A.SEX_TP_CD                     = B.SEX_TP_CD
                            , A.FST_WRT_DTM                   = B.ADS_ACPT_BSC_FST_WRT_DTM
                            , A.LST_CHG_DTM                  = B.ADS_ACPT_BSC_LST_WRT_DTM
                            , A.LST_LOD_DTM                   = SYSDATE
              WHEN NOT MATCHED THEN
                   INSERT ( A.HSP_TP_CD
                          , A.PACT_ID
                          , A.PT_NO   
                          , A.PT_NM
                          , A.ADS_DT
                          , A.DS_EXPT_DT
                          , A.AGE
                          , A.AGE_MRK_NM
                          , A.ADS_PATH_CD
                          , A.ADS_PATH_CD_NM
                          , A.EMRG_PACT_ID
                          , A.EMRM_ARVL_DTM
                          , A.SEX_TP_CD
                          , A.FST_WRT_DTM
                          , A.LST_CHG_DTM 
                          , A.FST_LOD_DTM
                          , A.LST_LOD_DTM
                          )
                   VALUES ( B.HSP_TP_CD
                          , B.PACT_ID
                          , B.PT_NO   
                          , B.PT_NM
                          , B.ADS_DT
                          , B.DS_EXPT_DT 
                          , B.AGE
                          , B.AGE_MRK_NM
                          , B.ADS_PATH_CD
                          , B.ADS_PATH_CD_NM
                          , B.EMRG_PACT_ID
                          , B.EMRM_ARVL_DTM 
                          , B.SEX_TP_CD      
                          , B.ADS_ACPT_BSC_FST_WRT_DTM
                          , B.ADS_ACPT_BSC_LST_WRT_DTM 
                          , SYSDATE
                          , SYSDATE
                          )
        ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICIIRID_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICIIRPD_SAVE;
