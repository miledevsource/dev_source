
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_MENULIST_CENTER" 
                          ( OUT_CURSOR OUT SYS_REFCURSOR )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_MENULIST_CENTER
*    CREATEDATE     : 2021.02.17
*    Author         : 이창우
*    Description    : 관제센터 병원별 메뉴 리스트 
*    Change History : 
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
             SELECT MAIN.HSP_TP_CD
                  , MAIN.HSP_NM
                  , MAIN.STCI_STU_NO
                  , MAIN.STCI_CD
                  , MAIN.PRGM_SCLS_CD
                  , MAIN.UPR_PRGM_SCLS_CD
                  , MAIN.UPR_STCI_CD
                  , MAIN.MN_TYPE1
                  , MAIN.MN_TYPE2
                  , MAIN.USR_SCR_NM
                  , MAIN.UI_PATH_NM
                  , DEPT.DEPT_CD 
                  , DEPT.DEPT_NM 
               FROM (SELECT CHPM.HSP_TP_CD 
                          , CHPM.HSP_NM 
                          , CSTE.COMN_CD_NM  MN_TYPE1
                          , CSTE2.COMN_CD_NM MN_TYPE2
                          , CUSE.STCI_STU_NO 
                          , CUSE.UPR_PRGM_SCLS_CD
                          , CUSE.UPR_STCI_CD 
                          , CUSE.STCI_CD
                          , CUSE.SORT_SEQ
                          , CSTM.PRGM_SCLS_CD
                          , CSTM.USR_SCR_NM
                          , CSTM.UI_PATH_NM 
                       FROM HICU.UCCOCHPM CHPM
                          , HICU.UCCOCUCD CUCD
                          , HICU.UCCOCUSE CUSE
                          , HICU.UCCOCSTM CSTM
                          , HICU.UCCOCSTE CSTE
                          , HICU.UCCOCSTE CSTE2
                      WHERE CHPM.USE_YN = 'Y'
                        AND CUCD.USE_YN = 'Y'
                        AND CUCD.MENU_USE_TP = '01'
                        AND CUSE.USE_YN = 'Y'
                        AND CSTM.USE_YN = 'Y'
                        AND CSTE.COMN_GRP_CD = 'IC001'
                        AND CSTE.COMN_CD = '01'
                        AND CSTE2.COMN_GRP_CD = 'IC003'
                        AND CSTE2.COMN_CD = CSTM.PRGM_SCLS_CD
                        AND CHPM.HSP_TP_CD = CUCD.HSP_TP_CD
                        AND CUCD.HSP_TP_CD = CUSE.HSP_TP_CD 
                        AND CUCD.STCI_STU_NO = CUSE.STCI_STU_NO
                        AND CUSE.HSP_TP_CD = CSTM.HSP_TP_CD 
                        AND CUSE.STCI_CD = CSTM.STCI_CD 
                        AND SYSDATE BETWEEN CSTM.AVL_STR_DTM AND CSTM.AVL_END_DTM 
                    ) MAIN
               FULL OUTER JOIN (
                                SELECT HSP_TP_CD, DEPT_CD, DEPT_NM, SORT_SEQ, '212' PRGM_SCLS_CD 
                                  FROM HICU.UCCOCDPM DAT1
                                 WHERE USE_YN = 'Y'
--                                UNION ALL
--                                SELECT B.HSP_TP_CD, A.DEPT_CD, A.DEPT_NM, 0 SORT_SEQ
--                                  FROM (SELECT 'ALL' DEPT_CD, '전체' DEPT_NM FROM DUAL) A
--                                     , (SELECT DISTINCT(HSP_TP_CD) HSP_TP_CD FROM UCCOCDPM) B
                               ) DEPT
                            ON MAIN.HSP_TP_CD = DEPT.HSP_TP_CD 
                           AND MAIN.PRGM_SCLS_CD = DEPT.PRGM_SCLS_CD
              WHERE MAIN.HSP_TP_CD IS NOT NULL
              ORDER BY MAIN.HSP_TP_CD, MAIN.PRGM_SCLS_CD, MAIN.SORT_SEQ, DEPT.SORT_SEQ;
    END;
END PC_EICU_SELECT_MENULIST_CENTER;
