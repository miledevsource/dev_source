
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_ISOLATE_BATCH" (  IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                            , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                                            , IN_TO_DTE       IN DATE             -- 04.조회종료일자
                                            , IO_ERRYN        IN OUT  VARCHAR2    -- 05. ERROR Y/N
                                            , IO_ERRMSG       IN OUT  VARCHAR2   -- 06. ERROR MESSAGE 
                                        ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_ISOLATE_BATCH
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민
*    Description    : 관제시스템에서 사용하는 국가지정 격리 병상 데이터 적재 
*    Change History : 2021.03.15, 오지민, 최초작성
**********************************************************************************************/
 AS
    N_DAYCOUNT NUMBER := 0;
    D_START_DTE DATE := TRUNC(IN_FROM_DTE) - 1;
    
    V_HLDY_YN VARCHAR2(1) := 'N';        
BEGIN   
	
	N_DAYCOUNT := TRUNC(IN_TO_DTE) - TRUNC(IN_FROM_DTE);
    
    BEGIN 
        FOR I IN 0..N_DAYCOUNT LOOP
            D_START_DTE := D_START_DTE + 1;
            
            BEGIN
            	SELECT NVL(HLDY_YN, 'N')    
				  INTO V_HLDY_YN
				  FROM HICU.UICIIRHD  
				 WHERE DT_CD = D_START_DTE;
			EXCEPTION
		        WHEN OTHERS THEN
		            V_HLDY_YN := 'N';	 
            END;
            
            BEGIN 
            IO_ERRYN := 'N';
	            MERGE INTO HICU.UCCIISPM A  --격리병동환자지표기본
			     USING (
			            WITH ISOLATE_PT_INFO AS
			                    (
			                        SELECT ETRM_WD_DEPT_CD                     AS WD_DEPT_CD
			                             , TO_CHAR(D_START_DTE, 'YYYYMMDD')    AS ETRM_DT_SEQ
			                             , HSP_TP_CD                           AS HSP_TP_CD
			                             , ETRM_WD_DEPT_CD_NM                  AS WD_DEPT_CD_NM
			                             , '1'  YY_PT_CNT
			                             , NVL((CASE WHEN ETRM_DTM = D_START_DTE THEN
			                        		                  1
			                        		             ELSE
			                        		                  0
			                        		             END), 0)    AS ETRM_PT_CNT
			                         FROM HICU.UICIISPM  A--격리병동지표기본
			                        WHERE D_START_DTE BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE , A.CHOT_DTM)
			                          AND HSP_TP_CD = IN_HSP_TP_CD)
			                 , AVG_STAY AS
			                    (
			                        /*퇴실환자 재실 일수*/
			                        SELECT TO_CHAR(D_START_DTE, 'YYYYMMDD')  AS ETRM_DT_SEQ
			                             , CNT
			                             , STAY_DAY
			                             , CASE WHEN 0 <= STAY_DAY AND STAY_DAY <= 5  THEN '5'
			                		            WHEN 5 < STAY_DAY AND STAY_DAY <= 10 THEN '10'
			                		            WHEN 10 < STAY_DAY AND STAY_DAY <= 15 THEN '15'
			                		            WHEN 15 < STAY_DAY  AND STAY_DAY <= 20 THEN '20'
			                		            WHEN 20 < STAY_DAY  AND STAY_DAY <= 25 THEN '25'
			                		            WHEN 25 < STAY_DAY  THEN 'OVER25'
			                		            ELSE NULL END       DAY_RANGE
			                		   FROM (
			                                    SELECT 1 CNT
			                                         , NVL(TRUNC(NVL(A.CHOT_DTM, SYSDATE)) - TRUNC(NVL(A.ETRM_DTM, SYSDATE))  + 1, 0)   STAY_DAY
			                                      FROM HICU.UICIISPM A --격리병동환자지표기본
			                                     WHERE A.HSP_TP_CD = IN_HSP_TP_CD
			                                       AND A.CHOT_DTM = D_START_DTE)
			                    )
			                 , BED_DAYS AS
			                 (
			                     /*연병상*/
			                     SELECT WD_DEPT_CD
			                          , COMN_CD_NM                                               AS WD_DEPT_CD_NM
			                          , TO_CHAR(D_START_DTE, 'YYYYMMDD')                         AS ETRM_DT_SEQ
		                              , TO_CHAR(D_START_DTE, 'YYYY')                             AS ETRM_YY
		                              , TO_CHAR(D_START_DTE, 'MM')                               AS ETRM_MM
		                              , TO_CHAR(D_START_DTE, 'DD')                               AS ETRM_DY
		                              , SUM(BED_CNT) BED_DAYS    
		                              , V_HLDY_YN                           AS HLDY_YN
								   FROM HICU.UICIWBCD A
								      , HICU.UCCOCSTE B
				 				  WHERE A.BED_CFMT_DT = D_START_DTE
								    AND A.HSP_TP_CD   = IN_HSP_TP_CD
--								    AND WD_DEPT_CD  IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
                                    AND A.HSP_TP_CD = B.HSP_TP_CD
								    AND A.WD_DEPT_CD  = B.COMN_CD
								    AND B.COMN_GRP_CD = 'IC018' AND B.USE_YN = 'Y'
								   GROUP BY WD_DEPT_CD, COMN_CD_NM
			                 )
			                 , ISOLATE_SILLM_CTG_DATA AS(
			                         SELECT TO_CHAR(D_START_DTE, 'YYYYMMDD')                         AS ETRM_DT_SEQ
			                              , A.PT_SILLM_CTG_GRP_CD                                    AS PT_SILLM_CTG_GRP_CD
			                              , COUNT(*)                                                 AS CNT
			                          FROM HICU.UICIISPD A   --중환자실환자중증도분류정보
			                             , HICU.UICIISPM B   --중환자실환자지표기본
			                	     WHERE A.HSP_TP_CD                = IN_HSP_TP_CD            --병원구분코드
			                	       AND A.PACT_ID                  = B.PACT_ID
			                	       AND A.PT_NO                    = B.PT_NO
			                	       AND A.HSP_TP_CD                = B.HSP_TP_CD
--			                           AND B.ETRM_WD_DEPT_CD          = A.WD_DEPT_CD
			                           AND A.PT_SILLM_CTG_DTM BETWEEN D_START_DTE AND D_START_DTE + 0.99999
			                           AND D_START_DTE BETWEEN  B.ETRM_DTM AND DECODE(B.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE , B.CHOT_DTM)
			                         GROUP BY A.PT_SILLM_CTG_GRP_CD)
			                 SELECT B.WD_DEPT_CD                                                AS WD_DEPT_CD
			                      , B.ETRM_DT_SEQ                                               AS ETRM_DT_SEQ
			                      , IN_HSP_TP_CD                                                AS HSP_TP_cD
			                      , NVL(A.WD_DEPT_CD_NM, B.WD_DEPT_CD_NM)                       AS WD_DEPT_CD_NM
			                      , HLDY_YN
			                      , B.ETRM_YY                                                    AS ETRM_YY
			                      , B.ETRM_MM                                                    AS ETRM_MM
			                      , B.ETRM_DY                                                    AS ETRM_DY
			                      , NVL(YY_PT_CNT, 0)                                            AS YY_PT_CNT
			                      , NVL(B.BED_DAYS, 0)                                           AS YY_BED_CNT
			                      , NVL(ETRM_PT_CNT, 0)                                          AS ETRM_PT_CNT
			                      , NVL(C.CNT, 0)                                                AS CHOT_PT_CNT
			                      , NVL(C.STAY_DAY,0)                                              AS WHL_SIRM_DYS
			                      , NVL(PT_SILLM_CTG_1_GRP_CNT, 0)                                AS PT_SILLM_CTG_1_GRP_CNT
			                      , NVL(PT_SILLM_CTG_2_GRP_CNT, 0)                                AS PT_SILLM_CTG_2_GRP_CNT
			                      , NVL(PT_SILLM_CTG_3_GRP_CNT, 0)                                AS PT_SILLM_CTG_3_GRP_CNT
			                      , NVL(PT_SILLM_CTG_4_GRP_CNT, 0)                                AS PT_SILLM_CTG_4_GRP_CNT
			                      , NVL(PT_SILLM_CTG_5_GRP_CNT, 0)                                AS PT_SILLM_CTG_5_GRP_CNT
			                      , NVL(PT_SILLM_CTG_6_GRP_CNT, 0)                                AS PT_SILLM_CTG_6_GRP_CNT
			                      , NVL(SIRM_5_DY_IN_CNT, 0)                                      AS SIRM_5_DY_IN_CNT
			                      , NVL(SIRM_10_DY_IN_CNT, 0)                                      AS SIRM_10_DY_IN_CNT
			                      , NVL(SIRM_15_DY_IN_CNT, 0)                                      AS SIRM_15_DY_IN_CNT
			                      , NVL(SIRM_20_DY_IN_CNT, 0)                                      AS SIRM_20_DY_IN_CNT
			                      , NVL(SIRM_25_DY_IN_CNT, 0)                                      AS SIRM_25_DY_IN_CNT
			                      , NVL(SIRM_25_TM_EXCS_CNT, 0)                                    AS SIRM_25_TM_EXCS_CNT
			                   FROM BED_DAYS B
			                      , (
			                         SELECT WD_DEPT_CD
			                              , ETRM_DT_SEQ
			                              , HSP_TP_CD
			                              , WD_DEPT_CD_NM
			                              , TO_CHAR(D_START_DTE, 'YYYY')                             AS ETRM_YY
			                              , TO_CHAR(D_START_DTE, 'MM')                               AS ETRM_MM
			                              , TO_CHAR(D_START_DTE, 'DD')                               AS ETRM_DY
			                              , SUM(YY_PT_CNT)               AS YY_PT_CNT
			                              , SUM(ETRM_PT_CNT)             AS ETRM_PT_CNT
			                           FROM ISOLATE_PT_INFO A
			                          GROUP BY WD_DEPT_CD
			                              , ETRM_DT_SEQ
			                              , HSP_TP_CD
			                              , WD_DEPT_CD_NM) A
			                       , (SELECT TO_CHAR(D_START_DTE, 'YYYYMMDD')                                    AS ETRM_DT_SEQ,
			                                 SUM(CNT)                                                            AS CNT ,
			                                 SUM(STAY_DAY)                                                       AS STAY_DAY
			                            FROM AVG_STAY) C
			                       , ( SELECT TO_CHAR(D_START_DTE, 'YYYYMMDD')                                    AS ETRM_DT_SEQ
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '1' THEN  CNT  ELSE 0 END)  AS PT_SILLM_CTG_1_GRP_CNT
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '2' THEN  CNT  ELSE 0 END)  AS PT_SILLM_CTG_2_GRP_CNT
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '3' THEN  CNT  ELSE 0 END)  AS PT_SILLM_CTG_3_GRP_CNT
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '4' THEN  CNT  ELSE 0 END)  AS  PT_SILLM_CTG_4_GRP_CNT
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '5' THEN  CNT  ELSE 0 END)  AS  PT_SILLM_CTG_5_GRP_CNT
			                                , SUM(CASE WHEN  A.PT_SILLM_CTG_GRP_CD  = '6' THEN  CNT  ELSE 0 END)  AS  PT_SILLM_CTG_6_GRP_CNT
			                            FROM ISOLATE_SILLM_CTG_DATA A) D
			                       , ( SELECT TO_CHAR(D_START_DTE, 'YYYYMMDD')                                AS ETRM_DT_SEQ
			                                , NVL(SUM(CASE WHEN  A.DAY_RANGE  = '5' THEN  1  ELSE 0 END), 0)  AS SIRM_5_DY_IN_CNT
			                                , SUM(CASE WHEN  A.DAY_RANGE  = '10' THEN  1  ELSE 0 END)         AS SIRM_10_DY_IN_CNT
			                                , SUM(CASE WHEN  A.DAY_RANGE  = '15' THEN  1  ELSE 0 END)         AS SIRM_15_DY_IN_CNT
			                                , SUM(CASE WHEN  A.DAY_RANGE  = '20' THEN  1  ELSE 0 END)         AS  SIRM_20_DY_IN_CNT
			                                , SUM(CASE WHEN  A.DAY_RANGE  = '25' THEN  1  ELSE 0 END)         AS  SIRM_25_DY_IN_CNT
			                                , SUM(CASE WHEN  A.DAY_RANGE  = 'OVER25' THEN  1  ELSE 0 END)     AS  SIRM_25_TM_EXCS_CNT
			                            FROM AVG_STAY A) E
			                WHERE B.ETRM_DT_SEQ = A.ETRM_DT_SEQ (+)
			                  AND B.ETRM_DT_SEQ = C.ETRM_DT_SEQ (+)
			                  AND B.ETRM_DT_SEQ = D.ETRM_DT_SEQ (+)
			                  AND B.ETRM_DT_SEQ = E.ETRM_DT_SEQ (+) ) B 
			                  ON (     A.WD_DEPT_CD                        = B.WD_DEPT_CD
						         AND A.HSP_TP_CD                       = B.HSP_TP_CD
						         AND A.ETRM_DT_SEQ                 = B.ETRM_DT_SEQ )
			   WHEN MATCHED THEN
			       UPDATE SET
			           A.WD_DEPT_CD_NM               = B.WD_DEPT_CD_NM
			         , A.ETRM_YY                     = B.ETRM_YY
			         , A.ETRM_MM                     = B.ETRM_MM
			         , A.ETRM_DY                     = B.ETRM_DY
			         , A.YY_PT_CNT                   = B.YY_PT_CNT
			         , A.YY_BED_CNT                  = B.YY_BED_CNT
			         , A.ETRM_PT_CNT                 = B.ETRM_PT_CNT
			         , A.CHOT_PT_CNT                 = B.CHOT_PT_CNT
			         , A.WHL_SIRM_DYS                = B.WHL_SIRM_DYS
			         , A.PT_SILLM_CTG_1_GRP_CNT      = B.PT_SILLM_CTG_1_GRP_CNT
			         , A.PT_SILLM_CTG_2_GRP_CNT      = B.PT_SILLM_CTG_2_GRP_CNT
			         , A.PT_SILLM_CTG_3_GRP_CNT      = B.PT_SILLM_CTG_3_GRP_CNT
			         , A.PT_SILLM_CTG_4_GRP_CNT      = B.PT_SILLM_CTG_4_GRP_CNT
			         , A.PT_SILLM_CTG_5_GRP_CNT      = B.PT_SILLM_CTG_5_GRP_CNT
			         , A.PT_SILLM_CTG_6_GRP_CNT      = B.PT_SILLM_CTG_6_GRP_CNT
			         , A.SIRM_5_DY_IN_CNT            = B.SIRM_5_DY_IN_CNT
			         , A.SIRM_10_DY_IN_CNT           = B.SIRM_10_DY_IN_CNT
			         , A.SIRM_15_DY_IN_CNT           = B.SIRM_15_DY_IN_CNT
			         , A.SIRM_20_DY_IN_CNT           = B.SIRM_20_DY_IN_CNT
			         , A.SIRM_25_DY_IN_CNT           = B.SIRM_25_DY_IN_CNT
			         , A.SIRM_25_TM_EXCS_CNT         = B.SIRM_25_TM_EXCS_CNT
			         , A.HLDY_YN                     = B.HLDY_YN
			         , A.LOD_DTM                     = SYSDATE
			
			  WHEN NOT MATCHED THEN
			      INSERT (
			                 WD_DEPT_CD
			               , ETRM_DT_SEQ
			               , HSP_TP_CD
			               , WD_DEPT_CD_NM
			               , ETRM_YY
			               , ETRM_MM
			               , ETRM_DY
			               , YY_PT_CNT
			               , YY_BED_CNT
			               , ETRM_PT_CNT
			               , CHOT_PT_CNT
			               , WHL_SIRM_DYS
			               , PT_SILLM_CTG_1_GRP_CNT
			               , PT_SILLM_CTG_2_GRP_CNT
			               , PT_SILLM_CTG_3_GRP_CNT
			               , PT_SILLM_CTG_4_GRP_CNT
			               , PT_SILLM_CTG_5_GRP_CNT
			               , PT_SILLM_CTG_6_GRP_CNT
			               , SIRM_5_DY_IN_CNT
			               , SIRM_10_DY_IN_CNT
			               , SIRM_15_DY_IN_CNT
			               , SIRM_20_DY_IN_CNT
			               , SIRM_25_DY_IN_CNT
			               , SIRM_25_TM_EXCS_CNT  
			               , HLDY_YN
			               , LOD_DTM
			        )
			      VALUES (
			                 B.WD_DEPT_CD
			               , B.ETRM_DT_SEQ
			               , B.HSP_TP_CD
			               , B.WD_DEPT_CD_NM
			               , B.ETRM_YY
			               , B.ETRM_MM
			               , B.ETRM_DY
			               , B.YY_PT_CNT
			               , B.YY_BED_CNT
			               , B.ETRM_PT_CNT
			               , B.CHOT_PT_CNT
			               , B.WHL_SIRM_DYS
			               , B.PT_SILLM_CTG_1_GRP_CNT
			               , B.PT_SILLM_CTG_2_GRP_CNT
			               , B.PT_SILLM_CTG_3_GRP_CNT
			               , B.PT_SILLM_CTG_4_GRP_CNT
			               , B.PT_SILLM_CTG_5_GRP_CNT
			               , B.PT_SILLM_CTG_6_GRP_CNT
			               , B.SIRM_5_DY_IN_CNT
			               , B.SIRM_10_DY_IN_CNT
			               , B.SIRM_15_DY_IN_CNT
			               , B.SIRM_20_DY_IN_CNT
			               , B.SIRM_25_DY_IN_CNT
			               , B.SIRM_25_TM_EXCS_CNT 
			               , B.HLDY_YN
			               , SYSDATE
			          );     
			 COMMIT;
			 EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';
		            IO_ERRMSG := '(XICU.PC_EICU_CENTER_ISOLATE_BATCH): HSP_TP_CD = '|| IN_HSP_TP_CD || 'BED_CFMT_DT = ' || TO_CHAR(D_START_DTE, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
		    END;
        END LOOP;
    END;    
END PC_EICU_CENTER_ISOLATE_BATCH;
