
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ISOLATE_YEAR_STATICS" 
                          ( IN_FROM_DTE    IN  DATE
                          , IN_TO_DTE      IN  DATE
                          , IN_WD_DEPT_CD  IN VARCHAR2
                          , IN_HSP_TP_CD   IN VARCHAR2
                          , OUT_CURSOR    OUT SYS_REFCURSOR
                          )

IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ISOLATE_PAT_STATICS                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표>>격리병동현황 조회(연병상, 연병상률 추이)
*    Change History : 2021.03.15                                                
**********************************************************************************************/
BEGIN
    BEGIN 
	    OPEN OUT_CURSOR FOR   
	        WITH MONTH_DATA AS
				(  /*월별 기준데이터*/
					SELECT TO_CHAR(DT_CD, 'YYYY-MM')                                       DATE_TYPE
					     , LAST_DAY(TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01' ,'YYYY-MM-DD')) - TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') + 1 NALSU
			             , CASE WHEN TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01' ,'YYYY-MM-DD') > TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM')||'-01', 'YYYY-MM-DD') THEN 'N' ELSE 'Y' END DIS_YN  /*미래는 표시안함*/
			          FROM HICU.UICIIRHD                        
			         WHERE DT_CD BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -11)) AND LAST_DAY(IN_TO_DTE)
			         GROUP BY TO_CHAR(DT_CD, 'YYYY-MM'))
			   , MAN_DAYS AS
			   (
			         SELECT DATA_TYPE
					      , SUM(IN_DAYS)    IN_DAYS
					   FROM (
						      SELECT TO_CHAR(D.DT_CD, 'YYYY-MM')  DATA_TYPE
						           , A.PACT_ID
							       , A.ETRM_DTM
							       , A.CHOT_DTM
							       , CASE WHEN DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) - LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  THEN
							                LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							          ELSE
							                DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							          END
							        - CASE WHEN A.ETRM_DTM - TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 THEN
							                   TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
			   		                  ELSE
							                   TRUNC(A.ETRM_DTM)
							          END + 1      IN_DAYS  --"연인원"
							    FROM HICU.UICIISPM A   --격리병동환자지표기본
   							       , HICU.UICIIRHD D   --휴일정보
							   WHERE A.HSP_TP_CD = IN_HSP_TP_CD                          
--							     AND A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                                 AND A.ETRM_WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
							     AND
							        (
							          A.ETRM_DTM BETWEEN  TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM') AND LAST_DAY(IN_TO_DTE)
							                    OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM') AND LAST_DAY(IN_TO_DTE)
							                    OR (A.ETRM_DTM < TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM') AND A.CHOT_DTM > LAST_DAY(IN_TO_DTE))
							        )
							     AND D.DT_CD BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							     AND D.DT_CD <= TRUNC(SYSDATE)
							   GROUP BY TO_CHAR(D.DT_CD, 'YYYY-MM'), A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM )
					   GROUP BY DATA_TYPE )
			   , BF_MAN_DAYS  AS
			   (   /*전년도 당월데이터*/
				     SELECT SUM(IN_DAYS)    IN_DAYS
					   FROM (SELECT TO_CHAR(D.DT_CD, 'YYYY-MM')  DATA_TYPE
						           , A.PACT_ID
						           , A.ETRM_DTM
						           , A.CHOT_DTM
						           , CASE WHEN DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE), A.CHOT_DTM) - LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  THEN
						                   LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
						             ELSE
						                   DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
						             END
						            - CASE WHEN A.ETRM_DTM - TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 THEN
						                   TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
						              ELSE
						                          TRUNC(A.ETRM_DTM)
						             END + 1      IN_DAYS  --"연인원"
						     FROM HICU.UICIISPM A   --격리병동환자지표기본
   							    , HICU.UICIIRHD D   --휴일정보
						    WHERE A.HSP_TP_CD = IN_HSP_TP_CD     
--							  AND A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                              AND A.ETRM_WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
						      AND
						          (
						            A.ETRM_DTM BETWEEN  TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM') AND LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12))
						                      OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM') AND LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12))
						                      OR (A.ETRM_DTM < TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM') AND A.CHOT_DTM > LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12)))
						          )
						      AND D.DT_CD BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
						      AND D.YYMM_CD = TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12),  'YYYY-MM')
						     GROUP BY TO_CHAR(D.DT_CD, 'YYYY-MM'), A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM ))
			   , BF_YEAR_MAN_DAYS AS
			   ( /*전년도 월평균*/
				    SELECT DATA_TYPE
				         , SUM(IN_DAYS)    IN_DAYS
					  FROM (
						       SELECT TO_CHAR(D.DT_CD, 'YYYY-MM')  DATA_TYPE
							        , A.PACT_ID
							        , A.ETRM_DTM
							        , A.CHOT_DTM
							        , CASE WHEN DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) - LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  THEN
							                        LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							         ELSE
							               DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							         END
							             - CASE WHEN A.ETRM_DTM - TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 THEN
							                          TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
							                     ELSE
							                          TRUNC(A.ETRM_DTM)
							                     END + 1      IN_DAYS  --"연인원"
							   FROM HICU.UICIISPM A   --격리병동환자지표기본
   							      , HICU.UICIIRHD D   --휴일정보
							  WHERE A.HSP_TP_CD = IN_HSP_TP_CD
--								AND A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                                AND A.ETRM_WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
							    AND
							        (
							          A.ETRM_DTM BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD')
							                    OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE,-12), 'YYYY') || '-12-31' ,'YYYY-MM-DD')
							                    OR (A.ETRM_DTM < TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND A.CHOT_DTM > TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD'))
							        )
							    AND D.DT_CD BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							    AND D.YY_CD = TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY')
						      GROUP BY TO_CHAR(D.DT_CD, 'YYYY-MM'), A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM )
						GROUP BY DATA_TYPE
			   )
			  , YEAR_MAN_DAYS AS
			   ( /*당년도 월평균*/
				    SELECT DATA_TYPE
				         , SUM(IN_DAYS)    IN_DAYS
					  FROM (
						       SELECT TO_CHAR(D.DT_CD, 'YYYY-MM')  DATA_TYPE
							        , A.PACT_ID
							        , A.ETRM_DTM
							        , A.CHOT_DTM
							        , CASE WHEN DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) - LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')) > 0  THEN
							                        LAST_DAY(TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD'))
							         ELSE
							               DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							         END
							             - CASE WHEN A.ETRM_DTM - TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') < 0 THEN
							                          TO_DATE(TO_CHAR(D.DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD')
							                     ELSE
							                          TRUNC(A.ETRM_DTM)
							                     END + 1      IN_DAYS  --"연인원"
							   FROM HICU.UICIISPM A   --격리병동환자지표기본
   							      , HICU.UICIIRHD D   --휴일정보
							  WHERE A.HSP_TP_CD = IN_HSP_TP_CD
                                AND A.ETRM_WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
							    AND
							        (
							          A.ETRM_DTM BETWEEN TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
							                    OR DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
							                    OR (A.ETRM_DTM < TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND A.CHOT_DTM > TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD'))
							        )
							    AND D.DT_CD BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM)
							    AND D.YY_CD = TO_CHAR(IN_TO_DTE, 'YYYY')
							    AND D.DT_CD <= TRUNC(SYSDATE)
						      GROUP BY TO_CHAR(D.DT_CD, 'YYYY-MM'), A.PACT_ID, A.ETRM_DTM, A.CHOT_DTM )
						GROUP BY DATA_TYPE
			   ) 
			  , BED_DAYS AS
			  (
			                SELECT '01'           DATA_CODE--연병상수
			                    , B.DATE_TYPE
			                    , B.DIS_YN
			                    , SUM(A.BED_CNT) BED_DAYS
			                 FROM HICU.UICIWBCD A
			                    , MONTH_DATA B
			                WHERE A.BED_CFMT_DT           BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM') AND LAST_DAY(IN_TO_DTE)
			                  AND TO_CHAR(A.BED_CFMT_DT, 'YYYY-MM') = B.DATE_TYPE
--			                  AND A.WD_DEPT_CD             = IN_WD_DEPT_CD
                              AND A.WD_DEPT_CD IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
			                  AND A.HSP_TP_CD              = IN_HSP_TP_CD
			                  AND B.DIS_YN                 = 'Y'         
			                  AND A.BED_CFMT_DT                    <= TRUNC(SYSDATE)
			                GROUP BY B.DATE_TYPE, B.DIS_YN, A.WD_DEPT_CD
			                UNION ALL
			                SELECT '02'           DATA_CODE--전년당월 연병상
			                     , TO_CHAR(TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM'), 'YYYY-MM-DD')
			                     , 'Y' DIS_YN
			                     ,SUM(A.BED_CNT) BED_DAYS
			                 FROM HICU.UICIWBCD A  --병실기본
			                WHERE A.BED_CFMT_DT               BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM') AND LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12))
--			                  AND A.WD_DEPT_CD             = IN_WD_DEPT_CD
                              AND A.WD_DEPT_CD             IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
			                  AND A.HSP_TP_CD              = IN_HSP_TP_CD
			                GROUP BY  TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM')
			                UNION ALL
			                SELECT '03'           DATA_CODE--전년월평균 연병상수
			                     , TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY')
			                     , 'Y' DIS_YN
			                     ,SUM(A.BED_CNT) BED_DAYS
			                 FROM HICU.UICIWBCD A  --병실기본
			                WHERE A.BED_CFMT_DT            BETWEEN TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD')
--			                  AND A.WD_DEPT_CD             = IN_WD_DEPT_CD
                              AND A.WD_DEPT_CD             IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
			                  AND A.HSP_TP_CD              = IN_HSP_TP_CD
			                GROUP BY  TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY')
			                UNION ALL
                           SELECT '04'           DATA_CODE--당년월평균 연병상수
		                        , TO_CHAR(IN_TO_DTE, 'YYYY')
			                    , 'Y' DIS_YN
			                    ,SUM(A.BED_CNT) BED_DAYS
			                FROM HICU.UICIWBCD A  --병실기본
			               WHERE A.BED_CFMT_DT            BETWEEN TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
			                 AND A.BED_CFMT_DT                    <= TRUNC(SYSDATE)
--			                 AND A.WD_DEPT_CD             = IN_WD_DEPT_CD
                             AND A.WD_DEPT_CD             IN (SELECT COMN_CD FROM HICU.UCCOCSTE WHERE HSP_TP_CD  = A.HSP_TP_CD AND COMN_GRP_CD = 'IC018' AND USE_YN = 'Y')
			                 AND A.HSP_TP_CD              = IN_HSP_TP_CD
			             )
			 SELECT '06'                       AS LARGE_CATEGORY
			      , CODE                       AS SMALL_CATEGORY
			      , TITLE                      AS TITLE
			      , DT                         AS VALUE01_NAME
			      , VALUE01_TYPE               AS VALUE01_TYPE
			      , NVL(VALUE01, '0')          AS VALUE01
			      , DT                         AS VALUE02_NAME
			      , VALUE02_TYPE               AS VALUE02_TYPE
			      , NVL(VALUE02, '0')          AS VALUE02
			      , DT                         AS VALUE03_NAME
			      , VALUE03_TYPE               AS VALUE03_TYPE
			      , NVL(VALUE03, '0')          AS VALUE03
			      , ''                         AS VALUE04_NAME
			      , ''                         AS VALUE04_TYPE
			      , ''                         AS VALUE04
			      , ''                         AS VALUE05_NAME
			      , ''                         AS VALUE05_TYPE
			      , ''                         AS VALUE05
			      , ''                         AS VALUE06_NAME
			      , ''                         AS VALUE06_TYPE
			      , ''                         AS VALUE06
			           FROM (
			            SELECT '06'                                AS LARGE_CATEGORY
			                 , '01'                                AS SMALL_CATEGORY
			                 , '재실환자/가동률 추이'                AS TITLE
			                 , '전년월평균'                         AS VALUE01_NAME
			                 , 'D0'                             VALUE01_TYPE
			                 , D1.DATA_CNT                      VALUE01  --병상수
			                 , '전년월평균'                      VALUE02_NAME
			                 , 'D0'                           VALUE02_TYPE
			                 , TRIM(TO_CHAR(ROUND(D2.DATA_CNT/ DECODE(D2.CNT,0,NULL,D2.CNT ),0)))            VALUE02           --환자수
			                 , '전년월평균'                      VALUE03_NAME
			                 , 'D1'                     VALUE03_TYPE
			                 , NVL(TRIM(TO_CHAR((D2.DATA_CNT/DECODE(D1.DATA_CNT ,0,NULL,D1.DATA_CNT ))*100,'99990.9')), '0') VALUE03 --가동률
			                  , ''     VALUE04_NAME
						      , ''     VALUE04_TYPE
						      , ''     VALUE04
						      , ''     VALUE05_NAME
						      , ''     VALUE05_TYPE
						      , ''     VALUE05
						      , ''     VALUE06_NAME
						      , ''     VALUE06_TYPE
						      , ''     VALUE06
		                  FROM (SELECT TO_CHAR(NVL(SUM(IN_DAYS), 0)) DATA_CNT
		                             , COUNT(*) CNT FROM BF_YEAR_MAN_DAYS) D2
		                     , (/*연병상수*/
				                   SELECT TO_CHAR(NVL(SUM(ROUND((DECODE(A.BED_DAYS, 0, NULL, A.BED_DAYS)), 1)), 0)) DATA_CNT
				                     FROM BED_DAYS A
				                    WHERE DATA_CODE = '03') D1
			            UNION ALL
			            SELECT '06'                          LARGE_CATEGORY
			                 , '02'                          SMALL_CATEGORY
			                 , '재실환자/가동률 추이'             TITLE
			                 , '당년월평균'                VALUE01_NAME
			                 , 'D0'                   VALUE01_TYPE
			                 , D1.DATA_CNT            VALUE01
			                 , '당년월평균'                    VALUE02_NAME
			                 , 'D0'                  VALUE02_TYPE
			                 , TRIM(TO_CHAR(ROUND(D2.DATA_CNT/ DECODE(D2.CNT,0,NULL,D2.CNT ),0)))           VALUE02
			                 , '당년월평균'                    VALUE03_NAME
			                 , 'D1'                  VALUE03_TYPE
			                 , NVL(TRIM(TO_CHAR((D2.DATA_CNT/DECODE(D1.DATA_CNT,0,NULL,D1.DATA_CNT))*100,'99990.9')),'0')  VALUE03
			                 , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			             FROM (/*당년연병상수*/
			                   SELECT TO_CHAR(NVL(SUM(ROUND((DECODE(A.BED_DAYS, 0, NULL, A.BED_DAYS)), 1)), 0)) DATA_CNT
			                     FROM BED_DAYS A
			                    WHERE DATA_CODE = '04') D1
			                 ,(/*당년연인원*/
			                   SELECT TO_CHAR(NVL(SUM(B.IN_DAYS), 0)) DATA_CNT
			                         , COUNT(*) CNT
			                     FROM (SELECT TO_CHAR(DT, 'YYYY-MM')  DATE_TYPE
			                            FROM (
			                                    SELECT TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') + LEVEL - 1  DT
			                                      FROM DUAL
			                                    CONNECT BY LEVEL - 1 <=  CASE WHEN TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD') < SYSDATE THEN
			                                                                       TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
			                                                                  ELSE SYSDATE  END  - TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD')
			                                  ) GROUP BY TO_CHAR(DT, 'YYYY-MM')) A
			                        , YEAR_MAN_DAYS B
			                    WHERE A.DATE_TYPE = B.DATA_TYPE) D2
			            UNION ALL
			            SELECT '06'                            LARGE_CATEGORY
			                 , '03'                            SMALL_CATEGORY
			                 , '재실환자/가동률 추이'              TITLE
			                 , '전년당월'                                                            VALUE01_NAME
			                 , 'D0'                                                               VALUE01_TYPE
			                 , B.DATA_CNT                                                         VALUE01
			                 , '전년당월'                                                                 VALUE02_NAME
			                 , 'D0'                                                               VALUE02_TYPE
			                 , NVL(TO_CHAR(A.IN_DAYS), '0')                                              VALUE02
			                 , '전년당월'                                                                 VALUE03_NAME
			                 , 'D1'                                                               VALUE03_TYPE
			                 , NVL(TRIM(TO_CHAR((A.IN_DAYS/DECODE(B.DATA_CNT ,0,NULL,B.DATA_CNT ))*100,'99990.9')),'0') VALUE03
			                 , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			              FROM BF_MAN_DAYS A
			                 ,(SELECT TO_CHAR(NVL(SUM(ROUND((DECODE(BED_DAYS, 0, NULL, BED_DAYS)), 1)), 0)) DATA_CNT
			                     FROM BED_DAYS
			                    WHERE DATA_CODE  ='02') B
			             UNION ALL
			             SELECT '06'                            LARGE_CATEGORY
			                  , '04'                            SMALL_CATEGORY
			                  , '재실환자/가동률 추이'              TITLE
			                  , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')          VALUE01_NAME
			                  , 'D0'                                      VALUE01_TYPE
			                  , D1.DATA_CNT                                VALUE01
			                  , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')                 VALUE02_NAME
			                  , 'D0'                                                               VALUE02_TYPE
			                  , NVL(D2.DATA_CNT, '0')                                              VALUE02
			                  , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')                 VALUE03_NAME
			                  , 'D1'                                                               VALUE03_TYPE
			                  , TRIM(NVL(TO_CHAR((D2.DATA_CNT/DECODE(D1.DATA_CNT,0,NULL,D1.DATA_CNT))*100,'99990.9'), '0'))VALUE03
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''
			                  , ''                                                                          
			             FROM (/*연병상수*/
			                   SELECT A.DATE_TYPE                                                                  STATCS_DATA
			                        , TO_CHAR(NVL(SUM(ROUND((DECODE(A.BED_DAYS, 0, NULL, A.BED_DAYS)), 1)), 0)) DATA_CNT
			                     FROM BED_DAYS A
			                    WHERE DATA_CODE = '01'
			                      GROUP BY A.DATE_TYPE) D1
			                 ,(/* 연인원*/
			                   SELECT B.DATA_TYPE                                                                   STATCS_DATA
			                        , TO_CHAR(NVL(SUM(B.IN_DAYS), 0)) DATA_CNT
			                     FROM MONTH_DATA A
			                        , MAN_DAYS B
			                    WHERE A.DATE_TYPE = B.DATA_TYPE
			                    group by  B.DATA_TYPE) D2
			            WHERE D1.STATCS_DATA = D2.STATCS_DATA (+)
			       ) A
			     , (SELECT '01' CODE, '전년월평균' DT FROM DUAL UNION ALL
			        SELECT '02' CODE, '당년월평균' DT FROM DUAL UNION ALL
			        SELECT '03' CODE, '전년당월'  DT FROM DUAL UNION ALL
			        SELECT '04' CODE, TO_CHAR(ADD_MONTHS(IN_TO_DTE, 1- LEVEL ), 'YY.MM')   DT
				   FROM DUAL
				CONNECT BY LEVEL - 1 <= 11 )         B
			WHERE B.CODE = A.SMALL_CATEGORY(+)
			  AND B.DT =  A.VALUE01_NAME(+)
			ORDER BY CODE, DT;         
  END;

END PC_EICU_ISOLATE_YEAR_STATICS;
