
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_ODRPY" (                  IN_FROM_DTM         IN DATE
                                                              , IN_TO_DTM           IN DATE
                                                              , IN_HSP_TP_CD        IN VARCHAR2
                                                              , IO_ERRYN            IN OUT  VARCHAR2    --  ERROR Y/N
                                                              , IO_ERRMSG           IN OUT  VARCHAR2   --  ERROR MESSAGE   
                                                            )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_ODRPY
*    CREATEDATE     : 2021.03.30
*    Author         : 한가혜
*    Description    : 운영통계 타과회신시간 현황 일마감 배치
*    Change History : 2021.03.31
**********************************************************************************************/    

AS
    V_CURSOR          SYS_REFCURSOR;   
    
    V_COMN_GRP_CD	  VARCHAR2(50);
    V_COMN_CD	      VARCHAR2(50);
    V_DTRL1_NM	      NUMBER := 0;    --VARCHAR2(50);
    
    N_DAYCNT          NUMBER := 0;
    V_SEARCH_DT       DATE   := TRUNC(IN_FROM_DTM);       --조회 날짜  
    
BEGIN 
     IO_ERRYN  := 'N';
     IO_ERRMSG := '';

     N_DAYCNT := TRUNC(IN_TO_DTM) - TRUNC(IN_FROM_DTM) + 1; --조회 기간  
     
     BEGIN 
       FOR I IN 1..N_DAYCNT LOOP 
           
    /*******************************************
     * 회신부서코드 조회
     *******************************************/ 
    DECLARE CURSOR DEPT_CD_CURSOR IS          SELECT A.RPLY_DEPT_CD
                                                   , A.RPLY_DEPT_NM    --210409 한가혜 회신부서명 추가 
                                                   , A.RPLY_DT         -- 회신일자
                                                FROM (SELECT A.RPLY_DT
                                                           , A.RPLY_DEPT_CD
                                                           , A.RPLY_DEPT_NM 
                                                           , TRIM(SUBSTR(A.ODRER_PT_CLCTN_NM, 4, INSTR(A.ODRER_PT_CLCTN_NM, '실') - 5)) AS WD_DEPT_CD
                                                        FROM HICU.UICIIRCD A   --U121_UICI(ODS)_타과의뢰회신정보 
                                                       WHERE A.RPLY_DT       = V_SEARCH_DT
                                                         AND A.APCN_YN       = 'N'
                                                         AND A.RPLY_YN       = 'Y' 
                                                   ) A
                                                   , HICU.UCCOCSTE B 
                                               WHERE B.COMN_GRP_CD   = 'IC504'
                                                 AND B.HSP_TP_CD     = IN_HSP_TP_CD
                                                 AND B.USE_YN        = 'Y'
                                                 AND A.WD_DEPT_CD    = B.COMN_CD
                                            GROUP BY A.RPLY_DEPT_CD, A.RPLY_DEPT_NM, A.RPLY_DT
                                            ;   
         
         REC  DEPT_CD_CURSOR%ROWTYPE;          
         
         BEGIN  
              OPEN DEPT_CD_CURSOR;                             
              LOOP FETCH DEPT_CD_CURSOR INTO REC;
              EXIT WHEN DEPT_CD_CURSOR%NOTFOUND; 
              
                  BEGIN  --지표조회용 
                         XICU.PC_EICU_ODRPY_STATISTICS (   REC.RPLY_DT       --회신일자 
                                                         , REC.RPLY_DEPT_CD  --회신부서코드
                                                         , IN_HSP_TP_CD      --병원구분코드
                                                         , V_CURSOR          --SYS_REFCURSOR
                                                         );
                    END; 
                    
                   BEGIN
                        LOOP
                        FETCH V_CURSOR INTO V_COMN_GRP_CD
                                          , V_COMN_CD  
                                          , V_DTRL1_NM 
                                          ;  
                        EXIT WHEN V_CURSOR%NOTFOUND;
                  
                         /********************************************
                         * 타과의뢰회신정보(UCOSCOSD)  BATCH
                         **********************************************/ 
                          BEGIN
                                 --UPDATE OR INSERT   
                                 MERGE INTO HICU.UCOSCOSD A  --U113_UCOS(운영통계)_타과의뢰회신정보
                                          USING DUAL
                                             ON (
                                                 A.RPLY_DEPT_CD		= REC.RPLY_DEPT_CD        --회신부서코드(pk)
                                             AND A.RPLY_DT          = REC.RPLY_DT               --회신일자(pk) 
                                             AND A.HSP_TP_CD        = IN_HSP_TP_CD
                                                 )   
                                                  
                                           WHEN MATCHED THEN
                                         UPDATE 
                                            SET  A.RPLY_WHL_CNT = DECODE(V_COMN_CD, 'RPLY_WHL_CNT', V_DTRL1_NM, NVL(A.RPLY_WHL_CNT, 0)) --전체회신수
                                               , A.RPLY_IN_6TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_6TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_6TM_CNT, 0)) --6시간이내회신수
                                               , A.RPLY_IN_12TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_12TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_12TM_CNT, 0))--12시간이내회신수
                                               , A.RPLY_IN_24TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_24TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_24TM_CNT, 0))--24시간이내회신수
                                               , A.RPLY_IN_36TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_36TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_36TM_CNT, 0))--36시간이내회신수
                                               , A.RPLY_IN_48TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_48TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_48TM_CNT, 0))--48시간이내회신수
                                               , A.RPLY_IN_60TM_CNT = DECODE(V_COMN_CD, 'RPLY_IN_60TM_CNT', V_DTRL1_NM, NVL(A.RPLY_IN_60TM_CNT, 0))--60시간이내회신수
                                               , A.RPLY_EXCS_60TM_CNT = DECODE(V_COMN_CD, 'RPLY_EXCS_60TM_CNT', V_DTRL1_NM, NVL(A.RPLY_EXCS_60TM_CNT, 0))--60시간초과회신수
                                               , A.UNTC_REPLY_WHL_CNT = DECODE(V_COMN_CD, 'UNTC_REPLY_WHL_CNT', V_DTRL1_NM, NVL(A.UNTC_REPLY_WHL_CNT, 0))--비대면전체회신수
                                               , A.UNTC_RPLY_IN_6TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_6TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_6TM_CNT, 0))--비대면6시간이내회신수
                                               , A.UNTC_RPLY_IN_12TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_12TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_12TM_CNT, 0))--비대면12시간이내회신수
                                               , A.UNTC_RPLY_IN_24TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_24TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_24TM_CNT, 0))--비대면24시간이내회신수
                                               , A.UNTC_RPLY_IN_36TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_36TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_36TM_CNT, 0))--비대면36시간이내회신수
                                               , A.UNTC_RPLY_IN_48TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_48TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_48TM_CNT, 0))--비대면48시간이내회신수
                                               , A.UNTC_RPLY_IN_60TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_IN_60TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_IN_60TM_CNT, 0))--비대면60시간이내회신수
                                               , A.UNTC_RPLY_EXCS_60TM_CNT = DECODE(V_COMN_CD, 'UNTC_RPLY_EXCS_60TM_CNT', V_DTRL1_NM, NVL(A.UNTC_RPLY_EXCS_60TM_CNT, 0))--비대면60시간초과회신수
                                               , A.EMGR_RPLY_CNT = DECODE(V_COMN_CD, 'EMGR_RPLY_CNT', V_DTRL1_NM, NVL(A.EMGR_RPLY_CNT, 0))--응급회신수
                                               , A.EMGR_UNTC_RPLY_CNT = DECODE(V_COMN_CD, 'EMGR_UNTC_RPLY_CNT', V_DTRL1_NM, NVL(A.EMGR_UNTC_RPLY_CNT, 0))--응급비대면회신수
                                               , A.WKDY_RPLY_WHL_TM_AVG = DECODE(V_COMN_CD, 'WKDY_RPLY_WHL_TM_AVG', V_DTRL1_NM, NVL(A.WKDY_RPLY_WHL_TM_AVG, 0))--평일전체회신시간평균
                                               , A.WKDY_UNTC_RPLY_WHL_TM_AVG = DECODE(V_COMN_CD, 'WKDY_UNTC_RPLY_WHL_TM_AVG', V_DTRL1_NM, NVL(A.WKDY_UNTC_RPLY_WHL_TM_AVG, 0))--평일비대면전체회신시간평균
                                               , A.WKN_RPLY_WHL_TM_AVG = DECODE(V_COMN_CD, 'WKN_RPLY_WHL_TM_AVG', V_DTRL1_NM, NVL(A.WKN_RPLY_WHL_TM_AVG, 0))--주말전체회신시간평균
                                               , A.WKN_UNTC_RPLY_WHL_TM_AVG = DECODE(V_COMN_CD, 'WKN_UNTC_RPLY_WHL_TM_AVG', V_DTRL1_NM, NVL(A.WKN_UNTC_RPLY_WHL_TM_AVG, 0))--주말비대면전체회신시간평균
                                               , A.LOD_DTM = SYSDATE--적재일시
                                          
                                           --최초적재
                                           WHEN NOT MATCHED THEN
                                         INSERT(
                                                      A.RPLY_DEPT_CD				--회신부서코드
                                                    , A.RPLY_DT						--회신일자
                                                    , A.HSP_TP_CD					--병원구분코드
                                                    , A.RPLY_DEPT_CD_NM				--회신부서코드명
                                                    , A.RPLY_YY						--회신 년
                                                    , A.RPLY_MM						--회신 월
                                                    , A.RPLY_DY						--회신 일
                                                    , A.RPLY_WHL_CNT				--전체회신수
                                                    , A.RPLY_IN_6TM_CNT				--6시간이내회신수
                                                    , A.RPLY_IN_12TM_CNT			--12시간이내회신수
                                                    , A.RPLY_IN_24TM_CNT			--24시간이내회신수
                                                    , A.RPLY_IN_36TM_CNT			--36시간이내회신수
                                                    , A.RPLY_IN_48TM_CNT			--48시간이내회신수
                                                    , A.RPLY_IN_60TM_CNT			--60시간이내회신수
                                                    , A.UNTC_REPLY_WHL_CNT			--비대면전체회신수
                                                    , A.UNTC_RPLY_IN_6TM_CNT		--비대면6시간이내회신수
                                                    , A.UNTC_RPLY_IN_12TM_CNT		--비대면12시간이내회신수
                                                    , A.UNTC_RPLY_IN_24TM_CNT		--비대면24시간이내회신수
                                                    , A.UNTC_RPLY_IN_36TM_CNT		--비대면36시간이내회신수
                                                    , A.UNTC_RPLY_IN_48TM_CNT		--비대면48시간이내회신수
                                                    , A.UNTC_RPLY_IN_60TM_CNT		--비대면60시간이내회신수
                                                    , A.EMGR_RPLY_CNT				--응급회신수
                                                    , A.EMGR_UNTC_RPLY_CNT			--응급비대면회신수
                                                    , A.WKDY_RPLY_WHL_TM_AVG		--평일전체회신시간평균
                                                    , A.WKDY_UNTC_RPLY_WHL_TM_AVG	--평일비대면전체회신시간평균
                                                    , A.WKN_RPLY_WHL_TM_AVG			--주말전체회신시간평균
                                                    , A.WKN_UNTC_RPLY_WHL_TM_AVG	--주말비대면전체회신시간평균
                                                    , A.LOD_DTM						--적재일시 
                                                    , A.RPLY_EXCS_60TM_CNT			--60시간초과회신수
                                                    , A.UNTC_RPLY_EXCS_60TM_CNT		--비대면60시간초과회신수
                                         )
                                         VALUES(
                                                     REC.RPLY_DEPT_CD                                
                                                   , REC.RPLY_DT          
                                                   , IN_HSP_TP_CD                                 --병원코드(pk)
                                                   , REC.RPLY_DEPT_NM                           --210409 한가혜 회신부서명 추가     
                                                   , TO_CHAR(REC.RPLY_DT, 'YYYY')              --입실년도
                                                   , TO_CHAR(REC.RPLY_DT, 'MM')                --입실월
                                                   , TO_CHAR(REC.RPLY_DT, 'DD')                --입실일
                                                   , DECODE(V_COMN_CD, 'RPLY_WHL_CNT', V_DTRL1_NM, 0) --전체회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_6TM_CNT', V_DTRL1_NM, 0) --6시간이내회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_12TM_CNT', V_DTRL1_NM, 0)--12시간이내회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_24TM_CNT', V_DTRL1_NM, 0)--24시간이내회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_36TM_CNT', V_DTRL1_NM, 0)--36시간이내회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_48TM_CNT', V_DTRL1_NM, 0)--48시간이내회신수
                                                   , DECODE(V_COMN_CD, 'RPLY_IN_60TM_CNT', V_DTRL1_NM, 0)--60시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_REPLY_WHL_CNT', V_DTRL1_NM, 0)--비대면전체회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_6TM_CNT', V_DTRL1_NM, 0)--비대면6시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_12TM_CNT', V_DTRL1_NM, 0)--비대면12시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_24TM_CNT', V_DTRL1_NM, 0)--비대면24시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_36TM_CNT', V_DTRL1_NM, 0)--비대면36시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_48TM_CNT', V_DTRL1_NM, 0)--비대면48시간이내회신수
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_IN_60TM_CNT', V_DTRL1_NM, 0)--비대면60시간이내회신수
                                                   , DECODE(V_COMN_CD, 'EMGR_RPLY_CNT', V_DTRL1_NM, 0)--응급회신수
                                                   , DECODE(V_COMN_CD, 'EMGR_UNTC_RPLY_CNT', V_DTRL1_NM, 0)--응급비대면회신수
                                                   , DECODE(V_COMN_CD, 'WKDY_RPLY_WHL_TM_AVG', V_DTRL1_NM, 0)--평일전체회신시간평균
                                                   , DECODE(V_COMN_CD, 'WKDY_UNTC_RPLY_WHL_TM_AVG', V_DTRL1_NM, 0)--평일비대면전체회신시간평균
                                                   , DECODE(V_COMN_CD, 'WKN_RPLY_WHL_TM_AVG', V_DTRL1_NM, 0)--주말전체회신시간평균
                                                   , DECODE(V_COMN_CD, 'WKN_UNTC_RPLY_WHL_TM_AVG', V_DTRL1_NM, 0)--주말비대면전체회신시간평균
                                                   , SYSDATE--적재일시  
                                                   , DECODE(V_COMN_CD, 'RPLY_EXCS_60TM_CNT', V_DTRL1_NM, 0)--60시간초과회신수 
                                                   , DECODE(V_COMN_CD, 'UNTC_RPLY_EXCS_60TM_CNT', V_DTRL1_NM, 0)--비대면60시간초과회신수
                                         );
                                 
                                EXCEPTION
                		        WHEN OTHERS THEN
                		            IO_ERRYN  := 'Y';
                		            IO_ERRMSG := '(XICU.PC_EICU_CENTER_BATCH_ODRPY): HSP_TP_CD = '|| IN_HSP_TP_CD || 'RPLY_DT = ' || TO_CHAR(REC.RPLY_DT, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
                		            RETURN ;
                		                    
                            END; --타과의뢰회신정보(UCOSCOSD)  BATCH END
                            
                        END LOOP;  --지표 조회
                        COMMIT;       
                      END;  --MERGE INTO USING 절                       
                      
     END LOOP; --회신부서코드 조회 
     CLOSE DEPT_CD_CURSOR;
     END;
        
           V_SEARCH_DT := V_SEARCH_DT + 1; 
      END LOOP; 
    END;
END PC_EICU_CENTER_BATCH_ODRPY;
