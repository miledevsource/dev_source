
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_STATISTIC_NONFACE" 
                          ( IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_WD_DEPT_CD_NM  IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2                      
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_STATISTIC_NONFACE
*    CREATEDATE     : 2021.03.30
*    Author         : 신솔
*    Description    : 비대면 협진기록 조회
*    Change History : 2021.03.30, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH NONFACE CONSULT LIST
            ************************/
            WITH SDATA AS(
                 SELECT TO_CHAR(IN_TO_DT, 'YYYYMMDD')                            AS UNTC_REC_DT       --비대면기록일자
                      , IN_HIS_HSP_TP_CD                                         AS HSP_TP_CD         --병원구분코드
                      , IN_WD_DEPT_CD                                            AS RER_DEPT_CD       --의뢰부서코드
                      , IN_WD_DEPT_CD_NM                                         AS RER_DEPT_CD_NM    --의뢰부서코드명
                      , TO_CHAR(IN_TO_DT, 'YYYY')                                AS UNTC_REC_YY       --비대면기록년도
                      , TO_CHAR(IN_TO_DT, 'MM')                                  AS UNTC_REC_MM       --비대면기록월
                      , TO_CHAR(IN_TO_DT, 'DD')                                  AS UNTC_REC_DY       --비대면기록일
                      , TO_CHAR(NVL(COUNT(*), 0))                                AS WHL_CSLT_CNT      --전체협진건수
                      , TO_CHAR(NVL(SUM(DECODE(A.PRTP_CNT, 1, 1, 0)), 0))        AS SGL_CSLT_CNT      --단일협진건수
                      , TO_CHAR(NVL(SUM(DECODE(A.PRTP_CNT, 1, 0, 1)), 0))        AS MIX_CSLT_CNT      --다자간협진건수
                      , TO_CHAR(NVL(SUM(DECODE(A.CSLT_CLS_CD, 5, 1, 0)), 0))     AS OTDP_RPLY_CNT     --타과회신건수
                      , TO_CHAR(NVL(SUM(DECODE(A.CSLT_CLS_CD, 1, 1, 0)), 0))     AS SMP_IQRY_CNT      --단순문의건수
                      , TO_CHAR(NVL(SUM(DECODE(A.CSLT_CLS_CD, 2, 1, 0)), 0))     AS PT_STS_INSP_CNT   --환자상태체크건수
                      , TO_CHAR(NVL(SUM(DECODE(A.CSLT_CLS_CD, 3, 1, 0)), 0))     AS MNTR_CNT          --모니터링건수
                      , TO_CHAR(NVL(SUM(DECODE(A.CSLT_CLS_CD, 4, 1, 0)), 0))     AS ETC_CNT           --기타건수
                      , SYSDATE                                                  AS LOD_DTM           --적재일시
                   FROM (SELECT A.EPCN_CSLT_ID        AS EPCN_CSLT_ID
                              , A.EPCN_CSLT_FOM_SEQ   AS EPCN_CSLT_FOM_SEQ
                              , A.CSLT_CLS_CD         AS CSLT_CLS_CD
                              , COUNT(*)              AS PRTP_CNT
                           FROM HICU.UCOMCNSM A
                              , HICU.UCOMCNRD B
                          WHERE A.CSLT_STR_DTM      BETWEEN TRUNC(IN_TO_DT) AND TRUNC(IN_TO_DT) + 0.99999
                            AND A.RER_DEPT_CD       = IN_WD_DEPT_CD
                            AND A.RER_HSP_CD        = IN_HIS_HSP_TP_CD
                            AND A.LST_YN            = 'Y'
                            AND A.SV_STS_CD         = 'S'
                            AND B.EPCN_CSLT_ID      = A.EPCN_CSLT_ID
                            AND B.EPCN_CSLT_FOM_SEQ = A.EPCN_CSLT_FOM_SEQ
                          GROUP BY A.EPCN_CSLT_ID, A.EPCN_CSLT_FOM_SEQ, A.CSLT_CLS_CD) A
            )
            
            SELECT COMN_CD           AS COMN_CD
                 , TO_CHAR(DTRL1_NM) AS DTRL1_NM
              FROM SDATA
           UNPIVOT (DTRL1_NM FOR COMN_CD
                              IN ( WHL_CSLT_CNT
                                 , SGL_CSLT_CNT
                                 , MIX_CSLT_CNT
                                 , OTDP_RPLY_CNT
                                 , SMP_IQRY_CNT
                                 , PT_STS_INSP_CNT
                                 , MNTR_CNT
                                 , ETC_CNT
                                 )
                   )
        ;    
    END;
END PC_EICU_STATISTIC_NONFACE;
