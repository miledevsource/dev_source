
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_UICIIRHD_BATCH" ( IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                        , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                                        , IN_TO_DTE       IN DATE             -- 04.조회종료일자
                                        , IO_ERRYN        IN OUT  VARCHAR2    -- 05. ERROR Y/N
                                        , IO_ERRMSG       IN OUT  VARCHAR2   -- 06. ERROR MESSAGE 
                                        ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_UICIIRHD_BATCH
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민
*    Description    : UICIIRHD 휴일정보를 적재함
*    Change History : 2021.03.15, 오지민, 최초작성
**********************************************************************************************/
 AS     
    D_START_DTE DATE := TRUNC(IN_FROM_DTE) -1 ;    
    N_DAYCOUNT NUMBER := 0;                
    
BEGIN       
    
    N_DAYCOUNT := TRUNC(IN_TO_DTE) - TRUNC(IN_FROM_DTE);
    
    BEGIN 
        FOR I IN 0..N_DAYCOUNT LOOP
            D_START_DTE := D_START_DTE + 1;
            
            BEGIN
	            MERGE INTO HICU.UICIIRHD A  --휴일정
			     USING (
			            SELECT DT_CD	
			                 , DT_NM	
			                 , YMD_CD	
			                 , YY_CD	
			                 , YY_NM	
			                 , HTERM_CD	
			                 , HTERM_NM	
			                 , QUT_CD	
			                 , QUT_NM	
			                 , YYMM_CD	
			                 , YYMM_NM	
			                 , YMW_CD	
			                 , YMW_NM	
			                 , DOW_NM	
			                 , DAY_CD	
			                 , DAY_NM	
			                 , HLDY_YN	
			                 , FSR_DTM	
			                 , LSH_DTM	
						  FROM XICU.EMEI014V
                         WHERE DT_CD BETWEEN TRUNC(D_START_DTE) AND TRUNC(SYSDATE) +0.99999 ) B 
                ON (     A.DT_CD                        = B.DT_CD )
			   WHEN MATCHED THEN
			       UPDATE SET
			           		   A.DT_NM	     = B.DT_NM
			                 , A.YMD_CD	     = B.YMD_CD
			                 , A.YY_CD	     = B.YY_CD
			                 , A.YY_NM	     = B.YY_NM
			                 , A.HTERM_CD	 = B.HTERM_CD
			                 , A.HTERM_NM	 = B.HTERM_NM
			                 , A.QUT_CD	     = B.QUT_CD
			                 , A.QUT_NM	     = B.QUT_NM
			                 , A.YYMM_CD	 = B.YYMM_CD
			                 , A.YYMM_NM	 = B.YYMM_NM
			                 , A.YMW_CD	     = B.YMW_CD
			                 , A.YMW_NM	     = B.YMW_NM
			                 , A.DOW_NM	     = B.DOW_NM
			                 , A.DAY_CD	     = B.DAY_CD
			                 , A.DAY_NM	     = B.DAY_NM
			                 , A.HLDY_YN	 = B.HLDY_YN
--			                 , A.FSR_DTM	 = B.FSR_DTM
			                 , A.LSH_DTM     = B.LSH_DTM
--			                 , A.FST_LOD_DTM = SYSDATE
			                 , A.LST_LOG_DTM = SYSDATE
			
			  WHEN NOT MATCHED THEN
			      INSERT (
			                 A.DT_CD    
			               ,  A.DT_NM	
			               , A.YMD_CD	
			               , A.YY_CD	
			               , A.YY_NM	
			               , A.HTERM_CD	
			               , A.HTERM_NM	
			               , A.QUT_CD	
			               , A.QUT_NM	
			               , A.YYMM_CD	
			               , A.YYMM_NM	
			               , A.YMW_CD	
			               , A.YMW_NM	
			               , A.DOW_NM	
			               , A.DAY_CD	
			               , A.DAY_NM	
			               , A.HLDY_YN	
			               , A.FSR_DTM	
			               , A.LSH_DTM  
			               , A.FST_LOD_DTM 
			               , A.LST_LOG_DTM 
			        )
			      VALUES ( 
			                 B.DT_CD
			               , B.DT_NM
			               , B.YMD_CD
			               , B.YY_CD
			               , B.YY_NM	
			               , B.HTERM_CD	
			               , B.HTERM_NM	
			               , B.QUT_CD
			               , B.QUT_NM
			               , B.YYMM_CD
			               , B.YYMM_NM
			               , B.YMW_CD
			               , B.YMW_NM
			               , B.DOW_NM
			               , B.DAY_CD
			               , B.DAY_NM
			               , B.HLDY_YN
			               , B.FSR_DTM
			               , B.LSH_DTM
			               , SYSDATE
			               , SYSDATE
			          );       			
		    COMMIT;	   
		    EXCEPTION
		        WHEN OTHERS THEN
		            IO_ERRYN := 'Y';                                                                                                              
		            IO_ERRMSG := '(XICU.PC_EICU_LD_UICIIRHD_BATCH): HSP_TP_CD = '|| IN_HSP_TP_CD || 'BED_CFMT_DT = ' || TO_CHAR(D_START_DTE, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
		            RETURN ;
		    END;	    
        END LOOP;
    END;     
END PC_EICU_LD_UICIIRHD_BATCH;
