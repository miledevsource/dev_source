
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_DETAIL_END_SEL1" 
                          ( P_VNDR              IN VARCHAR2
			                         ,P_CLNTIP            IN VARCHAR2
			                         ,P_USERID            IN VARCHAR2
			                         ,P_HSPTID            IN VARCHAR2
                           , IN_HSP_TP_CD      IN  VARCHAR2
                          , IN_START_DT       IN  VARCHAR2
                          , IN_END_DT         IN  VARCHAR2          
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_DETAIL_END_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송종료현황  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
SELECT  A.TRNF_PRGR_STS_CD                                     TRNF_PRGR_STS_CD     -- 이송진행상태코드 
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD)  TRNF_PRGR_STS_NM     -- 이송진행단계
      , A.PACT_ID                                       PACT_ID              -- 접수ID 
      , A.PT_NO						                                   PT_NO                -- 환자번호
      , A.PT_NM                                         PT_NM                -- 환자이름
      , B.SEX_TP_CD                                     SEX_TP_CD            -- 성별
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH             -- 생년월일
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE               -- 나이
      , (SELECT DEPT_NM
           FROM PDEDBMSM
          WHERE MED_DEPT_CD =  C.MED_DEPT_CD )          DEPT_NM              -- 진료과
      , ''                                              ANDR_NM              -- 주치의
      , ''                                              DGNS_NM              -- 진단명
      , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD,'CDNM')		HSP_TP_CD            -- 병원구분코드(의뢰요청한병원)
      , A.SEQ									                                		SEQ                   -- 순번  
      , IF_FN_CODE_SEL('STATUS_STS_CD',A.STATUS_STS_CD )        STATUS_STS_CD          --등록상태(이송종료, 협진완료, 이송불가, 취소)
      
      , A.EQUIP_YN                                      EQUIP_YN             -- 물품동반여부
      , A.EQUIP_NM                                      EQUIP_NM             -- 물품명
      , A.CO_TREAT_REASON                               CO_TREAT_REASON      -- 협진등록사유
      , A.CO_TREAT_RMK                                  CO_TREAT_RMK         -- 협진등록비고
      , A.XFER_REF_MEMO                                 XFER_REF_MEMO        -- 이송참고메모
      , A.MED_STAFF_ACCOMP_YN                           MED_STAFF_ACCOMP_YN  -- 의료진동반여부
--      , A.MED_STAFF_ACCOMP_ID                           MED_STAFF_ACCOMP_ID  -- 동반의료진사번
--      , A.MED_STAFF_ACCOMP_NM                           MED_STAFF_ACCOMP_ID  -- 동반의료진이름
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT       -- 협진등록일시
      , A.CO_TREAT_PROGRESS_DT                          CO_TREAT_PROGRESS_DT -- 협진진행일시
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT     -- 이송여부결정일시
      , A.REFERRAL_DOC_REG_DT                           REFERRAL_DOC_REG_DT  -- 진료의뢰서전달일시
      , A.XFER_INFO_REG_DT                              XFER_INFO_REG_DT     -- 이송정보등록일시
      , A.XFER_START_DT                                 XFER_START_DT        -- 이송시작일시 
      , A.XFER_ARVL_PLAN_DT                             XFER_ARVL_PLAN_DT    -- 이송도착예정일시
      , A.XFER_ARVL_DT                                  XFER_ARVL_DT         -- 이송도착시간
      , A.XFER_END_DT                                   XFER_END_DT          -- 이송종료일시
      
      , A.TARGET_HSP_CD                                 TARGET_HSP_CD        -- 협진의뢰병원코드
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM        -- 협진의뢰병원명
      , A.TARGET_DEPT_NM                                TARGET_DEPT_NM       -- 협진의뢰진료과명
      , A.CANCEL_REASON                                 CANCEL_REASON        -- 협진의뢰최소사유
      , A.FSR_DTM                                       FSR_DTM              -- 최초등록일시
      , A.FSR_IP_ADDR                                   FSR_IP_ADDR          -- 최초접속자IP
      , A.FSR_STF_NO                                    FSR_STF_NO           -- 최초등록자ID
      , A.FSR_STF_NM                                    FSR_STF_NM           -- 최초등록자성명
      , A.FSR_PRGM_NM                                   FSR_PRGM_NM          -- 최초변경프로그램명
      , A.LSH_DTM                                       LSH_DTM              -- 최종등록일시
      , A.LSH_IP_ADDR                                   LSH_IP_ADDR          -- 최종접속자IP
      , A.LSH_STF_NO                                    LSH_STF_NO           -- 최종등록자ID
      , A.LSH_STF_NM                                    LSH_STF_NM           -- 최종등록자성명
      , A.LSH_PRGM_NM                                   LSH_PRGM_NM          -- 최종변경프로그램명
      
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRAAM C
     , (
        SELECT *
        FROM (
            SELECT D.*
                 , ROW_NUMBER() OVER (
                      PARTITION BY D.PACT_ID
                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
                   ) AS RN
              FROM MOPPCCFD D
        )
        WHERE RN = 1
     ) D
WHERE A.HSP_TP_CD = IN_HSP_TP_CD
  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')
  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.PACT_ID = D.PACT_ID
  AND A.STATUS_STS_CD NOT IN ('A','D')


UNION ALL

SELECT  A.TRNF_PRGR_STS_CD                                     TRNF_PRGR_STS_CD     -- 이송진행상태코드 
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD)  TRNF_PRGR_STS_NM     -- 이송진행단계
      , A.PACT_ID                                       PACT_ID              -- 접수ID 
      , A.PT_NO						                                   PT_NO                -- 환자번호
      , A.PT_NM                                         PT_NM                -- 환자이름
      , B.SEX_TP_CD                                     SEX_TP_CD            -- 성별
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH             -- 생년월일
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE               -- 나이
      , C.MED_DEPT_CD                                   DEPT_NM              -- 진료과 
      , C.MEDR_SID                                      ANDR_NM              -- 주치의
      , ''                                              DGNS_NM              -- 진단명
      , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD,'CDNM')		HSP_TP_CD            -- 병원구분코드(의뢰요청한병원)
      , A.SEQ									                                		SEQ                   -- 순번  
      , IF_FN_CODE_SEL('STATUS_STS_CD',A.STATUS_STS_CD )        STATUS_STS_CD          --등록상태(이송종료, 협진완료, 이송불가, 취소)
      
      , A.EQUIP_YN                                      EQUIP_YN             -- 물품동반여부
      , A.EQUIP_NM                                      EQUIP_NM             -- 물품명
      , A.CO_TREAT_REASON                               CO_TREAT_REASON      -- 협진등록사유
      , A.CO_TREAT_RMK                                  CO_TREAT_RMK         -- 협진등록비고
      , A.XFER_REF_MEMO                                 XFER_REF_MEMO        -- 이송참고메모
      , A.MED_STAFF_ACCOMP_YN                           MED_STAFF_ACCOMP_YN  -- 의료진동반여부
--      , A.MED_STAFF_ACCOMP_ID                           MED_STAFF_ACCOMP_ID  -- 동반의료진사번
--      , A.MED_STAFF_ACCOMP_NM                           MED_STAFF_ACCOMP_ID  -- 동반의료진이름
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT       -- 협진등록일시
      , A.CO_TREAT_PROGRESS_DT                          CO_TREAT_PROGRESS_DT -- 협진진행일시
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT     -- 이송여부결정일시
      , A.REFERRAL_DOC_REG_DT                           REFERRAL_DOC_REG_DT  -- 진료의뢰서전달일시
      , A.XFER_INFO_REG_DT                              XFER_INFO_REG_DT     -- 이송정보등록일시
      , A.XFER_START_DT                                 XFER_START_DT        -- 이송시작일시 
      , A.XFER_ARVL_PLAN_DT                             XFER_ARVL_PLAN_DT    -- 이송도착예정일시
      , A.XFER_ARVL_DT                                  XFER_ARVL_DT         -- 이송도착시간
      , A.XFER_END_DT                                   XFER_END_DT          -- 이송종료일시
      
      , A.TARGET_HSP_CD                                 TARGET_HSP_CD        -- 협진의뢰병원코드
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM        -- 협진의뢰병원명
      , A.TARGET_DEPT_NM                                TARGET_DEPT_NM       -- 협진의뢰진료과명
      , A.CANCEL_REASON                                 CANCEL_REASON        -- 협진의뢰취소사유
      , A.FSR_DTM                                       FSR_DTM              -- 최초등록일시
      , A.FSR_IP_ADDR                                   FSR_IP_ADDR          -- 최초접속자IP
      , A.FSR_STF_NO                                    FSR_STF_NO           -- 최초등록자ID
      , A.FSR_STF_NM                                    FSR_STF_NM           -- 최초등록자성명
      , A.FSR_PRGM_NM                                   FSR_PRGM_NM          -- 최초변경프로그램명
      , A.LSH_DTM                                       LSH_DTM              -- 최종등록일시
      , A.LSH_IP_ADDR                                   LSH_IP_ADDR          -- 최종접속자IP
      , A.LSH_STF_NO                                    LSH_STF_NO           -- 최종등록자ID
      , A.LSH_STF_NM                                    LSH_STF_NM           -- 최종등록자성명
      , A.LSH_PRGM_NM                                   LSH_PRGM_NM          -- 최종변경프로그램명
      
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C      
     
WHERE A.HSP_TP_CD = IN_HSP_TP_CD
  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')
  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.STATUS_STS_CD NOT IN ('A','D')




ORDER BY CONSULT_REQ_DT DESC ;


END IF_TRNF_DETAIL_END_SEL1;
