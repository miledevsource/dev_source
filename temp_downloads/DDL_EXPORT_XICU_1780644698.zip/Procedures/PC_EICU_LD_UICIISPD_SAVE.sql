
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_UICIISPD_SAVE" (  IN_HSP_TP_CD    IN VARCHAR2         -- 01.병원구분코드
                                        , IN_WD_DEPT_CD   IN VARCHAR2         -- 02.병동구분코드
                                        , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                                        , IN_TO_DTE       IN DATE             -- 04.조회종료일자                                         
                                        , IO_ERRYN        IN OUT  VARCHAR2    -- 05. ERROR Y/N
                                        , IO_ERRMSG       IN OUT  VARCHAR2)   -- 06. ERROR MESSAGE 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_UICIISPD_SAVE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표 관련 UICIISPD(격리병동환자중증도분류정보) 데이터 적재(신규 데이터 생성 및 업데이트)
*    Change History : 2021.02.24, 오지민, 최초작성                                                
**********************************************************************************************/
 AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    /* ODS-UICICRSD(환자중증도분류기록정보)에 신규 또는 업데이트 된 데이터를 기준으로 UICIISPD(격리병동환자중증도분류정보)에 삭제하고 적재한다.*/
    BEGIN
	   /* UICIISPD(격리병동환자중증도분류정보)에서 삭제 조건
	    * 환자중증도 분류기록정보에 변경된 정보가 있으면 최종 정보를 적재하기 위해서 삭제한다.*/
	   DELETE FROM HICU.UICIISPD
	    WHERE PT_SILLM_CTG_REC_ID IN ( SELECT PT_SILLM_CTG_REC_ID
				                         FROM HICU.UICICRSD --환자중증도분류기록정보
                                        WHERE LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE 
                                          AND PT_SILLM_CTG_TP_CD = '1' )
	   ;   
	   COMMIT; 
	END;
	
    BEGIN        
         MERGE INTO HICU.UICIISPD A  --격리병동환자중증도분류정보
		 USING (
		        SELECT A.PT_SILLM_CTG_REC_ID
		             , A.WRT_SEQ PT_SILLM_CTG_REC_WRT_SEQ
		             , A.HSP_TP_CD
		             , A.PACT_ID
		             , A.PT_NO
		             , A.CTG_DTM PT_SILLM_CTG_DTM
		             , A.WD_DEPT_CD
		             , A.WD_DEPT_CD_NM
		             , A.PT_SILLM_CTG_TL_ID
		             , A.PT_SILLM_CTG_TL_NM
		             , A.PT_SILLM_CTG_TP_CD
		             , A.PT_SILLM_CTG_TP_CD_NM
		             , A.PT_SILLM_CTG_GRP_CD
		             , A.PT_SILLM_CTG_GRP_CD_NM
		             , A.PT_SILLM_CTG_SCR_SUM
		          FROM HICU.UICICRSD A --환자중증도분류기록정보       
		             , HICU.UICIISPM B
		         WHERE A.LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE
		           AND A.HSP_TP_CD = IN_HSP_TP_CD
		           AND A.HSP_TP_CD = B.HSP_TP_CD    
		           AND A.PACT_ID = B.PACT_ID
		           AND A.PT_SILLM_CTG_TP_CD = '1'
		           AND A.CTG_DTM BETWEEN B.ETRM_DTM AND B.CHOT_DTM
--		           AND A.WD_DEPT_CD = IN_WD_DEPT_CD
		           AND A.USE_YN = 'Y'
		           AND A.LST_YN = 'Y') B
		   ON (       A.PT_SILLM_CTG_REC_ID             = B.PT_SILLM_CTG_REC_ID
		        AND   A.PT_SILLM_CTG_REC_WRT_SEQ        = B.PT_SILLM_CTG_REC_WRT_SEQ
		        AND   A.HSP_TP_CD                       = B.HSP_TP_CD
		        AND   A.PACT_ID                         = B.PACT_ID
		        AND   A.PT_NO                           = B.PT_NO
		      )
	    WHEN MATCHED THEN
          UPDATE SET
              A.PT_SILLM_CTG_DTM                  = B.PT_SILLM_CTG_DTM
            , A.WD_DEPT_CD                        = B.WD_DEPT_CD
            , A.WD_DEPT_CD_NM                     = B.WD_DEPT_CD_NM
            , A.PT_SILLM_CTG_TL_ID                = B.PT_SILLM_CTG_TL_ID
            , A.PT_SILLM_CTG_TL_NM                = B.PT_SILLM_CTG_TL_NM
            , A.PT_SILLM_CTG_TP_CD                = B.PT_SILLM_CTG_TP_CD
            , A.PT_SILLM_CTG_TP_CD_NM             = B.PT_SILLM_CTG_TP_CD_NM
            , A.PT_SILLM_CTG_GRP_CD               = B.PT_SILLM_CTG_GRP_CD
            , A.PT_SILLM_CTG_GRP_CD_NM            = B.PT_SILLM_CTG_GRP_CD_NM
            , A.PT_SILLM_CTG_SCR_SUM              = B.PT_SILLM_CTG_SCR_SUM
            , A.LST_LOD_DTM                       = SYSDATE
            
        WHEN NOT MATCHED THEN
          INSERT (
                     A.PT_SILLM_CTG_REC_ID
                   , A.PT_SILLM_CTG_REC_WRT_SEQ
                   , A.HSP_TP_CD
                   , A.PACT_ID
                   , A.PT_NO
                   , A.PT_SILLM_CTG_DTM
                   , A.WD_DEPT_CD
                   , A.WD_DEPT_CD_NM
                   , A.PT_SILLM_CTG_TL_ID
                   , A.PT_SILLM_CTG_TL_NM
                   , A.PT_SILLM_CTG_TP_CD_NM
                   , A.PT_SILLM_CTG_GRP_CD
                   , A.PT_SILLM_CTG_GRP_CD_NM
                   , A.PT_SILLM_CTG_SCR_SUM
                   , A.FST_LOD_DTM
                   , A.LST_LOD_DTM
            )
          VALUES (
                     B.PT_SILLM_CTG_REC_ID
                   , B.PT_SILLM_CTG_REC_WRT_SEQ
                   , B.HSP_TP_CD
                   , B.PACT_ID
                   , B.PT_NO
                   , B.PT_SILLM_CTG_DTM
                   , B.WD_DEPT_CD
                   , B.WD_DEPT_CD_NM
                   , B.PT_SILLM_CTG_TL_ID
                   , B.PT_SILLM_CTG_TL_NM
                   , B.PT_SILLM_CTG_TP_CD_NM
                   , B.PT_SILLM_CTG_GRP_CD
                   , B.PT_SILLM_CTG_GRP_CD_NM
                   , B.PT_SILLM_CTG_SCR_SUM
                   , SYSDATE
                   , SYSDATE
              );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_LD_UICIISPD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', IN_WD_DEPT_CD = ' || IN_WD_DEPT_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_LD_UICIISPD_SAVE;
