
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EZOTC_SMS_SEND" (
      IN_REF_KEY        		IN VARCHAR2                               -- 환자번호 (nullable)
    , IN_SUBJECT        		IN VARCHAR2 DEFAULT '안내문자'             -- LMS/알림톡에서의 제목 (SMS의 경우 nullable)
    , IN_CONTENT        		IN VARCHAR2                               -- 실제 발송 메시지
    , IN_SMS_SDLT_TEL_NO_CD     IN VARCHAR2 DEFAULT '201'                 -- 발신번호
	, IN_RECIPIENT_NUM  		IN VARCHAR2                               -- 수신번호
    , IN_TEMPLATE_CODE  		IN VARCHAR2 DEFAULT NULL                  -- NULL 이면 일반 SMS/LMS 분기
    , IN_SENDSTFNO      		IN VARCHAR2 DEFAULT NULL                  -- 로그 저장용 (직원번호)
    , IN_SENDPRGMNM      		IN VARCHAR2 DEFAULT 'PC_EZOTC_SMS_SEND'   -- 로그 저장용 (프로그램명)
    , IN_HSP_TP_CD      		IN VARCHAR2                               -- 원주세브란스기독병원 01
    
    
)
IS
BEGIN

    XCOM.PC_COM_DEFAULT_SMS_SEND (
          IN_MT_REFKEY           => IN_REF_KEY
        , IN_DATE_CLIENT_REQ     => SYSTIMESTAMP    -- 클라이언트 전송요청 시간 (NVL, SYSDATE 처리 되어 있음)
        , IN_SUBJECT             => IN_SUBJECT
        , IN_CONTENT             => IN_CONTENT
        , IN_SMS_SDLT_TEL_NO_CD  => IN_SMS_SDLT_TEL_NO_CD
        , IN_RECIPIENT_NUM       => IN_RECIPIENT_NUM
        , IN_TEMPLATE_CODE       => IN_TEMPLATE_CODE
        , IN_SENDSTFNO           => IN_SENDSTFNO
        , IN_SENDPRGMNM          => IN_SENDPRGMNM
        , IN_HSP_TP_CD           => IN_HSP_TP_CD
    );

EXCEPTION
    WHEN OTHERS THEN
        RAISE;

END PC_EZOTC_SMS_SEND;
