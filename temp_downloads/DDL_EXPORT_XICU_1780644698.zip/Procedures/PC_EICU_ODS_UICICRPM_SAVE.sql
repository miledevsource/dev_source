
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRPM_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRPM_SAVE                                               
*    CREATEDATE     : 2021.03.24
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_중환자기본 데이터 적재
*    Change History : 2021.03.24                                               
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
     
    /*******************************************************************************************************************
    * DELETE : HICU.UICICRPM --U121_UICI(ODS)_중환자기본
    * FROM : XICU.EMEI003V
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICICRPM A --U121_UICI(ODS)_중환자기본
          WHERE EXISTS (SELECT 1
                          FROM XICU.EMEI003V B
                         WHERE A.PACT_ID           = B.PACT_ID
                           AND B.LST_ACP_DTM BETWEEN IN_FROM_DTM 
                                                 AND IN_TO_DTM
                      ); 
      END; 
      
    /****************************
    * 중환자기본(UICICRPM) BATCH 
    ****************************/
    BEGIN        
        MERGE INTO HICU.UICICRPM A  --U121_UICI(ODS)_중환자기본
             USING (SELECT DISTINCT
                           PACT_ID                            --원무접수ID
                         , PT_NO                              --환자번호
                         , PT_NM                              --환자명
                         , ADS_DT                             --입원일자
                         , DS_EXPT_DT                         --퇴원예정일자
                         , DS_DT                              --퇴원일자
                         , SEX_TP_CD                          --성별구분코드
                         , AGE                                --연령
                         , AGE_MRK_NM                         --연령표시명
                         , ADS_PATH_CD                        --입원경로코드
                         , ADS_PATH_CD_NM                     --입원경로코드명
                         , FST_ACP_DTM                        --입원접수기본최초작성일시
                         , LST_ACP_DTM                        --입원접수기본최종작성일시
                         , APCN_YN                            --접수취소여부
                      FROM XICU.EMEI003V
                     WHERE APCN_YN           = 'N'
                       AND LST_ACP_DTM BETWEEN IN_FROM_DTM AND IN_TO_DTM
                   ) B
                ON (    A.PACT_ID                        = B.PACT_ID
                    AND A.HSP_TP_CD                      = IN_HSP_TP_CD--B.HSP_TP_CD
                    --AND A.PT_NO                          = B.PT_NO
                   )     
              WHEN MATCHED THEN
              --최종 적재
                   UPDATE SET A.PT_NM           = B.PT_NM
                            , A.ADS_DT          = B.ADS_DT
                            , A.DS_EXPT_DT      = B.DS_EXPT_DT
                            , A.SEX_TP_CD       = B.SEX_TP_CD
                            , A.AGE             = B.AGE
                            , A.AGE_MRK_NM      = B.AGE_MRK_NM
                            , A.ADS_PATH_CD     = B.ADS_PATH_CD
                            , A.ADS_PATH_CD_NM  = B.ADS_PATH_CD_NM
                            , A.FST_WRT_DTM     = B.FST_ACP_DTM
                            , A.LST_CHG_DTM     = B.LST_ACP_DTM
                            , A.LST_LOD_DTM     = SYSDATE        --최종적재일시
              WHEN NOT MATCHED THEN
              --최초 적재
                   INSERT ( A.PACT_ID
                          , A.HSP_TP_CD
                          , A.PT_NO
                          , A.PT_NM
                          , A.ADS_DT
                          , A.DS_EXPT_DT
                          , A.SEX_TP_CD
                          , A.AGE
                          , A.AGE_MRK_NM
                          , A.ADS_PATH_CD
                          , A.ADS_PATH_CD_NM
                          , A.FST_WRT_DTM
                          , A.LST_CHG_DTM
                          , A.FST_LOD_DTM
                          , A.LST_LOD_DTM
                          )
                   VALUES ( B.PACT_ID
                          , IN_HSP_TP_CD
                          , B.PT_NO
                          , B.PT_NM
                          , B.ADS_DT
                          , B.DS_EXPT_DT
                          , B.SEX_TP_CD
                          , B.AGE
                          , B.AGE_MRK_NM
                          , B.ADS_PATH_CD
                          , B.ADS_PATH_CD_NM
                          , B.FST_ACP_DTM
                          , B.LST_ACP_DTM
                          , SYSDATE                              --최초적재일시
                          , SYSDATE                              --최종적재일시
                          );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';  
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRPM_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICRPM_SAVE;
