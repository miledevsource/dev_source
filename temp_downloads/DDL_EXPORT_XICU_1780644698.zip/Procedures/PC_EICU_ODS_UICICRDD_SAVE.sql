
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRDD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRDD_SAVE                                    
*    CREATEDATE     : 2021.03.31
*    Author         : 진료분석사망정보                                                               
*    Description    : UICICRDD(U121_UICI(ODS)_진료분석사망정보)
*    Change History : 2021.03.31                                          
**********************************************************************************************/
AS 
BEGIN
    IO_ERRYN := 'N';
    IO_ERRMSG := '';

    BEGIN        
        MERGE INTO HICU.UICICRDD A  --진료분석사망정보
             USING ( SELECT PT_NO
                          , DS_DT
                          , MED_DEPT_CD
                          , PACT_TP_CD
                          , DS_MED_DEPT_CD
                          , DS_MED_DEPT_CD_NM
                          , ADS_WD_DEPT_CD
                          , ADS_WD_DEPT_CD_NM
                          , DTH_TP_CD
                          , DTH_TP_CD_NM
                          , ICU_USE_TP_CD
                          , ICU_USE_TP_CD_NM
                          , DTH_DT
                          , FST_WRT_DTM
                          , LST_CHG_DTM
                       FROM XICU.EMEI005V
                      WHERE LST_CHG_DTM BETWEEN IN_FROM_DTM AND IN_TO_DTM
                   ) B
                ON (    A.PT_NO       = B.PT_NO
                    AND A.DS_DT       = B.DS_DT
                    AND A.MED_DEPT_CD = B.MED_DEPT_CD
                   )
              WHEN MATCHED THEN
                   UPDATE SET PACT_TP_CD        = B.PACT_TP_CD
                            , DS_MED_DEPT_CD    = B.DS_MED_DEPT_CD
                            , DS_MED_DEPT_CD_NM = B.DS_MED_DEPT_CD_NM
                            , ADS_WD_DEPT_CD    = B.ADS_WD_DEPT_CD
                            , ADS_WD_DEPT_CD_NM = B.ADS_WD_DEPT_CD_NM
                            , DS_WD_DEPT_CD     = NULL --B.DS_WD_DEPT_CD
                            , DS_WD_DEPT_CD_NM  = NULL --B.DS_WD_DEPT_CD_NM
                            , DTH_TP_CD         = B.DTH_TP_CD
                            , DTH_TP_CD_NM      = B.DTH_TP_CD_NM
                            , ICU_USE_TP_CD     = B.ICU_USE_TP_CD
                            , ICU_USE_TP_CD_NM  = B.ICU_USE_TP_CD_NM
                            , DTH_DT            = B.DTH_DT
                            , FST_WRT_DTM       = B.FST_WRT_DTM
                            , LST_CHG_DTM       = B.LST_CHG_DTM
                            , LST_LOD_DTM       = SYSDATE
              WHEN NOT MATCHED THEN
                   INSERT ( PT_NO
                          , DS_DT
                          , MED_DEPT_CD
                          , HSP_TP_CD
                          , PACT_TP_CD
                          , DS_MED_DEPT_CD
                          , DS_MED_DEPT_CD_NM
                          , ADS_WD_DEPT_CD
                          , ADS_WD_DEPT_CD_NM
                          , DS_WD_DEPT_CD
                          , DS_WD_DEPT_CD_NM
                          , DTH_TP_CD
                          , DTH_TP_CD_NM
                          , ICU_USE_TP_CD
                          , ICU_USE_TP_CD_NM
                          , DTH_DT
                          , FST_WRT_DTM
                          , LST_CHG_DTM
                          , FST_LOD_DTM
                          , LST_LOD_DTM
                          ) 
                   VALUES ( B.PT_NO
                          , B.DS_DT
                          , B.MED_DEPT_CD
                          , IN_HSP_TP_CD
                          , B.PACT_TP_CD
                          , B.DS_MED_DEPT_CD
                          , B.DS_MED_DEPT_CD_NM
                          , B.ADS_WD_DEPT_CD
                          , B.ADS_WD_DEPT_CD_NM
                          , NULL --B.DS_WD_DEPT_CD
                          , NULL --B.DS_WD_DEPT_CD_NM
                          , B.DTH_TP_CD
                          , B.DTH_TP_CD_NM
                          , B.ICU_USE_TP_CD
                          , B.ICU_USE_TP_CD_NM
                          , B.DTH_DT
                          , B.FST_WRT_DTM
                          , B.LST_CHG_DTM
                          , SYSDATE
                          , SYSDATE
                          )
        ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRDD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;
END PC_EICU_ODS_UICICRDD_SAVE;
