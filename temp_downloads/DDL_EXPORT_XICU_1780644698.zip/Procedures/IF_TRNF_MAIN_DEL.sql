
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_MAIN_DEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																						    , IN_HSP_TP_CD        IN  VARCHAR2
																						    , IN_SEQ              IN VARCHAR2
																						    , IN_PT_NO            IN  VARCHAR2
																						    , IN_PACT_ID          IN  VARCHAR2
																						    , IN_STATUS_STS_CD    IN VARCHAR2
																						    , IN_LSH_DTM		        IN VARCHAR2
																										, IN_LSH_IP_ADDR	     IN VARCHAR2
																										, IN_LSH_STF_NO	      IN VARCHAR2
																										, IN_LSH_STF_NM	      IN VARCHAR2
																										, IN_LSH_PRGM_NM	     IN VARCHAR2
																						
																						    , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000);
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000) ;
/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_MAIN_DEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 협진삭제
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/

 BEGIN    
    BEGIN   
    
       SELECT TRNF_PRGR_STS_CD 
         , STATUS_STS_CD 
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO; 
       
   IF V_STATUS_STS_CD = 'A'  THEN 
   
       UPDATE ARPA_PT_LIST
          SET STATUS_STS_CD  = IN_STATUS_STS_CD 
            , LSH_DTM =  TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
            , LSH_IP_ADDR = IN_LSH_IP_ADDR
            , LSH_STF_NO  = IN_LSH_STF_NO
            , LSH_STF_NM  = IN_LSH_STF_NM
            , LSH_PRGM_NM = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ =  IN_SEQ
       AND PT_NO = IN_PT_NO
       AND PACT_ID = IN_PACT_ID;       
       
   				  	IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
								  
								  		  
     ELSE IS_SUCCESS := 'N';
          ERROR_MSG  := '이미 처리된 환자입니다.';
                    
							END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;
