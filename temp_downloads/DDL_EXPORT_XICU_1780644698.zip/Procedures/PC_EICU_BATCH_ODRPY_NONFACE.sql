
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_ODRPY_NONFACE" 

                          ( IN_PRMR_DTM       IN  DATE

                          , IN_HSP_TP_CD      IN  VARCHAR2

                          , IO_ERR_YN         OUT VARCHAR2

                          , IO_ERR_MSG        OUT VARCHAR2

                          )

/**********************************************************************************************

*    SERVICENAME    : PC_EICU_BATCH_ODRPY_NONFACE

*    CREATEDATE     : 2021.04.07

*    Author         : 신솔

*    Description    : 타과의뢰 정보 비대면협진 데이터 배치

*    Change History : 2021.04.07, 신솔, 최초작성

**********************************************************************************************/

AS

    V_CURSOR              SYS_REFCURSOR;

    V_IO_ERR_YN           VARCHAR(500);

    V_IO_ERR_MSG          VARCHAR(2000);



    V_ROW_NUM             VARCHAR(50);    -- ROW NUMBER

    V_EPCN_CSLT_ID        VARCHAR(50);    -- 관제센터협진ID

    V_EPCN_CSLT_FOM_SEQ   NUMBER(22);     -- 관제센터협진개정순번

    V_MED_DEPT_CD         VARCHAR(50);    -- 환자진료과코드

    V_MED_DEPT_NM         VARCHAR(200);   -- 환자진료과명

    V_RER_DEPT_CD         VARCHAR(5);     -- 의뢰부서코드

    V_RER_STF_NO          VARCHAR(20);    -- 의뢰직원번호

    V_RER_STF_NM          VARCHAR(100);   -- 의뢰직원이름

    V_CSLT_STR_DTM        DATE;           -- 협진시작일시

    V_CSLT_END_DTM        DATE;           -- 협진종료일시

    V_PT_NO               VARCHAR(8);     -- 환자번호

    V_PT_NM               VARCHAR(500);   -- 환자이름

    V_PACT_ID             VARCHAR(50);    -- 원무접수ID

    V_ADS_DT              DATE;           -- 입원일자

    V_SEX_TP_CD           VARCHAR(1);     -- 성별구분코드

    V_AGE                 NUMBER(22);     -- 연령

    V_PRTP_DEPT_CD        VARCHAR(5);     -- 참여부서코드

    V_PRTP_DEPT_NM        VARCHAR(500);   -- 참여부서명

    V_PRTP_SID            VARCHAR(10);    -- 참여직원식별ID

    V_PRTP_STF_NM         VARCHAR(500);   -- 참여직원명

    V_CNSL_CNTE           VARCHAR(4000);  -- 상담내용

    V_ODRER_DIAG          VARCHAR(4000);  -- 진단명

    V_RER_CNTE            VARCHAR(4000);  -- 의뢰내용

    V_ODRPY_MDRC_ID       VARCHAR(50);    -- 회신기록ID



    V_ODRPY_YN            VARCHAR(50);

    V_ODRPY_NUM           NUMBER(22);

    

    V_INSERT_EPCN_CSLT_ID          NUMBER(22)     := 0;

    V_INSERT_EPCN_CSLT_FOM_SEQ     NUMBER(22)     := 0;

    

BEGIN

    /*******************************************

     * 진료기록ID 조회

     *******************************************/ 

    DECLARE CURSOR MDRC_ID_CURSOR IS SELECT A.MDRC_ID AS MDRC_ID

                                       FROM XICU.EMEI015V A

                                          , HICU.UICICRPM B

                                      WHERE A.RPLY_YN            = 'Y'

                                        AND A.NONFACE_CONSULT_YN = 'Y'

                                        AND B.PACT_ID            = A.PACT_ID

                                        AND B.HSP_TP_CD          = IN_HSP_TP_CD

                                        AND (A.LSH_DTM           > IN_PRMR_DTM

                                         OR B.LST_LOD_DTM        > IN_PRMR_DTM)

                                     ;

                                     

    REC MDRC_ID_CURSOR%ROWTYPE;

    BEGIN

        OPEN MDRC_ID_CURSOR;

        LOOP FETCH MDRC_ID_CURSOR INTO REC;

        EXIT WHEN MDRC_ID_CURSOR%NOTFOUND;

            BEGIN

                -- 타과의뢰 정보 비대면협진 데이터 조회

                XICU.PC_EICU_SELECT_ODRPY_NONFACE( IN_PRMR_DTM

                                                 , REC.MDRC_ID

                                                 , IN_HSP_TP_CD

                                                 , V_CURSOR

                                                 , V_IO_ERR_YN

                                                 , V_IO_ERR_MSG

                                                 )

                                                 ;

            END;

            

            BEGIN

                LOOP

                FETCH V_CURSOR

                 INTO V_ROW_NUM

                    , V_EPCN_CSLT_ID

                    , V_EPCN_CSLT_FOM_SEQ

                    , V_RER_DEPT_CD

                    , V_MED_DEPT_CD

                    , V_MED_DEPT_NM

                    , V_RER_STF_NO

                    , V_RER_STF_NM

                    , V_CSLT_STR_DTM

                    , V_CSLT_END_DTM

                    , V_PT_NO

                    , V_PT_NM

                    , V_PACT_ID

                    , V_ADS_DT

                    , V_SEX_TP_CD

                    , V_AGE

                    , V_PRTP_DEPT_CD

                    , V_PRTP_DEPT_NM

                    , V_PRTP_SID

                    , V_PRTP_STF_NM

                    , V_CNSL_CNTE

                    , V_ODRER_DIAG

                    , V_RER_CNTE                    

                    , V_ODRPY_MDRC_ID

                    ;

                EXIT WHEN V_CURSOR%NOTFOUND;

                    BEGIN

                        /**********************

                        관제센터협진기본(UCOMCNSM) 저장

                        ************************/

                        BEGIN

                            INSERT 

                              INTO HICU.UCOMCNSM

                                 ( EPCN_CSLT_ID

                                 , EPCN_CSLT_FOM_SEQ

                                 , RER_HSP_CD

                                 , RER_DEPT_CD

                                 , RER_STF_NO

                                 , RER_STF_NM

                                 , CSLT_STR_DTM

                                 , CSLT_END_DTM

                                 , CSLT_CLS_CD

                                 , PT_NO

                                 , PT_NM

                                 , PACT_ID

                                 , PACT_DTM

                                 , ADS_DT

                                 , ETRM_DTM

                                 , PT_MED_DEPT_CD

                                 , PT_MED_DEPT_NM

                                 , SEX_TP_CD

                                 , AGE

                                 , MAIN_DGNS_DT

                                 , DGNS_VOC_ID

                                 , ICD10_CD

                                 , DGNS_VOC_NM

                                 , WD_DEPT_CD

                                 , WD_DEPT_CD_NM

                                 , LST_YN

                                 , SV_STS_CD

                                 , WRT_DTM

                                 , WRTR_ID

                                 , FSR_STF_NO

                                 , FSR_DTM

                                 , FSR_PRGM_NM

                                 , FSR_IP_ADDR

                                 , LSH_STF_NO

                                 , LSH_DTM

                                 , LSH_PRGM_NM

                                 , LSH_IP_ADDR

                                 , MDRC_ID

                                 , RER_CNTE

                                 )

                            VALUES 

                                 ( V_EPCN_CSLT_ID

                                 , V_EPCN_CSLT_FOM_SEQ

                                 , IN_HSP_TP_CD

                                 , V_RER_DEPT_CD

                                 , V_RER_STF_NO

                                 , V_RER_STF_NM

                                 , V_CSLT_STR_DTM

                                 , V_CSLT_END_DTM

                                 , '5'

                                 , V_PT_NO

                                 , V_PT_NM

                                 , V_PACT_ID

                                 , NULL

                                 , V_ADS_DT

                                 , NULL

                                 , V_MED_DEPT_CD

                                 , V_MED_DEPT_NM

                                 , V_SEX_TP_CD

                                 , V_AGE

                                 , NULL

                                 , NULL

                                 , NULL

                                 , V_ODRER_DIAG

                                 , V_RER_DEPT_CD

                                 , V_RER_DEPT_CD

                                 , 'Y'

                                 , 'S'

                                 , V_CSLT_END_DTM

                                 , V_PRTP_SID

                                 , 'BATCH'

                                 , SYSDATE

                                 , 'BATCH'

                                 , ''

                                 , 'BATCH'

                                 , SYSDATE

                                 , 'BATCH'

                                 , ''

                                 , REC.MDRC_ID

                                 , V_RER_CNTE

                                 );

                            

                                EXCEPTION

                                    WHEN OTHERS THEN

                                        IO_ERR_YN  := 'Y';

                                        IO_ERR_MSG := '1) 관제센터협진기본 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                        RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                    RETURN;          

                        END;

                    

                        IF V_ROW_NUM = 1 THEN

                            -- 개정순번 추가된 경우 최종여부 업데이트

                            IF V_EPCN_CSLT_FOM_SEQ > 1 THEN

                                BEGIN

                                    UPDATE HICU.UCOMCNSM A

                                       SET A.LST_YN            = 'N'

                                         , A.LSH_STF_NO        = 'BATCH'

                                         , A.LSH_DTM           = SYSDATE

                                         , A.LSH_PRGM_NM       = 'BATCH'

                                         , A.LSH_IP_ADDR       = ''

                                     WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID

                                       AND A.EPCN_CSLT_FOM_SEQ = TO_CHAR(TO_NUMBER(V_EPCN_CSLT_FOM_SEQ) - 1)

                                    ;

                            

                                    EXCEPTION

                                        WHEN OTHERS THEN

                                            IO_ERR_YN  := 'Y';

                                            IO_ERR_MSG := '2) 관제센터협진기본 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                            RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                        RETURN;

                                END;

                            END IF;

                        ELSE

                            BEGIN

                                UPDATE HICU.UCOMCNSM A

                                   SET A.WRT_DTM           = V_CSLT_END_DTM 

                                     , A.WRTR_ID           = V_PRTP_SID

                                     , A.LSH_STF_NO        = 'BATCH'

                                     , A.LSH_DTM           = SYSDATE

                                     , A.LSH_PRGM_NM       = 'BATCH'

                                     , A.LSH_IP_ADDR       = ''

                                 WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID

                                   AND A.EPCN_CSLT_FOM_SEQ = V_EPCN_CSLT_FOM_SEQ

                                ;

                        

                                EXCEPTION

                                    WHEN OTHERS THEN

                                        IO_ERR_YN  := 'Y';

                                        IO_ERR_MSG := '3) 관제센터협진기본 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                        RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                    RETURN;

                            END;

                        END IF;

                    

                        IF V_EPCN_CSLT_FOM_SEQ = 1 THEN

                            /**********************

                            협진참여자정보(UCOMCNRD) 저장

                            ************************/

                            BEGIN

                              INSERT

                                INTO HICU.UCOMCNRD

                                   ( EPCN_CSLT_ID

                                   , EPCN_CSLT_FOM_SEQ

                                   , PRTP_SEQ

                                   , PRTP_HSP_CD

                                   , PRTP_HSP_NM

                                   , PRTP_DEPT_CD

                                   , PRTP_DEPT_NM

                                   , PRTP_SID

                                   , PRTP_STF_NM

                                   , FSR_STF_NO

                                   , FSR_DTM

                                   , FSR_PRGM_NM

                                   , FSR_IP_ADDR

                                   , LSH_STF_NO

                                   , LSH_DTM

                                   , LSH_PRGM_NM

                                   , LSH_IP_ADDR

                                   , RPLY_REC_ID

                                   )

                              VALUES 

                                   ( V_EPCN_CSLT_ID

                                   , V_EPCN_CSLT_FOM_SEQ

                                   , V_ROW_NUM

                                   , IN_HSP_TP_CD

                                   , (SELECT X.HSP_NM FROM HICU.UCCOCHPM X WHERE USE_YN = 'Y' AND HSP_TP_CD = IN_HSP_TP_CD)

                                   , V_PRTP_DEPT_CD

                                   , V_PRTP_DEPT_NM

                                   , V_PRTP_SID

                                   , V_PRTP_STF_NM

                                   , 'BATCH'

                                   , SYSDATE

                                   , 'BATCH'

                                   , ''

                                   , 'BATCH'

                                   , SYSDATE

                                   , 'BATCH'

                                   , ''

                                   , V_ODRPY_MDRC_ID

                                   );

                      

                              EXCEPTION

                                  WHEN OTHERS THEN

                                      IO_ERR_YN  := 'Y';

                                      IO_ERR_MSG := '4) 협진참여자정보 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                      RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                  RETURN; 

                            END;

                            

                            /**********************

                            협진상담상세(UCOMCNSE) 저장

                            ************************/

                            BEGIN

                              INSERT

                                INTO HICU.UCOMCNSE

                                   ( EPCN_CNSL_ID

                                   , FOM_SEQ

                                   , CMPS_SEQ

                                   , CNSL_CNTE

                                   , DEL_YN

                                   , FST_WRT_DTM

                                   , FST_WRTR_SID

                                   , LST_MDF_DTM

                                   , LST_MDF_SID

                                   , FSR_STF_NO

                                   , FSR_DTM

                                   , FSR_PRGM_NM

                                   , FSR_IP_ADDR

                                   , LSH_STF_NO

                                   , LSH_DTM

                                   , LSH_PRGM_NM

                                   , LSH_IP_ADDR

                                   , RPLY_REC_ID

                                   )

                              VALUES 

                                   ( V_EPCN_CSLT_ID

                                   , V_EPCN_CSLT_FOM_SEQ

                                   , V_ROW_NUM

                                   , V_CNSL_CNTE

                                   , 'N'

                                   , V_CSLT_END_DTM

                                   , V_PRTP_SID

                                   , V_CSLT_END_DTM

                                   , V_PRTP_SID

                                   , 'BATCH'

                                   , SYSDATE

                                   , 'BATCH'

                                   , ''

                                   , 'BATCH'

                                   , SYSDATE

                                   , 'BATCH'

                                   , ''

                                   , V_ODRPY_MDRC_ID

                                   );

                      

                              EXCEPTION

                                  WHEN OTHERS THEN

                                      IO_ERR_YN  := 'Y';

                                      IO_ERR_MSG := '5) 협진상담상세 데이터 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                      RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                  RETURN; 

                            END;

                        ELSE -- 개정순번 추가

                            BEGIN

                                IF V_ROW_NUM = 1 THEN

                                    BEGIN

                                        INSERT 

                                          INTO HICU.UCOMCNRD

                                             ( EPCN_CSLT_ID

                                             , EPCN_CSLT_FOM_SEQ

                                             , PRTP_SEQ

                                             , PRTP_HSP_CD

                                             , PRTP_HSP_NM

                                             , PRTP_DEPT_CD

                                             , PRTP_DEPT_NM

                                             , PRTP_SID

                                             , PRTP_STF_NM

                                             , FSR_STF_NO

                                             , FSR_DTM

                                             , FSR_PRGM_NM

                                             , FSR_IP_ADDR

                                             , LSH_STF_NO

                                             , LSH_DTM

                                             , LSH_PRGM_NM

                                             , LSH_IP_ADDR

                                             , RPLY_REC_ID

                                             )

                                        SELECT V_EPCN_CSLT_ID

                                             , V_EPCN_CSLT_FOM_SEQ

                                             , A.PRTP_SEQ

                                             , A.PRTP_HSP_CD

                                             , A.PRTP_HSP_NM

                                             , A.PRTP_DEPT_CD

                                             , A.PRTP_DEPT_NM

                                             , A.PRTP_SID

                                             , A.PRTP_STF_NM

                                             , A.FSR_STF_NO

                                             , A.FSR_DTM

                                             , A.FSR_PRGM_NM

                                             , A.FSR_IP_ADDR

                                             , A.LSH_STF_NO

                                             , A.LSH_DTM

                                             , A.LSH_PRGM_NM

                                             , A.LSH_IP_ADDR

                                             , A.RPLY_REC_ID

                                          FROM HICU.UCOMCNRD A

                                         WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID

                                           AND A.EPCN_CSLT_FOM_SEQ = V_EPCN_CSLT_FOM_SEQ - 1

                                        ;

                                        

                                        EXCEPTION

                                            WHEN OTHERS THEN

                                                IO_ERR_YN  := 'Y';

                                                IO_ERR_MSG := '6) 협진참여자정보 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                            RETURN;

                                    END;

                                    

                                    BEGIN

                                        INSERT 

                                          INTO HICU.UCOMCNSE

                                             ( EPCN_CNSL_ID

                                             , FOM_SEQ

                                             , CMPS_SEQ

                                             , CNSL_CNTE

                                             , DEL_YN

                                             , FST_WRT_DTM

                                             , FST_WRTR_SID

                                             , LST_MDF_DTM

                                             , LST_MDF_SID

                                             , FSR_STF_NO

                                             , FSR_DTM

                                             , FSR_PRGM_NM

                                             , FSR_IP_ADDR

                                             , LSH_STF_NO

                                             , LSH_DTM

                                             , LSH_PRGM_NM

                                             , LSH_IP_ADDR

                                             , RPLY_REC_ID

                                             )

                                        SELECT V_EPCN_CSLT_ID

                                             , V_EPCN_CSLT_FOM_SEQ

                                             , A.CMPS_SEQ

                                             , A.CNSL_CNTE

                                             , A.DEL_YN

                                             , A.FST_WRT_DTM

                                             , A.FST_WRTR_SID

                                             , A.LST_MDF_DTM

                                             , A.LST_MDF_SID

                                             , A.FSR_STF_NO

                                             , A.FSR_DTM

                                             , A.FSR_PRGM_NM

                                             , A.FSR_IP_ADDR

                                             , A.LSH_STF_NO

                                             , A.LSH_DTM

                                             , A.LSH_PRGM_NM

                                             , A.LSH_IP_ADDR

                                             , A.RPLY_REC_ID

                                          FROM HICU.UCOMCNSE A

                                         WHERE A.EPCN_CNSL_ID = V_EPCN_CSLT_ID

                                           AND A.FOM_SEQ      = V_EPCN_CSLT_FOM_SEQ - 1

                                        ;

                                        

                                        EXCEPTION

                                            WHEN OTHERS THEN

                                                IO_ERR_YN  := 'Y';

                                                IO_ERR_MSG := '7) 협진상담상세 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                            RETURN;

                                    END;

                                END IF;

                                

                                BEGIN

                                    SELECT DECODE(COUNT(*), 0, 'N', 'Y')

                                      INTO V_ODRPY_YN

                                      FROM HICU.UCOMCNRD A

                                     WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID

                                       AND A.EPCN_CSLT_FOM_SEQ = V_EPCN_CSLT_FOM_SEQ

                                       AND A.RPLY_REC_ID       = V_ODRPY_MDRC_ID

                                    ;

                                

                                    EXCEPTION

                                        WHEN OTHERS THEN

                                            IO_ERR_YN  := 'Y';

                                            IO_ERR_MSG := '8) 협진기록 존재유무 조회 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                            RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                        RETURN;

                                END;

                                

                                IF V_ODRPY_YN = 'Y' THEN

                                    BEGIN

                                        UPDATE HICU.UCOMCNRD A

                                           SET A.PRTP_SID          = V_PRTP_SID

                                             , A.PRTP_STF_NM       = V_PRTP_STF_NM

                                             , A.LSH_STF_NO        = 'BATCH'

                                             , A.LSH_DTM           = SYSDATE

                                             , A.LSH_PRGM_NM       = 'BATCH'

                                             , A.LSH_IP_ADDR       = ''

                                         WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID

                                           AND A.EPCN_CSLT_FOM_SEQ = V_EPCN_CSLT_FOM_SEQ

                                           AND A.RPLY_REC_ID       = V_ODRPY_MDRC_ID

                                        ;

                                

                                        EXCEPTION

                                            WHEN OTHERS THEN

                                                IO_ERR_YN  := 'Y';

                                                IO_ERR_MSG := '9) 협진참여자정보 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                            RETURN;

                                    END;

                                    

                                    BEGIN

                                        UPDATE HICU.UCOMCNSE A

                                           SET A.DEL_YN       = 'Y'

                                             , A.LSH_STF_NO   = 'BATCH'

                                             , A.LSH_DTM      = SYSDATE

                                             , A.LSH_PRGM_NM  = 'BATCH'

                                             , A.LSH_IP_ADDR  = ''

                                         WHERE A.EPCN_CNSL_ID = V_EPCN_CSLT_ID

                                           AND A.FOM_SEQ      = V_EPCN_CSLT_FOM_SEQ

                                           AND A.RPLY_REC_ID  = V_ODRPY_MDRC_ID

                                        ;

                                

                                        EXCEPTION

                                            WHEN OTHERS THEN

                                                IO_ERR_YN  := 'Y';

                                                IO_ERR_MSG := '10) 협진상담상세 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                            RETURN;

                                    END;

                                ELSE

                                    BEGIN

                                        BEGIN

                                            SELECT COUNT(*)

                                              INTO V_ODRPY_NUM

                                              FROM HICU.UCOMCNRD A

                                             WHERE A.EPCN_CSLT_ID      = V_EPCN_CSLT_ID 

                                               AND A.EPCN_CSLT_FOM_SEQ = V_EPCN_CSLT_FOM_SEQ 

                                               AND A.RPLY_REC_ID       = V_ODRPY_MDRC_ID 

                                            ;

                                        END;

                                

                                        INSERT 

                                          INTO HICU.UCOMCNRD

                                             ( EPCN_CSLT_ID

                                             , EPCN_CSLT_FOM_SEQ

                                             , PRTP_SEQ

                                             , PRTP_HSP_CD

                                             , PRTP_HSP_NM

                                             , PRTP_DEPT_CD

                                             , PRTP_DEPT_NM

                                             , PRTP_SID

                                             , PRTP_STF_NM

                                             , FSR_STF_NO

                                             , FSR_DTM

                                             , FSR_PRGM_NM

                                             , FSR_IP_ADDR

                                             , LSH_STF_NO

                                             , LSH_DTM

                                             , LSH_PRGM_NM

                                             , LSH_IP_ADDR

                                             , RPLY_REC_ID

                                             )

                                        VALUES 

                                             ( V_EPCN_CSLT_ID

                                             , V_EPCN_CSLT_FOM_SEQ

                                             , V_ODRPY_NUM + 1

                                             , IN_HSP_TP_CD

                                             , (SELECT X.HSP_NM FROM HICU.UCCOCHPM X WHERE USE_YN = 'Y' AND HSP_TP_CD = IN_HSP_TP_CD)

                                             , V_PRTP_DEPT_CD

                                             , V_PRTP_DEPT_NM

                                             , V_PRTP_SID

                                             , V_PRTP_STF_NM

                                             , 'BATCH'

                                             , SYSDATE

                                             , 'BATCH'

                                             , ''

                                             , 'BATCH'

                                             , SYSDATE

                                             , 'BATCH'

                                             , ''

                                             , V_ODRPY_MDRC_ID

                                             )

                                        ;

                                

                                        EXCEPTION

                                            WHEN OTHERS THEN

                                                IO_ERR_YN  := 'Y';

                                                IO_ERR_MSG := '11) 협진참여자정보 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                            RETURN;

                                    END;

                                END IF;

                                

                                BEGIN

                                    BEGIN

                                        SELECT COUNT(*)

                                          INTO V_ODRPY_NUM

                                          FROM HICU.UCOMCNSE A

                                         WHERE A.EPCN_CNSL_ID = V_EPCN_CSLT_ID 

                                           AND A.FOM_SEQ      = V_EPCN_CSLT_FOM_SEQ 

                                        ;

                                    END;

                

                                    INSERT 

                                      INTO HICU.UCOMCNSE

                                         ( EPCN_CNSL_ID

                                         , FOM_SEQ

                                         , CMPS_SEQ

                                         , CNSL_CNTE

                                         , DEL_YN

                                         , FST_WRT_DTM

                                         , FST_WRTR_SID

                                         , LST_MDF_DTM

                                         , LST_MDF_SID

                                         , FSR_STF_NO

                                         , FSR_DTM

                                         , FSR_PRGM_NM

                                         , FSR_IP_ADDR

                                         , LSH_STF_NO

                                         , LSH_DTM

                                         , LSH_PRGM_NM

                                         , LSH_IP_ADDR

                                         , RPLY_REC_ID

                                         )

                                    VALUES 

                                         ( V_EPCN_CSLT_ID

                                         , V_EPCN_CSLT_FOM_SEQ

                                         , V_ODRPY_NUM + 1

                                         , V_CNSL_CNTE

                                         , 'N'

                                         , V_CSLT_END_DTM

                                         , V_PRTP_SID

                                         , V_CSLT_END_DTM

                                         , V_PRTP_SID

                                         , 'BATCH'

                                         , SYSDATE

                                         , 'BATCH'

                                         , ''

                                         , 'BATCH'

                                         , SYSDATE

                                         , 'BATCH'

                                         , ''

                                         , V_ODRPY_MDRC_ID

                                         )

                                    ;

                            

                                    EXCEPTION

                                        WHEN OTHERS THEN

                                            IO_ERR_YN  := 'Y';

                                            IO_ERR_MSG := '12) 협진상담상세 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                                            RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                                        RETURN;

                                END;

                            END;

                        END IF;

                    END;

                END LOOP; --V_CURSOR LOOP 종료

                COMMIT;

            END;

        END LOOP; --MDRC_ID_CURSOR LOOP 종료

        COMMIT;

        CLOSE MDRC_ID_CURSOR; --MDRC_ID_CURSOR 종료

    END;

END PC_EICU_BATCH_ODRPY_NONFACE;
