
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_STATISTIC_MORTALITY" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_STATISTIC_MORTALITY
*    CREATEDATE     : 2021.02.03
*    Author         : 신솔
*    Description    : 중환자실 사망률
*    Change History : 2021.02.03, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            /**********************
                     지표화면(UI) 조회
            ************************/
            WITH CHARTGUB AS (
                 /* 차트 구분 공통코드 */
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                   FROM (SELECT 'AGE_GRP' AS COMN_GRP_CD, '1' AS COMN_CD, '~10대' AS COMN_CD_NM FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '2', '20대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '3', '30대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '4', '40대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '5', '50대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '6', '60대' FROM DUAL UNION ALL
                         SELECT 'AGE_GRP', '7', '70대~' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'F', '여성' FROM DUAL UNION ALL
                         SELECT 'SEX_GRP', 'M', '남성' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '1', '1군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '2', '2군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '3', '3군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '4', '4군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '5', '5군' FROM DUAL UNION ALL
                         SELECT 'PT_SILLM_CTG_GRP', '6', '6군' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '10', '10' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '20', '20' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '30', '30' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '40', '40' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '50', '50' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '60', '60' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '70', '70' FROM DUAL UNION ALL
                         SELECT 'APCS_SUM_SCR_GRP', '80', '80' FROM DUAL) A
                  ORDER BY A.COMN_GRP_CD
                 )
               , MONTHGUB AS (
                 /* 년간 추이 공통코드 */
                 SELECT TO_CHAR(A.YMD, 'YYYY-MM') AS DTM
                  FROM (
                        SELECT ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) AS YMD
                          FROM DUAL
                       CONNECT BY ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) >= ADD_MONTHS(IN_TO_DT, -11)
                       ) A
                 )
               , BF_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '12', 'YYYYMM'), TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM')) + 1
            
                 )
               , CUR_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYYMM'), 'YYYYMM'), TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , OUT_DATA AS (
                 /* 퇴실환자수 */
                 SELECT NVL(SUM(COUNT(*)), 0) AS OUT_CNT
                   FROM HICU.UICICSDM A --중환자실사망지표기본
                  WHERE A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                    AND A.CHOT_DTM        <= SYSDATE  /*미래자 퇴실일자는 제외*/
                    AND A.CHOT_DTM        BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                    AND A.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                  GROUP BY A.CIPT_ETRM_CHOT_ID
                 )
               , DIE_DATA AS (
                 /* 사망환자 상세 */
                 SELECT A.HSP_TP_CD
                      , A.PACT_ID
                      , A.PT_NO
                      , A.CIPT_ETRM_CHOT_ID
                      , A.PT_NM
                      , A.ADS_DT
                      , A.DS_EXPT_DT
                      , A.SEX_TP_CD
                      , A.AGE
                      , A.ADS_PATH_CD
                      , A.ADS_PATH_NM
                      , A.MED_DEPT_CD
                      , A.MED_DEPT_CD_NM
                      , A.RPRN_MED_DEPT_CD
                      , A.RPRN_MED_DEPT_CD_NM
                      , A.ETRM_DTM
                      , A.ETRM_WD_DEPT_CD
                      , A.ETRM_WD_DEPT_CD_NM
                      , A.ETRM_PRM_NO
                      , A.ETRM_BED_NO
                      , A.EMRG_BED_YN
                      , A.ISLT_BED_YN
                      , A.ICU_ETRM_PATH_CLS_CD
                      , A.ICU_ETRM_PATH_CLS_CD_NM
                      , A.CHOT_DTM
                      , A.ICU_CHOT_PLC_TP_CD
                      , A.ICU_CHOT_PLC_TP_CD_NM
                      , A.CHOT_WD_MTD_CD
                      , A.CHOT_WD_MTD_CD_NM
                      , A.APCS_REC_INPT_DTM
                      , A.APCS_REC_WRT_SEQ
                      , A.APCS_PT_STS_CD
                      , A.APCS_PT_STS_CD_NM
                      , A.APCS_SUM_SCR
                      , A.DTH_DGCT_WRT_DTM
                      , A.DTH_TP_CD
                      , A.DTH_DT
                   FROM HICU.UICICSDM A
                  WHERE A.ICU_CHOT_PLC_TP_CD IN('06', '07')
                    AND A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                    AND A.CHOT_DTM        <= SYSDATE  /*미래자 퇴실일자는 제외*/
                    AND A.CHOT_DTM        BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                    AND A.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                 )
               , DIE_DATA_FOR_ANNU AS(
                 SELECT CIPT_ETRM_CHOT_ID
                      , CHOT_DTM
                      , ICU_CHOT_PLC_TP_CD
                   FROM HICU.UICICSDM --중환자실사망지표기본
                  WHERE ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                    AND CHOT_DTM        <= SYSDATE
                    AND CHOT_DTM        BETWEEN TRUNC(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '-01-01', 'YYYY-MM-DD')) AND TRUNC(LAST_DAY(IN_TO_DT)) + 0.99999
                    AND HSP_TP_CD       = IN_HIS_HSP_TP_CD
                  GROUP BY CIPT_ETRM_CHOT_ID, CHOT_DTM, ICU_CHOT_PLC_TP_CD
                 )
               , SILLM_DATA AS(
                 SELECT PT_SILLM_CTG_DTM
                      , PT_SILLM_CTG_GRP_CD
                   FROM (
                         SELECT B.PT_SILLM_CTG_DTM    AS PT_SILLM_CTG_DTM
                              , B.PT_SILLM_CTG_GRP_CD AS PT_SILLM_CTG_GRP_CD
                           FROM (SELECT X.HSP_TP_CD
                                      , X.PACT_ID
                                      , X.PT_NO
                                      , X.ETRM_DTM
                                      , X.CHOT_DTM
                                   FROM HICU.UICICSDM X
                                  WHERE X.ICU_CHOT_PLC_TP_CD IN('06', '07')
                                    AND X.ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                                    AND X.CHOT_DTM           <= SYSDATE  /*미래자 퇴실일자는 제외*/
                                    AND X.HSP_TP_CD          = IN_HIS_HSP_TP_CD)      A --중환자실사망지표기본 ( 아파치 중복 제거한 사망환자 리스트 )
                               , (SELECT Y.HSP_TP_CD
                                       , Y.PACT_ID
                                       , Y.PT_NO
                                       , Y.PT_SILLM_CTG_DTM
                                       , Y.PT_SILLM_CTG_GRP_CD
                                       , DENSE_RANK() OVER (PARTITION BY Y.PT_SILLM_CTG_REC_ID ORDER BY Y.PT_SILLM_CTG_DTM DESC, Y.PT_SILLM_CTG_REC_WRT_SEQ DESC) AS RANK
                                    FROM HICU.UICICSDD Y
                                   WHERE Y.PT_SILLM_CTG_TP_CD      = '2'
                                     AND Y.PT_SILLM_CTG_DTM        BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                                     AND Y.HSP_TP_CD               = IN_HIS_HSP_TP_CD) B --중환자실사망중증도분류정보 ( 조회기간내 모든 중증도 정보 )
                          WHERE A.HSP_TP_CD           = B.HSP_TP_CD(+)
                            AND A.PACT_ID             = B.PACT_ID(+)
                            AND A.PT_NO               = B.PT_NO(+)
                            AND (B.PT_SILLM_CTG_DTM = (SELECT MAX(Z.PT_SILLM_CTG_DTM)
                                                         FROM HICU.UICICSDD Z
                                                        WHERE Z.HSP_TP_CD          = A.HSP_TP_CD
                                                          AND Z.PACT_ID            = A.PACT_ID
                                                          AND Z.PT_NO              = A.PT_NO
                                                          AND Z.PT_SILLM_CTG_TP_CD = '2'
                                                          AND Z.PT_SILLM_CTG_DTM   BETWEEN TRUNC(A.ETRM_DTM) AND TRUNC(A.CHOT_DTM))  /*입원기간 내 마지막 중증도*/
                             OR  B.PT_SILLM_CTG_DTM IS NULL)
                            AND (B.RANK = 1 OR B.RANK IS NULL)
                        )
                  WHERE PT_SILLM_CTG_DTM BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                 )
            
            
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT 'DTH_RATE'     AS COMN_GRP_CD
                 , '01'           AS COMN_CD
                 , '사망률 현황'      AS COMN_CD_NM
                 , 'PT_CNT'         AS COMN_CD_EXPL
                 , TO_CHAR(DIE_CNT) AS DTRL1_NM --사망환자수
                 , TO_CHAR(OUT_CNT) AS DTRL2_NM --퇴원환자수
                 , RTRIM(TO_CHAR(DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100 , 1)), 'FM9990.9'), '.') AS DTRL3_NM --사망률
              FROM (SELECT COUNT(*) AS DIE_CNT FROM DIE_DATA) A
                 , OUT_DATA B
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , DECODE(A.COMN_CD, 'F', 'SEX_FEML_CNT', 'SEX_MALE_CNT') AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT SEX_TP_CD AS COMN_CD
                         , COUNT(*)  AS COUNT
                      FROM DIE_DATA X
                     GROUP BY X.SEX_TP_CD) B
             WHERE A.COMN_GRP_CD = 'SEX_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '1' THEN 'AGE_10_GRP_BLW_CNT'
                        WHEN A.COMN_CD = '2' THEN 'AGE_20_GRP_CNT'
                        WHEN A.COMN_CD = '3' THEN 'AGE_30_GRP_CNT'
                        WHEN A.COMN_CD = '4' THEN 'AGE_40_GRP_CNT'
                        WHEN A.COMN_CD = '5' THEN 'AGE_50_GRP_CNT'
                        WHEN A.COMN_CD = '6' THEN 'AGE_60_GRP_CNT'
                        ELSE 'AGE_70_GRP_UPR_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN AGE < 20 THEN '1'
                                WHEN AGE < 30 THEN '2'
                                WHEN AGE < 40 THEN '3'
                                WHEN AGE < 50 THEN '4'
                                WHEN AGE < 60 THEN '5'
                                WHEN AGE < 70 THEN '6'
                                ELSE '7' END             AS COMN_CD
                              , COUNT(*)                 AS COUNT
                       FROM DIE_DATA
                      GROUP BY CASE WHEN AGE < 20 THEN '1'
                                    WHEN AGE < 30 THEN '2'
                                    WHEN AGE < 40 THEN '3'
                                    WHEN AGE < 50 THEN '4'
                                    WHEN AGE < 60 THEN '5'
                                    WHEN AGE < 70 THEN '6'
                                    ELSE '7' END) B
             WHERE A.COMN_GRP_CD = 'AGE_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '1' THEN 'PT_SILLM_CTG_1_GRP_CNT'
                        WHEN A.COMN_CD = '2' THEN 'PT_SILLM_CTG_2_GRP_CNT'
                        WHEN A.COMN_CD = '3' THEN 'PT_SILLM_CTG_3_GRP_CNT'
                        WHEN A.COMN_CD = '4' THEN 'PT_SILLM_CTG_4_GRP_CNT'
                        WHEN A.COMN_CD = '5' THEN 'PT_SILLM_CTG_5_GRP_CNT'
                        ELSE 'PT_SILLM_CTG_6_GRP_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN PT_SILLM_CTG_GRP_CD IS NULL THEN '-1'
                                WHEN PT_SILLM_CTG_GRP_CD = '1' THEN '1'
                                WHEN PT_SILLM_CTG_GRP_CD = '2' THEN '2'
                                WHEN PT_SILLM_CTG_GRP_CD = '3' THEN '3'
                                WHEN PT_SILLM_CTG_GRP_CD = '4' THEN '4'
                                WHEN PT_SILLM_CTG_GRP_CD = '5' THEN '5'
                                ELSE '6' END             AS COMN_CD
                              , COUNT(*)                 AS COUNT
                       FROM SILLM_DATA
                      GROUP BY CASE WHEN PT_SILLM_CTG_GRP_CD IS NULL THEN '-1'
                                    WHEN PT_SILLM_CTG_GRP_CD = '1' THEN '1'
                                    WHEN PT_SILLM_CTG_GRP_CD = '2' THEN '2'
                                    WHEN PT_SILLM_CTG_GRP_CD = '3' THEN '3'
                                    WHEN PT_SILLM_CTG_GRP_CD = '4' THEN '4'
                                    WHEN PT_SILLM_CTG_GRP_CD = '5' THEN '5'
                                    ELSE '6' END ) B
             WHERE A.COMN_GRP_CD = 'PT_SILLM_CTG_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT A.COMN_GRP_CD            AS COMN_GRP_CD
                 , A.COMN_CD                AS COMN_CD
                 , A.COMN_CD_NM             AS COMN_CD_NM
                 , CASE WHEN A.COMN_CD = '10' THEN 'APCS_SUM_10_SCR_BLW_CNT'
                        WHEN A.COMN_CD = '20' THEN 'APCS_SUM_20_SCR_CNT'
                        WHEN A.COMN_CD = '30' THEN 'APCS_SUM_30_SCR_CNT'
                        WHEN A.COMN_CD = '40' THEN 'APCS_SUM_40_SCR_CNT'
                        WHEN A.COMN_CD = '50' THEN 'APCS_SUM_50_SCR_CNT'
                        WHEN A.COMN_CD = '60' THEN 'APCS_SUM_60_SCR_CNT'
                        WHEN A.COMN_CD = '70' THEN 'APCS_SUM_70_SCR_CNT'
                        ELSE 'APCS_SUM_80_SCR_UPR_CNT' END AS COMN_CD_EXPL
                 , NVL(TO_CHAR(B.COUNT), 0) AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM CHARTGUB A
                 , (SELECT CASE WHEN APCS_SUM_SCR IS NULL THEN '-1'
                                WHEN APCS_SUM_SCR < 20 THEN '10'
                                WHEN APCS_SUM_SCR < 30 THEN '20'
                                WHEN APCS_SUM_SCR < 40 THEN '30'
                                WHEN APCS_SUM_SCR < 50 THEN '40'
                                WHEN APCS_SUM_SCR < 60 THEN '50'
                                WHEN APCS_SUM_SCR < 70 THEN '60'
                                WHEN APCS_SUM_SCR < 80 THEN '70'
                                ELSE '80' END             AS COMN_CD
                              , COUNT(*)                  AS COUNT
                       FROM (SELECT APCS_SUM_SCR
                               FROM DIE_DATA
                              WHERE APCS_SUM_SCR IS NOT NULL)
                       GROUP BY CASE WHEN APCS_SUM_SCR IS NULL THEN '-1'
                                     WHEN APCS_SUM_SCR < 20 THEN '10'
                                     WHEN APCS_SUM_SCR < 30 THEN '20'
                                     WHEN APCS_SUM_SCR < 40 THEN '30'
                                     WHEN APCS_SUM_SCR < 50 THEN '40'
                                     WHEN APCS_SUM_SCR < 60 THEN '50'
                                     WHEN APCS_SUM_SCR < 70 THEN '60'
                                     WHEN APCS_SUM_SCR < 80 THEN '70'
                                     ELSE '80' END ) B
             WHERE A.COMN_GRP_CD = 'APCS_SUM_SCR_GRP'
               AND A.COMN_CD = B.COMN_CD(+)
            
            UNION ALL
            
            SELECT 'BY_DEPT'                   AS COMN_GRP_CD
                 , A.RPRN_MED_DEPT_CD          AS COMN_CD
                 , A.RPRN_MED_DEPT_CD_NM       AS COMN_CD_NM
                 , '진료과별 사망환자'              AS COMN_CD_EXPL
                 , TO_CHAR(COUNT(*))           AS DTRL1_NM
                 , NULL AS DTRL2_NM
                 , NULL AS DTRL3_NM
              FROM DIE_DATA A
             GROUP BY A.RPRN_MED_DEPT_CD, A.RPRN_MED_DEPT_CD_NM
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'BF_YEAR' AS COMN_CD
                 , '전년월평균'   AS COMN_CD_NM
                 , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(CEIL(SUM(DIE_CNT) / COUNT(*)))  AS DTRL1_NM
                 , TO_CHAR(CEIL(SUM(OUT_CNT) / COUNT(*)))  AS DTRL2_NM
                 , TO_CHAR(ROUND(SUM(DTH_RATE) / COUNT(*), 2)) AS DTRL3_NM
              FROM (
                    SELECT DTM
                         , DIE_CNT
                         , OUT_CNT
                         , DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2)) AS DTH_RATE
                      FROM (
                            SELECT A.DTM
                                 , NVL(SUM(DECODE(B.ICU_CHOT_PLC_TP_CD, '06', B.CNT, '07', B.CNT, 0)), 0) AS DIE_CNT
                                 , NVL(SUM(B.CNT), 0) AS OUT_CNT
                              FROM BF_YEAR A
                                 , (
                                    SELECT X.DTM                AS DTM
                                         , Y.ICU_CHOT_PLC_TP_CD AS ICU_CHOT_PLC_TP_CD
                                         , COUNT(*) AS CNT
                                      FROM BF_YEAR X --년간추이공통코드
                                         , DIE_DATA_FOR_ANNU Y
                                     WHERE X.DTM = TO_CHAR(Y.CHOT_DTM, 'YYYY-MM')
                                     GROUP BY X.DTM, Y.ICU_CHOT_PLC_TP_CD
                                   ) B
                             WHERE A.DTM = B.DTM(+)
                             GROUP BY A.DTM
                             ORDER BY A.DTM
                           )
                   )
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'CUR_YEAR' AS COMN_CD
                 , '당년월평균'   AS COMN_CD_NM
                 , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(CEIL(SUM(DIE_CNT) / COUNT(*)))  AS DTRL1_NM
                 , TO_CHAR(CEIL(SUM(OUT_CNT) / COUNT(*)))  AS DTRL2_NM
                 , TO_CHAR(ROUND(SUM(DTH_RATE) / COUNT(*), 2)) AS DTRL3_NM
              FROM (
                    SELECT DTM
                         , DIE_CNT
                         , OUT_CNT
                         , DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2)) AS DTH_RATE
                      FROM (
                            SELECT A.DTM
                                 , NVL(SUM(DECODE(B.ICU_CHOT_PLC_TP_CD, '06', B.CNT, '07', B.CNT, 0)), 0) AS DIE_CNT
                                 , NVL(SUM(B.CNT), 0) AS OUT_CNT
                              FROM CUR_YEAR A
                                 , (
                                    SELECT X.DTM                AS DTM
                                         , Y.ICU_CHOT_PLC_TP_CD AS ICU_CHOT_PLC_TP_CD
                                         , COUNT(*) AS CNT
                                      FROM CUR_YEAR X --년간추이공통코드
                                         , DIE_DATA_FOR_ANNU Y
                                     WHERE X.DTM = TO_CHAR(Y.CHOT_DTM, 'YYYY-MM')
                                     GROUP BY X.DTM, Y.ICU_CHOT_PLC_TP_CD
                                   ) B
                             WHERE A.DTM = B.DTM(+)
                             GROUP BY A.DTM
                             ORDER BY A.DTM
                           )
                   )
            
            UNION ALL
            
            SELECT 'ANNU_AVG' AS COMN_GRP_CD
                 , 'BF_MON' AS COMN_CD
                 , '전년당월' AS COMN_CD_NM
                 , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(DIE_CNT) AS DTRL1_NM
                 , TO_CHAR(OUT_CNT) AS DTRL2_NM
                 , TO_CHAR(DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2))) AS DTRL3_NM
              FROM (
                    SELECT NVL(SUM(DECODE(A.ICU_CHOT_PLC_TP_CD, '06', A.CNT, '07', A.CNT, 0)), 0) AS DIE_CNT
                         , NVL(SUM(A.CNT), 0) AS OUT_CNT
                      FROM (
                            SELECT X.ICU_CHOT_PLC_TP_CD AS ICU_CHOT_PLC_TP_CD
                                 , COUNT(*) AS CNT
                              FROM DIE_DATA_FOR_ANNU X
                             WHERE TO_CHAR(X.CHOT_DTM, 'YYYY-MM') = TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM')
                             GROUP BY X.ICU_CHOT_PLC_TP_CD
                           ) A
                   )
            
            UNION ALL
            
            SELECT 'ANNU_TREND' AS COMN_GRP_CD
                 , DTM AS COMN_CD
                 , DTM AS COMN_CD_NM
                 , '사망환자/사망률 년간추이' AS COMN_CD_EXPL
                 , TO_CHAR(DIE_CNT) AS DTRL1_NM
                 , TO_CHAR(OUT_CNT) AS DTRL2_NM
                 , TO_CHAR(DECODE(OUT_CNT, 0, 0, ROUND((DIE_CNT / OUT_CNT) * 100, 2))) AS DTRL3_NM
              FROM (
                    SELECT A.DTM
                         , NVL(SUM(DECODE(B.ICU_CHOT_PLC_TP_CD, '06', B.CNT, '07', B.CNT, 0)), 0) AS DIE_CNT
                         , NVL(SUM(B.CNT), 0) AS OUT_CNT
                      FROM MONTHGUB A
                         , (
                            SELECT X.DTM                AS DTM
                                 , Y.ICU_CHOT_PLC_TP_CD AS ICU_CHOT_PLC_TP_CD
                                 , COUNT(*) AS CNT
                              FROM MONTHGUB X --년간추이공통코드
                                 , DIE_DATA_FOR_ANNU Y
                             WHERE X.DTM = TO_CHAR(Y.CHOT_DTM, 'YYYY-MM')
                             GROUP BY X.DTM, Y.ICU_CHOT_PLC_TP_CD
                           ) B
                     WHERE A.DTM = B.DTM(+)
                     GROUP BY A.DTM
                     ORDER BY A.DTM
                   )
            
             ORDER BY COMN_GRP_CD, COMN_CD
        ;    
    END;
END PC_EICU_STATISTIC_MORTALITY;
