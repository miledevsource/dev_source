
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_INFO_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
                          , IN_SEARCH_INFO      IN  VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : IF_PT_INFO_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 환자 조회
*    Change History : 2025.07.16, 장인수, 최초작성
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
											SELECT
									    C.HSP_TP_CD
									  , (SELECT COMN_CD_NM
									       FROM CCCCCSTE
									      WHERE COMN_GRP_CD = '101'
									        AND COMN_CD = C.HSP_TP_CD ) HSP_NM
									  , A.PT_NM
									  , C.PT_NO
									  , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									  , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									  , A.SEX_TP_CD
									  , C.MED_DEPT_CD DEPT_CD
									  , (SELECT DEPT_NM
									       FROM PDEDBMSM
									      WHERE DEPT_CD = C.MED_DEPT_CD
									        AND HSP_TP_CD = C.HSP_TP_CD ) DEPT_NM
            , C.PACT_ID
									FROM PCTPCPAM_DAMO A
									   , ACPPRETM C
									WHERE A.PT_NO     = c.PT_NO
									  AND C.SIHS_YN   = 'Y'
									  AND C.APCN_YN   = 'N'
									  AND ( IN_SEARCH_INFO = A.PT_NM OR IN_SEARCH_INFO = C.PT_NO ) 
--									  AND C.HSP_TP_CD = IN_HSP_TP_CD
									  AND C.HSP_TP_CD = '01'

  UNION ALL
              SELECT     A.HSP_TP_CD
									  , (SELECT COMN_CD_NM
									       FROM CCCCCSTE
									      WHERE COMN_GRP_CD = '101'
									        AND COMN_CD = A.HSP_TP_CD ) HSP_NM
									  , B.PT_NM								 
									  , A.PT_NO
									  , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									  , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									  , B.SEX_TP_CD
									  , A.MED_DEPT_CD DEPT_CD
									  , (SELECT DEPT_NM
									       FROM PDEDBMSM
									      WHERE DEPT_CD = A.MED_DEPT_CD
									        AND HSP_TP_CD = A.HSP_TP_CD ) DEPT_NM 
									  , A.PACT_ID
			 FROM ACPPRAAM A
       , PCTPCPAM_DAMO B
			WHERE 1=1
     AND A.SIHS_YN = 'Y'
     AND A.APCN_YN    = 'N'
     AND A.PT_NO = B.PT_NO
				 AND A.TWRM_WD_DEPT_CD IN ('CICU','NICU','DICU','MICU','EICU','NCU','OICU','EICU2')
--     AND C.HSP_TP_CD = IN_HSP_TP_CD
				 AND A.HSP_TP_CD = '01'
				 AND ( IN_SEARCH_INFO = B.PT_NM OR IN_SEARCH_INFO = A.PT_NO );



END IF_PT_INFO_SEL;
