
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."CSLT_PRGR_UPD" (
    IN_HSP_TP_CD        IN  VARCHAR2,  
    IN_PT_NO            IN  VARCHAR2,
    IN_PACT_ID          IN  VARCHAR2,
    IN_TRNF_PRGR_STS_CD  IN VARCHAR2,
    IN_CONSULT_REQ_DT    IN  DATE, 
    IN_LSH_DTM           IN  DATE,
    IN_LSH_PRGM_NM       IN VARCHAR2,   
    IN_SEQ               IN NUMBER,
    OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
/**********************************************************************************************
*    SERVICENAME    : PC_PT_TRNF_INS
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송환자 ezOntheCall 실행 및 상태값 변경 
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
BEGIN
     IS_SUCCESS := 'Y';
     ERROR_MSG := '';
    BEGIN
       UPDATE ARPA_PT_LIST
          SET CO_TREAT_PROGRESS_DT = IN_CONSULT_REQ_DT
        	  , TRNF_PRGR_STS_CD  = IN_TRNF_PRGR_STS_CD
            , LSH_DTM = IN_LSH_DTM
            , LSH_PRGM_NM = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ =  IN_SEQ
       AND PT_NO = IN_PT_NO
       AND PACT_ID = IN_PACT_ID;

       EXCEPTION
       WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;
    END;



    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

END;
