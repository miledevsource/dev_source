
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_COM_DTALK_SEND" (
    -- 01~22 모든 컬럼을 인자화 (KO_SEQ은 OUT으로 반환)
    IN_KO_MT_REFKEY       IN  VARCHAR2,      -- 01. 부서코드(참조용필드)
    IN_KO_DATE_CLIENT_REQ IN  VARCHAR2,      -- 02. 전송예약시간 'YYYY-MM-DD HH24:MI:SS'
    IN_KO_SUBJECT         IN  VARCHAR2,      -- 03. 메시지 제목(환자번호 등)
    IN_KO_CALLBACK        IN  VARCHAR2,      -- 04. 발신자 전화번호
    IN_KO_TEMPLATE_CODE   IN  VARCHAR2,      -- 05. 템플릿 코드
    IN_KO_CONTENT         IN  VARCHAR2,          -- 06. 전송메세지(장문 가능)
    IN_KO_RECIPIENT_NUM   IN  VARCHAR2,      -- 07. 수신자 전화번호
    IN_KO_SMCONTENT       IN  VARCHAR2,      -- 08. 문자 재처리시 사용하는 메시지
    IN_KO_KKO_BTN_TYPE    IN  VARCHAR2,      -- 09. 카카오 버튼타입
    IN_KO_KKO_BTN_INFO    IN  VARCHAR2,          -- 10. 버튼템플릿 정보(JSON 등)
    IN_KO_USER_ID         IN  VARCHAR2,      -- 11. 발송자 사번
    IN_KO_ORD_ID          IN  VARCHAR2,      -- 12. ORD_ID
    IN_KO_PT_NM           IN  VARCHAR2,      -- 13. 환자명
    IN_KO_ETC_TEXT_1      IN  VARCHAR2,      -- 14. 유저 기타필드1
    IN_KO_ETC_TEXT_2      IN  VARCHAR2,      -- 15. 유저 기타필드2
    IN_KO_ETC_TEXT_3      IN  VARCHAR2,      -- 16. 유저 기타필드3
    IN_KO_ETC_NUM_1       IN  NUMBER,        -- 17. 예비 숫자1(버튼 템플릿 등)
    IN_KO_ETC_NUM_2       IN  NUMBER,        -- 18. 예비 숫자2
    IN_KO_ETC_NUM_3       IN  NUMBER,        -- 19. 예비 숫자3
    IN_KO_SEQ       	 	  IN  NUMBER,
    OUT_CURSOR            OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000);
    V_RESULT VARCHAR2(1000);
/**********************************************************************************************
*    SERVICENAME    : PC_COM_DTALK_SEND
*    CREATEDATE     : 2025.11.10
*    Author         : 윤재림
*    Description    : EICU 환자이송시스템 환자등록 알림톡
*    Change History :
**********************************************************************************************/
BEGIN
    BEGIN


          INSERT INTO ATA_MMT_TRAN (
            KO_MT_REFKEY,
            KO_DATE_CLIENT_REQ,
            KO_SUBJECT,
            KO_CALLBACK,
            KO_TEMPLATE_CODE,
            KO_CONTENT,
            KO_RECIPIENT_NUM,
            KO_SMCONTENT,
            KO_KKO_BTN_TYPE,
            KO_KKO_BTN_INFO,
            KO_USER_ID,
            KO_ORD_ID,
            KO_PT_NM,
            KO_ETC_TEXT_1,
            KO_ETC_TEXT_2,
            KO_ETC_TEXT_3,
            KO_ETC_NUM_1,
            KO_ETC_NUM_2,
            KO_ETC_NUM_3,
            KO_SEQ
        ) VALUES (
            IN_KO_MT_REFKEY,
            TO_DATE(IN_KO_DATE_CLIENT_REQ,'YYYY-MM-DD HH24:MI:SS'),
            IN_KO_SUBJECT,
            IN_KO_CALLBACK,
            IN_KO_TEMPLATE_CODE,
            IN_KO_CONTENT,
            IN_KO_RECIPIENT_NUM,
            IN_KO_SMCONTENT,
            IN_KO_KKO_BTN_TYPE,
            IN_KO_KKO_BTN_INFO,
            IN_KO_USER_ID,
            IN_KO_ORD_ID,
            IN_KO_PT_NM,
            IN_KO_ETC_TEXT_1,
            IN_KO_ETC_TEXT_2,
            IN_KO_ETC_TEXT_3,
            IN_KO_ETC_NUM_1,
            IN_KO_ETC_NUM_2,
            IN_KO_ETC_NUM_3,
            IN_KO_SEQ
        );


  		   	 IS_SUCCESS := 'Y';
			 ERROR_MSG  := '';  -- 성공일 때는 메시지 없음


        EXCEPTION
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;

    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;

END;
