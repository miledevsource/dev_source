
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_SUMMARY_READM" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_SUMMARY_READM
*    CREATEDATE     : 2021.03.08
*    Author         : 신솔
*    Description    : 중환자실별 재입실 현황 요약정보
*    Change History : 2021.03.08, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT B.DEPT_CD                           AS WD_DEPT_CD
                 , TO_CHAR(NVL(A.RPT_ETRM_PT_CNT, 0))  AS DTRL1_NM
                 , TO_CHAR(NVL(A.CHOT_PT_CNT, 0))      AS DTRL2_NM
                 , RTRIM(TO_CHAR(DECODE(NVL(A.CHOT_PT_CNT, 0), 0, 0, ROUND((NVL(A.RPT_ETRM_PT_CNT, 0) / NVL(A.CHOT_PT_CNT, 0)) * 100, 1)), 'FM9990.9'), '.') || '%' AS DTRL3_NM
                 , NVL(A.RPT_ETRM_24_TM_IN_CNT, 0)     AS RPT_ETRM_24_TM_IN_CNT
                 , NVL(A.RPT_ETRM_48_TM_IN_CNT, 0)     AS RPT_ETRM_48_TM_IN_CNT
                 , NVL(A.RPT_ETRM_72_TM_IN_CNT, 0)     AS RPT_ETRM_72_TM_IN_CNT
                 , NVL(A.RPT_ETRM_72_TM_EXCS_CNT, 0)   AS RPT_ETRM_72_TM_EXCS_CNT
              FROM (SELECT X.WD_DEPT_CD
                         , X.RPT_ETRM_PT_CNT
                         , Y.CHOT_PT_CNT
                         , X.RPT_ETRM_24_TM_IN_CNT
                         , X.RPT_ETRM_48_TM_IN_CNT
                         , X.RPT_ETRM_72_TM_IN_CNT
                         , X.RPT_ETRM_72_TM_EXCS_CNT
                      FROM (SELECT R.WD_DEPT_CD           AS WD_DEPT_CD
                                 , SUM(R.RPT_ETRM_PT_CNT) AS RPT_ETRM_PT_CNT
                                 , SUM(R.RPT_ETRM_24_TM_IN_CNT)   AS RPT_ETRM_24_TM_IN_CNT
                                 , SUM(R.RPT_ETRM_48_TM_IN_CNT)   AS RPT_ETRM_48_TM_IN_CNT
                                 , SUM(R.RPT_ETRM_72_TM_IN_CNT)   AS RPT_ETRM_72_TM_IN_CNT
                                 , SUM(R.RPT_ETRM_72_TM_EXCS_CNT) AS RPT_ETRM_72_TM_EXCS_CNT
                              FROM HICU.UCCICSRM R
                             WHERE R.TH2_ETRM_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                               AND R.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                             GROUP BY R.WD_DEPT_CD
                           ) X
                         , (SELECT O.WD_DEPT_CD       AS WD_DEPT_CD
                                 , SUM(O.CHOT_PT_CNT) AS CHOT_PT_CNT
                              FROM HICU.UCCICSOD O
                             WHERE O.CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                               AND O.HSP_TP_CD   = IN_HIS_HSP_TP_CD
                             GROUP BY O.WD_DEPT_CD
                           ) Y
                     WHERE X.WD_DEPT_CD = Y.WD_DEPT_CD
                   ) A
                 , HICU.UCCOCDPM B
             WHERE A.WD_DEPT_CD(+) = B.DEPT_CD
               AND B.HSP_TP_CD = IN_HIS_HSP_TP_CD
             ORDER BY B.SORT_SEQ
        ;    
    END;
END PC_EICU_CENTER_SUMMARY_READM;
