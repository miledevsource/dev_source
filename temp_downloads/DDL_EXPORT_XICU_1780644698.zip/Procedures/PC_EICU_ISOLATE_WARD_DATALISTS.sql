
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ISOLATE_WARD_DATALISTS" 
                                                    (   IN_FROM_DTE                     IN DATE 
                                                      , IN_TO_DTE                       IN DATE 
                                                      , IN_WD_DEPT_CD                   IN VARCHAR2   
                                                      , IN_HSP_TP_CD                    IN VARCHAR2
                                                      , IN_SEX_TP_CD                    IN VARCHAR2 
                                                      , IN_PT_SILLM_CTG_GRP_CD          IN VARCHAR2 
                                                      , OUT_CURSOR                      OUT SYS_REFCURSOR 
                                                    )
IS                                                   
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ISOLATE_PAT_STATICS                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표>>격리병동현황 상세조회
*    Change History : 2021.03.15                                                
**********************************************************************************************/
BEGIN 
     BEGIN   
          OPEN OUT_CURSOR FOR 
               WITH SDATA AS(
				               SELECT Z.PT_NO       				               
				                    , Z.PACT_ID
				                    , Z.EMRG_PACT_ID  				               
				                    , Z.HSP_TP_CD
				                    , SUBSTR(PT_NM, 1, 1) || '*' || SUBSTR(PT_NM, 3)     AS PT_NM  
				                    , Z.SEX_TP_CD
				                    , AGE_MRK_NM       AS  PT_AGE
				                    , Z.ADS_DT
				                    , Z.ETRM_DTM
				                    , Z.CHOT_DTM
				                    , Z.MED_DEPT_CD_NM
				                    , CASE WHEN Z.CHOT_DTM = TO_DATE('9999-12-31', 'YYYY-MM-DD') THEN '재실 중'
				                           ELSE TO_CHAR(NVL(TRUNC(NVL(z.CHOT_DTM, SYSDATE)) - TRUNC(NVL(z.ETRM_DTM, SYSDATE))  + 1, 0)) END STAY_DAY
				                    , B.PT_SILLM_CTG_GRP_CD
				                    , B.PT_SILLM_CTG_GRP_CD_NM
				                    , B.PT_SILLM_CTG_DTM
				                    , Z.INFC_MCB_TP_CD 
				                 FROM (SELECT PT_NO
                                            , PACT_ID
                                            , EMRG_PACT_ID
                                            , HSP_TP_CD
                                            , PT_NM
                                            , SEX_TP_CD
                                            , AGE_MRK_NM
                                            , ADS_DT
                                            , ETRM_DTM
                                            , CHOT_DTM
                                            , MED_DEPT_CD_NM
                                            , INFC_MCB_TP_CD
                                            , (SELECT MAX(PT_SILLM_CTG_DTM)
                                                 FROM HICU.UICIISPD X
                                                WHERE X.PACT_ID = A.PACT_ID AND X.PT_SILLM_CTG_DTM BETWEEN ETRM_DTM AND DECODE(CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),CHOT_DTM)) MAX_CHG_DTM
                                         FROM HICU.UICIISPM A
                                        WHERE HSP_TP_CD = '08'
                                          AND (ETRM_DTM BETWEEN  IN_FROM_DTE AND IN_TO_DTE  OR
          				                       DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),A.CHOT_DTM) BETWEEN IN_FROM_DTE AND IN_TO_DTE OR
			        	                      (A.ETRM_DTM < IN_FROM_DTE AND A.CHOT_DTM > IN_TO_DTE))) Z   --격리병동환자기본
				                     , HICU.UICIISPD B
                                 WHERE Z.HSP_TP_CD = B.HSP_TP_CD (+)
                                   AND Z.PACT_ID = B.PACT_ID     (+)
                                   AND Z.MAX_CHG_DTM = B.PT_SILLM_CTG_DTM (+)                                                                            
    	        )
				  SELECT PT_NO
				       , PT_NM
				       , SEX_TP_CD
				       , PT_AGE
				       , ADS_DT
				       , ETRM_DTM
				       , CHOT_DTM
				       , MED_DEPT_CD_NM
				       , STAY_DAY  
				       , PT_SILLM_CTG_GRP_CD
				       , PT_SILLM_CTG_GRP_CD_NM
				       , PT_SILLM_CTG_DTM
				       , (SELECT COMN_CD_NM 
				            FROM HICU.UCCOCSTE 
				           WHERE COMN_GRP_CD = 'IC015' 
				             AND USE_YN = 'Y' 
				             AND HSP_TP_CD = X.HSP_TP_CD 
				             AND COMN_CD = X.INFC_MCB_TP_CD) AS INFECTION_TYPE
                    FROM SDATA X
				   ORDER BY PT_NM, ETRM_DTM, PT_NO
								       ;
          
       END;
END PC_EICU_ISOLATE_WARD_DATALISTS;
