
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_MART_LAUNCHER" 
                          ( IN_SCHD_NAME IN VARCHAR2 /*스케쥴이름*/
                          , IN_HSP_TP_CD IN VARCHAR2 /*병원구분코드*/
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_LAUNCHER
*    CREATEDATE     : 2021.01.01
*    Author         : 이창우
*    Description    : 배치 실행
*    Change History : 2021.01.01, 이창우, 최초작성
**********************************************************************************************/
BEGIN
   DECLARE 
      V_SCHD_EXCT_ID VARCHAR2(22);
      V_WK_STR_DTM   DATE := SYSDATE;
      V_WK_STS_TP    VARCHAR2(1) := NULL;
      V_PRMR_STR_DTM DATE;
      V_PRMR_END_DTM DATE := SYSDATE;
      V_IO_ERRYN     VARCHAR2(10);
      V_IO_ERRMSG    VARCHAR2(4000);
   BEGIN
      SELECT (TO_CHAR(SYSDATE, 'YYYYMMDDHH24MI')|| dbms_random.string('U', 10)) AS SCHEDULE_EXEC_ID 
        INTO V_SCHD_EXCT_ID
        FROM DUAL;

      SELECT NVL(MAX(M1.SCHD_WK_STS_TP), 'F')
        INTO V_WK_STS_TP 
        FROM HICU.UCCOBELM M1
       WHERE M1.SCHD_NM = IN_SCHD_NAME
         AND M1.SCHD_WK_STR_DTM = (SELECT MAX(S1.SCHD_WK_STR_DTM)
                                     FROM HICU.UCCOBELM S1
                                    WHERE S1.SCHD_NM = M1.SCHD_NM
                                  );

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'MAKE-SCHD_EXCT_ID', V_WK_STS_TP);

      IF V_WK_STS_TP = 'N' THEN
         RETURN;
      END IF;

      SELECT NVL(MAX(PRMR_END_DTM), SYSDATE - (5/(24*60)))
        INTO V_PRMR_STR_DTM
        FROM HICU.UCCOBELM
       WHERE SCHD_NM = IN_SCHD_NAME
         AND SCHD_WK_STS_TP = 'Y';

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'EXECUTE-BEFORE', V_PRMR_STR_DTM);
      
      INSERT INTO HICU.UCCOBELM 
                ( SCHD_EXCT_ID
                , SCHD_NM
                , SCHD_WK_STR_DTM
                , SCHD_WK_END_DTM
                , SCHD_WK_STS_TP 
                , PRMR_STR_DTM 
                , PRMR_END_DTM
                )
         VALUES ( V_SCHD_EXCT_ID
                , IN_SCHD_NAME
                , V_WK_STR_DTM
                , NULL
                , 'N'
                , V_PRMR_STR_DTM
                , V_PRMR_END_DTM
                );
      COMMIT;
----------------------------------------------------
--실행 Procedure 시작
-- 전달 기본 파라미터 
-- V_PRMR_STR_DTM : 조회 시작 시간
-- V_PRMR_END_DTM   : 조회 종료 시간
----------------------------------------------------

   IF IN_SCHD_NAME = 'PC_EICU_BATCH_READMISSION' THEN
      /*중환자실 재입실 현황 데이터 배치*/
      XICU.PC_EICU_BATCH_READMISSION(V_PRMR_STR_DTM, V_PRMR_END_DTM, IN_HSP_TP_CD, V_IO_ERRYN, V_IO_ERRMSG);
   END IF;

   IF IN_SCHD_NAME = 'PC_EICU_BATCH_MORTALITY' THEN
      /*중환자실 사망률 데이터 배치*/
      XICU.PC_EICU_BATCH_MORTALITY(V_PRMR_STR_DTM, V_PRMR_END_DTM, IN_HSP_TP_CD, V_IO_ERRYN, V_IO_ERRMSG);
   END IF;

   IF IN_SCHD_NAME = 'PC_EICU_BATCH_PT' THEN
      /*중환자실환자지표기본 중환자실환자중증도분류정보 운영*/
      XICU.PC_EICU_BATCH_PT(V_PRMR_STR_DTM, V_PRMR_END_DTM, IN_HSP_TP_CD, V_IO_ERRYN, V_IO_ERRMSG);
   END IF;
   
   IF IN_SCHD_NAME = 'PC_EICU_LD_UICIWBCD_BATCH' THEN          
      /*일자별로 병동별 운영병상  운영*/ 
      XICU.PC_EICU_LD_UICIWBCD_BATCH(IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM,  V_IO_ERRYN, V_IO_ERRMSG);
   END IF;    
   
   IF IN_SCHD_NAME = 'PC_EICU_LD_ISOLATE_BATCH' THEN
      /*국가지정병상현황 운영*/                    
      XICU.PC_EICU_LD_ISOLATE_BATCH(V_SCHD_EXCT_ID, IN_HSP_TP_CD, V_PRMR_STR_DTM, V_PRMR_END_DTM);
   END IF;

----------------------------------------------------
--실행 Procedure 종료
----------------------------------------------------
      UPDATE HICU.UCCOBELM 
         SET SCHD_WK_STS_TP    = 'Y'
           , SCHD_WK_END_DTM   = SYSDATE
       WHERE SCHD_NM    = IN_SCHD_NAME
         AND SCHD_EXCT_ID = V_SCHD_EXCT_ID;

XICU.PC_EICU_PCLOG(V_SCHD_EXCT_ID, 'EXCUTE-AFTER', 'END');

      COMMIT;
   END;
END PC_EICU_BATCH_MART_LAUNCHER;
