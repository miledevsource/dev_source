
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICIIRCD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTE       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICIIRCD_SAVE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : ODS_UICIIRCD(타과의뢰회신정보)데이터 적재
*    Change History : 2021.03.15                                                
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    BEGIN        
	     MERGE INTO HICU.UICIIRCD A  --타과의뢰회신정보
	     USING (
	                SELECT MDRC_ID
	                     , PACT_ID
	                     , PT_NO
	                     , HME_DT
	                     , CTH_CLS_CD
	                     , ODRER_DT
	                     , ODRER_DTM
	                     , ODRER_DIAG
	                     , ODRER_CONTENTS
	                     , ODRER_DEPT_CD
	                     , ODRER_MEDR_STF_NO
	                     , ODRER_MDRC_DC_TP_CD
	                     , ODRPY_MDRC_ID
	                     , RPLY_DT
	                     , RPLY_DTM
	                     , RPLY_CONTENTS 
	                     , RPLY_DEPT_CD
	                     , RPLY_DEPT_NM        --회신부서명 추가 21/04/08 한가혜 
	                     , RPLY_MEDR_STF_NO
	                     , RPLY_MEDR_STF_NM    --회신의명 추가 21/04/08 한가혜 
	                     , RPLY_YN
	                     , ODRER_REQ_TIME
	                     , ODRER_REP_CRE_DTM
	                     , ODRER_SICU_YN
	                     , ODRER_DOW
	                     , WEEKDAY_YN
	                     , RCV_DEPT_CD
	                     , RCV_MEDR_STF_NO
	                     , ODRER_PT_CLCTN_NM
	                     , EMRG_YN
	                     , LST_RPLY_MEDR_STF_NO
	                     , RPLY_MEDR_STF_NO_GUBN
	                     , CNT
	                     , APCN_YN
	                     , NONFACE_CONSULT_YN
	                     , FSR_DTM
	                     , LSH_DTM
	                  FROM XICU.EMEI015V
	                 WHERE CTH_CLS_CD = 'I') B
	        ON (A.MDRC_ID = B.MDRC_ID)
	      WHEN MATCHED THEN
	      UPDATE SET A.PACT_ID               = B.PACT_ID
		           , A.PT_NO                 = B.PT_NO
		           , A.HME_DT                = B.HME_DT
		           , A.CTH_CLS_CD            = B.CTH_CLS_CD
		           , A.ODRER_DT              = B.ODRER_DT
		           , A.ODRER_DTM             = B.ODRER_DTM
		           , A.ODRER_DIAG            = B.ODRER_DIAG
		           , A.ODRER_CONTENTS        = B.ODRER_CONTENTS
		           , A.ODRER_DEPT_CD         = B.ODRER_DEPT_CD
		           , A.ODRER_MEDR_STF_NO     = B.ODRER_MEDR_STF_NO
		           , A.ODRER_MDRC_DC_TP_CD   = B.ODRER_MDRC_DC_TP_CD
		           , A.ODRPY_MDRC_ID         = B.ODRPY_MDRC_ID
		           , A.RPLY_DT               = B.RPLY_DT
		           , A.RPLY_DTM              = B.RPLY_DTM
		           , A.RPLY_CONTENTS         = B.RPLY_CONTENTS
		           , A.RPLY_DEPT_CD          = B.RPLY_DEPT_CD
		           , A.RPLY_MEDR_STF_NO      = B.RPLY_MEDR_STF_NO
		           , A.RPLY_YN               = B.RPLY_YN
		           , A.ODRER_REQ_TIME        = B.ODRER_REQ_TIME
		           , A.ODRER_REP_CRE_DTM     = B.ODRER_REP_CRE_DTM
		           , A.ODRER_SICU_YN         = B.ODRER_SICU_YN
		           , A.ODRER_DOW             = B.ODRER_DOW
		           , A.WEEKDAY_YN            = B.WEEKDAY_YN
		           , A.RCV_DEPT_CD           = B.RCV_DEPT_CD
		           , A.RCV_MEDR_STF_NO       = B.RCV_MEDR_STF_NO
		           , A.ODRER_PT_CLCTN_NM     = B.ODRER_PT_CLCTN_NM
		           , A.EMRG_YN               = B.EMRG_YN
		           , A.LST_RPLY_MEDR_STF_NO  = B.LST_RPLY_MEDR_STF_NO
		           , A.RPLY_MEDR_STF_NO_GUBN = B.RPLY_MEDR_STF_NO_GUBN
		           , A.CNT                   = B.CNT
		           , A.APCN_YN               = B.APCN_YN
		           , A.NONFACE_CONSULT_YN    = B.NONFACE_CONSULT_YN
		           , A.LSH_DTM               = SYSDATE
		           , A.LST_LOG_DTM           = SYSDATE
		           , A.RPLY_DEPT_NM	         = B.RPLY_DEPT_NM           --210409 한가혜 회신부서명 추가
                   , A.RPLY_MEDR_STF_NM	     = B.RPLY_MEDR_STF_NM       --210409 한가혜 회신의명 추가
	      WHEN NOT MATCHED THEN
	        INSERT (
			          A.MDRC_ID
			        , A.PACT_ID
			        , A.PT_NO
			        , A.HME_DT
			        , A.CTH_CLS_CD
			        , A.ODRER_DT
			        , A.ODRER_DTM
			        , A.ODRER_DIAG
			        , A.ODRER_CONTENTS
			        , A.ODRER_DEPT_CD
			        , A.ODRER_MEDR_STF_NO
			        , A.ODRER_MDRC_DC_TP_CD
			        , A.ODRPY_MDRC_ID
			        , A.RPLY_DT
			        , A.RPLY_DTM
			        , A.RPLY_CONTENTS
			        , A.RPLY_DEPT_CD
			        , A.RPLY_MEDR_STF_NO
			        , A.RPLY_YN
			        , A.ODRER_REQ_TIME
			        , A.ODRER_REP_CRE_DTM
			        , A.ODRER_SICU_YN
			        , A.ODRER_DOW
			        , A.WEEKDAY_YN
			        , A.RCV_DEPT_CD
			        , A.RCV_MEDR_STF_NO
			        , A.ODRER_PT_CLCTN_NM
			        , A.EMRG_YN
			        , A.LST_RPLY_MEDR_STF_NO
			        , A.RPLY_MEDR_STF_NO_GUBN
			        , A.CNT
			        , A.APCN_YN
			        , A.NONFACE_CONSULT_YN
			        , A.FSR_DTM
			        , A.LSH_DTM
			        , A.FST_LOD_DTM
			        , A.LST_LOG_DTM
			        , A.RPLY_DEPT_NM	                --210409 한가혜 회신부서명 추가
                    , A.RPLY_MEDR_STF_NM	            --210409 한가혜 회신의명 추가
                    )
	         VALUES
	         (
		              B.MDRC_ID
		            , B.PACT_ID
		            , B.PT_NO
		            , B.HME_DT
		            , B.CTH_CLS_CD
		            , B.ODRER_DT
		            , B.ODRER_DTM
		            , B.ODRER_DIAG
		            , B.ODRER_CONTENTS
		            , B.ODRER_DEPT_CD
		            , B.ODRER_MEDR_STF_NO
		            , B.ODRER_MDRC_DC_TP_CD
		            , B.ODRPY_MDRC_ID
		            , B.RPLY_DT
		            , B.RPLY_DTM
		            , B.RPLY_CONTENTS
		            , B.RPLY_DEPT_CD
		            , B.RPLY_MEDR_STF_NO
		            , B.RPLY_YN
		            , B.ODRER_REQ_TIME
		            , B.ODRER_REP_CRE_DTM
		            , B.ODRER_SICU_YN
		            , B.ODRER_DOW
		            , B.WEEKDAY_YN
		            , B.RCV_DEPT_CD
		            , B.RCV_MEDR_STF_NO
		            , B.ODRER_PT_CLCTN_NM
		            , B.EMRG_YN
		            , B.LST_RPLY_MEDR_STF_NO
		            , B.RPLY_MEDR_STF_NO_GUBN
		            , B.CNT
		            , B.APCN_YN
		            , B.NONFACE_CONSULT_YN
		            , B.FSR_DTM
		            , B.LSH_DTM
		            , SYSDATE
		            , SYSDATE
		            , B.RPLY_DEPT_NM           --210409 한가혜 회신부서명 추가
                    , B.RPLY_MEDR_STF_NM       --210409 한가혜 회신의명 추가
	            )
	      ;
	        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICIIRCD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICIIRCD_SAVE;
