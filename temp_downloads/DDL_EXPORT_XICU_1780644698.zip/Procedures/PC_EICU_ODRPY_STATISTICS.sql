
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODRPY_STATISTICS" (   
                                                        IN_RPLY_DT          IN DATE             --회신일자 
                                                      , IN_RPLY_DEPT_CD     IN VARCHAR2 
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODRPY_STATISTICS
*    CREATEDATE     : 2021.03.31
*    Author         : 한가혜
*    Description    : 통합관제 운영통계 타과회신시간 현황 지표 조회
*    Change History : 2021.03.31  
*    Change History : 2021.07-22 황선영 - 쿼리 수정 (시간 수정)
**********************************************************************************************/    

AS
    
BEGIN
      OPEN OUT_CURSOR FOR 
                          --정규 타과 회신
                          WITH MAIN AS (
                                          SELECT A.MDRC_ID
                                               , A.ODRER_DT       --의뢰일자 
                                               , A.RPLY_DEPT_CD
                                               , A.RPLY_DT        --회신일자 
                                               , A.RPLY_DTM
						                       , A.RPLY_DEPT_CD_NM               --210409 한가혜 회신부서명 추가 
											   , A.RPLY_YY
											   , A.RPLY_MM
						                       , A.RPLY_DY
                                               , A.ODRER_REQ_TIME
                                               , A.RPLY_YN	    --회신여부
                                               , A.WEEKDAY_YN     --평일여부
                                               , A.EMRG_YN        --응급여부
                                               , A.APCN_YN        --수진취소여부
                                               , A.NONFACE_CONSULT_YN     --비대면협진여부
                                               , CASE WHEN A.ODRER_REQ_TIME <= 6  THEN 'RPLY_IN_6TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 12 THEN 'RPLY_IN_12TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 24 THEN 'RPLY_IN_24TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 36 THEN 'RPLY_IN_36TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 48 THEN 'RPLY_IN_48TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 60 THEN 'RPLY_IN_60TM_CNT' 
            						             ELSE 'RPLY_EXCS_60TM_CNT' END                                                   AS ODRER_TM_TYPE
                                           FROM ( SELECT A.MDRC_ID
                                                       , A.ODRER_DT       --의뢰일자 
                                                       , A.RPLY_DEPT_CD
                                                       , A.RPLY_DT        --회신일자 
                                                       , A.RPLY_DTM
        						                       , A.RPLY_DEPT_NM             AS RPLY_DEPT_CD_NM               --210409 한가혜 회신부서명 추가 
        											   , TO_CHAR(A.RPLY_DT, 'YYYY') AS RPLY_YY
        											   , TO_CHAR(A.RPLY_DT, 'MM')   AS RPLY_MM
        						                       , TO_CHAR(A.RPLY_DT, 'DD')   AS RPLY_DY
                                                       , A.ODRER_REQ_TIME
                                                       , A.RPLY_YN	    --회신여부
                                                       , A.WEEKDAY_YN     --평일여부
                                                       , A.EMRG_YN        --응급여부
                                                       , A.APCN_YN        --수진취소여부
                                                       , A.NONFACE_CONSULT_YN     --비대면협진여부
                                                       , TRIM(SUBSTR(A.ODRER_PT_CLCTN_NM, 4, INSTR(A.ODRER_PT_CLCTN_NM, '실') - 5)) AS WD_DEPT_CD
                                                    FROM HICU.UICIIRCD A   --U121_UICI(ODS)_타과의뢰회신정보 
                                                   WHERE A.RPLY_DT       = IN_RPLY_DT
                                                     AND A.APCN_YN       = 'N'
                                                     AND A.RPLY_YN       = 'Y' 
                                                     AND A.RPLY_DEPT_CD  = IN_RPLY_DEPT_CD 
                                               ) A    --U121-ODS타과의뢰회신정보
                                               , HICU.UCCOCSTE B 
                                           WHERE B.COMN_GRP_CD   = 'IC504'
                                             AND B.HSP_TP_CD     = IN_HSP_TP_CD
                                             AND B.USE_YN        = 'Y'
                                             AND A.WD_DEPT_CD    = B.COMN_CD
                        ),
                        --비대면 타과 회신
                        UNTC_MAIN AS (
                                          SELECT A.MDRC_ID
                                               , A.ODRER_DT       --의뢰일자 
                                               , A.RPLY_DEPT_CD
                                               , A.RPLY_DT        --회신일자 
                                               , A.RPLY_DTM
						                       , A.RPLY_DEPT_CD_NM               --210409 한가혜 회신부서명 추가 
											   , A.RPLY_YY
											   , A.RPLY_MM
						                       , A.RPLY_DY
                                               , A.ODRER_REQ_TIME
                                               , A.RPLY_YN	    --회신여부
                                               , A.WEEKDAY_YN     --평일여부
                                               , A.EMRG_YN        --응급여부
                                               , A.APCN_YN        --수진취소여부
                                               , A.NONFACE_CONSULT_YN     --비대면협진여부
                                               , CASE WHEN A.ODRER_REQ_TIME <= 6  THEN 'UNTC_RPLY_IN_6TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 12 THEN 'UNTC_RPLY_IN_12TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 24 THEN 'UNTC_RPLY_IN_24TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 36 THEN 'UNTC_RPLY_IN_36TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 48 THEN 'UNTC_RPLY_IN_48TM_CNT'
            						                  WHEN A.ODRER_REQ_TIME <= 60 THEN 'UNTC_RPLY_IN_60TM_CNT'
            						             ELSE 'UNTC_RPLY_EXCS_60TM_CNT' END                                                   AS UNTC_ODRPY_TM_TYPE
                                            FROM ( SELECT A.MDRC_ID
                                                       , A.ODRER_DT       --의뢰일자 
                                                       , A.RPLY_DEPT_CD
                                                       , A.RPLY_DT        --회신일자 
                                                       , A.RPLY_DTM
        						                       , A.RPLY_DEPT_NM             AS RPLY_DEPT_CD_NM               --210409 한가혜 회신부서명 추가 
        											   , TO_CHAR(A.RPLY_DT, 'YYYY') AS RPLY_YY
        											   , TO_CHAR(A.RPLY_DT, 'MM')   AS RPLY_MM
        						                       , TO_CHAR(A.RPLY_DT, 'DD')   AS RPLY_DY
                                                       , A.ODRER_REQ_TIME
                                                       , A.RPLY_YN	    --회신여부
                                                       , A.WEEKDAY_YN     --평일여부
                                                       , A.EMRG_YN        --응급여부
                                                       , A.APCN_YN        --수진취소여부
                                                       , A.NONFACE_CONSULT_YN     --비대면협진여부
                                                       , TRIM(SUBSTR(A.ODRER_PT_CLCTN_NM, 4, INSTR(A.ODRER_PT_CLCTN_NM, '실') - 5)) AS WD_DEPT_CD
                                                    FROM HICU.UICIIRCD A   --U121_UICI(ODS)_타과의뢰회신정보 
                                                   WHERE A.RPLY_DT       = IN_RPLY_DT
                                                     AND A.APCN_YN       = 'N'
                                                     AND A.RPLY_YN       = 'Y'
                                                     AND A.NONFACE_CONSULT_YN = 'Y' 
                                                     AND A.RPLY_DEPT_CD       = IN_RPLY_DEPT_CD 
                                               ) A    --U121-ODS타과의뢰회신정보
                                               , HICU.UCCOCSTE B
                                           WHERE B.COMN_GRP_CD   = 'IC504'
                                             AND B.HSP_TP_CD     = IN_HSP_TP_CD
                                             AND B.USE_YN        = 'Y'
                                             AND A.WD_DEPT_CD    = B.COMN_CD
                        ),
                        BASE_TB AS (
            		                      SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                               , A.COMN_CD      AS COMN_CD
                                               , A.SEQ          AS SEQ
                                            FROM (   SELECT 'ODRPY_CRCCM'  AS COMN_GRP_CD
                                                          , 'RPLY_WHL_CNT' AS COMN_CD
                                                          , 1              AS SEQ 
                                                       FROM DUAL 
                                                  UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_REPLY_WHL_CNT', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'EMGR_RPLY_CNT', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'EMGR_UNTC_RPLY_CNT', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKDY_RPLY_WHL_TM_AVG', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKDY_UNTC_RPLY_WHL_TM_AVG', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKN_RPLY_WHL_TM_AVG', 1 FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKN_UNTC_RPLY_WHL_TM_AVG', 1 FROM DUAL
                                                  ) A
                                           ORDER BY A.COMN_GRP_CD, SEQ
                        ),
                        ODRPY_TM_TP_TB AS (
            		                      SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                               , A.COMN_CD      AS COMN_CD
                                               , A.SEQ          AS SEQ
                                            FROM (
                                                     SELECT 'ODRPY_TM_TYPE'    AS COMN_GRP_CD
                                                          , 'RPLY_IN_6TM_CNT'  AS COMN_CD
                                                          , 1                  AS SEQ
                                                       FROM DUAL 
                                                  UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_12TM_CNT', 2 FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_24TM_CNT', 3 FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_36TM_CNT', 4 FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_48TM_CNT', 5 FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_60TM_CNT', 6 FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_EXCS_60TM_CNT', 7 FROM DUAL 
                                                  ) A
                                           ORDER BY A.COMN_GRP_CD, SEQ
                        ),
                        UNTC_ODRPY_TP_TB AS (
            		                      SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                               , A.COMN_CD      AS COMN_CD
                                               , A.SEQ          AS SEQ
                                            FROM (
                                                     SELECT 'UNTC_ODRPY_TM_TYPE'    AS COMN_GRP_CD
                                                          , 'UNTC_RPLY_IN_6TM_CNT'  AS COMN_CD
                                                          , 1                  AS SEQ
                                                       FROM DUAL 
                                                  UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_IN_12TM_CNT', 2 FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_IN_24TM_CNT', 3 FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_IN_36TM_CNT', 4 FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_IN_48TM_CNT', 5 FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_IN_60TM_CNT', 6 FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'UNTC_RPLY_EXCS_60TM_CNT', 7 FROM DUAL
                                                  ) A
                                           ORDER BY A.COMN_GRP_CD, SEQ
                        )    
                            /********************
							* INDICATORS OUT DTO
							*********************/  

                            SELECT B.COMN_GRP_CD 
                                 , B.COMN_CD
                                 , NVL(A.CNT, 0) AS CNT
                              FROM (
                                        --정규 전체 회신 수
                                        SELECT 'RPLY_WHL_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                          FROM MAIN
                                         WHERE EMRG_YN = 'N'
                        
                                     UNION ALL 
                                     
                                       --정규 비대면 전체 회신 수
                                        SELECT 'UNTC_REPLY_WHL_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                          FROM UNTC_MAIN
                                         WHERE EMRG_YN = 'N'
                        
                                     UNION ALL
                                     
                                        --응급
                                       SELECT 'EMGR_RPLY_CNT' AS TITLE
                                            , COUNT(*) AS CNT
                                         FROM MAIN
                                        WHERE EMRG_YN = 'Y'
                        
                                    UNION ALL
                        
                                       SELECT 'EMGR_UNTC_RPLY_CNT' AS TITLE
                                             , COUNT(*) AS CNT
                                         FROM UNTC_MAIN
                                        WHERE EMRG_YN = 'Y'
                                       
                                    UNION ALL
                                    
                                        --평일
                                       SELECT 'WKDY_RPLY_WHL_TM_AVG' AS TITLE
                                            , ROUND(AVG(ODRER_REQ_TIME), 2) AS CNT
                                         FROM MAIN
                                        WHERE WEEKDAY_YN = 'Y'
                        
                                    UNION ALL
                        
                                       SELECT 'WKDY_UNTC_RPLY_WHL_TM_AVG' AS TITLE
                                             , ROUND(AVG(ODRER_REQ_TIME), 2) AS CNT
                                         FROM UNTC_MAIN
                                        WHERE WEEKDAY_YN = 'Y'
                        
                                    UNION ALL
                                   
                                        --주말
                                       SELECT 'WKN_RPLY_WHL_TM_AVG' AS TITLE
                                            , ROUND(AVG(ODRER_REQ_TIME), 2) AS CNT
                                         FROM MAIN
                                        WHERE WEEKDAY_YN = 'N'
                        
                                    UNION ALL
                        
                                       SELECT 'WKN_UNTC_RPLY_WHL_TM_AVG' AS TITLE
                                            , ROUND(AVG(ODRER_REQ_TIME), 2) AS CNT
                                         FROM UNTC_MAIN
                                        WHERE WEEKDAY_YN = 'N'
                                 ) A
                                 , BASE_TB B
                             WHERE B.COMN_CD = A.TITLE (+) 
                        
                         UNION ALL 
                         
                            SELECT X.COMN_GRP_CD
							     , X.COMN_CD
							     , SUM(X.CNT) OVER(PARTITION BY X.COMN_GRP_CD ORDER BY X.SEQ) AS CNT
                              FROM (SELECT B.COMN_GRP_CD 
                                         , B.COMN_CD
                                         , NVL(A.CNT, 0) AS CNT
                                         , B.SEQ
                                      FROM (
                                              --정규 시간별 전체 회신 수
                                                SELECT ODRER_TM_TYPE        AS TITLE
                                                     , COUNT(ODRER_TM_TYPE) AS CNT
                                                  FROM MAIN         
                                                 WHERE EMRG_YN = 'N'
                                              GROUP BY ODRER_TM_TYPE
                                         ) A
                                         , ODRPY_TM_TP_TB B
                                     WHERE B.COMN_CD = A.TITLE (+) 
                                     
                                 UNION ALL
                                    
                                    SELECT B.COMN_GRP_CD 
                                         , B.COMN_CD
                                         , NVL(A.CNT, 0) AS CNT
                                         , B.SEQ
                                      FROM (   
                                             --정규 비대면 시간별 전체 회신 수
                                                SELECT UNTC_ODRPY_TM_TYPE        AS TITLE
                                                     , COUNT(UNTC_ODRPY_TM_TYPE) AS CNT
                                                  FROM UNTC_MAIN 
                                                 WHERE EMRG_YN = 'N'
                                              GROUP BY UNTC_ODRPY_TM_TYPE
                                         ) A
                                         , UNTC_ODRPY_TP_TB B
                                     WHERE B.COMN_CD = A.TITLE (+)  
                                  ) X
                             
                          ORDER BY COMN_GRP_CD
                  ;       
        			           
  END PC_EICU_ODRPY_STATISTICS;
