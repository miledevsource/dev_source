
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_TRNF_INS" (
                             IN_VNDR              IN  VARCHAR2
                           , IN_CLNTIP            IN  VARCHAR2
                           , IN_USERID            IN  VARCHAR2
                           , IN_HSPTID            IN  VARCHAR2
																								   , IN_HSP_TP_CD         IN  VARCHAR2
																								   , IN_PT_NM             IN  VARCHAR2
																								   , IN_PT_NO             IN  VARCHAR2
																								   , IN_PACT_ID           IN  VARCHAR2
																								   , IN_TARGET_HSP_NM     IN  VARCHAR2
																								   , IN_TARGET_DEPT_NM    IN  VARCHAR2
																								   , IN_CO_TREAT_REASON   IN  VARCHAR2
																								   , IN_CO_TREAT_RMK      IN  VARCHAR2  
																								   , IN_TRNF_PRGR_STS_CD  IN  VARCHAR2  
																								   , IN_STATUS_STS_CD     IN  VARCHAR2
																								   , IN_CONSULT_REQ_DT    IN  VARCHAR2
																								   , IN_FSR_DTM           IN  VARCHAR2   
																								   , IN_FSR_IP_ADDR       IN  VARCHAR2
																								   , IN_FSR_STF_NO	       IN  VARCHAR2				
																								   , IN_FSR_STF_NM	       IN  VARCHAR2				
																								   , IN_FSR_PRGM_NM	      IN  VARCHAR2					
																								   , IN_LSH_DTM		         IN  VARCHAR2				
																								   , IN_LSH_IP_ADDR	      IN  VARCHAR2					
																								   , IN_LSH_STF_NO       	IN  VARCHAR2					
																								   , IN_LSH_STF_NM	       IN  VARCHAR2					
																								   , IN_LSH_PRGM_NM	      IN  VARCHAR2				
																								   , OUT_CURSOR           OUT SYS_REFCURSOR           
    

)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
    EXIST_CNT  NUMBER;
/**********************************************************************************************
*    SERVICENAME    : PC_PT_TRNF_INS
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송환자 등록
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
BEGIN

    SELECT COUNT(*)
      INTO EXIST_CNT
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID 
       AND STATUS_STS_CD = 'A';   -- ACTIVE 환자 (이송중) 
       
       
    IF EXIST_CNT > 0 THEN
        IS_SUCCESS := 'N';
        ERROR_MSG := '해당 환자는 이송요청 진행중인 환자입니다.';
    ELSE
        BEGIN
            INSERT INTO ARPA_PT_LIST (
                HSP_TP_CD
               , SEQ
               , PT_NM
               , PT_NO
               , PACT_ID
               , TARGET_HSP_NM
               , TARGET_DEPT_NM
               , CO_TREAT_REASON  
               , CO_TREAT_RMK
               , TRNF_PRGR_STS_CD
               , STATUS_STS_CD  
               , CONSULT_REQ_DT    
               , FSR_DTM
               , FSR_IP_ADDR
               , FSR_STF_NO
               , FSR_STF_NM
               , FSR_PRGM_NM 
               , LSH_DTM
               , LSH_IP_ADDR
               , LSH_STF_NO
               , LSH_STF_NM
               , LSH_PRGM_NM
            ) VALUES (
                IN_HSP_TP_CD
               , (SELECT NVL(MAX(SEQ), 0) + 1
												       FROM ARPA_PT_LIST
												      WHERE HSP_TP_CD = IN_HSP_TP_CD
												     )
               , IN_PT_NM
               , IN_PT_NO
               , IN_PACT_ID
               , IN_TARGET_HSP_NM
               , IN_TARGET_DEPT_NM
               , IN_CO_TREAT_REASON
               , IN_CO_TREAT_RMK
               , IN_TRNF_PRGR_STS_CD      
               , IN_STATUS_STS_CD  
               , TO_DATE(IN_CONSULT_REQ_DT, 'YYYY-MM-DD HH24:MI:SS')   
               , TO_DATE(IN_FSR_DTM, 'YYYY-MM-DD HH24:MI:SS')
               , IN_FSR_IP_ADDR
               , IN_FSR_STF_NO
               , IN_FSR_STF_NM
               , IN_FSR_PRGM_NM
               , TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
               , IN_LSH_IP_ADDR
               , IN_LSH_STF_NO
               , IN_LSH_STF_NM
               , IN_LSH_PRGM_NM
            );
            IS_SUCCESS := 'Y';
            ERROR_MSG := '';
        EXCEPTION
            WHEN OTHERS THEN
                IS_SUCCESS := 'N';
                ERROR_MSG := SQLERRM;
        END;
    END IF;

    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
