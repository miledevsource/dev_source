
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_RRS_STATISTICS" 
                                                    (   
                                                        IN_FROM_DTM         IN DATE 
                                                      , IN_TO_DTM           IN DATE 
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_RRS_STATISTICS
*    CREATEDATE     : 2021.03.30
*    Author         : 한가혜
*    Description    : 통합관제 운영통계 RRS 현황 지표 조회
*    Change History : 2021.03.30
**********************************************************************************************/    

AS
    
BEGIN
      OPEN OUT_CURSOR FOR 
					      WITH MAIN AS (
                        							           SELECT OCUR_DEPT_CD	            --발생부서코드(pk) <- 환자위치코드
                                                                    , OCUR_DT	                --발생일자(pk)
                                                                    , HSP_TP_CD	                --병원구분코드(pk)
                                                                    , OCUR_DEPT_CD_NM	        --발생부서코드명 <- 환자위치명
                                                                    , OCUR_YY	                --발생 년
                                                                    , OCUR_MM	                --발생 월
                                                                    , OCUR_DY	                --발생 일
                                                                    , WHL_PT_CNT	            --전체환자수
                                                                    , OCUR_PT_CNT	            --발생환자수
                                                                    , WHL_OCUR_CNT	            --전체발생건수
                                                                    , SBP_OCUR_CNT	            --SBP 발생건수
                                                                    , PR_OCUR_CNT	            --PR 발생건수
                                                                    , SPO2_OCUR_CNT	            --SpO2 발생건수
                                                                    , LOD_DTM	                --적재일시
                        							             FROM HICU.UCOSRRSD     --U113_UCOS(운영통계)_RRS Summary
                        							            WHERE TO_DATE(OCUR_YY || OCUR_MM || OCUR_DY, 'YYYY-MM-DD') BETWEEN TRUNC(IN_FROM_DTM)
                        							                                                                           AND TRUNC(IN_TO_DTM)
                        							              AND HSP_TP_CD     = IN_HSP_TP_CD 
							           ),
							           SUM_DATA AS (
                    							               SELECT SUM(1)                            AS SUM_DAY_CNT
                    							                    , SUM(A.WHL_PT_CNT)	                AS WHL_PT_CNT--전체환자수
                                                                    , SUM(A.OCUR_PT_CNT)	            AS OCUR_PT_CNT--발생환자수
                                                                    , SUM(A.WHL_OCUR_CNT)	            AS WHL_OCUR_CNT--전체발생건수
                                                                    , SUM(A.SBP_OCUR_CNT)	            AS SBP_OCUR_CNT--SBP 발생건수
                                                                    , SUM(A.PR_OCUR_CNT)	            AS PR_OCUR_CNT--PR 발생건수
                                                                    , SUM(A.SPO2_OCUR_CNT)	            AS SPO2_OCUR_CNT--SpO2 발생건수
                    							                 FROM MAIN A
							           ),
							           CHART_TYPE_TB AS (
                                        		               SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                                    , A.COMN_CD      AS COMN_CD
                                                                    , A.COMN_CD_NM   AS COMN_CD_NM
                                                                    , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                                                 FROM (
                                                                         SELECT 'RRS_OCUR'    AS COMN_GRP_CD
                                                                              , 'WHL_PT_CNT' AS COMN_CD
                                                                              , '중환자실전체환자수'    AS COMN_CD_NM
                                                                              , '1'           AS COMN_CD_EXPL
                                                                           FROM DUAL UNION ALL
                    										             SELECT 'RRS_OCUR', 'OCUR_PT_CNT', 'RRS발생환자수', '2' FROM DUAL UNION ALL
                    										             SELECT 'RRS_DETAIL_CNT', 'SBP_OCUR_CNT', 'SBP', '1' FROM DUAL UNION ALL
                    										             SELECT 'RRS_DETAIL_CNT', 'PR_OCUR_CNT', 'PR', '2' FROM DUAL UNION ALL
                    										             SELECT 'RRS_DETAIL_CNT', 'SPO2_OCUR_CNT', 'SpO2', '3' FROM DUAL 
                                                                         ) A
                                                             ORDER BY A.COMN_GRP_CD , COMN_CD_EXPL
                    		           ),
                    		           FLOW_RTO_CHART_TYPE_TB AS (
                                        		               SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                                    , A.COMN_CD      AS COMN_CD
                                                                    , A.COMN_CD_NM   AS COMN_CD_NM
                                                                    , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                                                 FROM (
                                                                         SELECT 'SBP_FLOW'    AS COMN_GRP_CD
                                                                              , 'BF_YEAR_MON' AS COMN_CD
                                                                              , '전년당월'    AS COMN_CD_NM
                                                                              , '1'           AS COMN_CD_EXPL
                                                                           FROM DUAL UNION ALL
                                                                         SELECT 'SBP_FLOW', 'BF_MON', '전월', '2' FROM DUAL UNION ALL
                                                                         SELECT 'SBP_FLOW', 'MON', '당월', '3' FROM DUAL UNION ALL
                                                                         SELECT 'PR_FLOW', 'BF_YEAR_MON', '전년당월', '1' FROM DUAL UNION ALL
                                                                         SELECT 'PR_FLOW', 'BF_MON', '전월', '2' FROM DUAL UNION ALL
                                                                         SELECT 'PR_FLOW', 'MON', '당월', '3' FROM DUAL UNION ALL
                                                                         SELECT 'SPO2_FLOW', 'BF_YEAR_MON', '전년당월', '1' FROM DUAL UNION ALL
                                                                         SELECT 'SPO2_FLOW', 'BF_MON', '전월', '2' FROM DUAL UNION ALL
                                                                         SELECT 'SPO2_FLOW', 'MON', '당월', '3' FROM DUAL 
                                                                         ) A
                                                             ORDER BY A.COMN_GRP_CD , COMN_CD_EXPL
                    		           ),   
                    		           RTO_CHART_TYPE_TB AS (
                                        		               SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                                    , A.COMN_CD      AS COMN_CD
                                                                    , A.COMN_CD_NM   AS COMN_CD_NM
                                                                    , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                                                 FROM (
                                                                         SELECT 'RRS_CRCCM'    AS COMN_GRP_CD
                                                                              , 'OCUR_PT_RTO'  AS COMN_CD
                                                                              , 'RRS발생율'    AS COMN_CD_NM
                                                                              , ''             AS COMN_CD_EXPL
                                                                           FROM DUAL UNION ALL
                                                                         SELECT 'AVG_FLOW', '1', '전년월평균', '1' FROM DUAL UNION ALL
                                                                         SELECT 'AVG_FLOW', '2', '당년월평균', '2' FROM DUAL UNION ALL
                                                                         SELECT 'AVG_FLOW', '3', '전년당월', '3' FROM DUAL UNION ALL
                    										             SELECT 'RRS_TYPE_OCUR', 'SBP_OCUR_RTO', 'SBP', '1' FROM DUAL UNION ALL
                    										             SELECT 'RRS_TYPE_OCUR', 'PR_OCUR_RTO', 'PR', '2' FROM DUAL UNION ALL
                    										             SELECT 'RRS_TYPE_OCUR', 'SPO2_OCUR_RTO', 'SpO2', '3' FROM DUAL 
                                                                         ) A
                                                             ORDER BY A.COMN_GRP_CD , COMN_CD_EXPL
                    		           ),
							           RRS_CRCCM AS (
                    							               SELECT WHL_PT_CNT               --중환자실 전체 환자수
                                                                    , OCUR_PT_CNT              --RRS발생 환자수
                                                                    , ROUND((DECODE(OCUR_PT_CNT, 0, NULL, OCUR_PT_CNT) / DECODE(WHL_PT_CNT, 0, NULL, WHL_PT_CNT)) * 100, 1)            AS OCUR_PT_RTO      --RRS발생률
                                                                    , SBP_OCUR_CNT             --SBP 발생건수
                                                                    , ROUND((DECODE(SBP_OCUR_CNT, 0, NULL, SBP_OCUR_CNT) / DECODE(WHL_OCUR_CNT, 0, NULL, WHL_OCUR_CNT)) * 100, 1)       AS SBP_OCUR_RTO     --SBP 발생률
                                                                    , PR_OCUR_CNT              --PR 발생건수
                                                                    , ROUND((DECODE(PR_OCUR_CNT, 0, NULL, PR_OCUR_CNT) / DECODE(WHL_OCUR_CNT, 0, NULL, WHL_OCUR_CNT)) * 100, 1)        AS PR_OCUR_RTO     --PR 발생률
                                                                    , SPO2_OCUR_CNT            --SPO2 발생건수
                                                                    , ROUND((DECODE(SPO2_OCUR_CNT, 0, NULL, SPO2_OCUR_CNT) / DECODE(WHL_OCUR_CNT, 0, NULL, WHL_OCUR_CNT)) * 100, 1)      AS SPO2_OCUR_RTO     --SPO2 발생률
                                                                 FROM SUM_DATA
							           ),
							           /***************************************************
                                		 * 중환자실 별 RRS 발생현황 : 전체, SBP, PR, SPO2
                                		***************************************************/     
                                       --중환자실 리스트 조회
            						   WD_DEPT_CD_DATA AS (
                    							               SELECT X.DEPT_CD        AS WD_DEPT_CD
                                                                    , X.RMK_CNTE       AS WD_DEPT_CD_NM
                                                                 FROM HICU.UCCOCDPM X   --U111_UCCO(설정)_부서기본
                                                                WHERE HSP_TP_CD        = IN_HSP_TP_CD
                                                             ORDER BY SORT_SEQ
            						   ),
							           DEPT_PT_CNT_DATA AS (
							                                   SELECT OCUR_DEPT_CD
							                                        , SUM(1)             AS CNT              
							                                        , SUM(WHL_PT_CNT)    AS WHL_PT_CNT       --전체환자수
							                                        , SUM(OCUR_PT_CNT)   AS OCUR_PT_CNT      --발생환자수
							                                        , SUM(WHL_OCUR_CNT)  AS WHL_OCUR_CNT     --전체발생건수
							                                        , SUM(SBP_OCUR_CNT)  AS SBP_OCUR_CNT     --SBP 발생건수
							                                        , SUM(PR_OCUR_CNT)   AS PR_OCUR_CNT      --PR 발생건수
							                                        , SUM(SPO2_OCUR_CNT) AS SPO2_OCUR_CNT    --SpO2 발생건수
							                                     FROM MAIN 
							                                 GROUP BY OCUR_DEPT_CD    --발생부서코드(pk) <- 환자위치코드
							           ),
							           /*****************************************************************************************************
                                		 * RRS 발생건수, 발생률  추이 전년월별평균, 당년월평균, 전년당월평균, 이전 12개월별 평균, 전월, 당월
                                		*****************************************************************************************************/ 
                                	   FLOW_MAIN AS (
                    											SELECT A.*
                    											     , TO_DATE(OCUR_YY || OCUR_MM || OCUR_DY, 'YYYY-MM-DD')                        AS OCUR_DATE   --날짜
                    											     , A.OCUR_YY || '-' || A.OCUR_MM                                               AS DATE_TYPE --날짜타입
                    											  FROM HICU.UCOSRRSD A    --U113_UCOS(운영통계)_RRS Summary
                    											 WHERE A.HSP_TP_CD          = IN_HSP_TP_CD
            						   ),
                                	   --전년 
                                	   BF_YEAR_MAN_DAYS AS (
                                						        SELECT SUM(A.WHL_PT_CNT)           AS WHL_PT_CNT         --전체환자수
                                							         , SUM(A.OCUR_PT_CNT)          AS OCUR_PT_CNT        --RRS발생환자수
                                							         , SUM(A.WHL_OCUR_CNT)         AS WHL_OCUR_CNT       --전체발생건수
                                                                     , SUM(1)                      AS YEAR_CNT           --건수
                                        				          FROM FLOW_MAIN A    
                                        			             WHERE A.OCUR_DATE BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM')
                                        			                                   AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-12-31', 'YYYY-MM-DD') 
                                					          --GROUP BY A.DATE_TYPE 
                                	   ), 
                                	   --당년 
                                	   MON_YEAR_MAN_DAYS AS (
                                						        SELECT SUM(A.WHL_PT_CNT)           AS WHL_PT_CNT         --전체환자수
                                							         , SUM(A.OCUR_PT_CNT)          AS OCUR_PT_CNT        --RRS발생환자수
                                							         , SUM(A.WHL_OCUR_CNT)         AS WHL_OCUR_CNT       --전체발생건수
                                                                     , SUM(1)                      AS YEAR_CNT           --건수
                                        				          FROM FLOW_MAIN A    
                                        			             WHERE A.OCUR_DATE BETWEEN TRUNC(IN_TO_DTM, 'YYYY')
                                        			                                   AND TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-12-31', 'YYYY-MM-DD') 
                                					          --GROUP BY A.DATE_TYPE
                                	   ),
                                	   --전년 당월 
                                	   BF_MON_MAN_DAYS AS (
                                        	                    SELECT SUM(A.WHL_PT_CNT)	            AS WHL_PT_CNT--전체환자수
                                                                     , SUM(A.OCUR_PT_CNT)	            AS OCUR_PT_CNT--발생환자수
                                                                     , SUM(A.WHL_OCUR_CNT)	            AS WHL_OCUR_CNT--전체발생건수
                                                                     , SUM(A.SBP_OCUR_CNT)	            AS SBP_OCUR_CNT--SBP 발생건수
                                                                     , SUM(A.PR_OCUR_CNT)	            AS PR_OCUR_CNT--PR 발생건수
                                                                     , SUM(A.SPO2_OCUR_CNT)	            AS SPO2_OCUR_CNT--SpO2 발생건수
                                        	                      FROM FLOW_MAIN A
                                        	                     WHERE A.OCUR_DATE BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM')
                    												                   AND TRUNC(LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12)))
                    									      --GROUP BY A.DATE_TYPE 
                                	   ),
                                	   --전월
                                	   BF_MON_DATA AS (
                                        	                    SELECT SUM(A.WHL_PT_CNT)	            AS WHL_PT_CNT--전체환자수
                                                                     , SUM(A.OCUR_PT_CNT)	            AS OCUR_PT_CNT--발생환자수
                                                                     , SUM(A.WHL_OCUR_CNT)	            AS WHL_OCUR_CNT--전체발생건수
                                                                     , SUM(A.SBP_OCUR_CNT)	            AS SBP_OCUR_CNT--SBP 발생건수
                                                                     , SUM(A.PR_OCUR_CNT)	            AS PR_OCUR_CNT--PR 발생건수
                                                                     , SUM(A.SPO2_OCUR_CNT)	            AS SPO2_OCUR_CNT--SpO2 발생건수
                                        	                      FROM FLOW_MAIN A
                                        	                     WHERE A.OCUR_DATE BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -1), 'MM')
                                        			                                   AND LAST_DAY(ADD_MONTHS(IN_TO_DTM, -1))
                    									      --GROUP BY A.DATE_TYPE 
                                	   ),
                                	   --당월
                                	   MON_DATA AS (
                                	                            SELECT SUM(A.WHL_PT_CNT)	            AS WHL_PT_CNT--전체환자수
                                                                     , SUM(A.OCUR_PT_CNT)	            AS OCUR_PT_CNT--발생환자수
                                                                     , SUM(A.WHL_OCUR_CNT)	            AS WHL_OCUR_CNT--전체발생건수
                                                                     , SUM(A.SBP_OCUR_CNT)	            AS SBP_OCUR_CNT--SBP 발생건수
                                                                     , SUM(A.PR_OCUR_CNT)	            AS PR_OCUR_CNT--PR 발생건수
                                                                     , SUM(A.SPO2_OCUR_CNT)	            AS SPO2_OCUR_CNT--SpO2 발생건수
                                        	                      FROM FLOW_MAIN A
                                        	                     WHERE A.OCUR_DATE BETWEEN TRUNC(IN_TO_DTM, 'MM')
                                        			                                   AND LAST_DAY(IN_TO_DTM)
                    									      --GROUP BY A.DATE_TYPE 
                                	   ),
                                	   -- 12개월 별 연간 추이 X 축
                                	   FROM_TO_DATE_TYPE AS (
                                        	                    SELECT TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYY-MM') AS DATE_TYPE
                                                                     , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YY.MM')   AS DT_CD_NM
                                                                     , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYYMM')  AS DT_CD
                                                                  FROM DUAL
                                                            CONNECT BY LEVEL - 1 <= 11 
                                	   ),
                                	   --조회기간 부터 이전 11개월 전 
                                	   FROM_TO_MAN_DAYS AS ( 
                                	                            SELECT SUM(A.WHL_PT_CNT)           AS WHL_PT_CNT         --전체환자수
                                							         , SUM(A.OCUR_PT_CNT)          AS OCUR_PT_CNT        --RRS발생환자수
                                							         , SUM(A.WHL_OCUR_CNT)         AS WHL_OCUR_CNT       --전체발생건수
                                							         , A.DATE_TYPE                 AS DATE_TYPE
                                        				          FROM FLOW_MAIN A
                                	                             WHERE A.OCUR_DATE BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM')
                                	                                                   AND LAST_DAY(IN_TO_DTM)
            									              GROUP BY A.DATE_TYPE
                                	   )            

							           

							/********************
							* INDICATORS OUT DTO
							*********************/ 
							SELECT X.COMN_GRP_CD
							     , X.COMN_CD
							     , X.COMN_CD_NM
							     , X.COMN_CD_EXPL
							     , X.DTRL1_NM
							     , X.DTRL2_NM 
							  FROM ( 
                                    SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
        							     , B.COMN_CD                AS COMN_CD
        							     , B.COMN_CD_NM             AS COMN_CD_NM       
        							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
        							     , TO_CHAR(NVL(A.DTRL1_NM, 0))       AS DTRL1_NM 
        							     , TO_CHAR(NVL(A.DTRL2_NM, 0))       AS DTRL2_NM
        							  FROM (
        									    SELECT 'RRS_OCUR'          AS COMN_GRP_CD
        										     , COMN_CD             AS COMN_CD
        										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM 
        										     , NULL                AS DTRL2_NM
        										  FROM RRS_CRCCM
        									   UNPIVOT (DTRL1_NM FOR COMN_CD
        										                  IN (WHL_PT_CNT      --중환자실전체환자수
                                                                    , OCUR_PT_CNT     --RRS발생환자수
        										                    )
        										       )  
        									 
        									 UNION ALL
        									         									 
        									    SELECT 'RRS_DETAIL_CNT'     AS COMN_GRP_CD
        										     , COMN_CD             AS COMN_CD
        										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM 
        										     , NULL                AS DTRL2_NM
        										  FROM RRS_CRCCM
        									   UNPIVOT (DTRL1_NM FOR COMN_CD
        										                  IN (SBP_OCUR_CNT      --SBP발생건수
                                                                    , PR_OCUR_CNT       --PR발생건수
                                                                    , SPO2_OCUR_CNT     --SPO2발생건수
        										                    )
        										       )  
        								 ) A
        								 , CHART_TYPE_TB B 	
        							 WHERE B.COMN_CD      = A.COMN_CD (+) 
        							   AND B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
        							   
        	                  UNION ALL
        	                      
        						 SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
        							     , B.COMN_CD                AS COMN_CD
        							     , B.COMN_CD_NM             AS COMN_CD_NM       
        							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
        							     , TO_CHAR(NVL(A.DTRL1_NM, 0))       AS DTRL1_NM 
        							     , RTRIM(TO_CHAR(NVL(A.DTRL2_NM, 0), 'FM9990.9'), '.')        AS DTRL2_NM
        							  FROM (
        									 --SBP 전년당월, 전월, 당월 발생건수 및 발생률	
        									 
        									    SELECT 'SBP_FLOW'               AS COMN_GRP_CD
        									         , 'BF_YEAR_MON'            AS COMN_CD  
        										     , NVL(A.SBP_OCUR_CNT, 0)   AS DTRL1_NM       --전년당월 SBP발생건수 
                                                     , NVL(ROUND(A.SBP_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전년당월SBP발생률 
        									      FROM BF_MON_MAN_DAYS A
        									 
        									 UNION ALL
        									 
        									    SELECT 'SBP_FLOW'                       AS COMN_GRP_CD
        									         , 'BF_MON'                         AS COMN_CD  
        										     , NVL(A.SBP_OCUR_CNT, 0)           AS DTRL1_NM       --전월 SBP발생건수 
                                                     , NVL(ROUND(A.SBP_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전월 SBP발생률 
        									      FROM BF_MON_DATA A
        									      
        									 UNION ALL
        									 
        									    SELECT 'SBP_FLOW'                       AS COMN_GRP_CD
        									         , 'MON'                            AS COMN_CD  
        										     , NVL(A.SBP_OCUR_CNT, 0)           AS DTRL1_NM       --당월 SBP발생건수 
                                                     , NVL(ROUND(A.SBP_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --당월 SBP발생률 
        									      FROM MON_DATA A	
        									       
        									 --PR 전년당월, 전월, 당월 발생건수 및 발생률
        									  UNION ALL
        									 
        									    SELECT 'PR_FLOW'               AS COMN_GRP_CD
        									         , 'BF_YEAR_MON'            AS COMN_CD  
        										     , NVL(A.PR_OCUR_CNT, 0)   AS DTRL1_NM       --전년 당월 PR발생건수 
                                                     , NVL(ROUND(A.PR_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전년 당월 PR발생률 
        									      FROM BF_MON_MAN_DAYS A
        									 
        									 UNION ALL
        									 
        									    SELECT 'PR_FLOW'                       AS COMN_GRP_CD
        									         , 'BF_MON'                         AS COMN_CD  
        										     , NVL(A.PR_OCUR_CNT, 0)           AS DTRL1_NM       --전월 PR발생건수 
                                                     , NVL(ROUND(A.PR_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전월 PR발생률 
        									      FROM BF_MON_DATA A
        									      
        									 UNION ALL
        									 
        									    SELECT 'PR_FLOW'                       AS COMN_GRP_CD
        									         , 'MON'                            AS COMN_CD  
        										     , NVL(A.PR_OCUR_CNT, 0)           AS DTRL1_NM       --당월 PR발생건수 
                                                     , NVL(ROUND(A.PR_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       -- 당월 PR발생률 
        									      FROM MON_DATA A
        									      	 
        									 --SPO2 전년당월, 전월, 당월 발생건수 및 발생률	
        									  UNION ALL
        									 
        									    SELECT 'SPO2_FLOW'               AS COMN_GRP_CD
        									         , 'BF_YEAR_MON'            AS COMN_CD  
        										     , NVL(A.SPO2_OCUR_CNT, 0)   AS DTRL1_NM       --전년당월 SpO2발생건수 
                                                     , NVL(ROUND(A.SPO2_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전년당월 SpO2발생률 
        									      FROM BF_MON_MAN_DAYS A
        									 
        									 UNION ALL
        									 
        									    SELECT 'SPO2_FLOW'                       AS COMN_GRP_CD
        									         , 'BF_MON'                         AS COMN_CD  
        										     , NVL(A.SPO2_OCUR_CNT, 0)           AS DTRL1_NM       --전월 SpO2발생건수 
                                                     , NVL(ROUND(A.SPO2_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --전월 SpO2발생률 
        									      FROM BF_MON_DATA A
        									      
        									 UNION ALL
        									 
        									    SELECT 'SPO2_FLOW'                       AS COMN_GRP_CD
        									         , 'MON'                            AS COMN_CD  
        										     , NVL(A.SPO2_OCUR_CNT, 0)           AS DTRL1_NM       --당월 SpO2발생건수 
                                                     , NVL(ROUND(A.SPO2_OCUR_CNT / DECODE(A.WHL_OCUR_CNT, 0, NULL, A.WHL_OCUR_CNT) * 100, 1), 0)     AS DTRL2_NM       --당월 SpO2발생률 
        									      FROM MON_DATA A
        							     ) A
        								 , FLOW_RTO_CHART_TYPE_TB B 	
        							 WHERE B.COMN_CD      = A.COMN_CD (+) 
        							   AND B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
        							  
        						 UNION ALL
        						    
        						    SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
        							     , B.COMN_CD                AS COMN_CD
        							     , B.COMN_CD_NM             AS COMN_CD_NM       
        							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
        							     , RTRIM(TO_CHAR(NVL(A.DTRL1_NM, 0), 'FM9990.9'), '.')       AS DTRL1_NM 
        							     , RTRIM(TO_CHAR(NVL(A.DTRL2_NM, 0), 'FM9990.9'), '.')       AS DTRL2_NM
        							  FROM (
        							            SELECT 'RRS_TYPE_OCUR'     AS COMN_GRP_CD
        										     , COMN_CD             AS COMN_CD
        										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM 
        										     , NULL                AS DTRL2_NM
        										  FROM RRS_CRCCM
        									   UNPIVOT (DTRL1_NM FOR COMN_CD
        										                  IN (SBP_OCUR_RTO      --SBP발생률
                                                                    , PR_OCUR_RTO       --PR발생률
                                                                    , SPO2_OCUR_RTO     --SPO2발생률
        										                    )
        										       )       
        										       
        									 UNION ALL
        									 
        									    SELECT 'RRS_CRCCM'         AS COMN_GRP_CD
        										     , COMN_CD             AS COMN_CD
        										     , NVL(DTRL1_NM, 0)    AS DTRL1_NM 
        										     , NULL                AS DTRL2_NM
        										  FROM RRS_CRCCM
        									   UNPIVOT (DTRL1_NM FOR COMN_CD
        										                  IN (OCUR_PT_RTO              --RRS발생률
        										                    )
        										       )
        										       
        									--전년 월, 당년 월 RRS발생건수평균, RRS발생률 / 전년 당월 RRS발생건수, RRS발생률
        									 UNION ALL
        									 
        									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
        									         , '1'            AS COMN_CD  
        										     --, '전년월평균'   AS COMN_CD_NM
        										     , NVL(ROUND(A.WHL_OCUR_CNT / DECODE(A.YEAR_CNT, 0, NULL, A.YEAR_CNT),0), 0)              AS DTRL1_NM       --전년 RRS발생건수평균
                                                     , NVL(ROUND(A.OCUR_PT_CNT / DECODE(A.WHL_PT_CNT, 0, NULL, A.WHL_PT_CNT) * 100, 1), 0)    AS DTRL2_NM       --전년 RRS발생률
        									      FROM BF_YEAR_MAN_DAYS A
        									 
        									 UNION ALL
        									 
        									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
        									         , '2'            AS COMN_CD  
        										     --, '당년월평균'   AS COMN_CD_NM
        										     , NVL(ROUND(A.WHL_OCUR_CNT / DECODE(A.YEAR_CNT, 0, NULL, A.YEAR_CNT),0), 0)              AS DTRL1_NM       --당년월 RRS발생건수평균
                                                     , NVL(ROUND(A.OCUR_PT_CNT / DECODE(A.WHL_PT_CNT, 0, NULL, A.WHL_PT_CNT) * 100, 1), 0)    AS DTRL2_NM       --당년월 RRS발생률
        									      FROM MON_YEAR_MAN_DAYS A
        									      
        									 UNION ALL
        									 
        									    SELECT 'AVG_FLOW'        AS COMN_GRP_CD
        									         , '3'               AS COMN_CD  
        										     --, '전년당월'        AS COMN_CD_NM
        										     , NVL(A.WHL_OCUR_CNT, 0)           AS DTRL1_NM       --전년 당월 RRS발생건수 
                                                     , NVL(ROUND(A.OCUR_PT_CNT / DECODE(A.WHL_PT_CNT, 0, NULL, A.WHL_PT_CNT) * 100, 1), 0)     AS DTRL2_NM       --전년 당월 RRS발생률 
        									      FROM BF_MON_MAN_DAYS A
        										        
        							     ) A
        								 , RTO_CHART_TYPE_TB B 	
        							 WHERE B.COMN_CD      = A.COMN_CD (+) 
        							   AND B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
        								   
        						 --당년 월별 RRS발생건수  , RRS 발생률 
        					 	 UNION ALL
        					 	 
        							SELECT 'AVG_MSTS'                            AS COMN_GRP_CD
        							     , A.DT_CD                               AS COMN_CD  
        							     , A.DT_CD_NM                            AS COMN_CD_NM 
        							     , NULL                                  AS COMN_CD_EXPL
        							     , TO_CHAR(NVL(B.WHL_OCUR_CNT, 0))                AS DTRL1_NM       --당년 월별 RRS발생건수 
                                         , RTRIM(TO_CHAR(NVL(ROUND(B.OCUR_PT_CNT / DECODE(B.WHL_PT_CNT, 0, NULL, B.WHL_PT_CNT) * 100, 1), 0), 'FM9990.9'), '.')          AS DTRL2_NM       --당년 월별 RRS발생률 
        							  FROM FROM_TO_DATE_TYPE A
        							     , FROM_TO_MAN_DAYS  B
        							 WHERE A.DATE_TYPE = B.DATE_TYPE(+)    
        						 
        			  			 ORDER BY COMN_GRP_CD, COMN_CD_EXPL, COMN_CD, COMN_CD_NM 
			  			 ) X
			  			 
					     --중환자실별 RRS 발생현황
					     UNION ALL
					            
					        SELECT Z.COMN_GRP_CD
							     , Z.COMN_CD
							     , Z.COMN_CD_NM
							     , Z.COMN_CD_EXPL
							     , Z.DTRL1_NM
							     , Z.DTRL2_NM
					          FROM (
        					        SELECT Y.COMN_GRP_CD
                                         , Y.COMN_CD
                                         , Y.COMN_CD_NM
                                         , Y.COMN_CD_EXPL
                                         , TO_CHAR(Y.DTRL1_NM)   AS DTRL1_NM
                                         , TO_CHAR(Y.DTRL2_NM)   AS DTRL2_NM
                                      FROM (
        							           SELECT 'ICU_TYPE'            AS COMN_GRP_CD
        							                , A.WD_DEPT_CD          AS COMN_CD
        							                , 'PT_CNT'              AS COMN_CD_NM
                					                , '1'                   AS COMN_CD_EXPL
        							                , NVL(B.WHL_PT_CNT, 0)  AS DTRL1_NM 
        							                , 0                     AS DTRL2_NM
        							             FROM WD_DEPT_CD_DATA A
        							                , DEPT_PT_CNT_DATA B
        							            WHERE A.WD_DEPT_CD  = B.OCUR_DEPT_CD(+)
        							            
        							        UNION ALL
        
        							           SELECT 'ICU_TYPE'            AS COMN_GRP_CD
        							                , A.WD_DEPT_CD          AS COMN_CD
        							                , 'SBP'                 AS COMN_CD_NM
                					                , '2'                   AS COMN_CD_EXPL
        							                , NVL(B.SBP_OCUR_CNT, 0)  AS DTRL1_NM
        							                , NVL(B.WHL_PT_CNT, 0)    AS DTRL2_NM
        							             FROM WD_DEPT_CD_DATA A
        							                , DEPT_PT_CNT_DATA B
        							            WHERE A.WD_DEPT_CD  = B.OCUR_DEPT_CD(+)
        							       
        							        UNION ALL
        							        
        							           SELECT 'ICU_TYPE'            AS COMN_GRP_CD
        							                , A.WD_DEPT_CD          AS COMN_CD
        							                , 'PR'                  AS COMN_CD_NM
                					                , '3'                   AS COMN_CD_EXPL
        							                , NVL((B.SBP_OCUR_CNT + B.PR_OCUR_CNT), 0)                    AS DTRL1_NM
        							                , NVL(B.PR_OCUR_CNT, 0)  AS DTRL2_NM
        							             FROM WD_DEPT_CD_DATA A
        							                , DEPT_PT_CNT_DATA B
        							            WHERE A.WD_DEPT_CD  = B.OCUR_DEPT_CD(+)
        							            
        							        UNION ALL
        							            
        							           SELECT 'ICU_TYPE'              AS COMN_GRP_CD
        							                , A.WD_DEPT_CD            AS COMN_CD
        							                , 'SPO2'                  AS COMN_CD_NM
                					                , '4'                     AS COMN_CD_EXPL
                					                , NVL((B.SBP_OCUR_CNT + B.PR_OCUR_CNT + B.SPO2_OCUR_CNT), 0) AS DTRL1_NM
        							                , NVL(B.SPO2_OCUR_CNT, 0)  AS DTRL2_NM
        							             FROM WD_DEPT_CD_DATA A
        							                , DEPT_PT_CNT_DATA B
        							            WHERE A.WD_DEPT_CD  = B.OCUR_DEPT_CD(+)
                                         ) Y
                                  ORDER BY COMN_GRP_CD, COMN_CD_EXPL, DECODE(COMN_CD, 'MICU', 1, 'CICU', 2, 'SICU', 3, 'NICU', 4, 'NICU2', 5, 'NCU', 6, 'EICU', 7, 'EICU2', 8)
					     	    ) Z
							;   
        			           
  END PC_EICU_CENTER_RRS_STATISTICS;
