
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICROD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            ) 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICROD_SAVE                                               
*    CREATEDATE     : 2021.03.24
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_혈관조영시술일정정보
*    Change History : 2021.03.24                                               
**********************************************************************************************/
AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';   
    
    /*******************************************************************************************************************
    * DELETE : HICU.UICICROD A  --U121_UICI(ODS)_혈관조영시술일정정보
    * FROM : XICU.EMEI008V
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICICROD A  --U121_UICI(ODS)_혈관조영시술일정정보
          WHERE EXISTS (SELECT 1 
                          FROM XICU.EMEI008V B
                         WHERE A.PT_NO             = B.PT_NO
                           AND A.OP_EXPT_DT        = B.OP_EXPT_DT
                           AND A.OP_EXPT_DT_SEQ    = B.OP_EXPT_DT_SEQ
                           AND A.ERAD_TP_CD        = B.ERAD_TP_CD
                           AND B.LST_CHG_DTM BETWEEN IN_FROM_DTM 
                                                 AND IN_TO_DTM
                      );
	   COMMIT;                
      END;
    /*******************************************
    * _혈관조영시술일정정보(UICICROD) BATCH 
    *******************************************/   
    BEGIN        
        MERGE INTO HICU.UICICROD A  --U121_UICI(ODS)_혈관조영시술일정정보
             USING ( SELECT PT_NO
                          , OP_EXPT_DT
                          , OP_EXPT_DT_SEQ
                          , AGPY_SEQ_CTG_CD
                          , AGPY_SEQ_CTG_CD_NM
                          , AOM_DTM
                          , PSD_YN
                          , ERAD_TP_CD
                          , FST_WRT_DTM
                          , LST_CHG_DTM
				 	   FROM XICU.EMEI008V
					  WHERE AGDP_MRK_TP_CD    = 'N' --완료건만 적재 
					    AND LST_CHG_DTM BETWEEN IN_FROM_DTM AND IN_TO_DTM
                   ) B
                ON ( 
                         A.PT_NO           = B.PT_NO
                     AND A.OP_EXPT_DT      = B.OP_EXPT_DT
                     AND A.OP_EXPT_DT_SEQ  = B.OP_EXPT_DT_SEQ 
                     AND A.ERAD_TP_CD      = B.ERAD_TP_CD             --210409 한가혜 응급접수부서구분코드 추가
                )
               WHEN MATCHED THEN
                    --최종 적재
                    UPDATE SET A.AGPY_SEQ_CTG_CD      = B.AGPY_SEQ_CTG_CD
                             , A.AGPY_SEQ_CTG_CD_NM   = B.AGPY_SEQ_CTG_CD_NM
                             , A.AOM_DTM              = B.AOM_DTM
                             , A.PSD_YN               = B.PSD_YN
                             , A.FST_WRT_DTM          = B.FST_WRT_DTM
                             , A.LST_CHG_DTM          = B.LST_CHG_DTM
                             , A.LST_LOD_DTM          = SYSDATE        --최종적재일시
               WHEN NOT MATCHED THEN
                    --최초 적재
                    INSERT ( A.PT_NO						--환자번호
                           , A.OP_EXPT_DT					--수술예정일자
                           , A.OP_EXPT_DT_SEQ			--수술예정일자순번
                           , A.HSP_TP_CD					--병원구분코드
                           , A.AGPY_SEQ_CTG_CD			--혈관조영순번분류코드
                           , A.AGPY_SEQ_CTG_CD_NM		--혈관조영순번분류코드명
                           , A.AOM_DTM						--시술일시
                           , A.PSD_YN						--보류여부
                           , A.FST_WRT_DTM				--최초작성일시
                           , A.LST_CHG_DTM				--최종변경일시
                           , A.FST_LOD_DTM				--최초적재일시
                           , A.LST_LOD_DTM				--최종적재일시 
                           , A.ERAD_TP_CD	            --210409 한가혜 응급접수부서구분코드 추가 
                           )
                    VALUES ( B.PT_NO
                           , B.OP_EXPT_DT
                           , B.OP_EXPT_DT_SEQ 
                           , IN_HSP_TP_CD
                           , B.AGPY_SEQ_CTG_CD
                           , B.AGPY_SEQ_CTG_CD_NM
                           , B.AOM_DTM
                           , B.PSD_YN
                           , B.FST_WRT_DTM
                           , B.LST_CHG_DTM
                           , SYSDATE                              --최초적재일시
                           , SYSDATE                              --최종적재일시 
                           , B.ERAD_TP_CD	            --210409 한가혜 응급접수부서구분코드 추가 
                           );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICROD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICROD_SAVE;
