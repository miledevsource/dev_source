
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_TRNF_MAIN_SEL" 
                          ( IN_STATUS_STS_CD        IN  VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_PT_INFO_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송요청 환자리스트  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
SELECT  A.TRNF_PRGR_STS_CD                              TRNF_PRGR_STS_CD     
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT       
      , A.PT_NM                                         PT_NM                
      , B.SEX_TP_CD                                     SEX_TP_CD            
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH           
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE             
      , (SELECT DEPT_NM                                                      
           FROM PDEDBMSM                                                     
          WHERE MED_DEPT_CD =  C.MED_DEPT_CD )          DEPT_NM            
      , A.PACT_ID                                       PACT_ID             
      , A.PT_NO						                    PT_NO               
      , D.PT_SILLM_CTG_GRP_CD                           PT_SCORE          
      , ''                                              ANDR_NM             
      , A.TARGET_HSP_NM                                 REF_HSP_NM          
      , ''                                              DGNS_NM                        
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD', A.STATUS_STS_CD)              STATUS_CNFM          
      , A.XFER_START_DT							                          XFER_START_DT        
      , A.SEQ									                                		SEQ                   
      , A.HSP_TP_CD									                            HSP_TP_CD           
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT    
  FROM ARPA_PT_LIST A       
     , PCTPCPAM_DAMO B
     , ACPPRAAM C
     , (
        SELECT *
        FROM (
            SELECT D.*
                 , ROW_NUMBER() OVER (
                      PARTITION BY D.PACT_ID
                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
                   ) AS RN
              FROM MOPPCCFD D
        )
        WHERE RN = 1
     ) D
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
--   AND A.HSP_TP_CD = IN_HSP_TP_CD
--  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')
--  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
-- AND A.STATUS_CNFM != 'N'
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.PACT_ID = D.PACT_ID


UNION ALL

SELECT  A.TRNF_PRGR_STS_CD                 TRNF_PRGR_STS_CD
      , A.CONSULT_REQ_DT                   CONSULT_REQ_DT
      , A.PT_NM                            PT_NM
      , B.SEX_TP_CD                        SEX_TP_CD
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')    PT_BIRTH
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
      , C.MED_DEPT_CD                        DEPT_NM
      , A.PACT_ID                            PACT_ID
      , A.PT_NO						PT_NO
      , C.KTAS_RSLT_CD  PT_SCORE
      , C.MEDR_SID    ANDR_NM
      , A.TARGET_HSP_NM                   REF_HSP_NM
      , ''                                              DGNS_NM           
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD', A.STATUS_STS_CD)              STATUS_CNFM           
      , A.XFER_START_DT							                          XFER_START_DT        
      , A.SEQ									                                		SEQ    
      , A.HSP_TP_CD									                            HSP_TP_CD
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT    

  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD 
--  AND A.HSP_TP_CD = IN_HSP_TP_CD
--  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')
--  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
--  AND A.STATUS_CNFM != 'N'
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID


ORDER BY CONSULT_REQ_DT DESC ;


END PC_TRNF_MAIN_SEL;
