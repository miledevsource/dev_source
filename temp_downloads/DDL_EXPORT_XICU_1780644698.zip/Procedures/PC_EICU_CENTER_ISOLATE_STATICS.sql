
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_ISOLATE_STATICS" 
                          ( IN_FROM_DTE    IN  DATE
                          , IN_TO_DTE      IN  DATE
                          , IN_WD_DEPT_CD  IN VARCHAR2
                          , IN_HSP_TP_CD   IN VARCHAR2
                          , OUT_CURSOR    OUT SYS_REFCURSOR
                          )

IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_ISOLATE_STATICS                                               
*    CREATEDATE     : 2021.02.24                                                               
*    Author         : 오지민                                                                     
*    Description    : 통합관제 임상지표 국가지정 격리병상 현황
*    Change History : 2021.02.24, 오지민, 최초작성                                                
**********************************************************************************************/
BEGIN
    BEGIN 
	    OPEN OUT_CURSOR FOR   
        	WITH SDATA_ISO AS(
                SELECT ETRM_PT_CNT
                     , CHOT_PT_CNT 
			         , WHL_SIRM_DYS
                     , YY_PT_CNT
                     , YY_BED_CNT
                     , PT_SILLM_CTG_1_GRP_CNT
                     , PT_SILLM_CTG_2_GRP_CNT
                     , PT_SILLM_CTG_3_GRP_CNT
                     , PT_SILLM_CTG_4_GRP_CNT
                     , PT_SILLM_CTG_5_GRP_CNT
                     , PT_SILLM_CTG_6_GRP_CNT
                     , SIRM_5_DY_IN_CNT
                     , SIRM_10_DY_IN_CNT
                     , SIRM_15_DY_IN_CNT
                     , SIRM_20_DY_IN_CNT
                     , SIRM_25_DY_IN_CNT
                     , SIRM_25_TM_EXCS_CNT
                  FROM HICU.UCCIISPM A
                 WHERE HSP_TP_CD =  IN_HSP_TP_CD
                   AND ETRM_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD'))
           , SDATA_SIRM AS
           (
               SELECT PACT_ID                      AS PACT_ID
                    , PT_NO                        AS PT_NO
                    , ETRM_DTM                     AS ETRM_DTM
                    , HSP_TP_CD                    AS HSP_TP_CD
                    , SEX_TP_CD                    AS SEX_TP_CD
                    , AGE                          AS AGE
                    , CHOT_DTM                     AS CHOT_DTM
                    , ETRM_WD_DEPT_CD              AS ETRM_WD_DEPT_CD
                    , ETRM_WD_DEPT_CD_NM           AS ETRM_WD_DEPT_CD_NM
                    , INFC_MCB_TP_CD               AS INFC_MCB_TP_CD
                    , 1                            AS CNT
                 FROM XICU.UICIISPV
                WHERE HSP_TP_CD = IN_HSP_TP_CD
                  AND (ETRM_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE  OR
                       DECODE(CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),CHOT_DTM) BETWEEN IN_FROM_DTE AND IN_TO_DTE OR
                      (ETRM_DTM < IN_FROM_DTE AND CHOT_DTM > IN_TO_DTE))
           )
           , MONTH_DATA AS
        				(  /*월별 기준데이터*/
        					SELECT TO_CHAR(DT_CD, 'YYYY-MM')                                       DATE_TYPE
        					     , LAST_DAY(TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01' ,'YYYY-MM-DD')) - TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01', 'YYYY-MM-DD') + 1 NALSU
        			             , CASE WHEN TO_DATE(TO_CHAR(DT_CD, 'YYYY-MM')||'-01' ,'YYYY-MM-DD') > TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM')||'-01', 'YYYY-MM-DD') THEN 'N' ELSE 'Y' END DIS_YN  /*미래는 표시안함*/
        			          FROM HICU.UICIIRHD
        			         WHERE DT_CD BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -11)) AND LAST_DAY(IN_TO_DTE)
        			         GROUP BY TO_CHAR(DT_CD, 'YYYY-MM'))
            , MAN_DAYS AS /*추이 데이터 조회기준 1년전까지*/
            		   (
            		         SELECT DATA_TYPE
            				      , YY_PT_CNT
            				      , YY_BED_CNT
            				   FROM (
            					      SELECT ETRM_YY||'-' || ETRM_MM   DATA_TYPE
            					           , SUM(YY_PT_CNT)  YY_PT_CNT--연인원
                                           , SUM(YY_BED_CNT) YY_BED_CNT--연병상수
            						    FROM HICU.UCCIISPM A   --격리병동환자지표기본
            						   WHERE A.HSP_TP_CD = IN_HSP_TP_CD
--            						     AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM') AND LAST_DAY(IN_TO_DTE)
                                         AND ETRM_DT_SEQ BETWEEN TO_CHAR(TRUNC(ADD_MONTHS(IN_TO_DTE, -11), 'MM'), 'YYYYMMDD') AND TO_CHAR(LAST_DAY(IN_TO_DTE), 'YYYYMMDD')
            						   GROUP BY ETRM_YY, ETRM_MM )
                             ORDER BY DATA_TYPE)
            , BF_MAN_DAYS  AS
            	   (   /*전년도 당월데이터*/
                     SELECT ETRM_YY||'-' || ETRM_MM   DATA_TYPE
                          , NVL(SUM(YY_PT_CNT), 0)  YY_PT_CNT--연인원
                          , NVL(SUM(YY_BED_CNT), 0) YY_BED_CNT--연병상수
                      FROM HICU.UCCIISPM A   --격리병동환자지표기본
                     WHERE A.HSP_TP_CD = IN_HSP_TP_CD
--                       AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM') AND LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12))
                       AND ETRM_DT_SEQ BETWEEN  TO_CHAR(TRUNC(ADD_MONTHS(IN_TO_DTE, -12), 'MM'), 'YYYYMMDD')  AND TO_CHAR(LAST_DAY(ADD_MONTHS(IN_TO_DTE, -12)), 'YYYYMMDD')                       
                     GROUP BY ETRM_YY||'-' || ETRM_MM
                   )
             , BF_YEAR_MAN_DAYS AS
            	   ( /*전년도 월평균*/
                     SELECT NVL(SUM(YY_PT_CNT), 0)                          AS YY_PT_CNT--연인원
                          , NVL(SUM(YY_BED_CNT), 0)                         AS YY_BED_CNT--연병상수
                          , SUM(1)                                          AS COUNT
                       FROM (SELECT ETRM_YY||'-'|| ETRM_MM                  AS DATA_TYPE
                                  , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
                                  , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
                               FROM HICU.UCCIISPM A   --격리병동환자지표기본
                              WHERE A.HSP_TP_CD = IN_HSP_TP_CD
--                                AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD')
--                                AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= SYSDATE
                                AND ETRM_DT_SEQ BETWEEN TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '0101' AND TO_CHAR(ADD_MONTHS(IN_TO_DTE, -12), 'YYYY') || '1231'
                                AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE,'YYYYMMDD')
                              GROUP BY ETRM_YY||'-' || ETRM_MM
                             ORDER BY DATA_TYPE )
                    )
             , YEAR_MAN_DAYS AS
            	   ( /*당년 월평균*/
                     SELECT NVL(SUM(YY_PT_CNT), 0)                      AS YY_PT_CNT--연인원
                          , NVL(SUM(YY_BED_CNT), 0)                     AS YY_BED_CNT--연병상수
                          , NVL(SUM(1), 0)                              AS COUNT
                       FROM (SELECT ETRM_YY||'-'|| ETRM_MM              AS DATA_TYPE
                                  , NVL(SUM(YY_PT_CNT), 0)              AS YY_PT_CNT--연인원
                                  , NVL(SUM(YY_BED_CNT), 0)             AS YY_BED_CNT--연병상수
                               FROM HICU.UCCIISPM A   --격리병동환자지표기본
                              WHERE A.HSP_TP_CD = IN_HSP_TP_CD
--                                AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-01-01' ,'YYYY-MM-DD') AND TO_DATE(TO_CHAR(IN_TO_DTE, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
--                                AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE)
                                AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE, 'YYYY') || '0101' AND TO_CHAR(IN_TO_DTE, 'YYYY') || '1231'
                                AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE,'YYYYMMDD')
                              GROUP BY ETRM_YY||'-' || ETRM_MM
                             ORDER BY DATA_TYPE )
                    )
         SELECT '01'                                                                          AS LARGE_CATEGORY
              , '01'                                                                          AS SMALL_CATEGORY
              , '격리병동 환자현황'                                                             AS TITLE
              , '입실환자'                                                                     AS VALUE01_NAME
              , 'C'                                                                           AS VALUE01_TYPE
              , NVL(TO_CHAR(A.ETRM_PT_CNT), '0')                                              AS VALUE01  --입실
              , '재실환자'                                                                     AS VALUE02_NAME
              , 'C'                                                                           AS VALUE02_TYPE
              , NVL(TO_CHAR(CNT), '0')                                                        AS VALUE02  --재실
              , '평균재실일'                                                                   AS VALUE03_NAME
              , 'C'                                                                          AS VALUE03_TYPE
              ,  NVL(TO_CHAR(ROUND(DECODE(A.WHL_SIRM_DYS,NULL,0,A.WHL_SIRM_DYS) / DECODE((A.CHOT_PT_CNT), 0, NULL,(A.CHOT_PT_CNT)),1)),0)       AS VALUE03  --평균재실일
              , '연환자'                                                                      AS VALUE04_NAME
              , 'C'                                                                          AS VALUE04_TYPE
              , NVL(TO_CHAR(A.YY_PT_CNT), '0')                                               AS VALUE04  --연환자
              , '연병상'                                                                      AS VALUE05_NAME
              , 'C'                                                                          AS VALUE05_TYPE
              , NVL(TO_CHAR(A.YY_BED_CNT), '0')                                              AS VALUE05  --연병상
              , '병상가동률(%)'                                                               AS VALUE06_NAME
              , 'C'                                                                          AS VALUE06_TYPE
              , NVL(TRIM(TO_CHAR((DECODE(A.YY_PT_CNT,NULL,0,A.YY_PT_CNT) /DECODE(A.YY_BED_CNT,0,NULL,A.YY_BED_CNT))*100,'99990.9')), '0')    AS VALUE06  --병상가동률
              , ''                                                                          AS VALUE07_NAME
              , ''                                                                          AS VALUE07_TYPE
              , ''                                                                          AS VALUE07
           FROM (
                     SELECT SUM(ETRM_PT_CNT)       AS ETRM_PT_CNT      
                         , SUM(YY_PT_CNT)          AS YY_PT_CNT
                         , SUM(YY_BED_CNT)         AS YY_BED_CNT
                         , SUM(WHL_SIRM_DYS)       AS WHL_SIRM_DYS
                         , SUM(CHOT_PT_CNT)        AS CHOT_PT_CNT
                      FROM SDATA_ISO) A
               , (SELECT SUM(CNT) CNT FROM (SELECT 1 CNT FROM SDATA_SIRM GROUP BY PACT_ID) ) B
         UNION ALL
         SELECT '02'                                                                         AS LARGE_CATEGORY
              , '01'                                                                         AS SMALL_CATEGORY
              , '재실시간별 재실환자'                                                           AS TITLE
              , COMN_CD_NM                                                                   AS VALUE01_NAME
              , 'C'                                                                          AS VALUE01_TYPE
              , NVL(TO_CHAR(COUNT), 0)                                                       AS VALUE01
              , ''                                                                           AS VALUE02_NAME
              , ''                                                                           AS VALUE02_TYPE
              , ''                                                                           AS VALUE02
              , ''                                                                           AS VALUE03_NAME
              , ''                                                                           AS VALUE03_TYPE
              , ''                                                                           AS VALUE03
              , ''                                                                           AS VALUE04_NAME
              , ''                                                                           AS VALUE04_TYPE
              , ''                                                                           AS VALUE04
              , ''                                                                           AS VALUE05_NAME
              , ''                                                                           AS VALUE05_TYPE
              , ''                                                                           AS VALUE05
              , ''                                                                           AS VALUE06_NAME
              , ''                                                                           AS VALUE06_TYPE
              , ''                                                                           AS VALUE06
              , ''                                                                           AS VALUE07_NAME
              , ''                                                                           AS VALUE07_TYPE
              , ''                                                                           AS VALUE07
           FROM (
        		 SELECT A.COMN_CD_NM,   NVL(TO_CHAR(B.COUNT), 0)  AS COUNT
        		   FROM HICU.UCCOCSTE A
        	          , (SELECT DECODE(BASE_CODE, 1, '1', 2, '2', 3, '3', 4, '4', 5, '5', 6, '6')   AS COMN_CD
                              , DECODE(BASE_CODE, 1, SIRM_5_DY_IN_CNT,
                                                  2, SIRM_10_DY_IN_CNT,
                                                  3, SIRM_15_DY_IN_CNT,
                                                  4, SIRM_20_DY_IN_CNT,
                                                  5, SIRM_25_DY_IN_CNT,
                                                  6, SIRM_25_TM_EXCS_CNT)                           AS COUNT
                           FROM (
        				         SELECT SUM(SIRM_5_DY_IN_CNT)    AS SIRM_5_DY_IN_CNT
                                      ,	SUM(SIRM_10_DY_IN_CNT)   AS SIRM_10_DY_IN_CNT
                                      ,	SUM(SIRM_15_DY_IN_CNT)   AS SIRM_15_DY_IN_CNT
                                      ,	SUM(SIRM_20_DY_IN_CNT)   AS SIRM_20_DY_IN_CNT
                                      ,	SUM(SIRM_25_DY_IN_CNT)   AS SIRM_25_DY_IN_CNT
                                      ,	SUM(SIRM_25_TM_EXCS_CNT) AS SIRM_25_TM_EXCS_CNT
        				           FROM SDATA_ISO)
                     , (SELECT LEVEL BASE_CODE FROM DUAL CONNECT BY LEVEL <7)) B
                         WHERE A.COMN_GRP_CD = 'IC017'
        	               AND A.HSP_TP_CD = IN_HSP_TP_CD
        	               AND A.COMN_CD = B.COMN_CD
                         ORDER BY SORT_SEQ)             
         UNION ALL
         SELECT LARGE_CATEGORY
              , SMALL_CATEGORY
              , TITLE
              , VALUE01_NAME
              , VALUE01_TYPE
              , VALUE01
              , VALUE02_NAME
              , VALUE02_TYPE
              , VALUE02
              , ''                                                                           AS VALUE03_NAME
              , ''                                                                           AS VALUE03_TYPE
              , ''                                                                           AS VALUE03
              , ''                                                                           AS VALUE04_NAME
              , ''                                                                           AS VALUE04_TYPE
              , ''                                                                           AS VALUE04
              , ''                                                                           AS VALUE05_NAME
              , ''                                                                           AS VALUE05_TYPE
              , ''                                                                           AS VALUE05
              , ''                                                                           AS VALUE06_NAME
              , ''                                                                           AS VALUE06_TYPE
              , ''                                                                           AS VALUE06
              , ''                                                                           AS VALUE07_NAME
              , ''                                                                           AS VALUE07_TYPE
              , ''                                                                           AS VALUE07
          FROM (
                SELECT '03'                                         AS LARGE_CATEGORY
                     , '01'                                         AS SMALL_CATEGORY
                     , '성별/연령대별 재실환자'                        AS TITLE
                     ,  TYPE_CD                                     AS VALUE01_NAME
                     , 'D0'                                         AS VALUE01_TYPE
                     ,  NVL(TO_CHAR(SUM(CNT)), '0')                 AS VALUE01
                     ,  TYPE_CD2                                    AS VALUE02_NAME
                     ,  'D1'                                        AS VALUE02_TYPE
                     ,  NVL(TO_CHAR(SUM(CNT2)), '0')                AS VALUE02
                     ,  1                                           AS SORT_SEQ
                 FROM ( SELECT SEX_TP_CD                            AS TYPE_CD
                             , 1                                    AS CNT
                             , 'F'                                  AS TYPE_CD2
                             , 0                                    AS CNT2
                          FROM SDATA_SIRM
                         WHERE SEX_TP_CD = 'M'
                         UNION ALL
                        SELECT 'M'                                 AS TYPE_CD
                             , 0                                   AS CNT
                             , SEX_TP_CD                           AS TYPE_CD2
                             , 1 CNT2
                         FROM SDATA_SIRM
                         WHERE SEX_TP_CD = 'F')
               GROUP BY TYPE_CD, TYPE_CD2
               UNION ALL
              SELECT '03'                                          AS LARGE_CATEGORY
                   , '02'                                          AS SMALL_CATEGORY
                   , '성별/연령대별 재실환자'                         AS TITLE
                   , COMN_CD_NM                                    AS VALUE01_NAME
                   , 'D0'                                          AS VALUE01_TYPE
                   , TO_CHAR(NVL(SUM(CNT), 0))                     AS VALUE01
                   , ''                                            AS VALUE02_NAME
                   , ''                                            AS VALUE02_TYPE
                   , '0'                                           AS VALUE02
                   , SORT_SEQ                                      AS SORT_SEQ
               FROM (
                      SELECT B.COMN_CD_NM                          AS COMN_CD_NM
                           , NVL(CNT,0)                            AS CNT
                           , B.SORT_SEQ
                        FROM (
                               SELECT CASE WHEN 0 <= AGE AND AGE < 20  THEN '1'
                     		              WHEN 20 <= AGE AND AGE < 30 THEN '2'
                     		              WHEN 30 <= AGE AND AGE < 40 THEN '3'
                     		              WHEN 40 <= AGE  AND AGE < 50 THEN '4'
                                          WHEN 50 <= AGE AND AGE < 60 THEN '5'
                     		              WHEN 60 <= AGE AND AGE  < 70 THEN '6'
                      		              WHEN 70 <= AGE  THEN '7'
                    		              ELSE NULL END       AS AGE_RANGE
                    		        , 1                       AS CNT
                    		     FROM SDATA_SIRM) A
                       	    , ( SELECT COMN_CD, COMN_CD_NM, SORT_SEQ
                                  FROM HICU.UCCOCSTE
                                 WHERE COMN_GRP_CD = 'IC016'
                                   AND HSP_TP_CD = IN_HSP_TP_CD)  B
                      WHERE  A.AGE_RANGE(+) = B.COMN_CD)
              GROUP BY COMN_CD_NM, SORT_SEQ
              ORDER BY SMALL_CATEGORY, SORT_SEQ)
         UNION ALL
         SELECT '04'                                                                        AS LARGE_CATEGORY
              , '01'                                                                        AS SMALL_CATEGORY
              , '전체 환자중증도 분류'                                                         AS TITLE
              , COMN_CD_NM                                                                   AS VALUE01_NAME
              , 'C'                                                                          AS VALUE01_TYPE
              , NVL(TO_CHAR(COUNT), 0)                                                       AS VALUE01
              , ''                                                                           AS VALUE02_NAME
              , ''                                                                           AS VALUE02_TYPE
              , ''                                                                           AS VALUE02
              , ''                                                                           AS VALUE03_NAME
              , ''                                                                           AS VALUE03_TYPE
              , ''                                                                           AS VALUE03
              , ''                                                                           AS VALUE04_NAME
              , ''                                                                           AS VALUE04_TYPE
              , ''                                                                           AS VALUE04
              , ''                                                                           AS VALUE05_NAME
              , ''                                                                           AS VALUE05_TYPE
              , ''                                                                           AS VALUE05
              , ''                                                                           AS VALUE06_NAME
              , ''                                                                           AS VALUE06_TYPE
              , ''                                                                           AS VALUE06
              , ''                                                                           AS VALUE07_NAME
              , ''                                                                           AS VALUE07_TYPE
              , ''                                                                           AS VALUE07
           FROM (
        		 SELECT A.COMN_CD_NM,   NVL(TO_CHAR(B.COUNT), 0) COUNT
        		   FROM HICU.UCCOCSTE A
        	          , (SELECT DECODE(BASE_CODE, 1, '1', 2, '2', 3, '3', 4, '4', 5, '5', 6, '6') COMN_CD
                              , DECODE(BASE_CODE, 1, PT_SILLM_CTG_1_GRP_CNT,
                                                    2, PT_SILLM_CTG_2_GRP_CNT,
                                                    3, PT_SILLM_CTG_3_GRP_CNT,
                                                    4, PT_SILLM_CTG_4_GRP_CNT,
                                                    5, PT_SILLM_CTG_5_GRP_CNT,
                                                    6, PT_SILLM_CTG_6_GRP_CNT)                AS COUNT
                           FROM (
        				         SELECT SUM(PT_SILLM_CTG_1_GRP_CNT) AS PT_SILLM_CTG_1_GRP_CNT
                                      ,	SUM(PT_SILLM_CTG_2_GRP_CNT) AS PT_SILLM_CTG_2_GRP_CNT
                                      ,	SUM(PT_SILLM_CTG_3_GRP_CNT) AS PT_SILLM_CTG_3_GRP_CNT
                                      ,	SUM(PT_SILLM_CTG_4_GRP_CNT) AS PT_SILLM_CTG_4_GRP_CNT
                                      ,	SUM(PT_SILLM_CTG_5_GRP_CNT) AS PT_SILLM_CTG_5_GRP_CNT
                                      ,	SUM(PT_SILLM_CTG_6_GRP_CNT) AS PT_SILLM_CTG_6_GRP_CNT
        				           FROM SDATA_ISO)
                   , (SELECT LEVEL BASE_CODE FROM DUAL CONNECT BY LEVEL <7)) B
        	           WHERE A.COMN_GRP_CD = 'IC010'
        	             AND A.HSP_TP_CD = IN_HSP_TP_CD
        	             AND A.COMN_CD = B.COMN_CD
                       ORDER BY SORT_SEQ)
          UNION ALL
          SELECT '05'                                                                      AS LARGE_CATEGORY
               , '01'                                                                      AS SMALL_CATEGORY
               , '감염미생물별 재실환자'                                                      AS TITLE
               , COMN_CD_NM                                                                AS VALUE01_NAME
               , 'C'                                                                       AS VALUE01_TYPE
               , NVL(TO_CHAR(CNT), '0')                                                    AS VALUE01
               , ''                                                                        AS VALUE02_NAME
               , ''                                                                        AS VALUE02_TYPE
               , ''                                                                        AS VALUE02
               , ''                                                                        AS VALUE03_NAME
               , ''                                                                        AS VALUE03_TYPE
               , ''                                                                        AS VALUE03
               , ''                                                                        AS VALUE04_NAME
               , ''                                                                        AS VALUE04_TYPE
               , ''                                                                        AS VALUE04
               , ''                                                                        AS VALUE05_NAME
               , ''                                                                        AS VALUE05_TYPE
               , ''                                                                        AS VALUE05
               , ''                                                                        AS VALUE06_NAME
               , ''                                                                        AS VALUE06_TYPE
               , ''                                                                        AS VALUE06
               , ''                                                                        AS VALUE07_NAME
               , ''                                                                        AS VALUE07_TYPE
               , ''                                                                        AS VALUE07
            FROM ( SELECT * 
                     FROM ( SELECT INFC_MCB_TP_CD, SUM(CNT)  AS CNT
                              FROM SDATA_SIRM
                             GROUP BY  INFC_MCB_TP_CD) A
		                , ( SELECT COMN_CD, COMN_CD_NM, SORT_SEQ
		                      FROM HICU.UCCOCSTE
		                     WHERE COMN_GRP_CD = 'IC015'
		                       AND HSP_TP_CD = IN_HSP_TP_CD
		                       AND USE_YN = 'Y'
		                     )  B
                    WHERE COMN_CD = INFC_MCB_TP_CD (+)           
                    ORDER BY SORT_SEQ)
          UNION ALL
          SELECT LARGE_CATEGORY                         AS LARGE_CATEGORY
               , SMALL_CATEGORY                         AS SMALL_CATEGORY
               , TITLE
               , VALUE01_NAME                           AS VALUE01_NAME
               , VALUE01_TYPE
               , VALUE01                                AS VALUE01
               , VALUE02_NAME                           AS VALUE02_NAME
               , VALUE02_TYPE
               , VALUE02                                AS VALUE02
               , VALUE03_NAME                           AS VALUE03_NAME
               , VALUE03_TYPE
               , VALUE03                                AS VALUE03
               , ''                                     AS VALUE04_NAME
               , ''                                     AS VALUE04_TYPE
               , ''                                     AS VALUE04
               , ''                                     AS VALUE05_NAME
               , ''                                     AS VALUE05_TYPE
               , ''                                     AS VALUE05
               , ''                                     AS VALUE06_NAME
               , ''                                     AS VALUE06_TYPE
               , ''                                     AS VALUE06
               , ''                                     AS VALUE07_NAME
               , ''                                     AS VALUE07_TYPE
               , ''                                     AS VALUE07
           FROM (
                  SELECT '06'                            AS LARGE_CATEGORY
                          , CODE                         AS SMALL_CATEGORY
                          , '재실환자/가동률추이'                AS TITLE
                          , DT                           AS VALUE01_NAME
                          , VALUE01_TYPE                 AS VALUE01_TYPE
                          , NVL(VALUE01, '0')            AS VALUE01
                          , DT                           AS VALUE02_NAME
                          , VALUE02_TYPE                 AS VALUE02_TYPE
                          , NVL(VALUE02, '0')            AS VALUE02
                          , DT                           AS VALUE03_NAME
                          , VALUE03_TYPE                 AS VALUE03_TYPE
                          , NVL(VALUE03, '0')          AS VALUE03
                     FROM (
                              SELECT '01'                                                                              AS SMALL_CATEGORY
                                   , '전년월평균'                                                                       AS VALUE01_NAME
                                   , 'D0'                                                                              AS VALUE01_TYPE
                                   , TO_CHAR(D1.YY_BED_CNT)                                                            AS VALUE01  --병상수
                                   , '전년월평균'                                                                       AS VALUE02_NAME
                                   , 'D0'                                                                              AS VALUE02_TYPE
                                   , TRIM(TO_CHAR(ROUND(D1.YY_PT_CNT/ DECODE(D1.COUNT,0,NULL,D1.COUNT),0)))            AS VALUE02           --환자수
                                   , '전년월평균'                                                                        AS VALUE03_NAME
                                   , 'D1'                                                                              AS VALUE03_TYPE
                                   , TRIM(TO_CHAR((D1.YY_PT_CNT/DECODE(D1.YY_BED_CNT ,0,NULL,D1.YY_BED_CNT ))*100,'99990.9')) AS VALUE03 --가동률
                                FROM BF_YEAR_MAN_DAYS D1
                               UNION ALL
                               SELECT '02'                                                                                    AS SMALL_CATEGORY
                                    , '당년월평균'                                                                             AS VALUE01_NAME
                                    , 'D0'                                                                                    AS VALUE01_TYPE
                                    , NVL(TO_CHAR(D1.YY_BED_CNT), '0')                                                        AS VALUE01
                                    , '당년월평균'                                                                             AS VALUE02_NAME
                                    , 'D0'                                                                                    AS VALUE02_TYPE
                                    , TRIM( NVL(TO_CHAR(ROUND(D1.YY_PT_CNT/ DECODE(D1.COUNT,0,NULL,D1.COUNT),0)), '0'))       AS VALUE02
                                    , '당년월평균'                                                                             AS VALUE03_NAME
                                    , 'D1'                                                                                   AS VALUE03_TYPE
                                    , TRIM(NVL(TO_CHAR((D1.YY_PT_CNT/DECODE(D1.YY_BED_CNT,0,NULL,D1.YY_BED_CNT))*100,'99990.9'), '0'))  AS VALUE03
                                 FROM YEAR_MAN_DAYS D1
                                UNION ALL
                               SELECT '03'                                                                                  AS SMALL_CATEGORY
                                    , '전년당월'                                                                             AS VALUE01_NAME
                                    , 'D0'                                                                                  AS VALUE01_TYPE
                                    , TO_CHAR(A.YY_BED_CNT)                                                                 AS VALUE01
                                    , '전년당월'                                                                             AS VALUE02_NAME
                                    , 'D0'                                                                                  AS VALUE02_TYPE
                                    , NVL(TO_CHAR(A.YY_PT_CNT), '0')                                                        AS VALUE02
                                    , '전년당월'                                                                             AS VALUE03_NAME
                                    , 'D1'                                                                                  AS VALUE03_TYPE
                                    , TRIM(NVL(TO_CHAR((A.YY_PT_CNT/DECODE(A.YY_BED_CNT ,0,NULL,A.YY_BED_CNT ))*100,'99990.9'), '0')) AS VALUE03
                                 FROM BF_MAN_DAYS A
                                UNION ALL
                               SELECT '04'                                                                                  AS SMALL_CATEGORY
                                    , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')                                    AS VALUE01_NAME
                                    , 'D0'                                                                                  AS VALUE01_TYPE
                                    , TO_CHAR(D1.YY_BED_CNT)                                                                AS VALUE01
                                    , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')                                    AS VALUE02_NAME
                                    , 'D0'                                                                                  AS VALUE02_TYPE
                                    , TO_CHAR(D1.YY_PT_CNT)                                                                 AS VALUE02
                                    , TO_CHAR(TO_DATE(D1.STATCS_DATA, 'YY-MM'), 'YY.MM')                                    AS VALUE03_NAME
                                    , 'D1'                                                                                  AS VALUE03_TYPE
                                    , TRIM(NVL(TO_CHAR((D1.YY_PT_CNT/DECODE(D1.YY_BED_CNT,0,NULL,D1.YY_BED_CNT))*100,'99990.9'), '0'))      AS VALUE03
                               FROM (
                                        SELECT A.DATA_TYPE                              AS STATCS_DATA
                                            , NVL(SUM(A.YY_BED_CNT), 0)                 AS YY_BED_CNT
                                            , NVL(SUM(A.YY_PT_CNT), 0)                  AS YY_PT_CNT
                                         FROM MAN_DAYS A
                                         GROUP BY DATA_TYPE
                                     ) D1 ) A
                        , (  SELECT '01' AS CODE, '전년월평균' AS DT FROM DUAL UNION ALL
                	         SELECT '02' AS CODE, '당년월평균' AS DT FROM DUAL UNION ALL
                	         SELECT '03' AS CODE, '전년당월'  AS DT FROM DUAL UNION ALL
                	         SELECT '04' AS CODE, TO_CHAR(ADD_MONTHS(IN_TO_DTE, 1- LEVEL ), 'YY.MM')   AS DT
                               FROM DUAL
                            CONNECT BY LEVEL - 1 <= 11 )         B
                  WHERE B.CODE = A.SMALL_CATEGORY(+)
                    AND B.DT =  A.VALUE01_NAME(+)
                  ORDER BY CODE, DT);
  END;

END PC_EICU_CENTER_ISOLATE_STATICS;
