
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_ODRPY_NONFACE" 

                          ( IN_PRMR_DTM           IN  DATE

                          , IN_MDRC_ID            IN  VARCHAR2

                          , IN_HSP_TP_CD          IN  VARCHAR2

                          , OUT_CURSOR            OUT SYS_REFCURSOR

                          , IO_ERR_YN             OUT VARCHAR2

                          , IO_ERR_MSG            OUT VARCHAR2

                          )

/**********************************************************************************************

*    SERVICENAME    : PC_EICU_SELECT_ODRPY_NONFACE

*    CREATEDATE     : 2021.04.07

*    Author         : 신솔

*    Description    : 타과의뢰 정보 비대면협진 데이터 조회

*    Change History : 2021.04.07, 신솔, 최초작성

**********************************************************************************************/

AS

    V_EPCN_CSLT_ID          NUMBER(22)     := 0;

    V_EPCN_CSLT_FOM_SEQ     NUMBER(22)     := 0;

BEGIN

    BEGIN

        SELECT NVL(MAX(TO_NUMBER(EPCN_CSLT_ID)), 0), NVL(MAX(EPCN_CSLT_FOM_SEQ), 0) + 1

          INTO V_EPCN_CSLT_ID, V_EPCN_CSLT_FOM_SEQ

          FROM HICU.UCOMCNSM

         WHERE MDRC_ID = IN_MDRC_ID

           AND LST_YN  = 'Y'

        ;

        

        EXCEPTION

            WHEN OTHERS THEN

                IO_ERR_YN  := 'Y';

                IO_ERR_MSG := '1) 관제센터협진ID 조회 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

            RETURN;

    END;

    

    IF V_EPCN_CSLT_ID = 0 THEN

        IF V_EPCN_CSLT_FOM_SEQ = 1 THEN

            BEGIN

                SELECT NVL(MAX(TO_NUMBER(EPCN_CSLT_ID)), 0) + 1

                  INTO V_EPCN_CSLT_ID

                  FROM HICU.UCOMCNSM

                ;

                

                EXCEPTION

                    WHEN OTHERS THEN

                        IO_ERR_YN  := 'Y';

                        IO_ERR_MSG := '2) 관제센터협진ID 생성 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                        RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                    RETURN;

            END;

        END IF;

    END IF;

    

    BEGIN

        OPEN OUT_CURSOR FOR

            SELECT ROWNUM                                                                     AS ROW_NUM

                 , TO_CHAR(V_EPCN_CSLT_ID)                                                    AS EPCN_CSLT_ID

                 , V_EPCN_CSLT_FOM_SEQ                                                        AS EPCN_CSLT_FOM_SEQ

                 , TRIM(SUBSTR(A.ODRER_PT_CLCTN_NM, 4, INSTR(A.ODRER_PT_CLCTN_NM, '실') - 5))  AS ODRER_PT_CLCTN_NM

                 , A.MED_DEPT_CD                                                              AS MED_DEPT_CD

                 , A.MED_DEPT_NM                                                              AS MED_DEPT_NM

                 , A.ODRER_MEDR_STF_NO                                                        AS ODRER_MEDR_STF_NO

                 , A.ODRER_MEDR_STF_NM                                                        AS ODRER_MEDR_STF_NM

                 , (SELECT MIN(X.ODRER_DTM)                                                   

                      FROM XICU.EMEI015V X                                                    

                     WHERE X.RPLY_YN            = 'Y'                                         

                       AND X.NONFACE_CONSULT_YN = 'Y'                                         

                       AND X.LSH_DTM            > IN_PRMR_DTM                                 

                       AND X.MDRC_ID            = IN_MDRC_ID)                                 AS CSLT_STR_DTM

                 , (SELECT MAX(X.RPLY_DTM)                                                    

                      FROM XICU.EMEI015V X                                                    

                     WHERE X.RPLY_YN            = 'Y'                                         

                       AND X.NONFACE_CONSULT_YN = 'Y'                                         

                       AND X.LSH_DTM            > IN_PRMR_DTM                                 

                       AND X.MDRC_ID            = IN_MDRC_ID)                                 AS CSLT_END_DTM

                 , A.PT_NO                                                                    AS PT_NO

                 , B.PT_NM                                                                    AS PT_NM

                 , A.PACT_ID                                                                  AS PACT_ID

                 , B.ADS_DT                                                                   AS ADS_DT

                 , B.SEX_TP_CD                                                                AS SEX_TP_CD

                 , B.AGE                                                                      AS AGE

                 , A.RPLY_DEPT_CD                                                             AS RPLY_DEPT_CD

                 , A.RPLY_DEPT_NM                                                             AS RPLY_DEPT_NM

                 , A.RPLY_MEDR_STF_NO                                                         AS RPLY_MEDR_STF_NO

                 , A.RPLY_MEDR_STF_NM                                                         AS RPLY_MEDR_STF_NM

                 , A.RPLY_CONTENTS                                                            AS RPLY_CONTENTS

                 , A.ODRER_DIAG                                                               AS ODRER_DIAG

                 , A.ODRER_CONTENTS                                                           AS RER_CNTE

                 , A.ODRPY_MDRC_ID                                                            AS ODRPY_MDRC_ID

              FROM XICU.EMEI015V A

                 , HICU.UICICRPM B

             WHERE A.RPLY_YN            = 'Y'

               AND A.NONFACE_CONSULT_YN = 'Y'

               AND A.MDRC_ID            = IN_MDRC_ID

               AND B.PACT_ID            = A.PACT_ID

               AND B.HSP_TP_CD          = IN_HSP_TP_CD

               AND (A.LSH_DTM           > IN_PRMR_DTM

                OR B.LST_LOD_DTM        > IN_PRMR_DTM)

            ;

            

            EXCEPTION

                WHEN OTHERS THEN

                    IO_ERR_YN  := 'Y';

                    IO_ERR_MSG := '3) 타과의뢰 정보 비대면협진 데이터 조회 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                RETURN;

    END;

END PC_EICU_SELECT_ODRPY_NONFACE;
