
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SEL_TEST_ITEM" ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   SYS_REFCURSOR )
IS

BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR
    select DETL_CD,
           DETL_CD_NM
    FROM BB_TEST_COUNT
    WHERE ITEM_TP_CD = IN_ITEM_TP_CD;

    END;

END PC_EICU_SEL_TEST_ITEM;
