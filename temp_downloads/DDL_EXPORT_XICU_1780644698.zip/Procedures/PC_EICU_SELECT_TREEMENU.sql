
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_TREEMENU" 
                          ( IN_EPCN_GRP_CD IN VARCHAR2
                          , IN_HSP_TP_CD IN VARCHAR2
                          , IN_PRGM_LCLS_CD IN VARCHAR2
                          , IN_PRGM_MCLS_CD IN VARCHAR2
                          , IN_USE_DEPT_CD IN VARCHAR2
                          , OUT_CURSOR OUT SYS_REFCURSOR )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_TREEMENU
*    CREATEDATE     : 2021.03.19
*    Author         : 이창우
*    Description    : 메뉴
*    Change History :  2021-07-08, 김국경, 39W 예외처리
**********************************************************************************************/
BEGIN
   BEGIN 
      OPEN OUT_CURSOR FOR
         SELECT TREEINF.EPCN_GRP_CD
              , TREEINF.SCR_MENU_ID
              , TREEINF.MENU_HSP_TP_CD
              , TREEINF.DEPT_CD
              , TREEINF.MENU_NM 
              , TREEINF.MENU_DPTH 
              , TREEINF.MENU_UP_ID
              , CSTM.UI_PATH_NM 
           FROM (
                 SELECT MAINDAT.EPCN_GRP_CD
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y'
                             THEN CASE WHEN DEPTINF.HSP_TP_CD IS NULL
                                       THEN TO_CHAR(MAINDAT.MENU_ID)
                                       ELSE TO_CHAR(MAINDAT.MENU_ID)||'_'||DEPTINF.DEPT_CD
                                  END
                             ELSE TO_CHAR(MAINDAT.MENU_ID)
                        END SCR_MENU_ID
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y' 
                             THEN CASE WHEN MAINDAT.MENU_HSP_TP_CD = DEPTINF.HSP_TP_CD OR DEPTINF.HSP_TP_CD IS NULL
                                       THEN 'Y'
                                       ELSE 'N'
                                  END
                             ELSE 'Y'
                        END USE_TP
                      , MAINDAT.MENU_HSP_TP_CD
                      , DEPTINF.DEPT_CD
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y'
                             THEN CASE WHEN DEPTINF.HSP_TP_CD IS NULL
                                       THEN MAINDAT.MENU_NM
                                       ELSE DEPTINF.DEPT_NM
                                  END
                             ELSE MAINDAT.MENU_NM 
                        END MENU_NM
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y'
                             THEN CASE WHEN DEPTINF.HSP_TP_CD IS NULL
                                       THEN MAINDAT.MENU_DPTH
                                       ELSE MAINDAT.MENU_DPTH + 1
                                  END
                             ELSE MAINDAT.MENU_DPTH
                        END MENU_DPTH
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y'
                             THEN CASE WHEN DEPTINF.HSP_TP_CD IS NULL
                                       THEN TO_CHAR(MAINDAT.UPR_ID)
                                       ELSE TO_CHAR(MAINDAT.MENU_ID)
                                  END
                             ELSE TO_CHAR(MAINDAT.UPR_ID)
                        END MENU_UP_ID
                      , CASE WHEN MAINDAT.LWR_DEPT_USE_YN = 'Y'
                             THEN CASE WHEN DEPTINF.HSP_TP_CD IS NULL
                                       THEN MAINDAT.URL_ID
                                       ELSE MAINDAT.LWR_URL_ID
                                  END
                             ELSE MAINDAT.URL_ID
                        END MENU_URL_ID
                   FROM (
                          SELECT MNGD.EPCN_GRP_CD 
                                , MNTD.MENU_ID 
                                , MNTD.MENU_NM
                                , MNTD.MENU_DPTH 
                                , MNTD.UPR_ID
                                , MNTD.LWR_DEPT_USE_YN 
                                , MNTD.MENU_HSP_TP_CD
                                , MNTD.URL_ID 
                                , MNTD.LWR_URL_ID 
                            FROM HICU.UCCOMNGD MNGD
                                , HICU.UCCOMNTD MNTD
                           WHERE MNGD.MENU_GRP_ID = MNTD.MENU_GRP_ID 
                             AND MNGD.EPCN_GRP_CD = NVL(IN_EPCN_GRP_CD, MNGD.EPCN_GRP_CD)
                             AND MNGD.HSP_TP_CD = NVL(IN_HSP_TP_CD, 'A')
                             AND MNGD.PRGM_LCLS_CD = IN_PRGM_LCLS_CD
                             AND MNGD.PRGM_MCLS_CD = IN_PRGM_MCLS_CD
                             AND MNGD.USE_DEPT_CD = NVL(IN_USE_DEPT_CD, 'A')
                           START WITH UPR_ID = 0
                         CONNECT BY PRIOR MNTD.MENU_ID = MNTD.UPR_ID 
                        ) MAINDAT
                   FULL OUTER JOIN (
                                    SELECT TMP0.HSP_TP_CD, TMP0.DEPT_CD, TMP0.DEPT_NM, TMP0.SORT_SEQ
                                      FROM (
                                            SELECT '' HSP_TP_CD, '' DEPT_CD, '' DEPT_NM, 0 SORT_SEQ
                                              FROM DUAL
                                            UNION ALL
                                            SELECT DAT1.HSP_TP_CD, DAT1.DEPT_CD, DAT1.DEPT_NM, DAT1.SORT_SEQ
                                              FROM HICU.UCCOCDPM DAT1
                                             WHERE DAT1.USE_YN = 'Y'
                                               AND DAT1.DEPT_CD != '039' /* 2021-07-08, 김국경, 39W 제외 : 마스터에서 제외할 수 없기 때문에 예외처리 */
                                           ) TMP0
                                     ORDER BY TMP0.SORT_SEQ
                                   ) DEPTINF
                                ON MAINDAT.LWR_DEPT_USE_YN = 'Y'
                ) TREEINF
              , HICU.UCCOCSTM CSTM
          WHERE TREEINF.USE_TP = 'Y'
            AND TREEINF.SCR_MENU_ID IS NOT NULL
            AND TREEINF.MENU_URL_ID = CSTM.STCI_CD (+);
   END;
END PC_EICU_SELECT_TREEMENU;
