
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SAVE_LOGIN_HISTORY" 

                          ( IN_HSP_TP_CD          IN  VARCHAR2 -- 병원구분코드

                          , IN_HIS_STF_NO         IN  VARCHAR2 -- HIS직원번호

                          , IN_USR_NM             IN  VARCHAR2 -- HIS사용자명

                          , IN_PRGM_LCLS_CD       IN  VARCHAR2 -- 프로그램대분류코드

                          , IN_EPCN_YN            IN  VARCHAR2 -- 관제센터여부

                          , IN_WD_DEPT_CD         IN  VARCHAR2 -- 병동부서코드

                          , IN_LGIN_DTM           IN  DATE     -- 로그인 일시

                          , IN_LGOT_DTM           IN  DATE     -- 로그아웃 일시

                          , IN_HIS_PRGM_NM        IN  VARCHAR2 -- 사용프로그램 명

                          , IN_HIS_IP_ADDR        IN  VARCHAR2 -- 사용자 PC IP 

                          , IO_ERR_YN             OUT VARCHAR2

                          , IO_ERR_MSG            OUT VARCHAR2

                          )

/**********************************************************************************************

*    SERVICENAME    : PC_EICU_SAVE_LOGIN_HISTORY

*    CREATEDATE     : 2021.04.09

*    Author         : 신솔

*    Description    : 로그인/아웃 이력 저장

*    Change History : 2021.04.09, 신솔, 최초작성

**********************************************************************************************/

AS

    V_USR_LGIN_ID           NUMBER(22)     := 0;

    V_USR_YN                VARCHAR(2);

BEGIN

    -- 로그인 이력 INSERT

    IF IN_LGOT_DTM IS NULL THEN

        BEGIN

            SELECT DECODE(COUNT(*), 0, 'N', 'Y')

              INTO V_USR_YN

              FROM HICU.UCCOCULH

             WHERE HSP_TP_CD    = IN_HSP_TP_CD

               AND HIS_STF_NO   = IN_HIS_STF_NO

               AND LGIN_IP_ADDR = IN_HIS_IP_ADDR

               AND LGOT_DTM     IS NULL

            ;

            

            EXCEPTION

                WHEN OTHERS THEN

                    IO_ERR_YN  := 'Y';

                    IO_ERR_MSG := '1) 사용자로그인 이력 조회 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                RETURN;

        END;

        

        IF V_USR_YN = 'N' THEN -- 동일한 ID, IP 로 로그인한 이력 없을 경우 INSERT (비정상 종료된 경우 추가 INSERT 방지)

            BEGIN

                BEGIN

                    SELECT NVL(MAX(TO_NUMBER(A.USR_LGIN_ID)), 0) + 1

                      INTO V_USR_LGIN_ID

                      FROM HICU.UCCOCULH A

                    ;

            

                    EXCEPTION

                        WHEN OTHERS THEN

                            IO_ERR_YN  := 'Y';

                            IO_ERR_MSG := '2) 사용자로그인ID 생성 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                            RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                        RETURN;

                END;

                

                BEGIN

                    INSERT 

                      INTO HICU.UCCOCULH

                         ( USR_LGIN_ID

                         , HSP_TP_CD

                         , HIS_USR_SID

                         , HIS_STF_NO

                         , PRGM_LCLS_CD

                         , EPCN_YN

                         , WD_DEPT_CD

                         , LGIN_IP_ADDR

                         , LGIN_DTM

                         , LGOT_DTM

                         , USR_SID

                         , USR_NM

                         , FSR_STF_NO

                         , FSR_DTM

                         , FSR_PRGM_NM

                         , FSR_IP_ADDR

                         , LSH_STF_NO

                         , LSH_DTM

                         , LSH_PRGM_NM

                         , LSH_IP_ADDR

                         )

                    VALUES 

                         ( TO_CHAR(V_USR_LGIN_ID)

                         , IN_HSP_TP_CD

                         , NULL

                         , IN_HIS_STF_NO

                         , IN_PRGM_LCLS_CD

                         , IN_EPCN_YN

                         , IN_WD_DEPT_CD

                         , IN_HIS_IP_ADDR

                         , SYSDATE

                         , NULL

                         , NULL

                         , IN_USR_NM

                         , IN_HIS_STF_NO

                         , SYSDATE

                         , IN_HIS_PRGM_NM

                         , IN_HIS_IP_ADDR

                         , IN_HIS_STF_NO

                         , SYSDATE

                         , IN_HIS_PRGM_NM

                         , IN_HIS_IP_ADDR

                         )

                    ;

            

                    EXCEPTION

                        WHEN OTHERS THEN

                            IO_ERR_YN  := 'Y';

                            IO_ERR_MSG := '3) 사용자로그인이력 추가 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                            RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                        RETURN; 

                END;

            END;

        END IF;

    -- 로그아웃 이력 UPDATE

    ELSE

        BEGIN

            UPDATE HICU.UCCOCULH A

               SET A.LGOT_DTM     = IN_LGOT_DTM

                 , A.LSH_STF_NO   = IN_HIS_STF_NO

                 , A.LSH_DTM      = SYSDATE

                 , A.LSH_PRGM_NM  = IN_HIS_PRGM_NM

                 , A.LSH_IP_ADDR  = IN_HIS_IP_ADDR

             WHERE A.HIS_STF_NO   = IN_HIS_STF_NO

               AND A.LGIN_IP_ADDR = IN_HIS_IP_ADDR

               AND A.USR_LGIN_ID  = (SELECT MAX(TO_NUMBER(X.USR_LGIN_ID)) 

                                       FROM HICU.UCCOCULH X

                                      WHERE X.HIS_STF_NO   = IN_HIS_STF_NO

                                        AND X.LGIN_IP_ADDR = IN_HIS_IP_ADDR)

            ;

            

            EXCEPTION

                WHEN OTHERS THEN

                    IO_ERR_YN  := 'Y';

                    IO_ERR_MSG := '4) 사용자로그인이력 갱신 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);

                    RAISE_APPLICATION_ERROR(-20001, IO_ERR_MSG);

                RETURN; 

        END;

    END IF;

END PC_EICU_SAVE_LOGIN_HISTORY;
