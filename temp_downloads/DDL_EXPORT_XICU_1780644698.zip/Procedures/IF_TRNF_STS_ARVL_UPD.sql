
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_STS_ARVL_UPD" (
                            IN_VNDR                IN  VARCHAR2
                          , IN_CLNTIP              IN  VARCHAR2
                          , IN_USERID              IN  VARCHAR2
                          , IN_HSPTID              IN  VARCHAR2
																							   , IN_HSP_TP_CD           IN  VARCHAR2
																							   , IN_SEQ                 IN  NUMBER
																							   , IN_PT_NO               IN  VARCHAR2
																							   , IN_PACT_ID             IN  VARCHAR2
																							   , IN_XFER_END_DT    		   IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD    IN  VARCHAR2
																							   , IN_STATUS_STS_CD       IN  VARCHAR2
																							   , IN_LSH_DTM             IN  VARCHAR2
																							   , IN_LSH_IP_ADDR         IN  VARCHAR2
																							   , IN_LSH_STF_NO          IN  VARCHAR2
																							   , IN_LSH_STF_NM          IN  VARCHAR2
																							   , IN_LSH_PRGM_NM         IN  VARCHAR2
																							   , OUT_CURSOR             OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
/**********************************************************************************************
*    SERVICENAME    : PC_TRNF_STS_ARVL_UPD
*    CREATEDATE     : 2025.08.20
*    Author         : 윤재림
*    Description    : EICU 환자이송종료
*    Change History :
**********************************************************************************************/
BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE ARPA_PT_LIST
       SET TRNF_PRGR_STS_CD    = IN_TRNF_PRGR_STS_CD
         , STATUS_STS_CD       = IN_STATUS_STS_CD
         , XFER_END_DT 				 = TO_DATE(IN_XFER_END_DT,'YYYYMMDDHH24:MI:SS')
         , LSH_DTM             = TO_DATE(IN_LSH_DTM,'YYYYMMDDHH24:MI:SS')
         , LSH_IP_ADDR         = IN_LSH_IP_ADDR
         , LSH_STF_NO          = IN_LSH_STF_NO
         , LSH_STF_NM          = IN_LSH_STF_NM
         , LSH_PRGM_NM         = IN_LSH_PRGM_NM
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
