
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_REGION_SUMMARY" 
                          ( IN_FROM_DTE      IN  DATE
                          , IN_TO_DTE        IN  DATE     
                          , IN_EPCN_GRP_CD   IN VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )    
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_REGION_SUMMARY                                               
*    CREATEDATE     : 2021.02.24                                                               
*    Author         : 오지민                                                                     
*    Description    : 통합관제 임상지표 권역별 병원통합지표현황
*    Change History : 2021.02.24, 오지민, 최초작성                                                
**********************************************************************************************/
BEGIN
    BEGIN 
	    OPEN OUT_CURSOR FOR   
	        /*중환자실 현황(실시간 데이터 및 재실환자 제외) 및 환자중증도 분류*/
	        WITH SDATA_ICU AS(
                    SELECT ETRM_PT_CNT
			             , CHOT_PT_CNT 
			             , WHL_SIRM_DYS
			             , YY_PT_CNT
			             , YY_BED_CNT
--			             , PT_SILLM_CTG_1_GRP_CNT
--			             , PT_SILLM_CTG_2_GRP_CNT
--			             , PT_SILLM_CTG_3_GRP_CNT
--			             , PT_SILLM_CTG_4_GRP_CNT
--			             , PT_SILLM_CTG_5_GRP_CNT
--			             , PT_SILLM_CTG_6_GRP_CNT
			          FROM HICU.UCCICSPM A
			         WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD) 
--			           AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN TRUNC(IN_FROM_DTE) AND TRUNC(IN_TO_DTE)
			           AND ETRM_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                	        )   
             /*중환자실 현황(재실환자)*/
             , SDATA_ICU_SIRM AS
	           (
	               SELECT COUNT(*) CNT
	                 FROM XICU.UICICSPV
	                WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD) 
	                  AND (ETRM_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE + 0.99999  OR
--	                       DECODE(CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),CHOT_DTM) BETWEEN IN_FROM_DTE AND IN_TO_DTE OR
	                       NVL(CHOT_DTM, SYSDATE) BETWEEN IN_FROM_DTE AND IN_TO_DTE + 0.99999 OR
	                      (ETRM_DTM < IN_FROM_DTE AND NVL(CHOT_DTM, SYSDATE) > IN_TO_DTE))
	                GROUP BY  PACT_ID       
	           )
	         /*격리병동(039병동) 환자현황*/ --2021-05-20 한가혜 추가  
	         , SDATA_ISO AS(
                    SELECT ETRM_PT_CNT
			             , CHOT_PT_CNT 
			             , WHL_SIRM_DYS
			             , YY_PT_CNT
			             , YY_BED_CNT
			          FROM HICU.UCCIISPM A
			         WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD) 
--			           AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY,'YYYY-MM-DD') BETWEEN TRUNC(IN_FROM_DTE) AND TRUNC(IN_TO_DTE)
                       AND ETRM_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                	        ) 
             /*격리병동(039병동) 현황(재실환자)*/ --2021-05-20 한가혜 추가
             , SDATA_ISO_SIRM AS
	           (
	               SELECT COUNT(*) CNT
	                 FROM XICU.UICIISPV
	                WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD) 
	                  AND (ETRM_DTM BETWEEN IN_FROM_DTE AND IN_TO_DTE + 0.99999  OR
--	                       DECODE(CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'),TRUNC(SYSDATE),CHOT_DTM) BETWEEN IN_FROM_DTE AND IN_TO_DTE OR
	                       NVL(CHOT_DTM, SYSDATE) BETWEEN IN_FROM_DTE AND IN_TO_DTE + 0.99999 OR
	                      (ETRM_DTM < IN_FROM_DTE AND NVL(CHOT_DTM, SYSDATE) > IN_TO_DTE))
	                GROUP BY  PACT_ID       
	           )   	           
	           /*재입실현황*/   	         
             , RE_IN_DATA AS (

                 SELECT A.RPT_ETRM_PT_CNT
                      , B.CHOT_PT_CNT    
                      , A.RPT_ETRM_24_TM_IN_CNT  
                      , A.RPT_ETRM_48_TM_IN_CNT 
                      , A.RPT_ETRM_72_TM_IN_CNT
                      , A.RPT_ETRM_72_TM_EXCS_CNT
                 FROM (SELECT SUM(X.RPT_ETRM_PT_CNT)           AS RPT_ETRM_PT_CNT
                            , SUM(X.RPT_ETRM_24_TM_IN_CNT)     AS RPT_ETRM_24_TM_IN_CNT  
                            , SUM(X.RPT_ETRM_48_TM_IN_CNT)     AS RPT_ETRM_48_TM_IN_CNT  
                            , SUM(X.RPT_ETRM_72_TM_IN_CNT)     AS RPT_ETRM_72_TM_IN_CNT  
                            , SUM(X.RPT_ETRM_72_TM_EXCS_CNT)   AS RPT_ETRM_72_TM_EXCS_CNT    
                         FROM HICU.UCCICSRM X                                       
                        WHERE X.TH2_ETRM_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                          AND X.HSP_TP_CD       IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD)                                                             
                        ) A        
                    , (SELECT SUM(Y.CHOT_PT_CNT) AS CHOT_PT_CNT
                         FROM HICU.UCCICSOD Y                  
                        WHERE Y.CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                          AND Y.HSP_TP_CD   IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD)                                                              
                        ) B                                                                                            
                 )
             , CHARTGUB AS (   
                 /* 차트 구분 공통코드 */  
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD    
                      , A.COMN_CD_NM   AS COMN_CD_NM 
                   FROM (
                         SELECT 'TIME_TYPE' AS COMN_GRP_CD, '1' AS COMN_CD, '24시간'|| chr(13) || ' 이내' AS COMN_CD_NM FROM DUAL UNION ALL
                         SELECT 'TIME_TYPE', '2', '24~48'|| chr(13) || ' 시간' FROM DUAL UNION ALL                                        
                         SELECT 'TIME_TYPE', '3', '48~72'|| chr(13) || ' 시간' FROM DUAL UNION ALL                                        
                         SELECT 'TIME_TYPE', '4', '72시간'|| chr(13) || ' 초과' FROM DUAL  ) A                                            
--                  ORDER BY A.COMN_GRP_CD
                  UNION ALL 
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD    
                      , A.COMN_CD_NM   AS COMN_CD_NM 
                   FROM (
                         SELECT 'RATE_PERIOD' AS COMN_GRP_CD, '01' AS COMN_CD, TO_CHAR(IN_TO_DTE - 20, 'MM.DD') || '~' || TO_CHAR(IN_TO_DTE -14, 'MM.DD')  AS COMN_CD_NM FROM DUAL UNION ALL
                         SELECT 'RATE_PERIOD', '02', TO_CHAR(IN_TO_DTE - 13, 'MM.DD') || '~' || TO_CHAR(IN_TO_DTE - 7, 'MM.DD')  FROM DUAL UNION ALL                                        
                         SELECT 'RATE_PERIOD', '03', TO_CHAR(IN_TO_DTE - 6, 'MM.DD') || '~' || TO_CHAR(IN_TO_DTE, 'MM.DD')  FROM DUAL  ) A                                            
                  ORDER BY COMN_GRP_CD 
                 )
          /*사망률 현황*/       
         , DIE_DATA AS ( 
                SELECT DTH_PT_CNT
		             , CHOT_PT_CNT
		             , PT_SILLM_CTG_1_GRP_CNT
		             , PT_SILLM_CTG_2_GRP_CNT
		             , PT_SILLM_CTG_3_GRP_CNT
		             , PT_SILLM_CTG_4_GRP_CNT
		             , PT_SILLM_CTG_5_GRP_CNT
		             , PT_SILLM_CTG_6_GRP_CNT
		          FROM HICU.UCCICSDM A
		         WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y') 
--			           AND TO_DATE(CHOT_YY || CHOT_MM || CHOT_DY, 'YYYY-MM-DD') BETWEEN TRUNC(IN_FROM_DTE) AND TRUNC(IN_TO_DTE)
			           AND CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
         ) 
         /*실시간 데이터*/      
         , REALTIME_DATA AS (
		        SELECT SUM(USE_WD_CNT)          AS USE_WD_CNT
		             , SUM(ISLT_USE_WD_CNT)     AS ISLT_USE_WD_CNT
		             , SUM(EMPT_WD_CNT)         AS EMPT_WD_CNT
		             , SUM(ISLT_EMPT_WD_CNT)    AS ISLT_EMPT_WD_CNT
		             , SUM(IN_WD_CNT)           AS IN_WD_CNT
		             , SUM(OUT_WD_CNT)          AS OUT_WD_CNT
		          FROM XICU.EMEI001V  --실시간 중환자실병상정보
                 WHERE WD_DEPT_CD IN (SELECT DEPT_CD   FROM HICU.UCCOCDPM --부서기본(중환자실 코드만 있음) 
                                                      WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y') 
                                                        AND USE_YN = 'Y') --2021-05-20 한가혜 격리병상(039) 추가
		        )              
--		 /*최근 병상 가동률*/       
		 , RECENTLY_BED_RATE  AS
		 (  		 	
			 SELECT A.CODE_TYPE
			      , NVL(SUM(A.YY_PT_CNT), 0) + NVL(SUM(B.YY_PT_CNT), 0)              AS YY_PT_CNT--연인원
			      , NVL(SUM(A.YY_BED_CNT), 0) + NVL(SUM(B.YY_BED_CNT), 0)            AS YY_BED_CNT--연병상수
			   FROM (
			           SELECT '01'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCICSPM   --중환자실환자지표기본
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 20  AND IN_TO_DTE - 14
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE)                          
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 20 , 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE - 14, 'YYYYMMDD') 
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')

			           UNION ALL
			           
			           SELECT '02'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCICSPM   --중환자실환자지표기본 
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 13  AND IN_TO_DTE - 7
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE)  
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 13 , 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE - 7, 'YYYYMMDD') 
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')
			           
			           UNION ALL
			           
			           SELECT '03'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCICSPM   --중환자실환자지표기본
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 6  AND IN_TO_DTE
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE))   
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 6, 'YYYYMMDD')   AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')
			      ) A
			      , ( 
			           SELECT '01'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCIISPM   --격리병동환자지표기본
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 20  AND IN_TO_DTE - 14
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE)                          
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 20 , 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE - 14, 'YYYYMMDD') 
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')

			           UNION ALL 
			           
			           SELECT '02'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCIISPM   --격리병동환자지표기본
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 13  AND IN_TO_DTE - 7
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE)  
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 13 , 'YYYYMMDD') AND TO_CHAR(IN_TO_DTE - 7, 'YYYYMMDD') 
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')
			           
			           UNION ALL
			           
			           SELECT '03'                                    AS CODE_TYPE
			                , NVL(SUM(YY_PT_CNT), 0)                  AS YY_PT_CNT--연인원
			                , NVL(SUM(YY_BED_CNT), 0)                 AS YY_BED_CNT--연병상수
			            FROM HICU.UCCIISPM   --격리병동환자지표기본
			           WHERE HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') BETWEEN  IN_TO_DTE - 6  AND IN_TO_DTE
--			             AND TO_DATE(ETRM_YY || ETRM_MM || ETRM_DY, 'YYYY-MM-DD') <= TRUNC(SYSDATE))   
			             AND ETRM_DT_SEQ BETWEEN  TO_CHAR(IN_TO_DTE - 6, 'YYYYMMDD')   AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
			             AND ETRM_DT_SEQ <= TO_CHAR(SYSDATE, 'YYYYMMDD')
			      ) B
			  WHERE A.CODE_TYPE = B.CODE_TYPE    
		   GROUP BY A.CODE_TYPE 
		 )                                                                                           
  	    SELECT  '01'                                                                         LARGE_CATEGORY
	          , '02'                                                                         SMALL_CATEGORY
	          , '중환자실 환자현황'                                                          TITLE
	          , '입실환자'                                                                   VALUE01_NAME
	          , 'C'                                                                          VALUE01_TYPE
	          , NVL(TO_CHAR(A.ETRM_PT_CNT), '0')                                             VALUE01  --입실
	          , '재실환자'                                                                   VALUE02_NAME
	          , 'C'                                                                          VALUE02_TYPE
	          , NVL(TO_CHAR(B.SIRM_PT_CNT), '0')                                             VALUE02  --재실
	          , '평균재실일'                                                                 VALUE03_NAME
	          , 'C'                                                                          VALUE03_TYPE
	          ,  NVL(TO_CHAR(ROUND(A.WHL_SIRM_DYS / DECODE((A.CHOT_PT_CNT), 0, NULL,(A.CHOT_PT_CNT)),1)),0)       VALUE03  --평균재실일
	          , '연환자'                                                                     VALUE04_NAME
	          , 'C'                                                                          VALUE04_TYPE
	          , NVL(TO_CHAR(A.YY_PT_CNT), '0')                                               VALUE04  --연환자
	          , '연병상'                                                                     VALUE05_NAME
	          , 'C'                                                                          VALUE05_TYPE
	          , NVL(TO_CHAR(A.YY_BED_CNT), '0')                                              VALUE05  --연병상
	          , '병상가동률(%)'                                                              VALUE06_NAME
              , 'C'                                                                          VALUE06_TYPE
	          , TRIM(NVL(TO_CHAR((DECODE(A.YY_PT_CNT,NULL,0,A.YY_PT_CNT) /DECODE(A.YY_BED_CNT,0,NULL,A.YY_BED_CNT))*100,'99990.9'), '0'))   VALUE06  --병상가동률
	          , ''                                                                       AS VALUE07_NAME
	          , ''                                                                       AS VALUE07_TYPE
	          , ''                                                                       AS VALUE07	          
	       FROM (SELECT SUM(X.ETRM_PT_CNT)     AS ETRM_PT_CNT
                      , SUM(X.YY_PT_CNT)       AS YY_PT_CNT
                      , SUM(X.YY_BED_CNT)      AS YY_BED_CNT
                      , SUM(X.WHL_SIRM_DYS)    AS WHL_SIRM_DYS
                      , SUM(X.CHOT_PT_CNT)     AS CHOT_PT_CNT
	               FROM (SELECT SUM(A.ETRM_PT_CNT)     AS ETRM_PT_CNT
                              , SUM(A.YY_PT_CNT)       AS YY_PT_CNT
                              , SUM(A.YY_BED_CNT)      AS YY_BED_CNT
                              , SUM(A.WHL_SIRM_DYS)    AS WHL_SIRM_DYS
                              , SUM(A.CHOT_PT_CNT)     AS CHOT_PT_CNT
                           FROM SDATA_ICU A
                      UNION ALL
                         SELECT SUM(B.ETRM_PT_CNT)    AS ETRM_PT_CNT
                              , SUM(B.YY_PT_CNT)      AS YY_PT_CNT
                              , SUM(B.YY_BED_CNT)     AS YY_BED_CNT
                              , SUM(B.WHL_SIRM_DYS)   AS WHL_SIRM_DYS
                              , SUM(B.CHOT_PT_CNT)    AS CHOT_PT_CNT
                           FROM SDATA_ISO B
                      ) X
              ) A
              , (SELECT SUM(X.SIRM_PT_CNT)           AS SIRM_PT_CNT
	               FROM (SELECT SUM(A.CNT)                    AS SIRM_PT_CNT
                           FROM SDATA_ICU_SIRM A
                      UNION ALL
                         SELECT SUM(B.CNT)                    AS SIRM_PT_CNT
                           FROM SDATA_ISO_SIRM B
                      ) X
              ) B
        UNION ALL   
      SELECT '02'                                                                         AS LARGE_CATEGORY
           , '01'                                                                         AS SMALL_CATEGORY
           , '중환자실 재입실 현황'                                                       AS TITLE
           , '재입실환자수'                                                               AS VALUE01_NAME
           , 'C'                                                                          AS VALUE01_TYPE
           , NVL(TO_CHAR(RPT_ETRM_PT_CNT), 0)                                             AS VALUE01 --재입실환자수
           , '일반병동전동환자수'                                                         AS VALUE02_NAME
           , 'C'                                                                          AS VALUE02_TYPE
           , NVL(TO_CHAR(CHOT_PT_CNT), 0)                                                 AS VALUE02 --일반병동전동환자수                                            
           , '재입실률'                                                                   AS VALUE03_NAME
           , 'C'                                                                          AS VALUE03_TYPE
           , NVL(TO_CHAR(DECODE(CHOT_PT_CNT, 0, 0, ROUND((RPT_ETRM_PT_CNT / CHOT_PT_CNT) * 100 , 1))), '0') AS VALUE03 --재입실률
           , ''                                                                           AS VALUE04_NAME
           , ''                                                                           AS VALUE04_TYPE
           , ''                                                                           AS VALUE04
           , ''                                                                           AS VALUE05_NAME
           , ''                                                                           AS VALUE05_TYPE
           , ''                                                                           AS VALUE05
           , ''                                                                           AS VALUE06_NAME
           , ''                                                                           AS VALUE06_TYPE
           , ''                                                                           AS VALUE06 
           , ''                                                                       AS VALUE07_NAME
           , ''                                                                       AS VALUE07_TYPE
	       , ''                                                                       AS VALUE07	                               
       FROM RE_IN_DATA A  	       
      UNION ALL
      SELECT '02'                                                                          LARGE_CATEGORY
           , '02'                                                                          SMALL_CATEGORY
           , '재입실시간 범위별 분포'                                                       AS TITLE
           , A.COMN_CD_NM                                                                AS VALUE01_NAME
           , 'C'                                                                         AS VALUE01_TYPE
           , NVL(A.COUNT, 0)                                                             AS VALUE01      
           , ''                                                                           AS VALUE02_NAME
           , ''                                                                           AS VALUE02_TYPE
           , ''                                                                           AS VALUE02
           , ''                                                                           AS VALUE03_NAME
           , ''                                                                           AS VALUE03_TYPE
           , ''                                                                           AS VALUE03                                                               
           , ''                                                                           AS VALUE04_NAME
           , ''                                                                           AS VALUE04_TYPE
           , ''                                                                           AS VALUE04
           , ''                                                                           AS VALUE05_NAME
           , ''                                                                           AS VALUE05_TYPE
           , ''                                                                           AS VALUE05
           , ''                                                                           AS VALUE06_NAME
           , ''                                                                           AS VALUE06_TYPE
           , ''                                                                           AS VALUE06  
           , ''                                                                       AS VALUE07_NAME
          , ''                                                                       AS VALUE07_TYPE
          , ''                                                                       AS VALUE07	                   
           FROM (
			        SELECT A.COMN_CD_NM,   NVL(TO_CHAR(B.COUNT), 0) COUNT  
			        FROM CHARTGUB A                                    
			           , (SELECT DECODE(BASE_CODE, 1, '1', 2, '2', 3, '3', 4, '4') COMN_CD
                               , DECODE(BASE_CODE, 1, RPT_ETRM_24_TM_IN_CNT,
                                                   2, RPT_ETRM_48_TM_IN_CNT,
                                                   3, RPT_ETRM_72_TM_IN_CNT,
                                                   4, RPT_ETRM_72_TM_EXCS_CNT)                            COUNT
                       FROM (
					         SELECT SUM(RPT_ETRM_24_TM_IN_CNT) AS RPT_ETRM_24_TM_IN_CNT
                                  ,	SUM(RPT_ETRM_48_TM_IN_CNT) AS RPT_ETRM_48_TM_IN_CNT
                                  ,	SUM(RPT_ETRM_72_TM_IN_CNT) AS RPT_ETRM_72_TM_IN_CNT
                                  ,	SUM(RPT_ETRM_72_TM_EXCS_CNT) AS RPT_ETRM_72_TM_EXCS_CNT
					           FROM RE_IN_DATA)  
					      , (SELECT LEVEL BASE_CODE FROM DUAL CONNECT BY LEVEL <5)) B  
			       WHERE A.COMN_GRP_CD = 'TIME_TYPE'       
			         AND A.COMN_CD = B.COMN_CD(+)  
			       ORDER BY A.COMN_CD  ) A
       UNION ALL
      SELECT '03'                                                                          LARGE_CATEGORY
           , '01'                                                                          SMALL_CATEGORY
           , '최근 병상 가동률'                                                         AS TITLE
           , COMN_CD_NM                                                                 AS VALUE01_NAME
           , 'C'                                                                          AS VALUE01_TYPE
           , NVL(TO_CHAR(YY_PT_CNT), '0')                                                   AS VALUE01    
           , '연병상'                                                                      AS VALUE02_NAME
           , 'C'                                                                          AS VALUE02_TYPE
           , NVL(TO_CHAR(YY_BED_CNT), '0')                                              AS VALUE02  --연병상
           , '병상가동률(%)'                                                               AS VALUE03_NAME
           , 'C'                                                                          AS VALUE03_TYPE
           , NVL(TRIM(TO_CHAR((DECODE(YY_PT_CNT,NULL,0,YY_PT_CNT) /DECODE(YY_BED_CNT,0,NULL, YY_BED_CNT))*100,'99990.9')), '0')   AS VALUE03  --병상가동률                                             
           , ''                                                                           AS VALUE04_NAME
           , ''                                                                           AS VALUE04_TYPE
           , ''                                                                           AS VALUE04
           , ''                                                                           AS VALUE05_NAME
           , ''                                                                           AS VALUE05_TYPE
           , ''                                                                           AS VALUE05
           , ''                                                                           AS VALUE06_NAME
           , ''                                                                           AS VALUE06_TYPE
           , ''                                                                           AS VALUE06   
           , ''                                                                       AS VALUE07_NAME
           , ''                                                                       AS VALUE07_TYPE
           , ''                                                                       AS VALUE07	          
       FROM (
			 SELECT A.COMN_CD_NM, B.YY_PT_CNT , B.YY_BED_CNT    
			   FROM CHARTGUB A                                                                                         
		          , RECENTLY_BED_RATE B
			       WHERE A.COMN_GRP_CD = 'RATE_PERIOD'       
			         AND A.COMN_CD = B.CODE_TYPE(+)  
			       ORDER BY A.COMN_CD )      				       
--     UNION ALL
--     --4.중증도분류별 재실환자 
--     SELECT '03'                                                                          LARGE_CATEGORY
--           , '01'                                                                          SMALL_CATEGORY
--           , '전체 환자중증도 분류'                                                         AS TITLE
--           , COMN_CD_NM                                                                 AS VALUE01_NAME
--           , 'C'                                                                          AS VALUE01_TYPE
--           , NVL(TO_CHAR(COUNT), 0)                                                     AS VALUE01    
--           , ''                                                                           AS VALUE02_NAME
--           , ''                                                                           AS VALUE02_TYPE
--           , ''                                                                           AS VALUE02
--           , ''                                                                           AS VALUE03_NAME
--           , ''                                                                           AS VALUE03_TYPE
--           , ''                                                                           AS VALUE03                                                               
--           , ''                                                                           AS VALUE04_NAME
--           , ''                                                                           AS VALUE04_TYPE
--           , ''                                                                           AS VALUE04
--           , ''                                                                           AS VALUE05_NAME
--           , ''                                                                           AS VALUE05_TYPE
--           , ''                                                                           AS VALUE05
--           , ''                                                                           AS VALUE06_NAME
--           , ''                                                                           AS VALUE06_TYPE
--           , ''                                                                           AS VALUE06   
--           , ''                                                                       AS VALUE07_NAME
--           , ''                                                                       AS VALUE07_TYPE
--           , ''                                                                       AS VALUE07	          
--       FROM (
--			 SELECT A.COMN_CD_NM,   NVL(TO_CHAR(B.COUNT), 0) COUNT  
--			   FROM HICU.UCCOCSTE A                                                                                         
--		          , (SELECT DECODE(BASE_CODE, 1, '1', 2, '2', 3, '3', 4, '4', 5, '5', 6, '6') COMN_CD
--                          , DECODE(BASE_CODE, 1, PT_SILLM_CTG_1_GRP_CNT,
--                                                2, PT_SILLM_CTG_2_GRP_CNT,
--                                                3, PT_SILLM_CTG_3_GRP_CNT,
--                                                4, PT_SILLM_CTG_4_GRP_CNT,
--                                                5, PT_SILLM_CTG_5_GRP_CNT,
--                                                6, PT_SILLM_CTG_6_GRP_CNT)                            COUNT
--                       FROM (
--					         SELECT SUM(PT_SILLM_CTG_1_GRP_CNT) AS PT_SILLM_CTG_1_GRP_CNT
--                                  ,	SUM(PT_SILLM_CTG_2_GRP_CNT) AS PT_SILLM_CTG_2_GRP_CNT
--                                  ,	SUM(PT_SILLM_CTG_3_GRP_CNT) AS PT_SILLM_CTG_3_GRP_CNT
--                                  ,	SUM(PT_SILLM_CTG_4_GRP_CNT) AS PT_SILLM_CTG_4_GRP_CNT
--                                  ,	SUM(PT_SILLM_CTG_5_GRP_CNT) AS PT_SILLM_CTG_5_GRP_CNT
--                                  ,	SUM(PT_SILLM_CTG_6_GRP_CNT) AS PT_SILLM_CTG_6_GRP_CNT
--					           FROM SDATA_ICU)
--               , (SELECT LEVEL BASE_CODE FROM DUAL CONNECT BY LEVEL <7)) B     
--		           WHERE A.COMN_GRP_CD = 'IC010'   
--		             AND A.HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND ROWNUM = 1)                      
--		             AND A.COMN_CD = B.COMN_CD
--                   ORDER BY COMN_CD_NM)      		            
     UNION ALL
      SELECT '04'                                                                         AS LARGE_CATEGORY
           , '01'                                                                         AS SMALL_CATEGORY
           , '환자중증도분류별 분포'                                                         AS TITLE
           , COMN_CD_NM                                                                   AS VALUE01_NAME
           , 'C'                                                                          AS VALUE01_TYPE
           , COUNT                                                                        AS VALUE01    
           , ''                                                                           AS VALUE02_NAME
           , ''                                                                           AS VALUE02_TYPE
           , ''                                                                           AS VALUE02
           , ''                                                                           AS VALUE03_NAME
           , ''                                                                           AS VALUE03_TYPE
           , ''                                                                           AS VALUE03                                                               
           , ''                                                                           AS VALUE04_NAME
           , ''                                                                           AS VALUE04_TYPE
           , ''                                                                           AS VALUE04
           , ''                                                                           AS VALUE05_NAME
           , ''                                                                           AS VALUE05_TYPE
           , ''                                                                           AS VALUE05
           , ''                                                                           AS VALUE06_NAME
           , ''                                                                           AS VALUE06_TYPE
           , ''                                                                           AS VALUE06   
           , ''                                                                           AS VALUE07_NAME
           , ''                                                                           AS VALUE07_TYPE
           , ''                                                                           AS VALUE07	                  
       FROM (
			 SELECT A.COMN_CD_NM,   NVL(TO_CHAR(B.COUNT), 0) COUNT  
			   FROM HICU.UCCOCSTE A                                                                                         
		          , (SELECT DECODE(BASE_CODE, 1, '1', 2, '2', 3, '3', 4, '4', 5, '5', 6, '6') COMN_CD
                          , DECODE(BASE_CODE, 1, PT_SILLM_CTG_1_GRP_CNT,
                                                2, PT_SILLM_CTG_2_GRP_CNT,
                                                3, PT_SILLM_CTG_3_GRP_CNT,
                                                4, PT_SILLM_CTG_4_GRP_CNT,
                                                5, PT_SILLM_CTG_5_GRP_CNT,
                                                6, PT_SILLM_CTG_6_GRP_CNT)                            COUNT
                       FROM (
					         SELECT SUM(PT_SILLM_CTG_1_GRP_CNT) AS PT_SILLM_CTG_1_GRP_CNT
                                  ,	SUM(PT_SILLM_CTG_2_GRP_CNT) AS PT_SILLM_CTG_2_GRP_CNT
                                  ,	SUM(PT_SILLM_CTG_3_GRP_CNT) AS PT_SILLM_CTG_3_GRP_CNT
                                  ,	SUM(PT_SILLM_CTG_4_GRP_CNT) AS PT_SILLM_CTG_4_GRP_CNT
                                  ,	SUM(PT_SILLM_CTG_5_GRP_CNT) AS PT_SILLM_CTG_5_GRP_CNT
                                  ,	SUM(PT_SILLM_CTG_6_GRP_CNT) AS PT_SILLM_CTG_6_GRP_CNT
					           FROM DIE_DATA)
                          , (SELECT LEVEL BASE_CODE FROM DUAL CONNECT BY LEVEL <7)) B     
		           WHERE A.COMN_GRP_CD = 'IC010'   
		             AND A.HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND ROWNUM = 1)                   
		             AND A.COMN_CD = B.COMN_CD
                   ORDER BY COMN_CD_NM)    
     UNION ALL
    SELECT '04'                                                                       AS  LARGE_CATEGORY
          , '02'                                                                      AS SMALL_CATEGORY
          , '사망률 현황'                                                              AS TITLE
          , '사망환자수'                                                               AS VALUE01_NAME
          , 'C'                                                                      AS VALUE01_TYPE           
          , NVL(TO_CHAR(DTH_PT_CNT),'0')                                             AS VALUE02 --사망환자수
          , '퇴원환자수'                                                              AS VALUE02_NAME
          , 'C'                                                                      AS VALUE02_TYPE          
          , NVL(TO_CHAR(CHOT_PT_CNT),'0')                                             AS VALUE02 --퇴원환자수
          , '사망률'                                                                  AS VALUE03_NAME
          , 'D2'                                                                     AS VALUE03_TYPE         
          , NVL(TO_CHAR(DECODE(CHOT_PT_CNT, 0, 0, ROUND((DTH_PT_CNT / CHOT_PT_CNT) * 100 , 1))),'0')  AS VALUE03 --사망률  
          , ''                                                                           AS VALUE04_NAME
          , ''                                                                           AS VALUE04_TYPE
          , ''                                                                           AS VALUE04
          , ''                                                                           AS VALUE05_NAME
          , ''                                                                           AS VALUE05_TYPE
          , ''                                                                           AS VALUE05
          , ''                                                                           AS VALUE06_NAME
          , ''                                                                           AS VALUE06_TYPE
          , ''                                                                           AS VALUE06           
          , ''                                                                           AS VALUE07_NAME
          , ''                                                                           AS VALUE07_TYPE
          , ''                                                                           AS VALUE07	                    
       FROM (SELECT SUM(DTH_PT_CNT) AS DTH_PT_CNT
                  ,	SUM(CHOT_PT_CNT) AS CHOT_PT_CNT
	           FROM DIE_DATA)
     UNION ALL 
     SELECT '01'                                                                       AS LARGE_CATEGORY
          , '01'                                                                       AS SMALL_CATEGORY
          , '실시간데이터-중환자실현황'                                                    AS TITLE
          , ''                                                                         AS VALUE01_NAME
          , 'C'                                                                        AS VALUE01_TYPE
          , '10'                                                                         AS VALUE01
          , '사용중인병상'                                                               AS VALUE02_NAME
          , 'D0'                                                                       AS VALUE02_TYPE
          , NVL(TO_CHAR(USE_WD_CNT), '0')                                              AS VALUE02
          , '사용중인격리병상'                                                           AS VALUE03_NAME
          , 'D0'                                                                       AS VALUE03_TYPE
          , NVL(TO_CHAR(ISLT_USE_WD_CNT), '0')                                                   AS VALUE03
          , '공병상'                                                                    AS VALUE04_NAME
          , 'D0'                                                                       AS VALUE04_TYPE
          , NVL(TO_CHAR(EMPT_WD_CNT), '0')                                                       AS VALUE04
          , '격리병실공병상'                                                             AS VALUE05_NAME
          , 'D0'                                                                       AS VALUE05_TYPE
          , NVL(TO_CHAR(ISLT_EMPT_WD_CNT), '0')                                                  AS VALUE05
          , '입실예정'                                                                  AS VALUE06_NAME
          , 'D0'                                                                       AS VALUE06_TYPE
          , NVL(TO_CHAR(IN_WD_CNT), '0')                                                         AS VALUE06
          , '퇴실예정'                                                                  AS VALUE07_NAME
          , 'D0'                                                                       AS VALUE07_TYPE
          , NVL(TO_CHAR(OUT_WD_CNT), '0')                                                        AS VALUE07
      FROM REALTIME_DATA    
     ;         
  END;

END PC_EICU_CENTER_REGION_SUMMARY;
