
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_TRNF_MAIN_SEL1" 
                          (  P_VNDR              IN VARCHAR2
			                         ,P_CLNTIP            IN VARCHAR2
			                         ,P_USERID            IN VARCHAR2
			                         ,P_HSPTID            IN VARCHAR2
                            ,IN_STATUS_STS_CD    IN  VARCHAR2
                            , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_PT_INFO_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송요청 환자리스트  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
BEGIN
    OPEN OUT_CURSOR FOR
SELECT  A.TRNF_PRGR_STS_CD                                    TRNF_PRGR_STS_CD
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD) TRNF_PRGR_STS_NM
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT
      , A.PACT_ID                                       PACT_ID
      , A.PT_NO						                                   PT_NO
      , A.PT_NM                                         PT_NM
      , B.SEX_TP_CD                                     SEX_TP_CD
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
      , (SELECT DEPT_NM
           FROM PDEDBMSM
          WHERE MED_DEPT_CD =  C.MED_DEPT_CD )          DEPT_NM
      , ''                                              ANDR_NM
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM
     , '진단명테스트 및 글자수테스트 테스트 테스트 테스트테스트테스트테스트테스트테스트테스트'                                                 DGNS_NM
--      , DECODE(TRNF_PRGR_STS_CD, '7','Y','N')           ARVL_YN
      , 'NEWS-' || '7'                PT_SCORE
      , A.HSP_TP_CD									                    HSP_TP_CD
      , A.CO_TREAT_PROGRESS_DT					                CO_TREAT_PROGRESS_DT
      , A.XFER_DECISION_DT					                    XFER_DECISION_DT
      , A.REFERRAL_DOC_REG_DT					                  REFERRAL_DOC_REG_DT
      , A.XFER_INFO_REG_DT					                    XFER_INFO_REG_DT
      , A.XFER_START_DT					                        XFER_START_DT
      , A.XFER_ARVL_PLAN_DT					                    XFER_ARVL_PLAN_DT
      , A.XFER_ARVL_DT					                        XFER_ARVL_DT
      , A.XFER_END_DT					                          XFER_END_DT
      , A.SEQ									                          SEQ
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRAAM C
     , (
        SELECT *
        FROM (
            SELECT D.*
                 , ROW_NUMBER() OVER (
                      PARTITION BY D.PACT_ID
                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
                   ) AS RN
              FROM MOPPCCFD D
        )
        WHERE RN = 1
     ) D
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.PACT_ID = D.PACT_ID


UNION ALL

      SELECT  A.TRNF_PRGR_STS_CD                                    TRNF_PRGR_STS_CD
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD) TRNF_PRGR_STS_NM
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT
      , A.PACT_ID                                       PACT_ID
      , A.PT_NO						                                   PT_NO
      , A.PT_NM                                         PT_NM
      , B.SEX_TP_CD                                     SEX_TP_CD
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
      , C.MED_DEPT_CD                        DEPT_NM
      , C.MEDR_SID                                      ANDR_NM
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM
      , '진단명테스트 및 글자수테스트 테스트 테스트 테스트테스트테스트테스트테스트테스트테스트테스트테스트'                                              DGNS_NM
--      , DECODE(TRNF_PRGR_STS_CD, '7','Y','N')           ARVL_YN
      , 'KTAS-' || '5'                       PT_SCORE
      , A.HSP_TP_CD									                    HSP_TP_CD
      , A.CO_TREAT_PROGRESS_DT					                CO_TREAT_PROGRESS_DT
      , A.XFER_DECISION_DT					                    XFER_DECISION_DT
      , A.REFERRAL_DOC_REG_DT					                  REFERRAL_DOC_REG_DT
      , A.XFER_INFO_REG_DT					                    XFER_INFO_REG_DT
      , A.XFER_START_DT					                        XFER_START_DT
      , A.XFER_ARVL_PLAN_DT					                    XFER_ARVL_PLAN_DT
      , A.XFER_ARVL_DT					                        XFER_ARVL_DT
      , A.XFER_END_DT					                          XFER_END_DT
      , A.SEQ									                          SEQ

  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID


ORDER BY CONSULT_REQ_DT DESC ;


END IF_TRNF_MAIN_SEL1;
