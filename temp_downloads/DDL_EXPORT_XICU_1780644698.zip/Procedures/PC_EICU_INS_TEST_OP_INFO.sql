
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_INS_TEST_OP_INFO" ( IN_SQL_ID           IN     VARCHAR2      /* SQL ID */
                       , IN_STF_NO           IN     VARCHAR2      /* 직원번호 */
                                          , IN_IP_ADDR          IN     VARCHAR2      /* IP ADDRESS */
                                             , IN_ICU_TP_CD        IN     VARCHAR2
                       , IN_PT_NO            IN     VARCHAR2
                       , IN_INPUT_DT         IN     VARCHAR2    /* 'hh24:mi'  */
                       , IN_HIST_SEQ         IN     VARCHAR2
                       , IN_HSP_TP_CD        IN     VARCHAR2
                       , IN_ITEM_TP_CD       IN     VARCHAR2
                       , IN_ITEM_CD          IN     VARCHAR2
                       , IN_ITEM_SUB_CD      IN     VARCHAR2
                       , IN_MEMO             IN     VARCHAR2
                                             , IO_ERRYN            IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG           IN OUT VARCHAR2 ) /* MESSAGE */
IS
BEGIN
  BEGIN

      INSERT INTO BB_TEST_OP_INFO ( ICU_TP_CD
              , PT_NO
              , INPUT_DT
              , HIST_SEQ
              , HSP_TP_CD
              , ITEM_TP_CD
              , ITEM_CD
              , ITEM_SUB_CD
              , MEMO
              , REG_DTM
              , REG_ID
                           )
                      VALUES
                           ( IN_ICU_TP_CD
              , IN_PT_NO
              , IN_INPUT_DT
              , nvl((select max(HIST_SEQ + 0)+ 1 from BB_TEST_OP_INFO
                                    where ICU_TP_CD = IN_ICU_TP_CD
                                    and PT_NO       = IN_PT_NO ), 1)
              , IN_HSP_TP_CD
              , IN_ITEM_TP_CD
              , IN_ITEM_CD
              , IN_ITEM_SUB_CD
              , IN_MEMO
              , TO_CHAR(sysdate, 'YY/MM/DD')
              , IN_STF_NO
                           )
                           ;

      END;
END PC_EICU_INS_TEST_OP_INFO;
