
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_CONSULT_EMPLOYE" 
                          ( IN_EPCN_CSLT_ID        IN  VARCHAR2
                          , IN_EPCN_CSLT_FOM_SEQ   IN  NUMBER                       
                          , OUT_CURSOR             OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_CONSULT_EMPLOYE
*    CREATEDATE     : 2021.02.19
*    Author         : 신솔
*    Description    : 협진 참여자 정보 조회
*    Change History : 2021.02.19, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH CONSULT EMPLOYEE
            ************************/ 
            SELECT
                   A.EPCN_CSLT_ID        AS EPCN_CSLT_ID
                 , A.EPCN_CSLT_FOM_SEQ   AS EPCN_CSLT_FOM_SEQ
                 , A.PRTP_SEQ            AS PRTP_SEQ
                 , A.PRTP_HSP_CD         AS PRTP_HSP_CD
                 , A.PRTP_HSP_NM         AS PRTP_HSP_NM
                 , A.PRTP_DEPT_CD        AS PRTP_DEPT_CD
                 , A.PRTP_DEPT_NM        AS PRTP_DEPT_NM
                 , A.PRTP_SID            AS PRTP_SID
                 , A.PRTP_STF_NM         AS PRTP_STF_NM
              FROM HICU.UCOMCNRD A
             WHERE A.EPCN_CSLT_ID      = IN_EPCN_CSLT_ID
               AND A.EPCN_CSLT_FOM_SEQ = IN_EPCN_CSLT_FOM_SEQ
             ORDER BY A.PRTP_SEQ
        ;    
    END;
END PC_EICU_SELECT_CONSULT_EMPLOYE;
