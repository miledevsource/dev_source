
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_CSLT_PT_SEL" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
																				      , IN_SEQ              IN  NUMBER
																				      , IN_PT_NO            IN  VARCHAR2
																				      , IN_PACT_ID          IN  VARCHAR2
                          , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
/**********************************************************************************************
*    SERVICENAME    : PC_CSLT_PT_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 협진의뢰 조회
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
BEGIN

   OPEN OUT_CURSOR FOR

									SELECT  C.HSP_TP_CD                    HSP_TP_CD
				           , (SELECT COMN_CD_NM
									           FROM CCCCCSTE
									          WHERE COMN_GRP_CD = '101'
									            AND COMN_CD = C.HSP_TP_CD ) HSP_NM
									      , A.PT_NM                        PT_NM
									      , A.PT_NO                        PT_NO

									      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									      , B.SEX_TP_CD                    SEX_TP_CD
									      , (SELECT DEPT_NM
									           FROM PDEDBMSM
									          WHERE MED_DEPT_CD =  C.MED_DEPT_CD ) DEPT_NM
 								      , A.PACT_ID                              PACT_ID    -- 20250828 장인수 인터페이스명세서에 PACT_ID 추가되어있어서 컬럼 추가 
									      , A.TARGET_HSP_NM                  TARGET_HSP_NM
									      , A.TARGET_DEPT_NM                 TARGET_DEPT_NM
									      , A.CO_TREAT_REASON             CO_TREAT_REASON  
									      , A.CO_TREAT_RMK                CO_TREAT_RMK
									  FROM ARPA_PT_LIST A
									     , PCTPCPAM_DAMO B
									     , ACPPRAAM C
									     , (
									        SELECT *
									        FROM (
									            SELECT D.*
									                 , ROW_NUMBER() OVER (
									                      PARTITION BY D.PACT_ID
									                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
									                   ) AS RN
									              FROM MOPPCCFD D
									        )
									        WHERE RN = 1
									     ) D
									WHERE A.HSP_TP_CD = IN_HSP_TP_CD
											AND A.SEQ = IN_SEQ
									  AND A.PT_NO = B.PT_NO
									  AND A.PT_NO = IN_PT_NO
									  AND A.PACT_ID = IN_PACT_ID
									  AND A.PACT_ID = C.PACT_ID
									  AND A.PACT_ID = D.PACT_ID


									UNION ALL

															SELECT  C.HSP_TP_CD                    HSP_TP_CD
				           , (SELECT COMN_CD_NM
									           FROM CCCCCSTE
									          WHERE COMN_GRP_CD = '101'
									            AND COMN_CD = C.HSP_TP_CD ) HSP_NM
									      , A.PT_NM                        PT_NM
									      , A.PT_NO                        PT_NO

									      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									      , B.SEX_TP_CD                    SEX_TP_CD
									      , NVL((SELECT DEPT_NM
									           FROM PDEDBMSM
									          WHERE MED_DEPT_CD =  C.MED_DEPT_CD ),C.MED_DEPT_CD) DEPT_NM
									      , A.PACT_ID                              PACT_ID   -- 20250828 장인수 인터페이스명세서에 PACT_ID 추가되어있어서 컬럼 추가 
									      , A.TARGET_HSP_NM                  TARGET_HSP_NM
									      , A.TARGET_DEPT_NM                 TARGET_DEPT_NM
									      , A.CO_TREAT_REASON             CO_TREAT_REASON
               , A.CO_TREAT_RMK                CO_TREAT_RMK 
									  FROM ARPA_PT_LIST A
									     , PCTPCPAM_DAMO B
									     , ACPPRETM C
									WHERE A.HSP_TP_CD = IN_HSP_TP_CD
									  AND A.SEQ       = IN_SEQ
									  AND A.PT_NO = IN_PT_NO
									  AND A.PACT_ID = IN_PACT_ID
									  AND A.PT_NO = B.PT_NO
									  AND A.PACT_ID = C.PACT_ID ;


END;
