
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_MED_RFFM_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	     	IN  NUMBER
																							   , IN_PT_NO     	      IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT A.HSP_TP_CD
		 , A.PT_NO
		 , A.PACT_ID
		 , S.HSP_NM
		 , A.PT_NM
		 , S.PHONE_NO
		 , S.RRN_MASKED
		 , S.PT_AGE
		 , S.SEX_TP_CD
		 , S.PT_ADDR
		 , S.TREAT_START_DT
		 , S.TREAT_END_DT
		 , S.TREAT_TYPE
		 , S.HSP_DR_NAME
		 , S.HSP_DEPT_NM
		 , S.HSP_ADDR
		 , S.TARGET_HSP_NM
		 , S.TARGET_DR_NAME
		 , S.TARGET_DEPT_NM
		 , S.TARGET_HSP_ADDR
		 , S.CLINICAL_NOTE   
		 , A.CO_TREAT_REASON
      FROM MED_RFFM_SEL	S
      	 , ARPA_PT_LIST	A
	  WHERE A.HSP_TP_CD = IN_HSP_TP_CD
        AND A.PT_NO   = IN_PT_NO
        AND A.PACT_ID = IN_PACT_ID
      	AND A.SEQ 		= IN_SEQ;
END IF_MED_RFFM_SEL;
