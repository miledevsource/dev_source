
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_DATALIST_READMISSION" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_DATALIST_READMISSION
*    CREATEDATE     : 2021.01.28
*    Author         : 신솔
*    Description    : 중환자실 재입실 현황 데이터 리스트
*    Change History : 2021.01.28, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT
                   A.PT_NO                  AS PT_NO
                 , SUBSTR(A.PT_NM, 1, 1) || '*' || SUBSTR(A.PT_NM, 3) AS PT_NM
                 , A.SEX_TP_CD              AS SEX_TP_CD
                 , A.AGE                    AS AGE
                 , A.AGE_MRK_NM             AS AGE_MRK_NM
                 , A.ADS_DT                 AS ADS_DT
                 , A.TH1_ETRM_DTM           AS TH1_ETRM_DTM
                 , A.TH1_CHOT_DTM           AS TH1_CHOT_DTM
                 , A.MED_DEPT_CD_NM         AS MED_DEPT_CD_NM
                 , A.TH2_ETRM_BED_NO        AS TH2_ETRM_BED_NO
                 , A.TH2_ETRM_DTM           AS TH2_ETRM_DTM
                 , B.PT_SILLM_CTG_DTM       AS PT_SILLM_CTG_DTM
                 , B.PT_SILLM_CTG_GRP_CD    AS PT_SILLM_CTG_GRP_CD
                 , B.PT_SILLM_CTG_GRP_CD_NM AS PT_SILLM_CTG_GRP_CD_NM
                 , A.RPT_ETRM_TM_ITVL_VAL   AS RPT_ETRM_TM_ITVL_VAL
                 , A.APCS_REC_INPT_DTM      AS APCS_REC_INPT_DTM
                 , A.APCS_SUM_SCR           AS APCS_SUM_SCR
              FROM (SELECT X.HSP_TP_CD
                         , X.PACT_ID
                         , X.PT_NO
                         , X.PT_NM
                         , X.SEX_TP_CD
                         , X.AGE
                         , X.AGE_MRK_NM
                         , X.ADS_DT
                         , X.TH1_ETRM_DTM
                         , X.TH1_CHOT_DTM
                         , X.MED_DEPT_CD_NM
                         , X.TH2_ETRM_BED_NO
                         , X.TH2_ETRM_DTM
                         , X.TH2_CHOT_DTM
                         , X.TH2_ETRM_WD_DEPT_CD
                         , X.RPT_ETRM_TM_ITVL_VAL
                         , X.APCS_REC_INPT_DTM
                         , X.APCS_SUM_SCR
                      FROM HICU.UICICSRM X --재입실지표기본
                     WHERE X.HSP_TP_CD              = IN_HIS_HSP_TP_CD
                       AND X.TH1_ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                       AND X.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                       AND X.TH1_ETRM_WD_DEPT_CD    = X.TH2_ETRM_WD_DEPT_CD
                       AND X.TH2_ETRM_DTM           BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999) A
                 , (SELECT Y.HSP_TP_CD
                         , Y.PACT_ID
                         , Y.PT_NO
                         , Y.PT_SILLM_CTG_DTM
                         , Y.PT_SILLM_CTG_GRP_CD
                         , Y.PT_SILLM_CTG_GRP_CD_NM
                         , DENSE_RANK() OVER (PARTITION BY Y.PT_SILLM_CTG_REC_ID ORDER BY Y.PT_SILLM_CTG_DTM, Y.PT_SILLM_CTG_REC_WRT_SEQ) AS RANK
                      FROM HICU.UICICSRD Y --재입실중증도분류정보
                     WHERE Y.HSP_TP_CD       = IN_HIS_HSP_TP_CD
                       AND Y.WD_DEPT_CD      = IN_WD_DEPT_CD
                       AND Y.PT_SILLM_CTG_DTM BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999) B
             WHERE A.HSP_TP_CD = B.HSP_TP_CD(+)
               AND A.PACT_ID   = B.PACT_ID(+)
               AND A.PT_NO     = B.PT_NO(+)
               AND (B.PT_SILLM_CTG_DTM = (SELECT MIN(Z.PT_SILLM_CTG_DTM)
                                            FROM HICU.UICICSRD Z
                                           WHERE Z.HSP_TP_CD  = A.HSP_TP_CD
                                             AND Z.PACT_ID    = A.PACT_ID
                                             AND Z.PT_NO      = A.PT_NO
                                             AND Z.WD_DEPT_CD = A.TH2_ETRM_WD_DEPT_CD
                                             AND Z.PT_SILLM_CTG_DTM BETWEEN TRUNC(A.TH2_ETRM_DTM) AND TRUNC(A.TH2_CHOT_DTM) + 0.99999)  /*재입실기간 내 첫번째 중증도*/
                OR  B.PT_SILLM_CTG_DTM IS NULL)
               AND (B.RANK = 1 OR B.RANK IS NULL)
             ORDER BY ADS_DT, PT_NM
        ;    
    END;
END PC_EICU_DATALIST_READMISSION;
