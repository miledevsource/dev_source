
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_TOT_MANAGE_SYS" ( OUT_CURSOR_1          OUT   RETURNCURSOR 
                                    , OUT_CURSOR_2          OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR_1 FOR
            select a.HSP_CD_CMT
			     , a.TOT_WD_CNT
			     , a.EMPT_WD_DNT
			     , a.ISLT_EMPT_WD_CNT
			     , a.TOT_VENT_PT_CNT
			     , (SELECT COUNT(HSP_TP_CD) HSP_TP_CD_CNT
  					  FROM ( SELECT CGPM.EPCN_GRP_NM --권역코드
						          , CGPM.EPCN_GRP_CD
						          , CHRD.HSP_TP_CD
						       FROM HICU.UCCOCGPM CGPM
						          , HICU.UCCOCHRD CHRD
						      WHERE CGPM.EPCN_GRP_CD = 'CTN01'
						        AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD ))  CONN_HSP_CNT
			     , a.ISLT_PT_CNT  ISOL_PT_CNT
			     , nvl((select sum(WHL_CSLT_CNT) WHL_CSLT_CNT
						 From hicu.ucoscnsd
						where untc_rec_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')), 0) NON_VIEW_CLINIC
			     , (select count(pt_no)
							  from (select distinct pt_no
							  		  from HICU.RRS_VALUE r
                                         , HICU.UCCOCDPM d
								     WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
									   and d.HSP_TP_CD = r.HSP_TP_CD
									   and d.DEPT_CD = r.WARD_NO
						   		       and d.USE_YN = 'Y'  ) )     RRS_PT_CNT
				   , NVL((select sum(cnt)
						        from (select count(rrs_item_cd) cnt
						                from HICU.RRS_VALUE r
                                           , HICU.UCCOCDPM d
						               WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
										 and d.HSP_TP_CD = r.HSP_TP_CD
										 and d.DEPT_CD = r.WARD_NO
							   		     and d.USE_YN = 'Y'
						               group by r.pt_no)), 0)                           RRS_ITEM_CNT
			from (
			select count(ai.HSP_CD)      HSP_CD_CMT -- 전체병원 수
			     , SUM(ai.TOT_WD_CNT)    TOT_WD_CNT -- 전체 병상 수
			     , SUM(ai.EMPT_WD_DNT)   EMPT_WD_DNT -- 전체 공병상 수
			     , SUM(ai.ISLT_EMPT_WD_CNT) ISLT_EMPT_WD_CNT -- 격리 공병상 수
			     , sum(ai.TOT_VENT_PT_CNT)  TOT_VENT_PT_CNT  -- 인공호흡기 적용 환자 수
                 , sum(ai.ISLT_PT_CNT)    ISLT_PT_CNT
			from (
				select HSP_CD
				     , TOT_WD_CNT          --04. 중환자실 전체 병상 수
				     , EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
				     , ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
				     , TOT_VENT_PT_CNT     --09. 중환자실 내 인공호흡기 적용 환자 수  
                     , ISLT_PT_CNT
				from xicu.EMNI001V
			) ai
			) a
			;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_1' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
    END;
    
    BEGIN            
    	OPEN OUT_CURSOR_2 FOR  
    		select v.HSP_CD              
    		     , h.HSP_NM
			     , v.ICU_CNT             --03. 중환자실 수
			     , v.TOT_WD_CNT          --04. 중환자실 전체 병상 수
			     , v.IN_CNT              --05. 중환자실 전체 입원환자 수
			     , v.EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
			     , v.ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
			     , v.NGPSSR_EMPT_WD_CNT  --08. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
			     , ROUND( ((v.IN_CNT / v.TOT_WD_CNT ) * 100), 2)  WORKING_PER  -- 병상가동률
			from xicu.EMNI001V v
			  , (select hsp_tp_cd
					  , hsp_nm
			       from HICU.UCCOCHPM
			      where USE_YN = 'Y'  ) h
			where v.HSP_CD = h.hsp_tp_cd  
			;  
		EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_2' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;      
    END;     
    RETURN;
END PC_EICU_TOT_MANAGE_SYS;
