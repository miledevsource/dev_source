
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_DATALIST_MORTALITY" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_WD_DEPT_CD     IN  VARCHAR2
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_DATALIST_MORTALITY
*    CREATEDATE     : 2021.01.28
*    Author         : 신솔
*    Description    : 중환자실 사망률 데이터 리스트
*    Change History : 2021.01.28, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT  A.PT_NO                               AS PT_NO
                  , SUBSTR(A.PT_NM, 1, 1) || '*' || SUBSTR(A.PT_NM, 3) AS PT_NM
                  , A.SEX_TP_CD                           AS SEX_TP_CD
                  , A.AGE                                 AS AGE
                  , A.AGE_MRK_NM                          AS AGE_MRK_NM
                  , A.ADS_DT                              AS ADS_DT
                  , A.ETRM_DTM                            AS ETRM_DTM
                  , A.MED_DEPT_CD                         AS MED_DEPT_CD
                  , A.MED_DEPT_CD_NM                      AS MED_DEPT_CD_NM
                  , A.RPRN_MED_DEPT_CD                    AS RPRN_MED_DEPT_CD
                  , A.RPRN_MED_DEPT_CD_NM                 AS RPRN_MED_DEPT_CD_NM
                  , B.PT_SILLM_CTG_DTM                    AS PT_SILLM_CTG_DTM
                  , B.PT_SILLM_CTG_GRP_CD                 AS PT_SILLM_CTG_GRP_CD
                  , B.PT_SILLM_CTG_GRP_CD_NM              AS PT_SILLM_CTG_GRP_CD_NM
                  , A.ETRM_BED_NO                         AS ETRM_BED_NO
                  , A.APCS_REC_INPT_DTM                   AS APCS_REC_INPT_DTM
                  , A.APCS_SUM_SCR                        AS APCS_SUM_SCR
              FROM (SELECT X.HSP_TP_CD
                         , X.PACT_ID
                         , X.PT_NO
                         , X.PT_NM
                         , X.SEX_TP_CD
                         , X.AGE
                         , X.AGE_MRK_NM
                         , X.ADS_DT
                         , X.ETRM_DTM
                         , X.CHOT_DTM
                         , X.MED_DEPT_CD
                         , X.MED_DEPT_CD_NM
                         , X.RPRN_MED_DEPT_CD
                         , X.RPRN_MED_DEPT_CD_NM
                         , X.ETRM_BED_NO
                         , X.APCS_REC_INPT_DTM
                         , X.APCS_SUM_SCR
                      FROM HICU.UICICSDM X
                     WHERE X.ICU_CHOT_PLC_TP_CD IN('06', '07')
                       AND X.ETRM_WD_DEPT_CD    = IN_WD_DEPT_CD
                       AND X.CHOT_DTM           <= SYSDATE  /*미래자 퇴실일자는 제외*/
                       AND X.CHOT_DTM           BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                       AND X.HSP_TP_CD          = IN_HIS_HSP_TP_CD)      A --중환자실사망지표기본 ( 아파치 중복 제거한 사망환자 리스트 )
                 , (SELECT Y.HSP_TP_CD
                         , Y.PACT_ID
                         , Y.PT_NO
                         , Y.PT_SILLM_CTG_DTM
                         , Y.PT_SILLM_CTG_GRP_CD
                         , Y.PT_SILLM_CTG_GRP_CD_NM
                         , DENSE_RANK() OVER (PARTITION BY Y.PT_SILLM_CTG_REC_ID ORDER BY Y.PT_SILLM_CTG_DTM DESC, Y.PT_SILLM_CTG_REC_WRT_SEQ DESC) AS RANK
                      FROM HICU.UICICSDD Y
                     WHERE Y.WD_DEPT_CD              = IN_WD_DEPT_CD
                       AND Y.PT_SILLM_CTG_DTM        BETWEEN TRUNC(IN_FROM_DT) AND TRUNC(IN_TO_DT) + 0.99999
                       AND Y.HSP_TP_CD               = IN_HIS_HSP_TP_CD) B --중환자실사망중증도분류정보 ( 조회기간내 모든 중증도 정보 )
             WHERE A.HSP_TP_CD           = B.HSP_TP_CD(+)
               AND A.PACT_ID             = B.PACT_ID(+)
               AND A.PT_NO               = B.PT_NO(+)
               AND (B.PT_SILLM_CTG_DTM = (SELECT MAX(PT_SILLM_CTG_DTM)
                                            FROM HICU.UICICSDD
                                           WHERE HSP_TP_CD = A.HSP_TP_CD
                                             AND PACT_ID   = A.PACT_ID
                                             AND PT_NO     = A.PT_NO
                                             AND ETRM_DTM  = A.ETRM_DTM
                                             AND PT_SILLM_CTG_DTM BETWEEN TRUNC(A.ETRM_DTM) AND TRUNC(A.CHOT_DTM) + 0.99999)  /*입원기간 내 마지막 중증도*/
                OR  B.PT_SILLM_CTG_DTM IS NULL)
               AND (B.RANK = 1 OR B.RANK IS NULL)
             ORDER BY ADS_DT, PT_NM
        ;    
    END;
END PC_EICU_DATALIST_MORTALITY;
