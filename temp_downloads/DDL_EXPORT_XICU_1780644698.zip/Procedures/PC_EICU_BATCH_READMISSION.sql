
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_READMISSION" 
                          ( IN_PRMR_STR_DTM   IN  DATE
                          , IN_PRMR_END_DTM   IN  DATE
                          , IN_HSP_TP_CD      IN  VARCHAR2
                          , IO_ERR_YN         IN OUT  VARCHAR2    --  ERROR Y/N
                          , IO_ERR_MSG        IN OUT  VARCHAR2    --  ERROR MESSAGE
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_READMISSION
*    CREATEDATE     : 2021.02.09
*    Author         : 신솔
*    Description    : 중환자실 재입실 현황 데이터 배치
*    Change History : 2021.02.09, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    /**********************************************************************************************
    *    재입실지표기본 ( UICICSRM ) BATCH
    *
    **********************************************************************************************/
    BEGIN
        -- 신규생성 또는 업데이트 데이터를 기준으로 삭제하고 데이터를 적재한다.
        DELETE 
          FROM HICU.UICICSRM
         WHERE PACT_ID IN ( SELECT X.PACT_ID
                              FROM HICU.UICICRID X
                             WHERE X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                               AND X.HSP_TP_CD   = IN_HSP_TP_CD
                             UNION ALL
                            SELECT Y.PACT_ID
                              FROM HICU.UICICRPM Y
                             WHERE Y.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                               AND Y.HSP_TP_CD   = IN_HSP_TP_CD )
        ;   
        COMMIT; 
    END;
    
    BEGIN
        MERGE INTO HICU.UICICSRM A  --재입실지표기본
             USING (
                       WITH RE_IN_DATA AS(
                            --재입실환자
                            SELECT
                                   C.PACT_ID                 AS PACT_ID
                                 , A.PT_NO                   AS PT_NO
                                 , B.HSP_TP_CD               AS HSP_TP_CD
                                 , B.CIPT_ETRM_CHOT_ID       AS CIPT_ETRM_CHOT_ID
                                 , A.MED_DEPT_CD             AS MED_DEPT_CD
                                 , A.MED_DEPT_CD_NM          AS MED_DEPT_CD_NM
                                 , A.RPRN_MED_DEPT_CD        AS RPRN_MED_DEPT_CD
                                 , A.RPRN_MED_DEPT_CD_NM     AS RPRN_MED_DEPT_CD_NM
                                 , A.ETRM_DTM                AS ETRM_DTM
                                 , A.ETRM_WD_DEPT_CD         AS ETRM_WD_DEPT_CD
                                 , A.ETRM_WD_DEPT_CD_NM      AS ETRM_WD_DEPT_CD_NM
                                 , A.ETRM_PRM_NO             AS ETRM_PRM_NO
                                 , A.ETRM_BED_NO             AS ETRM_BED_NO
                                 , A.EMRG_BED_YN             AS EMRG_BED_YN
                                 , A.ISLT_BED_YN             AS ISLT_BED_YN
                                 , A.ICU_ETRM_PATH_CLS_CD    AS ICU_ETRM_PATH_CLS_CD
                                 , A.ICU_ETRM_PATH_CLS_CD_NM AS ICU_ETRM_PATH_CLS_CD_NM
                                 , A.CHOT_DTM                AS CHOT_DTM
                                 , A.ICU_CHOT_PLC_TP_CD      AS ICU_CHOT_PLC_TP_CD
                                 , A.ICU_CHOT_PLC_TP_CD_NM   AS ICU_CHOT_PLC_TP_CD_NM
                                 , A.CHOT_WD_MTD_CD          AS CHOT_WD_MTD_CD
                                 , A.CHOT_WD_MTD_CD_NM       AS CHOT_WD_MTD_CD_NM
                                 , D.INPT_DTM                AS APCS_REC_INPT_DTM
                                 , D.WRT_SEQ                 AS APCS_REC_WRT_SEQ
                                 , D.APCS_PT_STS_CD          AS APCS_PT_STS_CD
                                 , D.APCS_PT_STS_CD_NM       AS APCS_PT_STS_CD_NM
                                 , D.SUM_SCR                 AS APCS_SUM_SCR
                                 , DENSE_RANK() OVER (PARTITION BY B.CIPT_ETRM_CHOT_ID, B.HSP_TP_CD ORDER BY D.INPT_DTM, D.WRT_SEQ) AS RANK
                                 , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND A.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND A.LST_LOD_DTM > NVL(D.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                        WHEN (B.LST_LOD_DTM IS NOT NULL AND B.LST_LOD_DTM > NVL(A.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND B.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND B.LST_LOD_DTM > NVL(D.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN B.LST_LOD_DTM
                                        WHEN (C.LST_LOD_DTM IS NOT NULL AND C.LST_LOD_DTM > NVL(A.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND C.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND C.LST_LOD_DTM > NVL(D.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN C.LST_LOD_DTM
                                        ELSE D.LST_LOD_DTM END AS LST_LOD_DTM
                              FROM HICU.UICICRID A -- 중환자실입실퇴실시간정보 ( 2nd )
                                 , HICU.UICICRID B -- 중환자실입실퇴실시간정보 ( 1st )
                                 , HICU.UICICRPM C -- 입원접수기본
                                 , HICU.UICICRAD D -- 아파치스코어기록정보
                             WHERE A.HSP_TP_CD       = IN_HSP_TP_CD
                               AND A.PACT_ID         = B.PACT_ID
                               AND A.ETRM_WD_DEPT_CD = B.ETRM_WD_DEPT_CD
                               AND A.HSP_TP_CD       = B.HSP_TP_CD
                               AND A.ETRM_DTM        > B.ETRM_DTM
                               AND A.PACT_ID         = C.PACT_ID
                               AND A.HSP_TP_CD       = C.HSP_TP_CD
                               AND A.USE_YN          = 'Y'
                               AND A.LST_YN          = 'Y'
                               AND A.PACT_TP_CD      = 'I'
                               AND B.USE_YN          = 'Y'
                               AND B.LST_YN          = 'Y'
                               AND B.PACT_TP_CD      = 'I'
                               AND B.ICU_CHOT_PLC_TP_CD IN ('01', '13') /*병실(01), ICR(13)*/
                               AND B.ETRM_DTM        = (SELECT MAX(ETRM_DTM) FROM HICU.UICICRID WHERE PACT_ID = A.PACT_ID AND USE_YN = 'Y' AND LST_YN = 'Y' AND HSP_TP_CD = A.HSP_TP_CD AND ETRM_DTM < A.ETRM_DTM)
                               AND D.PT_NO(+)        = A.PT_NO
                               AND D.PACT_ID(+)      = A.PACT_ID
                               AND D.HSP_TP_CD(+)    = A.HSP_TP_CD
                               AND D.ICU_ETRM_DTM(+) = A.ETRM_DTM
                               AND D.WD_DEPT_CD(+)   = A.ETRM_WD_DEPT_CD
                               AND D.USE_YN(+)       = 'Y'
                               AND D.LST_YN(+)       = 'Y'
                               AND D.PACT_TP_CD(+)   = 'I'
                               AND D.INPT_DTM(+)     BETWEEN TRUNC(A.ETRM_DTM) AND TRUNC(A.CHOT_DTM)
                               AND (A.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  B.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  C.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  D.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)
                            )
                          , GOWARD_DATA AS (
                            --일반병동전동환자
                            SELECT
                                   A.CIPT_ETRM_CHOT_ID       AS CIPT_ETRM_CHOT_ID
                                 , A.PACT_ID                 AS PACT_ID
                                 , A.HSP_TP_CD               AS HSP_TP_CD
                                 , B.PT_NO                   AS PT_NO
                                 , B.PT_NM                   AS PT_NM
                                 , B.ADS_DT                  AS ADS_DT
                                 , B.DS_EXPT_DT              AS DS_EXPT_DT
                                 , B.SEX_TP_CD               AS SEX_TP_CD
                                 , B.AGE                     AS AGE
                                 , B.AGE_MRK_NM              AS AGE_MRK_NM
                                 , B.ADS_PATH_CD             AS ADS_PATH_CD
                                 , B.ADS_PATH_CD_NM          AS ADS_PATH_NM
                                 , A.MED_DEPT_CD             AS MED_DEPT_CD
                                 , A.MED_DEPT_CD_NM          AS MED_DEPT_CD_NM
                                 , A.RPRN_MED_DEPT_CD        AS RPRN_MED_DEPT_CD
                                 , A.RPRN_MED_DEPT_CD_NM     AS RPRN_MED_DEPT_CD_NM
                                 , A.ETRM_DTM                AS ETRM_DTM
                                 , A.ETRM_WD_DEPT_CD         AS ETRM_WD_DEPT_CD
                                 , A.ETRM_WD_DEPT_CD_NM      AS ETRM_WD_DEPT_CD_NM
                                 , A.ETRM_PRM_NO             AS ETRM_PRM_NO
                                 , A.ETRM_BED_NO             AS ETRM_BED_NO
                                 , A.EMRG_BED_YN             AS EMRG_BED_YN
                                 , A.ISLT_BED_YN             AS ISLT_BED_YN
                                 , A.ICU_ETRM_PATH_CLS_CD    AS ICU_ETRM_PATH_CLS_CD
                                 , A.ICU_ETRM_PATH_CLS_CD_NM AS ICU_ETRM_PATH_CLS_CD_NM
                                 , A.CHOT_DTM                AS CHOT_DTM
                                 , A.ICU_CHOT_PLC_TP_CD      AS ICU_CHOT_PLC_TP_CD
                                 , A.ICU_CHOT_PLC_TP_CD_NM   AS ICU_CHOT_PLC_TP_CD_NM
                                 , A.CHOT_WD_MTD_CD          AS CHOT_WD_MTD_CD
                                 , A.CHOT_WD_MTD_CD_NM       AS CHOT_WD_MTD_CD_NM
                                 , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                        ELSE B.LST_LOD_DTM END AS LST_LOD_DTM
                              FROM HICU.UICICRID A -- 중환자실입실퇴실시간정보
                                 , HICU.UICICRPM B -- 입원접수기본
                             WHERE A.HSP_TP_CD          = IN_HSP_TP_CD
                               AND A.PACT_ID            = B.PACT_ID
                               AND A.HSP_TP_CD          = B.HSP_TP_CD
                               AND A.ICU_CHOT_PLC_TP_CD IN('01', '13')
                               AND A.USE_YN             = 'Y'
                               AND A.LST_YN             = 'Y'
                               AND A.PACT_TP_CD         = 'I'
                               AND (A.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  B.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)
                            )                       
                       
                       SELECT
                              A.CIPT_ETRM_CHOT_ID                           AS CIPT_ETRM_CHOT_ID
                            , A.HSP_TP_CD                                   AS HSP_TP_CD
                            , A.PACT_ID                                     AS PACT_ID
                            , A.PT_NO                                       AS PT_NO
                            , A.PT_NM                                       AS PT_NM
                            , A.ADS_DT                                      AS ADS_DT
                            , A.DS_EXPT_DT                                  AS DS_EXPT_DT
                            , A.SEX_TP_CD                                   AS SEX_TP_CD
                            , A.AGE                                         AS AGE
                            , A.AGE_MRK_NM                                  AS AGE_MRK_NM
                            , A.ADS_PATH_CD                                 AS ADS_PATH_CD
                            , A.ADS_PATH_NM                                 AS ADS_PATH_NM
                            , A.MED_DEPT_CD                                 AS MED_DEPT_CD
                            , A.MED_DEPT_CD_NM                              AS MED_DEPT_CD_NM
                            , A.RPRN_MED_DEPT_CD                            AS RPRN_MED_DEPT_CD
                            , A.RPRN_MED_DEPT_CD_NM                         AS RPRN_MED_DEPT_CD_NM
                            , A.ETRM_DTM                                    AS TH1_ETRM_DTM
                            , A.ETRM_WD_DEPT_CD                             AS TH1_ETRM_WD_DEPT_CD
                            , A.ETRM_WD_DEPT_CD_NM                          AS TH1_ETRM_WD_DEPT_CD_NM
                            , A.ETRM_PRM_NO                                 AS TH1_ETRM_PRM_NO
                            , A.ETRM_BED_NO                                 AS TH1_ETRM_BED_NO
                            , A.EMRG_BED_YN                                 AS TH1_EMRG_BED_YN
                            , A.ISLT_BED_YN                                 AS TH1_ISLT_BED_YN
                            , A.ICU_ETRM_PATH_CLS_CD                        AS TH1_ICU_ETRM_PATH_CLS_CD
                            , A.ICU_ETRM_PATH_CLS_CD_NM                     AS TH1_ICU_ETRM_PATH_CLS_CD_NM
                            , A.CHOT_DTM                                    AS TH1_CHOT_DTM
                            , A.ICU_CHOT_PLC_TP_CD                          AS TH1_ICU_CHOT_PLC_TP_CD
                            , A.ICU_CHOT_PLC_TP_CD_NM                       AS TH1_ICU_CHOT_PLC_TP_CD_NM
                            , A.CHOT_WD_MTD_CD                              AS TH1_CHOT_WD_MTD_CD
                            , A.CHOT_WD_MTD_CD_NM                           AS TH1_CHOT_WD_MTD_CD_NM
                            , B.ETRM_DTM                                    AS TH2_ETRM_DTM
                            , B.ETRM_WD_DEPT_CD                             AS TH2_ETRM_WD_DEPT_CD
                            , B.ETRM_WD_DEPT_CD_NM                          AS TH2_ETRM_WD_DEPT_CD_NM
                            , B.ETRM_PRM_NO                                 AS TH2_ETRM_PRM_NO
                            , B.ETRM_BED_NO                                 AS TH2_ETRM_BED_NO
                            , B.EMRG_BED_YN                                 AS TH2_EMRG_BED_YN
                            , B.ISLT_BED_YN                                 AS TH2_ISLT_BED_YN
                            , B.ICU_ETRM_PATH_CLS_CD                        AS TH2_ICU_ETRM_PATH_CLS_CD
                            , B.ICU_ETRM_PATH_CLS_CD_NM                     AS TH2_ICU_ETRM_PATH_CLS_CD_NM
                            , B.CHOT_DTM                                    AS TH2_CHOT_DTM
                            , B.ICU_CHOT_PLC_TP_CD                          AS TH2_ICU_CHOT_PLC_TP_CD
                            , B.ICU_CHOT_PLC_TP_CD_NM                       AS TH2_ICU_CHOT_PLC_TP_CD_NM
                            , B.CHOT_WD_MTD_CD                              AS TH2_CHOT_WD_MTD_CD
                            , B.CHOT_WD_MTD_CD_NM                           AS TH2_CHOT_WD_MTD_CD_NM
                            , CASE WHEN B.ETRM_DTM IS NOT NULL THEN ROUND((B.ETRM_DTM-A.CHOT_DTM)*24) ELSE NULL END AS RPT_ETRM_TM_ITVL_VAL
                            , B.APCS_REC_INPT_DTM                           AS APCS_REC_INPT_DTM
                            , B.APCS_REC_WRT_SEQ                            AS APCS_REC_WRT_SEQ
                            , B.APCS_PT_STS_CD                              AS APCS_PT_STS_CD
                            , B.APCS_PT_STS_CD_NM                           AS APCS_PT_STS_CD_NM
                            , B.APCS_SUM_SCR                                AS APCS_SUM_SCR
                            , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                   ELSE B.LST_LOD_DTM END                   AS LST_LOD_DTM
                         FROM GOWARD_DATA   A --일반병동전동환자
                            , RE_IN_DATA    B --재입실환자
                        WHERE A.CIPT_ETRM_CHOT_ID = B.CIPT_ETRM_CHOT_ID(+)
                          AND (B.RANK = 1 OR B.RANK IS NULL)
                        ORDER BY A.ADS_DT, A.CIPT_ETRM_CHOT_ID

                   ) B
                ON (       A.HSP_TP_CD         = B.HSP_TP_CD
                     AND   A.CIPT_ETRM_CHOT_ID = B.CIPT_ETRM_CHOT_ID
                   )
             WHEN MATCHED
             THEN UPDATE SET A.PACT_ID                     = B.PACT_ID
                           , A.PT_NO                       = B.PT_NO
                           , A.PT_NM                       = B.PT_NM
                           , A.ADS_DT                      = B.ADS_DT
                           , A.DS_EXPT_DT                  = B.DS_EXPT_DT
                           , A.SEX_TP_CD                   = B.SEX_TP_CD
                           , A.AGE                         = B.AGE
                           , A.AGE_MRK_NM                  = B.AGE_MRK_NM
                           , A.ADS_PATH_CD                 = B.ADS_PATH_CD
                           , A.ADS_PATH_NM                 = B.ADS_PATH_NM
                           , A.MED_DEPT_CD                 = B.MED_DEPT_CD
                           , A.MED_DEPT_CD_NM              = B.MED_DEPT_CD_NM
                           , A.RPRN_MED_DEPT_CD            = B.RPRN_MED_DEPT_CD
                           , A.RPRN_MED_DEPT_CD_NM         = B.RPRN_MED_DEPT_CD_NM
                           , A.TH1_ETRM_DTM                = B.TH1_ETRM_DTM
                           , A.TH1_ETRM_WD_DEPT_CD         = B.TH1_ETRM_WD_DEPT_CD
                           , A.TH1_ETRM_WD_DEPT_CD_NM      = B.TH1_ETRM_WD_DEPT_CD_NM
                           , A.TH1_ETRM_PRM_NO             = B.TH1_ETRM_PRM_NO
                           , A.TH1_ETRM_BED_NO             = B.TH1_ETRM_BED_NO
                           , A.TH1_EMRG_BED_YN             = B.TH1_EMRG_BED_YN
                           , A.TH1_ISLT_BED_YN             = B.TH1_ISLT_BED_YN
                           , A.TH1_ICU_ETRM_PATH_CLS_CD    = B.TH1_ICU_ETRM_PATH_CLS_CD
                           , A.TH1_ICU_ETRM_PATH_CLS_CD_NM = B.TH1_ICU_ETRM_PATH_CLS_CD_NM
                           , A.TH1_CHOT_DTM                = B.TH1_CHOT_DTM
                           , A.TH1_ICU_CHOT_PLC_TP_CD      = B.TH1_ICU_CHOT_PLC_TP_CD
                           , A.TH1_ICU_CHOT_PLC_TP_CD_NM   = B.TH1_ICU_CHOT_PLC_TP_CD_NM
                           , A.TH1_CHOT_WD_MTD_CD          = B.TH1_CHOT_WD_MTD_CD
                           , A.TH1_CHOT_WD_MTD_CD_NM       = B.TH1_CHOT_WD_MTD_CD_NM
                           , A.TH2_ETRM_DTM                = B.TH2_ETRM_DTM
                           , A.TH2_ETRM_WD_DEPT_CD         = B.TH2_ETRM_WD_DEPT_CD
                           , A.TH2_ETRM_WD_DEPT_CD_NM      = B.TH2_ETRM_WD_DEPT_CD_NM
                           , A.TH2_ETRM_PRM_NO             = B.TH2_ETRM_PRM_NO
                           , A.TH2_ETRM_BED_NO             = B.TH2_ETRM_BED_NO
                           , A.TH2_EMRG_BED_YN             = B.TH2_EMRG_BED_YN
                           , A.TH2_ISLT_BED_YN             = B.TH2_ISLT_BED_YN
                           , A.TH2_ICU_ETRM_PATH_CLS_CD    = B.TH2_ICU_ETRM_PATH_CLS_CD
                           , A.TH2_ICU_ETRM_PATH_CLS_CD_NM = B.TH2_ICU_ETRM_PATH_CLS_CD_NM
                           , A.TH2_CHOT_DTM                = B.TH2_CHOT_DTM
                           , A.TH2_ICU_CHOT_PLC_TP_CD      = B.TH2_ICU_CHOT_PLC_TP_CD
                           , A.TH2_ICU_CHOT_PLC_TP_CD_NM   = B.TH2_ICU_CHOT_PLC_TP_CD_NM
                           , A.TH2_CHOT_WD_MTD_CD          = B.TH2_CHOT_WD_MTD_CD
                           , A.TH2_CHOT_WD_MTD_CD_NM       = B.TH2_CHOT_WD_MTD_CD_NM
                           , A.RPT_ETRM_TM_ITVL_VAL        = B.RPT_ETRM_TM_ITVL_VAL
                           , A.APCS_REC_INPT_DTM           = B.APCS_REC_INPT_DTM
                           , A.APCS_REC_WRT_SEQ            = B.APCS_REC_WRT_SEQ
                           , A.APCS_PT_STS_CD              = B.APCS_PT_STS_CD
                           , A.APCS_PT_STS_CD_NM           = B.APCS_PT_STS_CD_NM
                           , A.APCS_SUM_SCR                = B.APCS_SUM_SCR
                           , A.LST_LOD_DTM                 = SYSDATE
             WHEN NOT MATCHED
             THEN INSERT ( A.CIPT_ETRM_CHOT_ID
                         , A.HSP_TP_CD
                         , A.PACT_ID
                         , A.PT_NO
                         , A.PT_NM
                         , A.ADS_DT
                         , A.DS_EXPT_DT
                         , A.SEX_TP_CD
                         , A.AGE
                         , A.AGE_MRK_NM
                         , A.ADS_PATH_CD
                         , A.ADS_PATH_NM
                         , A.MED_DEPT_CD
                         , A.MED_DEPT_CD_NM
                         , A.RPRN_MED_DEPT_CD
                         , A.RPRN_MED_DEPT_CD_NM
                         , A.TH1_ETRM_DTM
                         , A.TH1_ETRM_WD_DEPT_CD
                         , A.TH1_ETRM_WD_DEPT_CD_NM
                         , A.TH1_ETRM_PRM_NO
                         , A.TH1_ETRM_BED_NO
                         , A.TH1_EMRG_BED_YN
                         , A.TH1_ISLT_BED_YN
                         , A.TH1_ICU_ETRM_PATH_CLS_CD
                         , A.TH1_ICU_ETRM_PATH_CLS_CD_NM
                         , A.TH1_CHOT_DTM
                         , A.TH1_ICU_CHOT_PLC_TP_CD
                         , A.TH1_ICU_CHOT_PLC_TP_CD_NM
                         , A.TH1_CHOT_WD_MTD_CD
                         , A.TH1_CHOT_WD_MTD_CD_NM
                         , A.TH2_ETRM_DTM
                         , A.TH2_ETRM_WD_DEPT_CD
                         , A.TH2_ETRM_WD_DEPT_CD_NM
                         , A.TH2_ETRM_PRM_NO
                         , A.TH2_ETRM_BED_NO
                         , A.TH2_EMRG_BED_YN
                         , A.TH2_ISLT_BED_YN
                         , A.TH2_ICU_ETRM_PATH_CLS_CD
                         , A.TH2_ICU_ETRM_PATH_CLS_CD_NM
                         , A.TH2_CHOT_DTM
                         , A.TH2_ICU_CHOT_PLC_TP_CD
                         , A.TH2_ICU_CHOT_PLC_TP_CD_NM
                         , A.TH2_CHOT_WD_MTD_CD
                         , A.TH2_CHOT_WD_MTD_CD_NM
                         , A.RPT_ETRM_TM_ITVL_VAL
                         , A.APCS_REC_INPT_DTM
                         , A.APCS_REC_WRT_SEQ
                         , A.APCS_PT_STS_CD
                         , A.APCS_PT_STS_CD_NM
                         , A.APCS_SUM_SCR
                         , A.FST_LOD_DTM
                         , A.LST_LOD_DTM
                         )
                  VALUES ( B.CIPT_ETRM_CHOT_ID
                         , B.HSP_TP_CD
                         , B.PACT_ID
                         , B.PT_NO
                         , B.PT_NM
                         , B.ADS_DT
                         , B.DS_EXPT_DT
                         , B.SEX_TP_CD
                         , B.AGE
                         , B.AGE_MRK_NM
                         , B.ADS_PATH_CD
                         , B.ADS_PATH_NM
                         , B.MED_DEPT_CD
                         , B.MED_DEPT_CD_NM
                         , B.RPRN_MED_DEPT_CD
                         , B.RPRN_MED_DEPT_CD_NM
                         , B.TH1_ETRM_DTM
                         , B.TH1_ETRM_WD_DEPT_CD
                         , B.TH1_ETRM_WD_DEPT_CD_NM
                         , B.TH1_ETRM_PRM_NO
                         , B.TH1_ETRM_BED_NO
                         , B.TH1_EMRG_BED_YN
                         , B.TH1_ISLT_BED_YN
                         , B.TH1_ICU_ETRM_PATH_CLS_CD
                         , B.TH1_ICU_ETRM_PATH_CLS_CD_NM
                         , B.TH1_CHOT_DTM
                         , B.TH1_ICU_CHOT_PLC_TP_CD
                         , B.TH1_ICU_CHOT_PLC_TP_CD_NM
                         , B.TH1_CHOT_WD_MTD_CD
                         , B.TH1_CHOT_WD_MTD_CD_NM
                         , B.TH2_ETRM_DTM
                         , B.TH2_ETRM_WD_DEPT_CD
                         , B.TH2_ETRM_WD_DEPT_CD_NM
                         , B.TH2_ETRM_PRM_NO
                         , B.TH2_ETRM_BED_NO
                         , B.TH2_EMRG_BED_YN
                         , B.TH2_ISLT_BED_YN
                         , B.TH2_ICU_ETRM_PATH_CLS_CD
                         , B.TH2_ICU_ETRM_PATH_CLS_CD_NM
                         , B.TH2_CHOT_DTM
                         , B.TH2_ICU_CHOT_PLC_TP_CD
                         , B.TH2_ICU_CHOT_PLC_TP_CD_NM
                         , B.TH2_CHOT_WD_MTD_CD
                         , B.TH2_CHOT_WD_MTD_CD_NM
                         , B.RPT_ETRM_TM_ITVL_VAL
                         , B.APCS_REC_INPT_DTM
                         , B.APCS_REC_WRT_SEQ
                         , B.APCS_PT_STS_CD
                         , B.APCS_PT_STS_CD_NM
                         , B.APCS_SUM_SCR
                         , SYSDATE
                         , SYSDATE
                         )
        ;    
        
        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '1) 재입실지표기본 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
            RETURN;
    END;
    
    
    /**********************************************************************************************
    *    재입실중증도분류정보 ( UICICSRD )  BATCH
    *
    **********************************************************************************************/
    BEGIN
        -- 신규생성 또는 업데이트 데이터를 기준으로 삭제하고 데이터를 적재한다.
        DELETE 
          FROM HICU.UICICSRD
         WHERE PT_SILLM_CTG_REC_ID IN ( SELECT X.PT_SILLM_CTG_REC_ID
                                          FROM HICU.UICICRSD X --환자중증도분류기록정보
                                         WHERE X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                           AND X.HSP_TP_CD   = IN_HSP_TP_CD )
        ;   
        COMMIT; 
    END;
    
    BEGIN
        MERGE INTO HICU.UICICSRD A  --재입실중증도분류정보
             USING (
                       SELECT
                              C.PT_SILLM_CTG_REC_ID       AS PT_SILLM_CTG_REC_ID
                            , C.WRT_SEQ                   AS PT_SILLM_CTG_REC_WRT_SEQ
                            , B.HSP_TP_CD                 AS HSP_TP_CD
                            , A.PACT_ID                   AS PACT_ID
                            , A.PT_NO                     AS PT_NO
                            , C.CTG_DTM                   AS PT_SILLM_CTG_DTM
                            , A.ETRM_WD_DEPT_CD           AS WD_DEPT_CD
                            , A.ETRM_WD_DEPT_CD_NM        AS WD_DEPT_CD_NM
                            , C.PT_SILLM_CTG_TL_ID        AS PT_SILLM_CTG_TL_ID
                            , C.PT_SILLM_CTG_TL_NM        AS PT_SILLM_CTG_TL_NM
                            , C.PT_SILLM_CTG_TP_CD        AS PT_SILLM_CTG_TP_CD
                            , C.PT_SILLM_CTG_TP_CD_NM     AS PT_SILLM_CTG_TP_CD_NM
                            , C.PT_SILLM_CTG_GRP_CD       AS PT_SILLM_CTG_GRP_CD
                            , C.PT_SILLM_CTG_GRP_CD_NM    AS PT_SILLM_CTG_GRP_CD_NM
                            , C.PT_SILLM_CTG_SCR_SUM      AS PT_SILLM_CTG_SCR_SUM
                            , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND A.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                   WHEN (B.LST_LOD_DTM IS NOT NULL AND B.LST_LOD_DTM > NVL(A.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND B.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN B.LST_LOD_DTM
                                   ELSE C.LST_LOD_DTM END AS LST_LOD_DTM
                         FROM HICU.UICICRID A --중환자실입실퇴실시간정보 ( 2nd )
                            , HICU.UICICRID B --중환자실입실퇴실시간정보 ( 1st )
                            , HICU.UICICRSD C --환자중증도분류기록정보
                        WHERE A.PACT_ID         = B.PACT_ID
                          AND A.ETRM_WD_DEPT_CD = B.ETRM_WD_DEPT_CD
                          AND A.HSP_TP_CD       = IN_HSP_TP_CD
                          AND A.HSP_TP_CD       = B.HSP_TP_CD
                          AND A.ETRM_DTM        > B.ETRM_DTM
                          AND A.USE_YN          = 'Y'
                          AND A.LST_YN          = 'Y'
                          AND A.PACT_TP_CD      = 'I'
                          AND B.USE_YN          = 'Y'
                          AND B.LST_YN          = 'Y'
                          AND B.PACT_TP_CD      = 'I'
                          AND B.ICU_CHOT_PLC_TP_CD IN ('01', '13') /*병실(01), ICR(13)*/
                          AND B.ETRM_DTM        = (SELECT MAX(ETRM_DTM) FROM HICU.UICICRID WHERE PACT_ID = A.PACT_ID AND USE_YN = 'Y' AND LST_YN = 'Y' AND HSP_TP_CD = A.HSP_TP_CD AND ETRM_DTM < A.ETRM_DTM)
                          AND C.PACT_ID    = A.PACT_ID
                          AND C.HSP_TP_CD  = A.HSP_TP_CD
                          AND C.PT_NO      = A.PT_NO
                          AND C.WD_DEPT_CD = A.ETRM_WD_DEPT_CD
                          AND C.HSP_TP_CD  = A.HSP_TP_CD
                          AND C.USE_YN     = 'Y'
                          AND C.LST_YN     = 'Y'
                          AND C.PACT_TP_CD = 'I'
                          AND C.CTG_DTM    BETWEEN A.ETRM_DTM AND A.CHOT_DTM
                          AND (A.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                           OR  B.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                           OR  C.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)
                   ) B
                ON (       A.PT_SILLM_CTG_REC_ID      = B.PT_SILLM_CTG_REC_ID
                     AND   A.PT_SILLM_CTG_REC_WRT_SEQ = B.PT_SILLM_CTG_REC_WRT_SEQ
                     AND   A.HSP_TP_CD                = B.HSP_TP_CD
                   )
             WHEN MATCHED
             THEN UPDATE SET A.PACT_ID                = B.PACT_ID
                           , A.PT_NO                  = B.PT_NO
                           , A.PT_SILLM_CTG_DTM       = B.PT_SILLM_CTG_DTM
                           , A.WD_DEPT_CD             = B.WD_DEPT_CD
                           , A.WD_DEPT_CD_NM          = B.WD_DEPT_CD_NM
                           , A.PT_SILLM_CTG_TL_ID     = B.PT_SILLM_CTG_TL_ID
                           , A.PT_SILLM_CTG_TL_NM     = B.PT_SILLM_CTG_TL_NM
                           , A.PT_SILLM_CTG_TP_CD     = B.PT_SILLM_CTG_TP_CD
                           , A.PT_SILLM_CTG_TP_CD_NM  = B.PT_SILLM_CTG_TP_CD_NM
                           , A.PT_SILLM_CTG_GRP_CD    = B.PT_SILLM_CTG_GRP_CD
                           , A.PT_SILLM_CTG_GRP_CD_NM = B.PT_SILLM_CTG_GRP_CD_NM
                           , A.PT_SILLM_CTG_SCR_SUM   = B.PT_SILLM_CTG_SCR_SUM
                           , A.LST_LOD_DTM            = SYSDATE
             WHEN NOT MATCHED
             THEN INSERT ( A.PT_SILLM_CTG_REC_ID
                         , A.PT_SILLM_CTG_REC_WRT_SEQ
                         , A.HSP_TP_CD
                         , A.PACT_ID
                         , A.PT_NO
                         , A.PT_SILLM_CTG_DTM
                         , A.WD_DEPT_CD
                         , A.WD_DEPT_CD_NM
                         , A.PT_SILLM_CTG_TL_ID
                         , A.PT_SILLM_CTG_TL_NM
                         , A.PT_SILLM_CTG_TP_CD
                         , A.PT_SILLM_CTG_TP_CD_NM
                         , A.PT_SILLM_CTG_GRP_CD
                         , A.PT_SILLM_CTG_GRP_CD_NM
                         , A.PT_SILLM_CTG_SCR_SUM
                         , A.FST_LOD_DTM
                         , A.LST_LOD_DTM
                         )
                  VALUES ( B.PT_SILLM_CTG_REC_ID
                         , B.PT_SILLM_CTG_REC_WRT_SEQ
                         , B.HSP_TP_CD
                         , B.PACT_ID
                         , B.PT_NO
                         , B.PT_SILLM_CTG_DTM
                         , B.WD_DEPT_CD
                         , B.WD_DEPT_CD_NM
                         , B.PT_SILLM_CTG_TL_ID
                         , B.PT_SILLM_CTG_TL_NM
                         , B.PT_SILLM_CTG_TP_CD
                         , B.PT_SILLM_CTG_TP_CD_NM
                         , B.PT_SILLM_CTG_GRP_CD
                         , B.PT_SILLM_CTG_GRP_CD_NM
                         , B.PT_SILLM_CTG_SCR_SUM
                         , SYSDATE
                         , SYSDATE
                         )
        ;
        
        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '2) 재입실중증도분류 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
            RETURN;
    END;    
END PC_EICU_BATCH_READMISSION;
