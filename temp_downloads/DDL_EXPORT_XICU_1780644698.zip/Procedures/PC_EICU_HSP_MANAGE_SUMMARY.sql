
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_HSP_MANAGE_SUMMARY" 
                          ( IN_FROM_DTE      IN  DATE
                          , IN_TO_DTE        IN  DATE     
                          , IN_HSP_TP_CD     IN VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )    
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_HSP_MANAGE_SUMMARY                                               
*    CREATEDATE     : 2021.03.31                                                               
*    Author         : 오지민                                                                     
*    Description    : 통합관제 운영통계 병원별 SUMMARY
*    Change History : 2021.03.24, 오지민, 최초작성       
                      2021.06.24, 김국경, 01인 경우 제외 처리(UCCOCDPM, UCCOCSTE 테이블 값 중복) : 공통코드의 국가지정병상으로 유지                                     
**********************************************************************************************/
BEGIN
    BEGIN 
	    OPEN OUT_CURSOR FOR   
	          WITH UNTACT_RECORD AS
			    (
			        --비대면 협진 기록 Summary
			        SELECT RER_DEPT_CD
			             , SUM(WHL_CSLT_CNT)            AS WHL_CSLT_CNT
			          FROM HICU.UCOSCNSD
--			         WHERE TO_DATE(UNTC_REC_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
                     WHERE UNTC_REC_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
			           AND HSP_TP_CD = IN_HSP_TP_CD
			         GROUP BY RER_DEPT_CD)
			   , UNTACT_VIDEO AS (   --비대면 영상 Summary
			        SELECT PT_WD_DEPT_CD
			             , SUM(WHL_TELC_CNT)            AS WHL_TELC_CNT
			          FROM HICU.UCOSNFLD A
--			         WHERE TO_DATE(UNTC_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
                     WHERE UNTC_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
			           AND HSP_TP_CD = IN_HSP_TP_CD
			         GROUP BY  PT_WD_DEPT_CD
			     )
			   , RRS AS (    --RRS SUMMARY
			        SELECT SUM(WHL_PT_CNT)        AS WHL_PT_CNT
			             , SUM(OCUR_PT_CNT)       AS OCUR_PT_CNT
			             , SUM(SBP_OCUR_CNT)      AS SBP_OCUR_CNT
			             , SUM(PR_OCUR_CNT)       AS PR_OCUR_CNT
			             , SUM(SPO2_OCUR_CNT)     AS SPO2_OCUR_CNT
			          FROM HICU.UCOSRRSD
--			         WHERE TO_DATE(OCUR_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
			         WHERE OCUR_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
			           AND HSP_TP_CD = IN_HSP_TP_CD
			             )     
			   , CONSULT AS
				(
				    SELECT SUM(RPLY_WHL_CNT)                                               AS RPLY_WHL_CNT
					     , SUM(RPLY_IN_24TM_CNT)                                           AS RPLY_IN_24TM_CNT
					     , SUM(UNTC_REPLY_WHL_CNT)                                         AS UNTC_RPLY_WHL_CNT
					     , SUM(UNTC_RPLY_IN_24TM_CNT)                                      AS UNTC_RPLY_IN_24TM_CNT
				      FROM HICU.UCOSCOSD
--				     WHERE TO_DATE(RPLY_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
			         WHERE RPLY_DT BETWEEN IN_FROM_DTE  AND IN_TO_DTE
				       AND HSP_TP_CD = IN_HSP_TP_CD)          
			    SELECT 
			           '01'                                                                     AS LARGE_CATEGORY
			         , '01'                                                                     AS SMALL_CATEGORY
			         , '비대면 협진건수'                                                          AS TITLE
			         , '병동코드'                                                                AS VALUE01_NAME
			         , 'C'                                                                      AS VALUE01_TYPE
			         , DEPT_NM                                                                  AS VALUE01
			         , '발생건수'                                                                AS VALUE02_NAME
			         , 'D0'                                                                     AS VALUE02_TYPE
			         , NVL(TO_CHAR(WHL_CSLT_CNT), '0')                                          AS VALUE02
    		         , ''                                                                       AS VALUE03_NAME
		             , 'C'                                                                      AS VALUE03_TYPE
			         , ''                                                                       AS VALUE03  
			         , ''                                                                       AS VALUE04_NAME   
			         , 'C'                                                                      AS VALUE04_TYPE
			         , ''                                                                       AS VALUE04  
			         , ''                                                                       AS VALUE05_NAME   
			         , 'C'                                                                      AS VALUE05_TYPE
			         , ''                                                                       AS VALUE05  
			         , ''                                                                       AS VALUE06_NAME   
			         , 'C'                                                                      AS VALUE06_TYPE
			         , ''                                                                       AS VALUE06  			         			         
			      FROM (
			            SELECT A.DEPT_NM
			                 , NVL(B.WHL_CSLT_CNT, 0)     AS WHL_CSLT_CNT
--			              FROM HICU.UCCOCDPM A
                          FROM (SELECT HSP_TP_CD, DEPT_CD, DEPT_NM, '01' AS LARGE_CODE, SORT_SEQ
								  FROM HICU.UCCOCDPM
								 WHERE HSP_TP_CD = IN_HSP_TP_CD
								   AND USE_YN = 'Y'
								 UNION ALL
								SELECT HSP_TP_CD, COMN_CD, COMN_CD, '02' AS LARGE_CODE, SORT_SEQ
								  FROM HICU.UCCOCSTE
								 WHERE COMN_GRP_CD = 'IC018'
								   AND USE_YN = 'Y'
								   AND HSP_TP_CD = IN_HSP_TP_CD
								   ) A
			                 , UNTACT_RECORD B
			             WHERE A.DEPT_CD = B.RER_DEPT_CD (+)
			               AND A.HSP_TP_CD = IN_HSP_TP_CD    
			               /* 2021-06.24, 김국경 : 39병동 중복나는 현상.. 제외처리 */
			               AND CASE WHEN A.DEPT_CD = '039' AND A.LARGE_CODE = '02' THEN 'N'
			                   ELSE 'Y'
			                   END = 'Y'
			             ORDER BY A.LARGE_CODE, A.SORT_SEQ)
			    UNION ALL
			    SELECT '02'                                                                     AS LARGE_CATEGORY
			         , '01'                                                                     AS SMALL_CATEGORY
			         , '비대면 영상건수'                                                              AS TITLE
			         , '병동코드'                                                                  AS VALUE01_NAME
			         , 'C'                                                                     AS VALUE01_TYPE
			         , DEPT_NM                                                                  AS VALUE01
			         , '발생건수'                                                                   AS VALUE02_NAME
			         , 'D0'                                                                     AS VALUE02_TYPE
			         , NVL(TO_CHAR(WHL_TELC_CNT), '0')                                          AS VALUE02   
    		         , ''                                                                       AS VALUE03_NAME
		             , 'C'                                                                      AS VALUE03_TYPE
			         , ''                                                                       AS VALUE03   
			         , ''                                                                       AS VALUE04_NAME   
			         , 'C'                                                                      AS VALUE04_TYPE
			         , ''                                                                       AS VALUE04  
			         , ''                                                                       AS VALUE05_NAME   
			         , 'C'                                                                      AS VALUE05_TYPE
			         , ''                                                                       AS VALUE05  
			         , ''                                                                       AS VALUE06_NAME   
			         , 'C'                                                                      AS VALUE06_TYPE
			         , ''                                                                       AS VALUE06  					         
			     FROM (
			            SELECT A.DEPT_NM
			                 , NVL(B.WHL_TELC_CNT, 0)     AS WHL_TELC_CNT
--			              FROM HICU.UCCOCDPM A
                          FROM (SELECT HSP_TP_CD, DEPT_CD, DEPT_NM, '01' AS LARGE_CODE, SORT_SEQ
								  FROM HICU.UCCOCDPM
								 WHERE HSP_TP_CD = IN_HSP_TP_CD
								   AND USE_YN = 'Y'
								 UNION ALL
								SELECT HSP_TP_CD, COMN_CD, COMN_CD, '02' AS LARGE_CODE, SORT_SEQ
								  FROM HICU.UCCOCSTE
								 WHERE COMN_GRP_CD = 'IC018'
								   AND USE_YN = 'Y'
								   AND HSP_TP_CD = IN_HSP_TP_CD
								 UNION ALL
								 SELECT IN_HSP_TP_CD, 'ETC', '기타', '03' AS LARGE_CODE, 1  FROM DUAL) A
			                 , UNTACT_VIDEO B
			             WHERE A.DEPT_CD = B.PT_WD_DEPT_CD (+)
			               AND A.HSP_TP_CD = IN_HSP_TP_CD     
			                /* 2021-06.24, 김국경 : 39병동 중복나는 현상.. 제외처리 */
			               AND CASE WHEN A.DEPT_CD = '039' AND A.LARGE_CODE = '02' THEN 'N'
			                   ELSE 'Y'
			                   END = 'Y'
			             ORDER BY A.LARGE_CODE, A.SORT_SEQ)                                             
                UNION ALL
                SELECT '03'                                                                       AS LARGE_CATEGORY
				     , '01'                                                                       AS SMALL_CATEGORY
				     , '정규타과회신'                                                                    AS TITLE
				     , '정규_전체'                                                                 AS VALUE01_NAME
				     , 'D0'                                                                       AS VALUE01_TYPE
				     , NVL(TO_CHAR(RPLY_WHL_CNT), '0')                                            AS VALUE01
				     , '정규_24시간내'                                                                    AS VALUE02_NAME
				     , 'D0'                                                                       AS VALUE02_TYPE
				     , NVL(TO_CHAR(RPLY_IN_24TM_CNT), '0')                                        AS VALUE02
				     , '정규_회신율'                                                                   AS VALUE03_NAME
				     , 'C'                                                                         AS VALUE03_TYPE
				     , NVL(TRIM(TO_CHAR((DECODE(RPLY_IN_24TM_CNT,NULL,0,RPLY_IN_24TM_CNT) /DECODE(RPLY_WHL_CNT,0,NULL,RPLY_WHL_CNT))*100,'99990.9')), '0')   AS VALUE03  
				     , '정규_비대면'                                                                 AS VALUE04_NAME
				     , 'C'                                                                      AS VALUE04_TYPE
				     , NVL(TO_CHAR(UNTC_RPLY_WHL_CNT), '0')                                          AS VALUE04
				     , '정규_비대면_24시간내'                                                               AS VALUE05_NAME
				     , 'C'                                                                      AS VALUE05_TYPE
				     , NVL(TO_CHAR(UNTC_RPLY_IN_24TM_CNT), '0')                                      AS VALUE05
				     , '정규_비대면_회신율'                                                                       AS VALUE06_NAME
				     , 'C'                                                                      AS VALUE06_TYPE
				     , NVL(TRIM(TO_CHAR((DECODE(UNTC_RPLY_IN_24TM_CNT,NULL,0,UNTC_RPLY_IN_24TM_CNT) /DECODE(UNTC_RPLY_WHL_CNT,0,NULL,UNTC_RPLY_WHL_CNT))*100,'99990.9')), '0')   AS VALUE06
				  FROM CONSULT         
			    UNION ALL
			    SELECT '04'                                                                       AS LARGE_CATEGORY
			         , '01'                                                                       AS SMALL_CATEGORY
			         , 'RRS-발생연환자수'                                                              AS TITLE
			         , '전체건수'                                                                   AS VALUE01_NAME
			         , 'D0'                                                                        AS VALUE01_TYPE
			         , NVL(TO_CHAR(WHL_PT_CNT), '0')                                              AS VALUE01
			         , '발생건수'                                                                  AS VALUE02_NAME
			         , 'D0'                                                                       AS VALUE02_TYPE
			         , NVL(TO_CHAR(OCUR_PT_CNT), '0')                                             AS VALUE02
    		         , '발생률(%)'                                                               AS VALUE03_NAME
		             , 'C'                                                                      AS VALUE03_TYPE                                                     
			         , nvl(TRIM(TO_CHAR((DECODE(OCUR_PT_CNT,NULL,0,OCUR_PT_CNT) /DECODE(WHL_PT_CNT,0,NULL,WHL_PT_CNT))*100,'99990.9')), '0')   AS VALUE03  --병상가동률		             
			         , ''                                                                       AS VALUE04_NAME   
			         , 'C'                                                                      AS VALUE04_TYPE
			         , ''                                                                       AS VALUE04  
			         , ''                                                                       AS VALUE05_NAME   
			         , 'C'                                                                      AS VALUE05_TYPE
			         , ''                                                                       AS VALUE05  
			         , ''                                                                       AS VALUE06_NAME   
			         , 'C'                                                                      AS VALUE06_TYPE
			         , ''                                                                       AS VALUE06  				             
			      FROM RRS			            
    ;          
  END;

END PC_EICU_HSP_MANAGE_SUMMARY;
