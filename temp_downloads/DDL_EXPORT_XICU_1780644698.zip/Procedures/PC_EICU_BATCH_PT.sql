
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_PT" (                    
                                                                IN_FROM_DTM         IN DATE
                                                              , IN_TO_DTM           IN DATE
                                                              , IN_HSP_TP_CD        IN VARCHAR2
                                                              , IO_ERRYN            IN OUT  VARCHAR2    --  ERROR Y/N
                                                              , IO_ERRMSG           IN OUT  VARCHAR2   --  ERROR MESSAGE   
                                                            )
IS   
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_PT
*    CREATEDATE     : 2021.02.02
*    Author         : 한가혜
*    Description    : 운영 임상지표 중환자실 환자현황 데이터 배치 
*    Change History : 2021-12-23 황선영 수정 [CSR2 :202107-00441]
**********************************************************************************************/
BEGIN 
    IO_ERRYN  := 'N';
    IO_ERRMSG := '';
     /*******************************************************************************************************************
    * DELETE : 중환자실환자지표기본(UICICSPM)  
    * FROM : ODS 환자기본(UICICRPM), 중환자실입실퇴실시간정보(UICICRID)
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
   
   BEGIN 				     
	     DELETE 
	       FROM HICU.UICICSPM A --중환자실환자지표기본
          WHERE A.CIPT_ETRM_CHOT_ID IN (SELECT DISTINCT B.CIPT_ETRM_CHOT_ID
        						          FROM HICU.UICICRPM A  --ODS-중환자기본
                        					 , HICU.UICICRID B  --ODS-중환자실입실퇴실시간정보 
                        				 WHERE A.PACT_ID              = B.PACT_ID
        								   AND A.HSP_TP_CD            = B.HSP_TP_CD
        								   AND A.PT_NO                = B.PT_NO
        								   AND B.PACT_TP_CD           = 'I'
        								   AND B.USE_YN               = 'Y'
        								   AND B.LST_YN               = 'Y'
        								   AND A.HSP_TP_CD            = IN_HSP_TP_CD
        								   AND (  A.LST_LOD_DTM BETWEEN IN_FROM_DTM 
        								                            AND IN_TO_DTM
        									   OR B.LST_LOD_DTM BETWEEN IN_FROM_DTM 
        									                        AND IN_TO_DTM
        									   )
                		      ); 
		
	   COMMIT;                     
     END;                
    
   /***************************************
    * 중환자실환자지표기본(UICICSPM) BATCH 
    ***************************************/
   BEGIN 
      MERGE INTO HICU.UICICSPM A      --중환자실환자지표기본
           USING (WITH MAIN AS (SELECT DISTINCT A.PACT_ID
                					 , A.HSP_TP_CD
                					 , A.PT_NO
                					 , A.PT_NM
                					 , A.ADS_DT
                					 , A.DS_EXPT_DT
                					 , A.SEX_TP_CD
                					 , A.AGE
                					 , A.AGE_MRK_NM
                					 , A.ADS_PATH_CD
                					 , A.ADS_PATH_CD_NM    AS ADS_PATH_NM
                					 , B.CIPT_ETRM_CHOT_ID
                					 , B.HST_SEQ
                					 , B.USE_YN
                					 , B.LST_YN
                					 , B.PACT_TP_CD
                					 , B.MED_DEPT_CD
                					 , B.MED_DEPT_CD_NM
                					 , B.RPRN_MED_DEPT_CD
                					 , B.RPRN_MED_DEPT_CD_NM
                					 , B.ETRM_DTM
                					 , B.ETRM_WD_DEPT_CD
                					 , B.ETRM_WD_DEPT_CD_NM
                					 , B.ETRM_PRM_NO
                					 , B.ETRM_BED_NO
                					 , B.EMRG_BED_YN
                					 , B.ISLT_BED_YN
                					 , B.ICU_ETRM_PATH_CLS_CD
                					 , B.ICU_ETRM_PATH_CLS_CD_NM
                					 , B.CHOT_DTM
                					 , B.ICU_CHOT_PLC_TP_CD
                					 , B.ICU_CHOT_PLC_TP_CD_NM
                					 , B.CHOT_WD_MTD_CD
                					 , B.CHOT_WD_MTD_CD_NM
                					 , B.FST_LOD_DTM
                					 , B.LST_LOD_DTM
                				  FROM HICU.UICICRPM A  --ODS-중환자기본
                					 , HICU.UICICRID B  --ODS-중환자실입실퇴실시간정보
                				 WHERE A.PACT_ID            = B.PACT_ID
                				   AND A.HSP_TP_CD          = B.HSP_TP_CD
                				   AND A.PT_NO              = B.PT_NO
                				   AND B.PACT_TP_CD         = 'I'
                				   AND B.USE_YN             = 'Y'
                				   AND B.LST_YN             = 'Y'
                				   AND A.HSP_TP_CD          = IN_HSP_TP_CD
                				   AND B.HSP_TP_CD          = IN_HSP_TP_CD
                				   AND (A.LST_LOD_DTM BETWEEN IN_FROM_DTM 
                										  AND IN_TO_DTM
                					 OR B.LST_LOD_DTM BETWEEN IN_FROM_DTM 
                					                      AND IN_TO_DTM
                				    )
                )        
                
                   SELECT DISTINCT A.CIPT_ETRM_CHOT_ID
						, A.HSP_TP_CD
						, A.PACT_ID
						, A.PT_NO
						, A.PT_NM
						, A.ADS_DT
						, A.DS_EXPT_DT
						, A.SEX_TP_CD
						, A.AGE
						, A.AGE_MRK_NM
						, A.ADS_PATH_CD
						, A.ADS_PATH_NM
						, A.MED_DEPT_CD
						, A.MED_DEPT_CD_NM
						, A.RPRN_MED_DEPT_CD
						, A.RPRN_MED_DEPT_CD_NM
						, A.ETRM_DTM
						, A.ETRM_WD_DEPT_CD
						, A.ETRM_WD_DEPT_CD_NM
						, A.ETRM_PRM_NO
						, A.ETRM_BED_NO
						, A.EMRG_BED_YN
						, A.ISLT_BED_YN
						, A.ICU_ETRM_PATH_CLS_CD
						, A.ICU_ETRM_PATH_CLS_CD_NM
						, A.CHOT_DTM
						, A.ICU_CHOT_PLC_TP_CD
						, A.ICU_CHOT_PLC_TP_CD_NM
						, A.CHOT_WD_MTD_CD
						, A.CHOT_WD_MTD_CD_NM
						, NULL AS APCS_REC_INPT_DTM
						, NULL AS APCS_REC_WRT_SEQ
						, NULL AS APCS_PT_STS_CD
						, NULL AS APCS_PT_STS_CD_NM
						, NULL AS APCS_SUM_SCR
						, NULL AS AGPY_AOM_CNT
						, NULL AS AGPY_AOM_EMRG_CNT
						, A.FST_LOD_DTM
						, A.LST_LOD_DTM 
                     FROM MAIN A
                 ) B
              ON ( 
                      B.CIPT_ETRM_CHOT_ID = A.CIPT_ETRM_CHOT_ID
                  AND B.HSP_TP_CD         = A.HSP_TP_CD
                  --AND B.PT_NO             = A.PT_NO 
                  --AND B.ADS_DT            = A.ADS_DT
                  --AND B.ETRM_DTM          = A.ETRM_DTM
                 )
            
            --최종 데이터 적재     
            WHEN MATCHED THEN   -- 데이터가 있다면 UPDATE
                 UPDATE SET A.PT_NM                    = NVL(A.PT_NM, B.PT_NM)                                   --환자명
                          , A.DS_EXPT_DT               = B.DS_EXPT_DT                              --퇴원예정일자
                          , A.ADS_PATH_CD              = B.ADS_PATH_CD                             --입원경로코드
                          , A.ADS_PATH_NM              = B.ADS_PATH_NM                             --입원경로명
                          , A.MED_DEPT_CD_NM           = B.MED_DEPT_CD_NM                          --진료부서코드명
                          , A.RPRN_MED_DEPT_CD_NM      = B.RPRN_MED_DEPT_CD_NM                     --대표진료부서코드명
                          , A.ETRM_WD_DEPT_CD_NM       = B.ETRM_WD_DEPT_CD_NM                      --입실병동부서코드명
                          , A.EMRG_BED_YN              = B.EMRG_BED_YN                             --응급병상여부
                          , A.ISLT_BED_YN              = B.ISLT_BED_YN                             --격리병상여부
                          , A.ICU_ETRM_PATH_CLS_CD     = B.ICU_ETRM_PATH_CLS_CD                    --중환자실입실경로유형코드
                          , A.ICU_ETRM_PATH_CLS_CD_NM  = B.ICU_ETRM_PATH_CLS_CD_NM                 --중환자실입실경로유형코드명
                          , A.CHOT_DTM                 = B.CHOT_DTM                                --퇴실일시
                          , A.ICU_CHOT_PLC_TP_CD       = B.ICU_CHOT_PLC_TP_CD                      --중환자실퇴실장소구분코드
                          , A.ICU_CHOT_PLC_TP_CD_NM    = B.ICU_CHOT_PLC_TP_CD_NM                   --중환자실퇴실장소구분코드명
                          , A.CHOT_WD_MTD_CD           = B.CHOT_WD_MTD_CD                          --퇴실병동진료과코드
                          , A.CHOT_WD_MTD_CD_NM        = B.CHOT_WD_MTD_CD_NM                       --퇴실병동진료과코드명
                          , A.LST_LOD_DTM              = SYSDATE                                   --최종적재일시
                          , A.AGE_MRK_NM               = B.AGE_MRK_NM                              --연령표시명
                          
            --최초 데이터 적재
            WHEN NOT MATCHED THEN   -- 데이터가 없다면  INSERT
                 INSERT ( A.CIPT_ETRM_CHOT_ID				--중환자입실퇴실ID(pk)
                        , A.HSP_TP_CD					--병원구분코드
                        , A.PACT_ID						--원무접수ID
                        , A.PT_NO						--환자번호
                        , A.PT_NM						--환자명
                        , A.ADS_DT						--입원일자
                        , A.DS_EXPT_DT					--퇴원예정일자
                        , A.SEX_TP_CD					--성별구분코드
                        , A.AGE							--연령
                        , A.AGE_MRK_NM					--연령표시명
                        , A.ADS_PATH_CD					--입원경로코드
                        , A.ADS_PATH_NM					--입원경로명
                        , A.MED_DEPT_CD					--진료부서코드
                        , A.MED_DEPT_CD_NM				--진료부서코드명
                        , A.RPRN_MED_DEPT_CD			--대표진료부서코드
                        , A.RPRN_MED_DEPT_CD_NM			--대표진료부서코드명
                        , A.ETRM_DTM					--입실일시
                        , A.ETRM_WD_DEPT_CD				--입실병동부서코드
                        , A.ETRM_WD_DEPT_CD_NM			--입실병동부서코드명
                        , A.ETRM_PRM_NO					--입실병실번호
                        , A.ETRM_BED_NO					--입실병상번호
                        , A.EMRG_BED_YN					--응급병상여부
                        , A.ISLT_BED_YN					--격리병상여부
                        , A.ICU_ETRM_PATH_CLS_CD		--중환자실입실경로유형코드
                        , A.ICU_ETRM_PATH_CLS_CD_NM		--중환자실입실경로유형코드명
                        , A.CHOT_DTM					--퇴실일시
                        , A.ICU_CHOT_PLC_TP_CD			--중환자실퇴실장소구분코드
                        , A.ICU_CHOT_PLC_TP_CD_NM		--중환자실퇴실장소구분코드명
                        , A.CHOT_WD_MTD_CD				--퇴실병동진료과코드
                        , A.CHOT_WD_MTD_CD_NM			--퇴실병동진료과코드명
                        , A.APCS_REC_INPT_DTM			--아파치스코어기록입력일시
                        , A.APCS_REC_WRT_SEQ			--아파치스코어기록작성순번
                        , A.APCS_PT_STS_CD				--아파치스코어환자상태코드
                        , A.APCS_PT_STS_CD_NM			--아파치스코어환자상태코드명
                        , A.APCS_SUM_SCR				--아파치스코어합계점수
                        , A.AGPY_AOM_CNT				--혈관조영시술수
                        , A.AGPY_AOM_EMRG_CNT			--혈관조영시술응급수
                        , A.FST_LOD_DTM					--최초적재일시
                        , A.LST_LOD_DTM					--최종적재일시
                        )
                 VALUES ( B.CIPT_ETRM_CHOT_ID 
                        , B.HSP_TP_CD
                        , B.PACT_ID
                        , B.PT_NO
                        , B.PT_NM
                        , B.ADS_DT
                        , B.DS_EXPT_DT
                        , B.SEX_TP_CD
                        , B.AGE   
                        , B.AGE_MRK_NM
                        , B.ADS_PATH_CD
                        , B.ADS_PATH_NM
                        , B.MED_DEPT_CD
                        , B.MED_DEPT_CD_NM
                        , B.RPRN_MED_DEPT_CD
                        , B.RPRN_MED_DEPT_CD_NM
                        , B.ETRM_DTM
                        , B.ETRM_WD_DEPT_CD
                        , B.ETRM_WD_DEPT_CD_NM
                        , B.ETRM_PRM_NO
                        , B.ETRM_BED_NO
                        , B.EMRG_BED_YN
                        , B.ISLT_BED_YN
                        , B.ICU_ETRM_PATH_CLS_CD
                        , B.ICU_ETRM_PATH_CLS_CD_NM
                        , B.CHOT_DTM
                        , B.ICU_CHOT_PLC_TP_CD
                        , B.ICU_CHOT_PLC_TP_CD_NM
                        , B.CHOT_WD_MTD_CD
                        , B.CHOT_WD_MTD_CD_NM
                        , B.APCS_REC_INPT_DTM         --아파치스코어기록입력일시
                        , B.APCS_REC_WRT_SEQ          --아파치스코어기록작성순번
                        , B.APCS_PT_STS_CD            --아파치스코어환자상태코드
                        , B.APCS_PT_STS_CD_NM         --아파치스코어환자상태코드명
                        , B.APCS_SUM_SCR              --아파치스코어합계점수  
                        , NVL(B.AGPY_AOM_CNT, 0)              --혈관조영시술수 
                        , NVL(B.AGPY_AOM_EMRG_CNT, 0)         --혈관조영시술응급수
                        , B.LST_LOD_DTM               --최초적재일시
                        , SYSDATE                     --최종적재일시 
                        );
                        
               EXCEPTION
    		        WHEN OTHERS THEN
    		            IO_ERRYN  := 'Y';
    		            IO_ERRMSG := '(XICU.PC_EICU_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || 'MERGE INTO HICU.UICICSPM = ' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
    		            RETURN ; 
     END;    --UICICSPM BATCH END 
   
    
   /*******************************************************************************************************************
    * DELETE : 중환자실환자중증도분류정보(UICICSPD)  
    * FROM : ODS 환자기본(UICICRPM), 중환자실입실퇴실시간정보(UICICRID), 
            환자중증도분류기록정보(UICICRSD)
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
   BEGIN 
	      DELETE 
	        FROM HICU.UICICSPD A--중환자실환자중증도분류정보  
	       WHERE EXISTS (SELECT 1
	                       FROM HICU.UICICRSD B --ODS-환자중증도분류기록정보
	                      WHERE A.PT_SILLM_CTG_REC_ID          = B.PT_SILLM_CTG_REC_ID
	                        AND A.PT_SILLM_CTG_REC_WRT_SEQ     = B.WRT_SEQ
	                        AND A.HSP_TP_CD                    = B.HSP_TP_CD
	                        AND B.LST_LOD_DTM            BETWEEN IN_FROM_DTM
                                			                 AND IN_TO_DTM 
	                   );
	   COMMIT; 
     END;        
   /********************************************
    * 중환자실환자중증도분류정보(UICICSPD) BATCH  
    *********************************************/
   BEGIN
      MERGE INTO HICU.UICICSPD A      --중환자실환자중증도분류정보
           USING (WITH RSD_DATA AS (
                				SELECT A.PT_SILLM_CTG_REC_ID
                				     , A.WRT_SEQ             AS PT_SILLM_CTG_REC_WRT_SEQ
                				     , A.HSP_TP_CD
                				     , A.PT_NO
                				     , A.CTG_DTM             AS PT_SILLM_CTG_DTM
                				     , A.PT_SILLM_CTG_TL_ID
                				     , A.PT_SILLM_CTG_TL_NM
                				     , A.PACT_ID
                				     , A.PACT_TP_CD
                				     , A.WD_DEPT_CD
                				     , A.WD_DEPT_CD_NM
                				     , A.PT_SILLM_CTG_TP_CD                      --병동, 중환자실,...
                				     , A.PT_SILLM_CTG_TP_CD_NM
                				     , A.PT_SILLM_CTG_GRP_CD                     --1군, 2군, 3군,..
                				     , A.PT_SILLM_CTG_GRP_CD_NM
                				     , A.PT_SILLM_CTG_SCR_SUM
                				     , A.USE_YN
                				     , A.LST_YN
                				     , A.FST_WRT_DTM
                				     , A.LST_CHG_DTM
                				     , A.FST_LOD_DTM
                				     , A.LST_LOD_DTM
                				  FROM HICU.UICICRSD A --ODS-환자중증도분류기록정보
                				 WHERE A.PACT_TP_CD        = 'I'
                				   AND A.PT_SILLM_CTG_TP_CD IN('2', '4')    -- 중환자실 중증도 분류 2021-12-23 황선영 수정
                				   AND A.USE_YN            = 'Y'
                				   AND A.LST_YN            = 'Y' 
                				   AND A.HSP_TP_CD         = IN_HSP_TP_CD
                				   AND A.LST_LOD_DTM BETWEEN IN_FROM_DTM
                				                         AND IN_TO_DTM
                )

				  SELECT B.PT_SILLM_CTG_REC_ID
					   , B.PT_SILLM_CTG_REC_WRT_SEQ
					   , B.HSP_TP_CD
					   , A.PACT_ID
					   , A.PT_NO
					   , A.CIPT_ETRM_CHOT_ID
					   , B.PT_SILLM_CTG_DTM
					   , B.WD_DEPT_CD
					   , B.WD_DEPT_CD_NM
					   , B.PT_SILLM_CTG_TL_ID
					   , B.PT_SILLM_CTG_TL_NM
					   , B.PT_SILLM_CTG_TP_CD
					   , B.PT_SILLM_CTG_TP_CD_NM
					   , B.PT_SILLM_CTG_GRP_CD
					   , B.PT_SILLM_CTG_GRP_CD_NM
					   , B.PT_SILLM_CTG_SCR_SUM
					   , B.FST_LOD_DTM
					   , B.LST_LOD_DTM
					FROM RSD_DATA B
					   , UICICSPM A
				   WHERE B.PACT_ID                = A.PACT_ID
					 AND B.PT_NO                  = A.PT_NO 
					 AND B.HSP_TP_CD              = A.HSP_TP_CD
					 --AND B.WD_DEPT_CD             = A.ETRM_WD_DEPT_CD  
					 AND B.PT_SILLM_CTG_DTM BETWEEN TRUNC(A.ETRM_DTM) 
					                            AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM))
                 ) B
              ON (    
                      B.PT_SILLM_CTG_REC_ID      = A.PT_SILLM_CTG_REC_ID
                  AND B.PT_SILLM_CTG_REC_WRT_SEQ = A.PT_SILLM_CTG_REC_WRT_SEQ
                  AND B.HSP_TP_CD                = A.HSP_TP_CD
                  AND B.CIPT_ETRM_CHOT_ID        = A.CIPT_ETRM_CHOT_ID
                 )
                 
            WHEN MATCHED THEN   -- 데이터가 있다면 UPDATE
                 UPDATE SET A.PT_SILLM_CTG_DTM       = B.PT_SILLM_CTG_DTM           --환자중증도분류일시
                          , A.WD_DEPT_CD             = B.WD_DEPT_CD                 --병동부서코드
                          , A.WD_DEPT_CD_NM          = B.WD_DEPT_CD_NM              --병동부서코드명
                          , A.PT_SILLM_CTG_TL_ID     = B.PT_SILLM_CTG_TL_ID         --환자중증도분류도구ID
                          , A.PT_SILLM_CTG_TL_NM     = B.PT_SILLM_CTG_TL_NM         --환자중증도분류도구명
                          , A.PT_SILLM_CTG_TP_CD     = B.PT_SILLM_CTG_TP_CD         --환자중증도분류구분코드
                          , A.PT_SILLM_CTG_TP_CD_NM  = B.PT_SILLM_CTG_TP_CD_NM      --환자중증도분류구분코드명
                          , A.PT_SILLM_CTG_GRP_CD    = B.PT_SILLM_CTG_GRP_CD        --환자중증도분류그룹코드
                          , A.PT_SILLM_CTG_GRP_CD_NM = B.PT_SILLM_CTG_GRP_CD_NM     --환자중증도분류그룹코드명
                          , A.PT_SILLM_CTG_SCR_SUM   = B.PT_SILLM_CTG_SCR_SUM       --환자중증도분류점수합계
                          , A.LST_LOD_DTM            = SYSDATE                      --최종적재일시
            
            WHEN NOT MATCHED THEN   -- 데이터가 없다면  INSERT
                 INSERT ( A.PT_SILLM_CTG_REC_ID          --환자중증도분류기록ID
                        , A.PT_SILLM_CTG_REC_WRT_SEQ     --환자중증도분류기록작성순번
                        , A.HSP_TP_CD                    --병원코드
                        , A.PACT_ID                      --원무접수ID
                        , A.PT_NO                        --환자번호
                        , A.CIPT_ETRM_CHOT_ID            --중환자입실퇴실ID
                        , A.PT_SILLM_CTG_DTM             --환자중증도분류일시
                        , A.WD_DEPT_CD                   --병동부서코드
                        , A.WD_DEPT_CD_NM                --병동부서코드명
                        , A.PT_SILLM_CTG_TL_ID           --환자중증도분류도구ID
                        , A.PT_SILLM_CTG_TL_NM           --환자중증도분류도구명
                        , A.PT_SILLM_CTG_TP_CD           --환자중증도분류구분코드
                        , A.PT_SILLM_CTG_TP_CD_NM        --환자중증도분류구분코드명
                        , A.PT_SILLM_CTG_GRP_CD          --환자중증도분류그룹코드
                        , A.PT_SILLM_CTG_GRP_CD_NM       --환자중증도분류그룹코드명
                        , A.PT_SILLM_CTG_SCR_SUM         --환자중증도분류점수합계
                        , A.FST_LOD_DTM                  --최초적재일시
                        , A.LST_LOD_DTM                  --최종적재일시
                        )
                 VALUES ( B.PT_SILLM_CTG_REC_ID          --환자중증도분류기록ID
                        , B.PT_SILLM_CTG_REC_WRT_SEQ     --환자중증도분류기록작성순번
                        , B.HSP_TP_CD                    --병원코드
                        , B.PACT_ID                      --원무접수ID
                        , B.PT_NO                        --환자번호     
                        , B.CIPT_ETRM_CHOT_ID            --중환자입실퇴실ID
                        , B.PT_SILLM_CTG_DTM             --환자중증도분류일시
                        , B.WD_DEPT_CD                   --병동부서코드
                        , B.WD_DEPT_CD_NM                --병동부서코드명
                        , B.PT_SILLM_CTG_TL_ID           --환자중증도분류도구ID
                        , B.PT_SILLM_CTG_TL_NM           --환자중증도분류도구명
                        , B.PT_SILLM_CTG_TP_CD           --환자중증도분류구분코드
                        , B.PT_SILLM_CTG_TP_CD_NM        --환자중증도분류구분코드명
                        , B.PT_SILLM_CTG_GRP_CD          --환자중증도분류그룹코드
                        , B.PT_SILLM_CTG_GRP_CD_NM       --환자중증도분류그룹코드명
                        , B.PT_SILLM_CTG_SCR_SUM         --환자중증도분류점수합계
                        , SYSDATE                        --최초적재일시
                        , SYSDATE                        --최종적재일시
                        );   
                        
               EXCEPTION
    		        WHEN OTHERS THEN
    		            IO_ERRYN  := 'Y';
    		            IO_ERRMSG := '(XICU.PC_EICU_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || 'MERGE INTO HICU.UICICSPD = ' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
    		            RETURN ; 

   END;    --UICICSPD BATCH END 
   
   
   /*******************************************************************************************************************
    * DELETE : 혈관조영시술건수(HICU.UICISROD)  
    * FROM : 중환자실입실퇴실(UICICSPM), 
            ODS 혈관조영시술 정보(UICICROD)
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
   BEGIN 
	      DELETE 
	        FROM HICU.UICISROD A--혈관조영시술건수  
	       WHERE EXISTS (SELECT 1
	                       FROM HICU.UICICROD B --ODS-혈관조영시술정보
	                      WHERE A.PT_NO             = B.PT_NO
	                        AND A.OP_EXPT_DT        = B.OP_EXPT_DT
	                        AND A.HSP_TP_CD         = B.HSP_TP_CD
	                        AND B.LST_LOD_DTM BETWEEN IN_FROM_DTM
                                			      AND IN_TO_DTM 
	                   );
	   COMMIT; 
     END;      
     
   /**************************************************************
    * 혈관조영시술건수(HICU.UICISROD)  BATCH 
    ***************************************************************/
   BEGIN 
      MERGE INTO HICU.UICISROD A      --혈관조영시술건수
           USING (         
                   SELECT DISTINCT B.PT_NO
        				, B.HSP_TP_CD
        				, B.OP_EXPT_DT
        				, COUNT(B.OP_EXPT_DT)                                    AS AGPY_AOM_CNT         --혈관조영시술 총 건수
        				, COUNT(DECODE(B.AGPY_SEQ_CTG_CD, '응급', 'Y'))          AS AGPY_AOM_EMRG_CNT    --응급 혈관조영시술 건수
            		 FROM (SELECT A.PT_NO
            		            , A.HSP_TP_CD
            		            , A.ETRM_DTM
            		            , A.CHOT_DTM
        			         FROM HICU.UICICSPM A  --중환자실입실퇴실 정보
        			        WHERE A.HSP_TP_CD          = IN_HSP_TP_CD
        			          AND A.ETRM_WD_DEPT_CD    = 'CICU'        --CICU만 가져오기 
            			) A
            			, ( SELECT B.PT_NO
                                 , B.HSP_TP_CD
                                 , B.OP_EXPT_DT
                                 , B.AGPY_SEQ_CTG_CD
	                          FROM HICU.UICICROD B --ODS-혈관조영시술정보
                             WHERE B.HSP_TP_CD         = IN_HSP_TP_CD
                			   AND B.LST_LOD_DTM BETWEEN IN_FROM_DTM
                			                         AND IN_TO_DTM 
                	    ) B  --혈관조영시술 정보
            	    WHERE A.PT_NO            = B.PT_NO
            		  AND A.HSP_TP_CD        = B.HSP_TP_CD
            		  AND B.OP_EXPT_DT BETWEEN TRUNC(A.ETRM_DTM)
            			                   AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM))
                 GROUP BY B.PT_NO, B.HSP_TP_CD, B.OP_EXPT_DT
                 ) B
              ON ( 
                      B.PT_NO             = A.PT_NO
                  AND B.HSP_TP_CD         = A.HSP_TP_CD
                  AND B.OP_EXPT_DT        = A.OP_EXPT_DT
                 )
            
            --최종 데이터 적재     
            WHEN MATCHED THEN   -- 데이터가 있다면 UPDATE
                 UPDATE SET A.AGPY_AOM_CNT             = NVL(B.AGPY_AOM_CNT, A.AGPY_AOM_CNT)                            --혈관조영시술수
                          , A.AGPY_AOM_EMRG_CNT        = NVL(B.AGPY_AOM_EMRG_CNT, A.AGPY_AOM_EMRG_CNT)                       --혈관조영시술응급수
                          , A.LST_LOD_DTM              = SYSDATE                                   --최종적재일시
                        
    		--최초 데이터 적재            
    		WHEN NOT MATCHED THEN   -- 데이터가 없다면  INSERT
                 INSERT ( A.PT_NO                        --환자번호 
                        , A.OP_EXPT_DT	                 --수술예정일자
                        , A.HSP_TP_CD                    --병원코드
                        , A.AGPY_AOM_CNT	             --혈관조영시술수
                        , A.AGPY_AOM_EMRG_CNT	         --혈관조영응급시술수
                        , A.FST_LOD_DTM                  --최초적재일시
                        , A.LST_LOD_DTM                  --최종적재일시
                        )
                 VALUES ( B.PT_NO                        --환자번호 
                        , B.OP_EXPT_DT	                 --수술예정일자
                        , B.HSP_TP_CD                    --병원코드
                        , B.AGPY_AOM_CNT	             --혈관조영시술수
                        , B.AGPY_AOM_EMRG_CNT	         --혈관조영응급시술수
                        , SYSDATE                        --최초적재일시
                        , SYSDATE                        --최종적재일시
                        );  

               EXCEPTION
    		        WHEN OTHERS THEN
    		            IO_ERRYN  := 'Y';
    		            IO_ERRMSG := '(XICU.PC_EICU_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || 'MERGE INTO HICU.UICISROD = ' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
    		            RETURN ; 

     END;    --HICU.UICISROD 혈관조영시술건수 BATCH   
      
     /************************************************************
    * 중환자실환자지표기본(UICICSPM) UPDATE
    * 아파치점수(HICU.UICICRAD A   --ODS 아파치스코어 정보 기준
    ************************************************************/  
   BEGIN 
      MERGE INTO HICU.UICICSPM A      --중환자실환자지표기본
           USING ( SELECT A.CIPT_ETRM_CHOT_ID
						, A.HSP_TP_CD
						, A.PACT_ID
						, A.PT_NO
						, B.INPT_DTM          AS APCS_REC_INPT_DTM
    					, B.WRT_SEQ           AS APCS_REC_WRT_SEQ
    					, B.APCS_PT_STS_CD    AS APCS_PT_STS_CD
    					, B.APCS_PT_STS_CD_NM AS APCS_PT_STS_CD_NM
    					, B.SUM_SCR           AS APCS_SUM_SCR
				     FROM HICU.UICICSPM A
				        , (SELECT A.PACT_ID
				                , A.PT_NO
				                , A.HSP_TP_CD
				                , A.WD_DEPT_CD
				                , A.INPT_DTM
	    					    , A.WRT_SEQ
	    					    , A.APCS_PT_STS_CD
	    					    , A.APCS_PT_STS_CD_NM
	    					    , A.SUM_SCR
	    				     FROM HICU.UICICRAD A   --ODS 아파치스코어 정보
	    					    , (SELECT PACT_ID, PT_NO, HSP_TP_CD, PACT_TP_CD
	    						        , MAX(INPT_DTM) AS  INPT_DTM
	    						        , MAX(WRT_SEQ)  AS  WRT_SEQ
	    						     FROM HICU.UICICRAD     --ODS 아파치스코어 정보
	    						    WHERE HSP_TP_CD            = IN_HSP_TP_CD
	    						      AND LST_LOD_DTM    BETWEEN IN_FROM_DTM
	    				                                     AND IN_TO_DTM
	    					     GROUP BY PACT_ID, PT_NO, HSP_TP_CD, PACT_TP_CD
	    					    ) B
    	    				 WHERE A.HSP_TP_CD     = IN_HSP_TP_CD
    				           AND A.PACT_ID       = B.PACT_ID
    	    				   AND A.PT_NO         = B.PT_NO
    	    				   AND A.HSP_TP_CD     = B.HSP_TP_CD
    	    				   AND A.PACT_TP_CD    = B.PACT_TP_CD
    	    				   AND A.INPT_DTM      = B.INPT_DTM
    	    				   AND A.WRT_SEQ       = B.WRT_SEQ
				  			) B
    				    WHERE A.HSP_TP_CD       = IN_HSP_TP_CD
    				      AND A.PACT_ID         = B.PACT_ID
    				      AND A.PT_NO           = B.PT_NO
    				      AND A.HSP_TP_CD       = B.HSP_TP_CD
    				      AND B.INPT_DTM  BETWEEN TRUNC(A.ETRM_DTM)
    				                          AND TRUNC(DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE, NULL, SYSDATE, A.CHOT_DTM))
                 ) B
              ON ( 
                      B.CIPT_ETRM_CHOT_ID = A.CIPT_ETRM_CHOT_ID
                  AND B.HSP_TP_CD         = A.HSP_TP_CD
                 )
            
            --최종 데이터 적재     
            WHEN MATCHED THEN   -- 데이터가 있다면 UPDATE
                 UPDATE SET A.APCS_REC_INPT_DTM        = NVL(B.APCS_REC_INPT_DTM, A.APCS_REC_INPT_DTM)                       --아파치스코어기록입력일시
                          , A.APCS_REC_WRT_SEQ         = NVL(B.APCS_REC_WRT_SEQ, A.APCS_REC_WRT_SEQ)                        --아파치스코어기록작성순번
                          , A.APCS_PT_STS_CD           = NVL(B.APCS_PT_STS_CD, A.APCS_PT_STS_CD)                          --아파치스코어환자상태코드
                          , A.APCS_PT_STS_CD_NM        = NVL(B.APCS_PT_STS_CD_NM, A.APCS_PT_STS_CD_NM)                       --아파치스코어환자상태코드명
                          , A.APCS_SUM_SCR             = NVL(B.APCS_SUM_SCR, A.APCS_SUM_SCR)                            --아파치스코어합계점수
                          , A.LST_LOD_DTM              = SYSDATE                                  --최종적재일시  
                       ; 
                       
               EXCEPTION
    		        WHEN OTHERS THEN
    		            IO_ERRYN  := 'Y';
    		            IO_ERRMSG := '(XICU.PC_EICU_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || '아파치스코어 UPDATE HICU.UICICSPM = ' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
    		            RETURN ; 
     END;    --UICICSPM 업데이트 아파치스코어기록 정보 
       
END PC_EICU_BATCH_PT;
