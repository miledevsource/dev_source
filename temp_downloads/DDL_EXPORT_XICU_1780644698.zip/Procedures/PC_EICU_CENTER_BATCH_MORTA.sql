
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_MORTA" 
                          ( IN_PRMR_STR_DTM   IN  DATE
                          , IN_PRMR_END_DTM   IN  DATE
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , IO_ERR_YN         IN OUT  VARCHAR2    --  ERROR Y/N
                          , IO_ERR_MSG        IN OUT  VARCHAR2    --  ERROR MESSAGE
                          )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_MORTA
*    CREATEDATE     : 2021.02.24
*    Author         : 신솔
*    Description    : 통합관제 임상지표 중환자실 사망률 데이터 배치
*    Change History : 2021.02.24, 신솔, 최초작성
**********************************************************************************************/
AS
    V_CURSOR          SYS_REFCURSOR; 
    V_COMN_GRP_CD     VARCHAR(500);
    V_COMN_CD         VARCHAR(500);
    V_COMN_CD_NM      VARCHAR(500);
    V_COMN_CD_EXPL    VARCHAR(500);
    V_DTRL1_NM        VARCHAR(500);
    V_DTRL2_NM        VARCHAR(500);
    V_DTRL3_NM        VARCHAR(500);
BEGIN
    /*******************************************
     * 병원 별 중환자실 코드 조회
     *******************************************/
    DECLARE CURSOR DTM_CURSOR IS SELECT DISTINCT TRUNC(X.CHOT_DTM) AS CHOT_DTM
                                   FROM HICU.UICICSDM X --중환자실사망지표기본
                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                    AND X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM                                     
                                  UNION      
                                 SELECT DISTINCT TRUNC(Y.CHOT_DTM) AS CHOT_DTM
                                   FROM HICU.UICICSDM Y --중환자실사망지표기본
                                  WHERE Y.CIPT_ETRM_CHOT_ID IN(SELECT DISTINCT Z.CIPT_ETRM_CHOT_ID
                                                                 FROM HICU.UICICSDD Z --중환자실사망중증도분류정보
                                                                WHERE Z.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                                                  AND Z.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)
                                  ORDER BY CHOT_DTM
                                 ;
    DTM DTM_CURSOR%ROWTYPE;
    BEGIN
        OPEN DTM_CURSOR;
        LOOP FETCH DTM_CURSOR INTO DTM;
        EXIT WHEN DTM_CURSOR%NOTFOUND;
            BEGIN            

                DECLARE CURSOR DEPT_CD_CURSOR IS SELECT X.DEPT_CD  AS WD_DEPT_CD
                                                      , X.RMK_CNTE AS WD_DEPT_CD_NM
                                                   FROM HICU.UCCOCDPM X
                                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                                  ORDER BY X.SORT_SEQ
                                                 ;
                REC DEPT_CD_CURSOR%ROWTYPE;
                BEGIN
                    OPEN DEPT_CD_CURSOR;
                    LOOP FETCH DEPT_CD_CURSOR INTO REC;
                    EXIT WHEN DEPT_CD_CURSOR%NOTFOUND;
                
                        /********************************************
                         * 임상지표 조회
                         **********************************************/ 
                        BEGIN
                            XICU.PC_EICU_STATISTIC_MORTALITY( DTM.CHOT_DTM
                                                            , DTM.CHOT_DTM
                                                            , REC.WD_DEPT_CD
                                                            , IN_HIS_HSP_TP_CD
                                                            , V_CURSOR
                                                            )
                                                            ;
                                                         
                        END;
                        
                        /********************************************
                         * 통합중환자실사망지표기본 BATCH
                         **********************************************/
                        BEGIN
                            LOOP
                            FETCH V_CURSOR 
                             INTO V_COMN_GRP_CD  
                                , V_COMN_CD      
                                , V_COMN_CD_NM 
                                , V_COMN_CD_EXPL
                                , V_DTRL1_NM     
                                , V_DTRL2_NM     
                                , V_DTRL3_NM      
                                ;
                            EXIT WHEN V_CURSOR%NOTFOUND;
                                IF V_COMN_GRP_CD = 'BY_DEPT' THEN
                                    BEGIN
                                        --통합중환자실환자지표진료과정보 ( UCCICSDD ) UPDATE OR INSERT
                                        MERGE INTO HICU.UCCICSDD A
                                             USING DUAL
                                                ON (       A.WD_DEPT_CD           = REC.WD_DEPT_CD
                                                     AND   A.CHOT_DT_SEQ          = TO_CHAR(DTM.CHOT_DTM, 'YYYYMMDD')
                                                     AND   A.RPRN_MED_DEPT_CD     = V_COMN_CD
                                                     AND   A.HSP_TP_CD            = IN_HIS_HSP_TP_CD
                                                   )
                                            WHEN MATCHED
                                            THEN UPDATE SET A.RPRN_MED_DEPT_CD_NM = V_COMN_CD_NM
                                                          , A.SIRM_PT_CNT         = TO_NUMBER(V_DTRL1_NM)
                                                          , A.LOD_DTM             = SYSDATE
                                            WHEN NOT MATCHED
                                            THEN INSERT ( A.WD_DEPT_CD
                                                        , A.CHOT_DT_SEQ
                                                        , A.RPRN_MED_DEPT_CD
                                                        , A.HSP_TP_CD
                                                        , A.RPRN_MED_DEPT_CD_NM
                                                        , A.SIRM_PT_CNT
                                                        , A.LOD_DTM
                                                        )
                                                   VALUES
                                                        ( REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.CHOT_DTM, 'YYYYMMDD')
                                                        , V_COMN_CD
                                                        , IN_HIS_HSP_TP_CD
                                                        , V_COMN_CD_NM
                                                        , TO_NUMBER(V_DTRL1_NM)
                                                        , SYSDATE
                                                        )
                                        ;
                                        
                                        EXCEPTION
                                            WHEN OTHERS THEN
                                                IO_ERR_YN  := 'Y';
                                                IO_ERR_MSG := '1) 통합중환자실환자지표진료과정보 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                            RETURN;
                                    END; --통합중환자실환자지표진료과정보 ( UCCICSDD )  BATCH  END
                                ELSE
                                    BEGIN
                                        --통합중환자실사망지표기본 ( UCCICSDM ) UPDATE OR INSERT
                                        MERGE INTO HICU.UCCICSDM A
                                             USING DUAL
                                                ON (       A.WD_DEPT_CD    = REC.WD_DEPT_CD
                                                     AND   A.CHOT_DT_SEQ   = TO_CHAR(DTM.CHOT_DTM, 'YYYYMMDD')
                                                     AND   A.HSP_TP_CD     = IN_HIS_HSP_TP_CD
                                                   )
                                            WHEN MATCHED
                                            THEN UPDATE SET A.DTH_PT_CNT              = DECODE(V_COMN_CD_EXPL, 'PT_CNT', TO_NUMBER(V_DTRL1_NM), A.DTH_PT_CNT)
                                                          , A.CHOT_PT_CNT             = DECODE(V_COMN_CD_EXPL, 'PT_CNT', TO_NUMBER(V_DTRL2_NM), A.CHOT_PT_CNT)
                                                          , A.SEX_MALE_CNT            = DECODE(V_COMN_CD_EXPL, 'SEX_MALE_CNT', TO_NUMBER(V_DTRL1_NM), A.SEX_MALE_CNT)
                                                          , A.SEX_FEML_CNT            = DECODE(V_COMN_CD_EXPL, 'SEX_FEML_CNT', TO_NUMBER(V_DTRL1_NM), A.SEX_FEML_CNT)
                                                          , A.AGE_10_GRP_BLW_CNT      = DECODE(V_COMN_CD_EXPL, 'AGE_10_GRP_BLW_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_10_GRP_BLW_CNT)
                                                          , A.AGE_20_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_20_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_20_GRP_CNT)
                                                          , A.AGE_30_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_30_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_30_GRP_CNT)
                                                          , A.AGE_40_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_40_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_40_GRP_CNT)
                                                          , A.AGE_50_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_50_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_50_GRP_CNT)
                                                          , A.AGE_60_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_60_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_60_GRP_CNT)
                                                          , A.AGE_70_GRP_UPR_CNT      = DECODE(V_COMN_CD_EXPL, 'AGE_70_GRP_UPR_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_70_GRP_UPR_CNT)
                                                          , A.PT_SILLM_CTG_1_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_1_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_1_GRP_CNT)
                                                          , A.PT_SILLM_CTG_2_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_2_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_2_GRP_CNT)
                                                          , A.PT_SILLM_CTG_3_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_3_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_3_GRP_CNT)
                                                          , A.PT_SILLM_CTG_4_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_4_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_4_GRP_CNT)
                                                          , A.PT_SILLM_CTG_5_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_5_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_5_GRP_CNT)
                                                          , A.PT_SILLM_CTG_6_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_6_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_6_GRP_CNT)
                                                          , A.APCS_SUM_10_SCR_BLW_CNT = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_10_SCR_BLW_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_10_SCR_BLW_CNT)
                                                          , A.APCS_SUM_20_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_20_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_20_SCR_CNT)
                                                          , A.APCS_SUM_30_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_30_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_30_SCR_CNT)
                                                          , A.APCS_SUM_40_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_40_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_40_SCR_CNT)
                                                          , A.APCS_SUM_50_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_50_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_50_SCR_CNT)
                                                          , A.APCS_SUM_60_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_60_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_60_SCR_CNT)
                                                          , A.APCS_SUM_70_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_70_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_70_SCR_CNT)
                                                          , A.APCS_SUM_80_SCR_UPR_CNT = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_80_SCR_UPR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_80_SCR_UPR_CNT)
                                            WHEN NOT MATCHED
                                            THEN INSERT ( A.WD_DEPT_CD
                                                        , A.CHOT_DT_SEQ
                                                        , A.HSP_TP_CD
                                                        , A.WD_DEPT_CD_NM
                                                        , A.CHOT_YY
                                                        , A.CHOT_MM
                                                        , A.CHOT_DY
                                                        , A.HLDY_YN
                                                        , A.DTH_PT_CNT
                                                        , A.CHOT_PT_CNT
                                                        , A.SEX_MALE_CNT
                                                        , A.SEX_FEML_CNT
                                                        , A.AGE_10_GRP_BLW_CNT
                                                        , A.AGE_20_GRP_CNT
                                                        , A.AGE_30_GRP_CNT
                                                        , A.AGE_40_GRP_CNT
                                                        , A.AGE_50_GRP_CNT
                                                        , A.AGE_60_GRP_CNT
                                                        , A.AGE_70_GRP_UPR_CNT
                                                        , A.PT_SILLM_CTG_1_GRP_CNT
                                                        , A.PT_SILLM_CTG_2_GRP_CNT
                                                        , A.PT_SILLM_CTG_3_GRP_CNT
                                                        , A.PT_SILLM_CTG_4_GRP_CNT
                                                        , A.PT_SILLM_CTG_5_GRP_CNT
                                                        , A.PT_SILLM_CTG_6_GRP_CNT
                                                        , A.APCS_SUM_10_SCR_BLW_CNT
                                                        , A.APCS_SUM_20_SCR_CNT
                                                        , A.APCS_SUM_30_SCR_CNT
                                                        , A.APCS_SUM_40_SCR_CNT
                                                        , A.APCS_SUM_50_SCR_CNT
                                                        , A.APCS_SUM_60_SCR_CNT
                                                        , A.APCS_SUM_70_SCR_CNT
                                                        , A.APCS_SUM_80_SCR_UPR_CNT
                                                        , A.LOD_DTM
                                                        )
                                                 VALUES ( REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.CHOT_DTM, 'YYYYMMDD')
                                                        , IN_HIS_HSP_TP_CD
                                                        , REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.CHOT_DTM, 'YYYY')
                                                        , TO_CHAR(DTM.CHOT_DTM, 'MM')
                                                        , TO_CHAR(DTM.CHOT_DTM, 'DD')
                                                        , NVL((SELECT X.HLDY_YN FROM HICU.UICIIRHD X WHERE TO_CHAR(X.DT_CD, 'YYYY-MM-DD') = TO_CHAR(DTM.CHOT_DTM, 'YYYY-MM-DD')), '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_CNT', V_DTRL2_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'SEX_MALE_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'SEX_FEML_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_10_GRP_BLW_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_20_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_30_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_40_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_50_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_60_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_70_GRP_UPR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_1_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_2_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_3_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_4_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_5_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_6_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_10_SCR_BLW_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_20_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_30_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_40_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_50_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_60_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_70_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_80_SCR_UPR_CNT', V_DTRL1_NM, '')
                                                        , SYSDATE
                                                        )
                                        ;
                                        
                                        EXCEPTION
                                            WHEN OTHERS THEN
                                                IO_ERR_YN  := 'Y';
                                                IO_ERR_MSG := '2) 통합중환자실사망지표기본 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                            RETURN;
                                    END; --통합중환자실사망지표기본 ( UCCICSDM )  BATCH END        
                                END IF; 
                            END LOOP;
                            COMMIT;
                        END;
                    END LOOP;
                    CLOSE DEPT_CD_CURSOR;
                END;

            END; -- 변경일자 데이터 BATCH END            
        END LOOP; --DTM_CURSOR 종료
        CLOSE DTM_CURSOR;
    END;
END PC_EICU_CENTER_BATCH_MORTA;
