
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_SUMMARY_MORTA" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_SUMMARY_MORTA
*    CREATEDATE     : 2021.03.08
*    Author         : 신솔
*    Description    : 중환자실별 사망률 요약정보
*    Change History : 2021.03.08, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            INDICATORS OUT DTO
            ************************/
            SELECT B.DEPT_CD                        AS WD_DEPT_CD
                 , TO_CHAR(NVL(A.DTH_PT_CNT, 0))    AS DTRL1_NM
                 , TO_CHAR(NVL(A.CHOT_PT_CNT, 0))   AS DTRL2_NM
                 , RTRIM(TO_CHAR(DECODE(NVL(A.CHOT_PT_CNT, 0), 0, 0, ROUND((NVL(A.DTH_PT_CNT, 0) / NVL(A.CHOT_PT_CNT, 0)) * 100, 1)), 'FM9990.9'), '.') || '%' AS DTRL3_NM
                 , NVL(A.PT_SILLM_CTG_1_GRP_CNT, 0) AS PT_SILLM_CTG_1_GRP_CNT
                 , NVL(A.PT_SILLM_CTG_2_GRP_CNT, 0) AS PT_SILLM_CTG_2_GRP_CNT
                 , NVL(A.PT_SILLM_CTG_3_GRP_CNT, 0) AS PT_SILLM_CTG_3_GRP_CNT
                 , NVL(A.PT_SILLM_CTG_4_GRP_CNT, 0) AS PT_SILLM_CTG_4_GRP_CNT
                 , NVL(A.PT_SILLM_CTG_5_GRP_CNT, 0) AS PT_SILLM_CTG_5_GRP_CNT
                 , NVL(A.PT_SILLM_CTG_6_GRP_CNT, 0) AS PT_SILLM_CTG_6_GRP_CNT
              FROM (SELECT X.WD_DEPT_CD                    AS WD_DEPT_CD
                         , SUM(X.DTH_PT_CNT)               AS DTH_PT_CNT
                         , SUM(X.CHOT_PT_CNT)              AS CHOT_PT_CNT
                         , SUM(X.PT_SILLM_CTG_1_GRP_CNT)   AS PT_SILLM_CTG_1_GRP_CNT
                         , SUM(X.PT_SILLM_CTG_2_GRP_CNT)   AS PT_SILLM_CTG_2_GRP_CNT
                         , SUM(X.PT_SILLM_CTG_3_GRP_CNT)   AS PT_SILLM_CTG_3_GRP_CNT
                         , SUM(X.PT_SILLM_CTG_4_GRP_CNT)   AS PT_SILLM_CTG_4_GRP_CNT
                         , SUM(X.PT_SILLM_CTG_5_GRP_CNT)   AS PT_SILLM_CTG_5_GRP_CNT
                         , SUM(X.PT_SILLM_CTG_6_GRP_CNT)   AS PT_SILLM_CTG_6_GRP_CNT
                      FROM HICU.UCCICSDM X
                     WHERE X.CHOT_DT_SEQ BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                       AND X.HSP_TP_CD   = IN_HIS_HSP_TP_CD
                     GROUP BY X.WD_DEPT_CD
                   ) A
                 , HICU.UCCOCDPM B
             WHERE A.WD_DEPT_CD(+) = B.DEPT_CD
               AND B.HSP_TP_CD     = IN_HIS_HSP_TP_CD
             ORDER BY B.SORT_SEQ
        ;    
    END;
END PC_EICU_CENTER_SUMMARY_MORTA;
