
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SEL_TEST_OP_INFO" ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   SYS_REFCURSOR )
IS
BEGIN
    OPEN OUT_CURSOR FOR
           SELECT   b.ICU_TP_CD
                 , b.PT_NO
                 , b.INPUT_DT
                 , b.HIST_SEQ
                 , b.HSP_TP_CD
                 , b.ITEM_TP_CD
                 , b.ITEM_CD
                 , b.ITEM_SUB_CD
                 , b.MEMO
                 , b.REG_DTM
                 , b.REG_ID
                 , b.IS_READ
             FROM   BB_TEST_OP_INFO b
             WHERE   1=1
                AND b.PT_NO  = IN_PT_NO
                AND b.HSP_TP_CD  = IN_HSP_TP_CD
                AND (b.REG_DTM = TO_CHAR(SYSDATE, 'YY/MM/DD') OR b.ITEM_TP_CD = 'C') -- 협진은 등록일 무시
           ORDER BY b.INPUT_DT DESC
          ;
END PC_EICU_SEL_TEST_OP_INFO;
