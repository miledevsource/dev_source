
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_ODS_UICICRSD_SAVE" 
                            ( IN_SCHD_EXCT_ID IN VARCHAR2         -- 01.배치 실행 ID
                            , IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                            , IN_FROM_DTM     IN DATE             -- 03.조회시작일자
                            , IN_TO_DTM       IN DATE             -- 03.조회종료일자                                         
                            , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                            , IO_ERRMSG       IN OUT  VARCHAR2    -- 05. ERROR MESSAGE
                            )  
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_ODS_UICICRSD_SAVE                                               
*    CREATEDATE     : 2021.03.24
*    Author         : 한가혜                                                                     
*    Description    : U121_UICI(ODS)_환자중증도분류기록정보 데이터 적재
*    Change History : 2021.03.24                                               
**********************************************************************************************/
 AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    /*******************************************************************************************************************
    * DELETE : HICU.UICICRSD A  --U121_UICI(ODS)_환자중증도분류기록정보
    * FROM : XICU.EMEI006V
    * Description : ODS테이블에서 변경된 정보가 있으면 최종정보를 적재하기 위해 운영 임상지표 테이블 데이터를 삭제한다. 
    *******************************************************************************************************************/
    BEGIN 
         DELETE 
           FROM HICU.UICICRSD A  --U121_UICI(ODS)_환자중증도분류기록정보
          WHERE EXISTS ( SELECT 1
                           FROM XICU.EMEI006V B
                          WHERE A.PT_SILLM_CTG_REC_ID     = B.PT_SILLM_CTG_REC_ID
                            AND A.WRT_SEQ                 = B.PT_SILLM_CTG_REC_WRT_SEQ
                            AND B.LST_LOD_DTM       BETWEEN IN_FROM_DTM 
                                                        AND IN_TO_DTM
                      ); 
      END;
    /*******************************************
    * _환자중증도분류기록정보(UICICRSD) BATCH 
    *******************************************/
    BEGIN        
        MERGE INTO HICU.UICICRSD A  --U121_UICI(ODS)_환자중증도분류기록정보
             USING ( SELECT PT_SILLM_CTG_REC_ID
                          , PT_SILLM_CTG_REC_WRT_SEQ
                          , PT_NO
                          , PT_SILLM_CTG_DTM
                          , PT_SILLM_CTG_TL_ID
                          , PT_SILLM_CTG_TL_NM
                          , PACT_ID
                          , PACT_TP_CD
                          , WD_DEPT_CD
                          , WD_DEPT_CD_NM
                          , PT_SILLM_CTG_TP_CD                    --병동, 정신건강,...
                          , PT_SILLM_CTG_TP_CD_NM
                          , PT_SILLM_CTG_GRP_CD                   --1군, 2군, 3군...
                          , PT_SILLM_CTG_GRP_CD_NM
                          , PT_SILLM_CTG_SCR_SUM
                          , USE_YN
                          , LST_YN 
                          , FST_LOD_DTM
                          , LST_LOD_DTM
                       FROM XICU.EMEI006V
                      WHERE LST_LOD_DTM BETWEEN IN_FROM_DTM AND IN_TO_DTM
                   ) B
                ON (    A.PT_SILLM_CTG_REC_ID   = B.PT_SILLM_CTG_REC_ID
                    AND A.HSP_TP_CD             = IN_HSP_TP_CD--B.HSP_TP_CD
                    AND A.WRT_SEQ               = B.PT_SILLM_CTG_REC_WRT_SEQ
                    --AND A.PT_NO                 = B.PT_NO
                    --AND A.PACT_ID               = B.PACT_ID
                   )
              WHEN MATCHED THEN
                   --최종 적재
                   UPDATE SET A.PT_SILLM_CTG_TL_ID          = B.PT_SILLM_CTG_TL_ID
                            , A.PT_SILLM_CTG_TL_NM          = B.PT_SILLM_CTG_TL_NM
                            , A.PACT_TP_CD                  = B.PACT_TP_CD
                            , A.WD_DEPT_CD                  = B.WD_DEPT_CD
                            , A.WD_DEPT_CD_NM               = B.WD_DEPT_CD_NM
                            , A.PT_SILLM_CTG_TP_CD          = B.PT_SILLM_CTG_TP_CD
                            , A.PT_SILLM_CTG_TP_CD_NM       = B.PT_SILLM_CTG_TP_CD_NM
                            , A.PT_SILLM_CTG_GRP_CD         = B.PT_SILLM_CTG_GRP_CD
                            , A.PT_SILLM_CTG_GRP_CD_NM      = B.PT_SILLM_CTG_GRP_CD_NM
                            , A.PT_SILLM_CTG_SCR_SUM        = B.PT_SILLM_CTG_SCR_SUM
                            , A.USE_YN                      = B.USE_YN
                            , A.LST_YN                      = B.LST_YN
                            , A.FST_WRT_DTM                 = B.FST_LOD_DTM
                            , A.LST_CHG_DTM                 = B.LST_LOD_DTM
                            , A.FST_LOD_DTM                 = B.LST_LOD_DTM  --최초적재일시
                            , A.LST_LOD_DTM                 = SYSDATE        --최종적재일시
             
              WHEN NOT MATCHED THEN
                   --최초 적재    
                   INSERT ( A.PT_SILLM_CTG_REC_ID       --환자중증도분류기록ID
                          , A.WRT_SEQ             --작성순번
                          , A.HSP_TP_CD           --병원구분코드
                          , A.PT_NO             --환자번호
                          , A.CTG_DTM             --분류일시
                          , A.PT_SILLM_CTG_TL_ID        --환자중증도분류도구ID
                          , A.PT_SILLM_CTG_TL_NM        --환자중증도분류도구명
                          , A.PACT_ID             --원무접수ID
                          , A.PACT_TP_CD            --원무접수구분코드
                          , A.WD_DEPT_CD            --병동부서코드
                          , A.WD_DEPT_CD_NM         --병동부서코드명
                          , A.PT_SILLM_CTG_TP_CD        --환자중증도분류구분코드
                          , A.PT_SILLM_CTG_TP_CD_NM     --환자중증도분류구분코드명
                          , A.PT_SILLM_CTG_GRP_CD       --환자중증도분류그룹코드
                          , A.PT_SILLM_CTG_GRP_CD_NM      --환자중증도분류그룹코드명
                          , A.PT_SILLM_CTG_SCR_SUM      --환자중증도분류점수합계
                          , A.USE_YN              --사용여부
                          , A.LST_YN              --최종여부
                          , A.FST_WRT_DTM           --최초작성일시
                          , A.LST_CHG_DTM           --최종변경일시
                          , A.FST_LOD_DTM           --최초적재일시
                          , A.LST_LOD_DTM           --최종적재일시
                          )
                   VALUES ( B.PT_SILLM_CTG_REC_ID
                          , B.PT_SILLM_CTG_REC_WRT_SEQ
                          , IN_HSP_TP_CD
                          , B.PT_NO
                          , B.PT_SILLM_CTG_DTM
                          , B.PT_SILLM_CTG_TL_ID
                          , B.PT_SILLM_CTG_TL_NM
                          , B.PACT_ID
                          , B.PACT_TP_CD
                          , B.WD_DEPT_CD
                          , B.WD_DEPT_CD_NM
                          , B.PT_SILLM_CTG_TP_CD
                          , B.PT_SILLM_CTG_TP_CD_NM
                          , B.PT_SILLM_CTG_GRP_CD
                          , B.PT_SILLM_CTG_GRP_CD_NM
                          , B.PT_SILLM_CTG_SCR_SUM
                          , B.USE_YN
                          , B.LST_YN
                          , B.FST_LOD_DTM
                          , B.LST_LOD_DTM
                          , SYSDATE                              --최초적재일시
                          , SYSDATE                              --최종적재일시
                          );
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_ODS_UICICRSD_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || 'IN_FROM_DTM :' || TO_CHAR(IN_FROM_DTM, 'YYYY-MM-DD') || 'IN_TO_DTM :' || TO_CHAR(IN_TO_DTM, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_ODS_UICICRSD_SAVE;
