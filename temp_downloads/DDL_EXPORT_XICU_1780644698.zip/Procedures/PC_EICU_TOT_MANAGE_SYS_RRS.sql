
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_TOT_MANAGE_SYS_RRS" 
(
  IN_TM       IN  NUMBER
  , OUT_CURSOR1  OUT  SYS_REFCURSOR
  , OUT_CURSOR2  OUT  SYS_REFCURSOR
)
IS
  RRS_TOT_CNT VARCHAR2(10);
  RRS_NEWS_CNT VARCHAR2(10);
  RRS_UNCHECK_CNT VARCHAR2(5);
BEGIN

  PKG_NEORRS_MAIN.PC_RRS_LIST_ALL_COUNT(24, RRS_TOT_CNT, RRS_NEWS_CNT);

  SELECT    COUNT(COUNT(1)) INTO RRS_UNCHECK_CNT
  FROM    RRS_VALUE r
  WHERE    1=1
      AND r.RRS_STATE_CD = 'I'
      AND SYSDATE - r.ENT_DTM <= IN_TM / 24.0
  GROUP BY   r.PT_NO;

  OPEN OUT_CURSOR1 FOR
    SELECT    ROWNUM() AS "INDEX"
          , TITLE
          , CNT
    FROM    (
      -- 미확인 수
      SELECT     '미확인' AS "TITLE"
            , RRS_UNCHECK_CNT AS "CNT"
      FROM     DUAL
      UNION ALL

      -- 병원 별 RRS 발생 수
      SELECT    wvc.HSP_NM
            , FN_GET_RRS_PAT_COUNT(wvc.HSP_TP_CD, IN_TM)
      FROM     WD_VALUE_COUNT wvc
      WHERE     1=1
    );

  OPEN OUT_CURSOR2 FOR
    SELECT DISTINCT
      'FALSE' AS "BGCOLOR"
      , TO_CHAR(r.ENT_DTM, 'YYYY-MM-DD') AS "DATE"
      , TO_CHAR(r.ENT_DTM, 'HH24:MI:SS') AS "TIME"
      , r.HSP_TP_CD AS "HSP_TP_CD"
      , NVL(wvc.HSP_NM, r.HSP_TP_CD) AS "HSP_NM"
      , r.WARD_NO || '/' || r.BED_NO AS "LOC"
      , NVL(rd.DETL_CD_NM, r.RRS_ITEM_CD) AS "DETL_CD_NM"
      , r.RRS_VALUE AS "RRS_VALUE"
    FROM     RRS_VALUE r
    LEFT JOIN  WD_VALUE_COUNT wvc
        ON  wvc.HSP_TP_CD = r.HSP_TP_CD
    LEFT JOIN  RRS_DETAIL rd
        ON  r.RRS_ITEM_CD IN (rd.DETL_CD_1, rd.DETL_CD_2, rd.DETL_CD_3, rd.DETL_CD_4)
    WHERE    SYSDATE - r.ENT_DTM <= IN_TM / 24.0
      AND r.ITEM_NEWS_SCORE  >= '3';

  /*
  OPEN OUT_CURSOR2 FOR
    select distinct
        'FALSE' AS BGCOLOR
        , to_char(r.ENT_DTM, 'YYYY-MM-DD') AS "DATE"
        , to_char(r.ENT_DTM, 'HH24:MI:SS') AS "TIME"
        , r.HSP_TP_CD AS "HSP_TP_CD"
        , wvc.HSP_NM AS "HSP_NM"
      , r.WARD_NO || '/' || r.BED_NO AS "LOC"
      , i.DETL_CD_NM AS "DETL_CD_NM"
      , r.RRS_VALUE AS "RRS_VALUE"
  from RRS_VALUE r
    , RRS_USER u
    , RRS_DETAIL d
    , RRS_DETAIL i
    , (SELECT DISTINCT wv.HSP_TP_CD, wv.HSP_NM FROM WD_VALUE_COUNT wv) wvc

  where 1=1     -- 시연기 용도


  AND  wvc.HSP_TP_CD = r.HSP_TP_CD

  and r.ENT_DTE = TO_CHAR(SYSDATE, 'YYYYMMDD')
  and r.ENT_DTM >= ( select max(ENT_DTM) - 1/24 * IN_TM  --  1/24/60*20
    from RRS_VALUE av
    where av.HSP_TP_CD = r.HSP_TP_CD
    and av.PT_NO     = r.PT_NO
    and av.ENT_DTE = r.ENT_DTE  )
  and u.HSP_TP_CD(+) = r.HSP_TP_CD
  and r.CFRM_ID = u.USR_ID(+)
  and u.HIST_SEQ(+) = 0

  and d.HSP_TP_CD = r.HSP_TP_CD
  and d.MSTR_CD = 'STAT_CD'
  and r.RRS_STATE_CD = d.DETL_CD

  and i.HSP_TP_CD = r.HSP_TP_CD
  and i.MSTR_CD IN ('VITAL','VITAL_ADD', 'LAB', 'LAB_ADD', 'DIRECT')
  and i.USE_YN = 'Y'
  AND r.RRS_ITEM_CD IN (i.DETL_CD_1, i.DETL_CD_2, i.DETL_CD_3, i.DETL_CD_4)

  UNION ALL

    select DISTINCT
        'FALSE' AS BGCOLOR
        , to_char(r.ENT_DTM, 'YYYY-MM-DD') AS "DATE"
        , to_char(r.ENT_DTM, 'HH24:MI:SS') AS "TIME"
        , r.HSP_TP_CD AS "HSP_TP_CD"
        , wvc.HSP_NM AS "HSP_NM"
      , r.WARD_NO AS "LOC"
      , i.DETL_CD_NM AS "DETL_CD_NM"
      , r.RRS_VALUE AS "RRS_VALUE"
  from RRS_VALUE r
      , RRS_USER u
      , RRS_DETAIL d
      , RRS_DETAIL i
      , (select MAX_VAL, MIN_VAL, DEPT_CD, ITEM_CD
        from RRS_ITEM_STD
        where mstr_Cd = 'VITAL'
        and AGE_GRP = 'A'
        and HIST_SEQ = 0) cd
      , (SELECT DISTINCT wv.HSP_TP_CD, wv.HSP_NM FROM WD_VALUE_COUNT wv) wvc
  where 1=1     -- 시연기 용도

  AND  wvc.HSP_TP_CD = r.HSP_TP_CD

  AND r.ENT_DTE = TO_CHAR(SYSDATE, 'YYYYMMDD')
  and r.ENT_DTM >= ( select max(ENT_DTM) - 1/24 * IN_TM  --  1/24/60*20
    from RRS_VALUE av
    where av.HSP_TP_CD = r.HSP_TP_CD
    and av.PT_NO     = r.PT_NO
    and av.ENT_DTE = r.ENT_DTE  )
  and r.RRS_STATE_CD <> 'X'

  and u.HSP_TP_CD(+) = r.HSP_TP_CD
  and r.CFRM_ID = u.USR_ID(+)
  and u.HIST_SEQ(+) = 0

  and d.HSP_TP_CD = r.HSP_TP_CD
  and d.MSTR_CD = 'STAT_CD'
  and r.RRS_STATE_CD = d.DETL_CD

  and i.HSP_TP_CD = r.HSP_TP_CD
  and i.MSTR_CD IN ('VITAL','VITAL_ADD', 'LAB', 'LAB_ADD', 'DIRECT')
        and i.USE_YN = 'Y'
    AND r.RRS_ITEM_CD IN (i.DETL_CD_1, i.DETL_CD_2, i.DETL_CD_3, i.DETL_CD_4)

  and r.WARD_NO = cd.DEPT_CD
  and r.RRS_ITEM_CD = cd.ITEM_CD
   ; */


RETURN;
END PC_EICU_TOT_MANAGE_SYS_RRS;
