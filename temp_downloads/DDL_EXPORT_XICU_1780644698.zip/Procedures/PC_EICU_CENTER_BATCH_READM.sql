
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_READM" 
                          ( IN_PRMR_STR_DTM   IN      DATE
                          , IN_PRMR_END_DTM   IN      DATE
                          , IN_HIS_HSP_TP_CD  IN      VARCHAR2
                          , IO_ERR_YN         IN OUT  VARCHAR2    --  ERROR Y/N
                          , IO_ERR_MSG        IN OUT  VARCHAR2    --  ERROR MESSAGE
                          )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_READM
*    CREATEDATE     : 2021.03.03
*    Author         : 신솔
*    Description    : 통합관제 임상지표 중환자실 재입실 현황 데이터 배치
*    Change History : 2021.03.03, 신솔, 최초작성
**********************************************************************************************/
AS
    V_CURSOR          SYS_REFCURSOR; 
    V_COMN_GRP_CD     VARCHAR(500);
    V_COMN_CD         VARCHAR(500);
    V_COMN_CD_NM      VARCHAR(500);
    V_COMN_CD_EXPL    VARCHAR(500);
    V_DTRL1_NM        VARCHAR(500);
    V_DTRL2_NM        VARCHAR(500);
    V_DTRL3_NM        VARCHAR(500);
BEGIN
    /*******************************************
     * 병원 별 중환자실 코드 조회
     *******************************************/
    DECLARE CURSOR DTM_CURSOR IS SELECT DISTINCT TRUNC(X.TH2_ETRM_DTM) AS TH2_ETRM_DTM
                                   FROM HICU.UICICSRM X --재입실지표기본
                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                    AND X.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                                    AND X.TH1_ETRM_WD_DEPT_CD = X.TH2_ETRM_WD_DEPT_CD
                                    AND X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM                                     
                                  UNION  
                                 SELECT DISTINCT TRUNC(X.TH1_CHOT_DTM) AS TH2_ETRM_DTM
                                   FROM HICU.UICICSRM X --재입실지표기본
                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                    AND X.TH1_ICU_CHOT_PLC_TP_CD IN('01', '13')
                                    AND X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM  
                                    AND X.TH1_CHOT_DTM IS NOT NULL -- 10-20 황선영 빌드                                   
                                  UNION 
                                 SELECT DISTINCT TRUNC(Y.PT_SILLM_CTG_DTM) AS TH2_ETRM_DTM
                                   FROM HICU.UICICSRD Y --재입실중증도분류정보
                                  WHERE Y.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                    AND Y.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                  ORDER BY TH2_ETRM_DTM
                                 ;
    DTM DTM_CURSOR%ROWTYPE;
    BEGIN
        OPEN DTM_CURSOR;
        LOOP FETCH DTM_CURSOR INTO DTM;
        EXIT WHEN DTM_CURSOR%NOTFOUND;
            BEGIN       
                DECLARE CURSOR DEPT_CD_CURSOR IS SELECT X.DEPT_CD  AS WD_DEPT_CD
                                                      , X.RMK_CNTE AS WD_DEPT_CD_NM
                                                   FROM HICU.UCCOCDPM X
                                                  WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                                  ORDER BY X.SORT_SEQ
                                                 ;
                REC DEPT_CD_CURSOR%ROWTYPE;
                BEGIN
                    OPEN DEPT_CD_CURSOR;
                    LOOP FETCH DEPT_CD_CURSOR INTO REC;
                    EXIT WHEN DEPT_CD_CURSOR%NOTFOUND;
                
                        /********************************************
                         * 임상지표 조회
                         **********************************************/ 
                        BEGIN
                            XICU.PC_EICU_STATISTIC_READMISSION( DTM.TH2_ETRM_DTM
                                                              , DTM.TH2_ETRM_DTM
                                                              , REC.WD_DEPT_CD
                                                              , IN_HIS_HSP_TP_CD
                                                              , V_CURSOR
                                                              )
                                                              ;
                                                         
                        END;
                        
                        /********************************************
                         * 통합재입실지표기본 BATCH
                         **********************************************/
                        BEGIN
                            LOOP
                            FETCH V_CURSOR 
                             INTO V_COMN_GRP_CD  
                                , V_COMN_CD      
                                , V_COMN_CD_NM 
                                , V_COMN_CD_EXPL
                                , V_DTRL1_NM     
                                , V_DTRL2_NM     
                                , V_DTRL3_NM      
                                ;
                            EXIT WHEN V_CURSOR%NOTFOUND;
                                IF V_COMN_GRP_CD = 'BY_DEPT' THEN
                                    BEGIN
                                        --통합재입실지표진료과정보 ( UCCICSRD ) UPDATE OR INSERT
                                        MERGE INTO HICU.UCCICSRD A
                                             USING DUAL
                                                ON (       A.WD_DEPT_CD           = REC.WD_DEPT_CD
                                                     AND   A.TH2_ETRM_DT_SEQ      = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                     AND   A.RPRN_MED_DEPT_CD     = V_COMN_CD
                                                     AND   A.HSP_TP_CD            = IN_HIS_HSP_TP_CD
                                                   )
                                            WHEN MATCHED
                                            THEN UPDATE SET A.RPRN_MED_DEPT_CD_NM = V_COMN_CD_NM
                                                          , A.SIRM_PT_CNT         = TO_NUMBER(V_DTRL1_NM)
                                                          , A.LOD_DTM             = SYSDATE
                                            WHEN NOT MATCHED
                                            THEN INSERT ( A.WD_DEPT_CD
                                                        , A.TH2_ETRM_DT_SEQ
                                                        , A.RPRN_MED_DEPT_CD
                                                        , A.HSP_TP_CD
                                                        , A.RPRN_MED_DEPT_CD_NM
                                                        , A.SIRM_PT_CNT
                                                        , A.LOD_DTM
                                                        )
                                                   VALUES
                                                        ( REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                        , V_COMN_CD
                                                        , IN_HIS_HSP_TP_CD
                                                        , V_COMN_CD_NM
                                                        , TO_NUMBER(V_DTRL1_NM)
                                                        , SYSDATE
                                                        )
                                        ;
                                        
                                        EXCEPTION
                                            WHEN OTHERS THEN
                                                IO_ERR_YN  := 'Y';
                                                IO_ERR_MSG := '1) 통합재입실지표진료과정보 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                            RETURN;
                                    END; --통합재입실지표진료과정보 ( UCCICSRD )  BATCH  END 
                                ELSIF V_COMN_GRP_CD = 'READM_RATE' THEN
                                    BEGIN
                                        BEGIN
                                            --통합재입실지표퇴실환자정보 ( UCCICSOD ) UPDATE OR INSERT
                                            MERGE INTO HICU.UCCICSOD A
                                                 USING DUAL
                                                    ON (       A.WD_DEPT_CD     = REC.WD_DEPT_CD
                                                         AND   A.CHOT_DT_SEQ    = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                         AND   A.HSP_TP_CD      = IN_HIS_HSP_TP_CD
                                                       )
                                                WHEN MATCHED
                                                THEN UPDATE SET A.WD_DEPT_CD_NM = REC.WD_DEPT_CD_NM
                                                              , A.CHOT_YY       = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYY')
                                                              , A.CHOT_MM       = TO_CHAR(DTM.TH2_ETRM_DTM, 'MM')
                                                              , A.CHOT_DY       = TO_CHAR(DTM.TH2_ETRM_DTM, 'DD')
                                                              , A.CHOT_PT_CNT   = TO_NUMBER(V_DTRL2_NM)
                                                              , A.LOD_DTM       = SYSDATE
                                                WHEN NOT MATCHED
                                                THEN INSERT ( A.WD_DEPT_CD
                                                            , A.CHOT_DT_SEQ
                                                            , A.HSP_TP_CD
                                                            , A.WD_DEPT_CD_NM
                                                            , A.CHOT_YY
                                                            , A.CHOT_MM
                                                            , A.CHOT_DY
                                                            , A.CHOT_PT_CNT
                                                            , A.LOD_DTM
                                                            )
                                                       VALUES
                                                            ( REC.WD_DEPT_CD
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                            , IN_HIS_HSP_TP_CD
                                                            , REC.WD_DEPT_CD_NM
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYY')
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'MM')
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'DD')
                                                            , TO_NUMBER(V_DTRL2_NM)
                                                            , SYSDATE
                                                            )
                                            ;
                                            
                                            EXCEPTION
                                                WHEN OTHERS THEN
                                                    IO_ERR_YN  := 'Y';
                                                    IO_ERR_MSG := '2) 통합재입실지표퇴실환자정보 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                                RETURN;
                                        END; --통합재입실지표퇴실환자정보 ( UCCICSOD )  BATCH  END
                                        BEGIN
                                            --통합재입실지표기본 : 재입실환자수 ( UCCICSRM : RPT_ETRM_PT_CNT ) UPDATE OR INSERT
                                            MERGE INTO HICU.UCCICSRM A
                                                 USING DUAL
                                                    ON (       A.WD_DEPT_CD       = REC.WD_DEPT_CD
                                                         AND   A.TH2_ETRM_DT_SEQ  = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                         AND   A.HSP_TP_CD        = IN_HIS_HSP_TP_CD
                                                       )
                                                WHEN MATCHED
                                                THEN UPDATE SET A.RPT_ETRM_PT_CNT = TO_NUMBER(V_DTRL1_NM)
                                                              , A.LOD_DTM         = SYSDATE
                                                WHEN NOT MATCHED
                                                THEN INSERT ( A.WD_DEPT_CD
                                                            , A.TH2_ETRM_DT_SEQ
                                                            , A.HSP_TP_CD
                                                            , A.WD_DEPT_CD_NM
                                                            , A.TH2_ETRM_YY
                                                            , A.TH2_ETRM_MM
                                                            , A.TH2_ETRM_DY
                                                            , A.RPT_ETRM_PT_CNT
                                                            , A.LOD_DTM
                                                            )
                                                       VALUES
                                                            ( REC.WD_DEPT_CD
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                            , IN_HIS_HSP_TP_CD
                                                            , REC.WD_DEPT_CD_NM
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYY')
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'MM')
                                                            , TO_CHAR(DTM.TH2_ETRM_DTM, 'DD')
                                                            , TO_NUMBER(V_DTRL1_NM)
                                                            , SYSDATE
                                                            )
                                            ;
                                            
                                            EXCEPTION
                                                WHEN OTHERS THEN
                                                    IO_ERR_YN  := 'Y';
                                                    IO_ERR_MSG := '3) 통합재입실지표기본 : 재입실환자수 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                                RETURN;
                                        END; --통합재입실지표기본 : 재입실환자수 ( UCCICSRM : RPT_ETRM_PT_CNT )  BATCH  END
                                    END;
                                ELSE
                                    BEGIN
                                        --통합재입실지표기본 ( UCCICSRM ) UPDATE OR INSERT
                                        MERGE INTO HICU.UCCICSRM A
                                             USING DUAL
                                                ON (       A.WD_DEPT_CD        = REC.WD_DEPT_CD
                                                     AND   A.TH2_ETRM_DT_SEQ   = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                     AND   A.HSP_TP_CD         = IN_HIS_HSP_TP_CD
                                                   )
                                            WHEN MATCHED
                                            THEN UPDATE SET A.SEX_MALE_CNT            = DECODE(V_COMN_CD_EXPL, 'SEX_MALE_CNT', TO_NUMBER(V_DTRL1_NM), A.SEX_MALE_CNT)
                                                          , A.SEX_FEML_CNT            = DECODE(V_COMN_CD_EXPL, 'SEX_FEML_CNT', TO_NUMBER(V_DTRL1_NM), A.SEX_FEML_CNT)
                                                          , A.AGE_10_GRP_BLW_CNT      = DECODE(V_COMN_CD_EXPL, 'AGE_10_GRP_BLW_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_10_GRP_BLW_CNT)
                                                          , A.AGE_20_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_20_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_20_GRP_CNT)
                                                          , A.AGE_30_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_30_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_30_GRP_CNT)
                                                          , A.AGE_40_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_40_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_40_GRP_CNT)
                                                          , A.AGE_50_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_50_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_50_GRP_CNT)
                                                          , A.AGE_60_GRP_CNT          = DECODE(V_COMN_CD_EXPL, 'AGE_60_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_60_GRP_CNT)
                                                          , A.AGE_70_GRP_UPR_CNT      = DECODE(V_COMN_CD_EXPL, 'AGE_70_GRP_UPR_CNT', TO_NUMBER(V_DTRL1_NM), A.AGE_70_GRP_UPR_CNT)
                                                          , A.RPT_ETRM_24_TM_IN_CNT   = DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_24_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), A.RPT_ETRM_24_TM_IN_CNT)
                                                          , A.RPT_ETRM_48_TM_IN_CNT   = DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_48_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), A.RPT_ETRM_48_TM_IN_CNT)
                                                          , A.RPT_ETRM_72_TM_IN_CNT   = DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_72_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), A.RPT_ETRM_72_TM_IN_CNT)
                                                          , A.RPT_ETRM_72_TM_EXCS_CNT = DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_72_TM_EXCS_CNT', TO_NUMBER(V_DTRL1_NM), A.RPT_ETRM_72_TM_EXCS_CNT)
                                                          , A.PT_SILLM_CTG_1_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_1_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_1_GRP_CNT)
                                                          , A.PT_SILLM_CTG_2_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_2_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_2_GRP_CNT)
                                                          , A.PT_SILLM_CTG_3_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_3_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_3_GRP_CNT)
                                                          , A.PT_SILLM_CTG_4_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_4_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_4_GRP_CNT)
                                                          , A.PT_SILLM_CTG_5_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_5_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_5_GRP_CNT)
                                                          , A.PT_SILLM_CTG_6_GRP_CNT  = DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_6_GRP_CNT', TO_NUMBER(V_DTRL1_NM), A.PT_SILLM_CTG_6_GRP_CNT)
                                                          , A.APCS_SUM_10_SCR_BLW_CNT = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_10_SCR_BLW_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_10_SCR_BLW_CNT)
                                                          , A.APCS_SUM_20_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_20_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_20_SCR_CNT)
                                                          , A.APCS_SUM_30_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_30_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_30_SCR_CNT)
                                                          , A.APCS_SUM_40_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_40_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_40_SCR_CNT)
                                                          , A.APCS_SUM_50_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_50_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_50_SCR_CNT)
                                                          , A.APCS_SUM_60_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_60_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_60_SCR_CNT)
                                                          , A.APCS_SUM_70_SCR_CNT     = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_70_SCR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_70_SCR_CNT)
                                                          , A.APCS_SUM_80_SCR_UPR_CNT = DECODE(V_COMN_CD_EXPL, 'APCS_SUM_80_SCR_UPR_CNT', TO_NUMBER(V_DTRL1_NM), A.APCS_SUM_80_SCR_UPR_CNT)
                                            WHEN NOT MATCHED
                                            THEN INSERT ( A.WD_DEPT_CD
                                                        , A.TH2_ETRM_DT_SEQ
                                                        , A.HSP_TP_CD
                                                        , A.WD_DEPT_CD_NM
                                                        , A.TH2_ETRM_YY
                                                        , A.TH2_ETRM_MM
                                                        , A.TH2_ETRM_DY
                                                        , A.HLDY_YN
                                                        , A.RPT_ETRM_PT_CNT
                                                        , A.SEX_MALE_CNT
                                                        , A.SEX_FEML_CNT
                                                        , A.AGE_10_GRP_BLW_CNT
                                                        , A.AGE_20_GRP_CNT
                                                        , A.AGE_30_GRP_CNT
                                                        , A.AGE_40_GRP_CNT
                                                        , A.AGE_50_GRP_CNT
                                                        , A.AGE_60_GRP_CNT
                                                        , A.AGE_70_GRP_UPR_CNT
                                                        , A.RPT_ETRM_24_TM_IN_CNT
                                                        , A.RPT_ETRM_48_TM_IN_CNT
                                                        , A.RPT_ETRM_72_TM_IN_CNT
                                                        , A.RPT_ETRM_72_TM_EXCS_CNT
                                                        , A.PT_SILLM_CTG_1_GRP_CNT
                                                        , A.PT_SILLM_CTG_2_GRP_CNT
                                                        , A.PT_SILLM_CTG_3_GRP_CNT
                                                        , A.PT_SILLM_CTG_4_GRP_CNT
                                                        , A.PT_SILLM_CTG_5_GRP_CNT
                                                        , A.PT_SILLM_CTG_6_GRP_CNT
                                                        , A.APCS_SUM_10_SCR_BLW_CNT
                                                        , A.APCS_SUM_20_SCR_CNT
                                                        , A.APCS_SUM_30_SCR_CNT
                                                        , A.APCS_SUM_40_SCR_CNT
                                                        , A.APCS_SUM_50_SCR_CNT
                                                        , A.APCS_SUM_60_SCR_CNT
                                                        , A.APCS_SUM_70_SCR_CNT
                                                        , A.APCS_SUM_80_SCR_UPR_CNT
                                                        , A.LOD_DTM
                                                        )
                                                 VALUES ( REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYYMMDD')
                                                        , IN_HIS_HSP_TP_CD
                                                        , REC.WD_DEPT_CD
                                                        , TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYY')
                                                        , TO_CHAR(DTM.TH2_ETRM_DTM, 'MM')
                                                        , TO_CHAR(DTM.TH2_ETRM_DTM, 'DD')
                                                        , NVL((SELECT X.HLDY_YN FROM HICU.UICIIRHD X WHERE TO_CHAR(X.DT_CD, 'YYYY-MM-DD') = TO_CHAR(DTM.TH2_ETRM_DTM, 'YYYY-MM-DD')), '')
                                                        , DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_PT_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'SEX_MALE_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'SEX_FEML_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_10_GRP_BLW_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_20_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_30_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_40_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_50_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_60_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'AGE_70_GRP_UPR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_24_TM_IN_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_48_TM_IN_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_72_TM_IN_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'RPT_ETRM_72_TM_EXCS_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_1_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_2_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_3_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_4_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_5_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'PT_SILLM_CTG_6_GRP_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_10_SCR_BLW_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_20_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_30_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_40_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_50_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_60_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_70_SCR_CNT', V_DTRL1_NM, '')
                                                        , DECODE(V_COMN_CD_EXPL, 'APCS_SUM_80_SCR_UPR_CNT', V_DTRL1_NM, '')
                                                        , SYSDATE
                                                        )                                            
                                        ;
                                        
                                        EXCEPTION
                                            WHEN OTHERS THEN
                                                IO_ERR_YN  := 'Y';
                                                IO_ERR_MSG := '4) 통합재입실지표기본 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                            RETURN;
                                    END; --통합재입실지표기본 ( UCCICSRM )  BATCH  END        
                                END IF;
                            END LOOP;
                            COMMIT;
                        END; --통합재입실지표기본 BATCH END
                        
                        BEGIN
                            /********************************************
                             * 아파치스코어 UPDATE BATCH
                             **********************************************/
                            FOR DIFF IN (SELECT A.CIPT_ETRM_CHOT_ID                        AS CIPT_ETRM_CHOT_ID
                                              , A.HSP_TP_CD                                AS HSP_TP_CD
                                              , A.TH2_ETRM_DTM                             AS TH2_ETRM_DTM
                                              , CASE WHEN A.APCS_SUM_SCR IS NULL THEN '-1'
                                                     WHEN A.APCS_SUM_SCR < 20 THEN '10'
                                                     WHEN A.APCS_SUM_SCR < 30 THEN '20'
                                                     WHEN A.APCS_SUM_SCR < 40 THEN '30'
                                                     WHEN A.APCS_SUM_SCR < 50 THEN '40'
                                                     WHEN A.APCS_SUM_SCR < 60 THEN '50'
                                                     WHEN A.APCS_SUM_SCR < 70 THEN '60'
                                                     WHEN A.APCS_SUM_SCR < 80 THEN '70'
                                                     ELSE '80' END                         AS APCS_SUM_CD
                                           FROM HICU.UICICSRM A
                                          WHERE A.APCS_REC_INPT_DTM   BETWEEN TRUNC(DTM.TH2_ETRM_DTM - 1) AND TRUNC(DTM.TH2_ETRM_DTM)
                                            AND A.TH2_ETRM_DTM        < A.APCS_REC_INPT_DTM
                                            AND A.TH2_ETRM_WD_DEPT_CD = REC.WD_DEPT_CD
                                            AND A.HSP_TP_CD           = IN_HIS_HSP_TP_CD)                                      
                            LOOP
                                BEGIN
                                    UPDATE HICU.UCCICSRM
                                       SET APCS_SUM_10_SCR_BLW_CNT = DECODE(DIFF.APCS_SUM_CD, '10', APCS_SUM_10_SCR_BLW_CNT + 1, APCS_SUM_10_SCR_BLW_CNT)
                                         , APCS_SUM_20_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '20', APCS_SUM_20_SCR_CNT + 1, APCS_SUM_20_SCR_CNT)
                                         , APCS_SUM_30_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '30', APCS_SUM_30_SCR_CNT + 1, APCS_SUM_30_SCR_CNT)
                                         , APCS_SUM_40_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '40', APCS_SUM_40_SCR_CNT + 1, APCS_SUM_40_SCR_CNT)
                                         , APCS_SUM_50_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '50', APCS_SUM_50_SCR_CNT + 1, APCS_SUM_50_SCR_CNT)
                                         , APCS_SUM_60_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '60', APCS_SUM_60_SCR_CNT + 1, APCS_SUM_60_SCR_CNT)
                                         , APCS_SUM_70_SCR_CNT     = DECODE(DIFF.APCS_SUM_CD, '70', APCS_SUM_70_SCR_CNT + 1, APCS_SUM_70_SCR_CNT)
                                         , APCS_SUM_80_SCR_UPR_CNT = DECODE(DIFF.APCS_SUM_CD, '80', APCS_SUM_80_SCR_UPR_CNT + 1, APCS_SUM_80_SCR_UPR_CNT)
                                     WHERE WD_DEPT_CD      = REC.WD_DEPT_CD
                                       AND TH2_ETRM_DT_SEQ = TO_CHAR(DIFF.TH2_ETRM_DTM, 'YYYYMMDD')
                                       AND HSP_TP_CD       = IN_HIS_HSP_TP_CD
                                    ;
                                    
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            IO_ERR_YN  := 'Y';
                                            IO_ERR_MSG := '5) 아파치스코어 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                        RETURN;
                                END;
                            END LOOP;
                        END; --아파치스코어 UPDATE BATCH END
                        
                        BEGIN
                            /********************************************
                             * 환자중증도 UPDATE BATCH
                             **********************************************/
                            FOR DIFF2 IN (SELECT A.TH2_ETRM_DTM        AS TH2_ETRM_DTM
                                               , B.PT_SILLM_CTG_GRP_CD AS PT_SILLM_CTG_GRP_CD
                                            FROM HICU.UICICSRM A
                                               , HICU.UICICSRD B
                                           WHERE A.HSP_TP_CD = IN_HIS_HSP_TP_CD
                                             AND A.HSP_TP_CD = B.HSP_TP_CD
                                             AND A.PT_NO     = B.PT_NO
                                             AND A.PACT_ID   = B.PACT_ID
                                             AND B.PT_SILLM_CTG_DTM = (SELECT MIN(Z.PT_SILLM_CTG_DTM)
                                                                         FROM HICU.UICICSRD Z
                                                                        WHERE Z.HSP_TP_CD  = IN_HIS_HSP_TP_CD
                                                                          AND Z.HSP_TP_CD  = A.HSP_TP_CD
                                                                          AND Z.PACT_ID    = A.PACT_ID
                                                                          AND Z.PT_NO      = A.PT_NO
                                                                          AND Z.WD_DEPT_CD = A.TH2_ETRM_WD_DEPT_CD
                                                                          AND Z.PT_SILLM_CTG_DTM BETWEEN TRUNC(A.TH2_ETRM_DTM) AND TRUNC(A.TH2_CHOT_DTM))  /*재입실기간 내 첫번째 중증도*/
                                             AND B.PT_SILLM_CTG_DTM    = TRUNC(DTM.TH2_ETRM_DTM)
                                             AND A.TH2_ETRM_DTM        < B.PT_SILLM_CTG_DTM
                                             AND A.TH2_ETRM_WD_DEPT_CD = REC.WD_DEPT_CD)
                            LOOP
                                BEGIN
                                    UPDATE HICU.UCCICSRM
                                       SET PT_SILLM_CTG_1_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '1', PT_SILLM_CTG_1_GRP_CNT + 1, PT_SILLM_CTG_1_GRP_CNT)
                                         , PT_SILLM_CTG_2_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '2', PT_SILLM_CTG_2_GRP_CNT + 1, PT_SILLM_CTG_2_GRP_CNT)
                                         , PT_SILLM_CTG_3_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '3', PT_SILLM_CTG_3_GRP_CNT + 1, PT_SILLM_CTG_3_GRP_CNT)
                                         , PT_SILLM_CTG_4_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '4', PT_SILLM_CTG_4_GRP_CNT + 1, PT_SILLM_CTG_4_GRP_CNT)
                                         , PT_SILLM_CTG_5_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '5', PT_SILLM_CTG_5_GRP_CNT + 1, PT_SILLM_CTG_5_GRP_CNT)
                                         , PT_SILLM_CTG_6_GRP_CNT = DECODE(DIFF2.PT_SILLM_CTG_GRP_CD, '6', PT_SILLM_CTG_6_GRP_CNT + 1, PT_SILLM_CTG_6_GRP_CNT)
                                     WHERE WD_DEPT_CD      = REC.WD_DEPT_CD
                                       AND TH2_ETRM_DT_SEQ = TO_CHAR(DIFF2.TH2_ETRM_DTM, 'YYYYMMDD')
                                       AND HSP_TP_CD       = IN_HIS_HSP_TP_CD
                                    ;
                                    
                                    EXCEPTION
                                        WHEN OTHERS THEN
                                            IO_ERR_YN  := 'Y';
                                            IO_ERR_MSG := '6) 환자중증도 업데이트 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
                                        RETURN;
                                END;
                            END LOOP;
                        END; --환자중증도 UPDATE BATCH END            
                    END LOOP; --DEPT_CD_CURSOR 종료
                    CLOSE DEPT_CD_CURSOR;
                END;
                
            END; -- 변경일자 데이터 BATCH END            
        END LOOP; --DTM_CURSOR 종료
        CLOSE DTM_CURSOR;
    END;
END PC_EICU_CENTER_BATCH_READM;
