
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_CONSULT_LIST" 
                          ( IN_CSLT_STR_DTM   IN  DATE
                          , IN_CSLT_END_DTM   IN  DATE
                          , IN_RER_HSP_CD     IN  VARCHAR2
                          , IN_RER_DEPT_CD    IN  VARCHAR2
                          , IN_CSLT_CLS_CD    IN  VARCHAR2
                          , IN_SV_STS_CD      IN  VARCHAR2
                          , IN_PT_NM          IN  VARCHAR2                        
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_CONSULT_LIST
*    CREATEDATE     : 2021.02.18
*    Author         : 신솔
*    Description    : 협진 목록 조회
*    Change History : 2021.02.18, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR  
            /**********************
            SEARCH CONSULT LIST
            ************************/
            SELECT 
                   A.EPCN_CSLT_ID        AS EPCN_CSLT_ID
                 , A.EPCN_CSLT_FOM_SEQ   AS EPCN_CSLT_FOM_SEQ
                 , A.RER_HSP_CD          AS RER_HSP_CD
                 , B.HSP_NM              AS RER_HSP_NM
                 , A.RER_DEPT_CD         AS RER_DEPT_CD
                 , A.RER_STF_NO          AS RER_STF_NO
                 , A.RER_STF_NM          AS RER_STF_NM
                 , A.CSLT_STR_DTM        AS CSLT_STR_DTM
                 , A.CSLT_END_DTM        AS CSLT_END_DTM
                 , A.CSLT_CLS_CD         AS CSLT_CLS_CD
                 , C.COMN_CD_NM          AS CSLT_CLS_CD_NM
                 , A.PT_NO               AS PT_NO
                 , A.PT_NM               AS PT_NM
                 , A.PACT_ID             AS PACT_ID
                 , A.PACT_DTM            AS PACT_DTM
                 , A.ADS_DT              AS ADS_DT
                 , A.ETRM_DTM            AS ETRM_DTM
                 , A.PT_MED_DEPT_CD      AS PT_MED_DEPT_CD
                 , A.PT_MED_DEPT_NM      AS PT_MED_DEPT_NM
                 , A.SEX_TP_CD           AS SEX_TP_CD
                 , A.AGE                 AS AGE
                 , A.MAIN_DGNS_DT        AS MAIN_DGNS_DT 
                 , A.DGNS_VOC_ID         AS DGNS_VOC_ID
                 , A.ICD10_CD            AS ICD10_CD
                 , A.DGNS_VOC_NM         AS DGNS_VOC_NM
                 , A.WD_DEPT_CD          AS WD_DEPT_CD 
                 , A.WD_DEPT_CD_NM       AS WD_DEPT_CD_NM
                 , A.LST_YN              AS LST_YN
                 , A.SV_STS_CD           AS SV_STS_CD
                 , D.COMN_CD_NM          AS SV_STS_CD_NM
                 , A.WRT_DTM             AS WRT_DTM
                 , A.WRTR_ID             AS WRTR_ID
                 , A.MDRC_ID             AS MDRC_ID 
                 , A.RER_CNTE            AS RER_CNTE
              FROM HICU.UCOMCNSM A
                 , HICU.UCCOCHPM B
                 , HICU.UCCOCSTE C
                 , HICU.UCCOCSTE D
             WHERE A.CSLT_STR_DTM      BETWEEN TRUNC(IN_CSLT_STR_DTM) AND TRUNC(IN_CSLT_END_DTM) + 0.99999
               AND A.RER_HSP_CD        = NVL(IN_RER_HSP_CD, A.RER_HSP_CD)
               AND A.RER_DEPT_CD       = NVL(IN_RER_DEPT_CD, A.RER_DEPT_CD)
               AND A.CSLT_CLS_CD       = NVL(IN_CSLT_CLS_CD, A.CSLT_CLS_CD)
               AND A.SV_STS_CD         = NVL(IN_SV_STS_CD, A.SV_STS_CD)
               AND A.PT_NM             LIKE IN_PT_NM || '%'
               AND A.LST_YN            = 'Y'
               AND B.HSP_TP_CD         = A.RER_HSP_CD
               AND B.USE_YN            = 'Y'
               AND C.COMN_GRP_CD       = 'IC007'
               AND C.USE_YN            = 'Y'
               AND C.HSP_TP_CD         = A.RER_HSP_CD
               AND C.COMN_CD           = A.CSLT_CLS_CD
               AND D.COMN_GRP_CD       = 'IC008'
               AND D.USE_YN            = 'Y'
               AND D.HSP_TP_CD         = A.RER_HSP_CD
               AND D.COMN_CD           = A.SV_STS_CD
          ORDER BY A.CSLT_STR_DTM, A.PT_NO
        ;    
    END;
END PC_EICU_SELECT_CONSULT_LIST;
