
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PHONE_NUMBER_UPD" (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
    , IN_COMKDCD           		 IN  VARCHAR2,
    IN_CDBS           		 IN  VARCHAR2,
    IN_CDDES1              IN  VARCHAR2,
    OUT_CURSOR             OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
/**********************************************************************************************
*    SERVICENAME    : IF_TRAN_TIME_UPD
*    CREATEDATE     : 2025.09.03
*    Author         : 윤재림
*    Description    : 이송시간 업데이트
*    Change History :
**********************************************************************************************/
BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE ARPA_CD_LIST
       SET CDDES1    = IN_CDDES1
     WHERE COMKDCD 	 = IN_COMKDCD
       AND CDBS      = IN_CDBS;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
