
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_ODRPY_STTS" 
                                                    (   
                                                        IN_FROM_DTM         IN DATE 
                                                      , IN_TO_DTM           IN DATE 
                                                      , IN_HSP_TP_CD        IN VARCHAR2
                                                      , OUT_CURSOR          OUT SYS_REFCURSOR 
                                                    ) 
                                                    
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_ODRPY_STTS
*    CREATEDATE     : 2021.03.18
*    Author         : 한가혜
*    Description    : 통합관제 운영통계 타과회신시간 현황 지표 조회
*    Change History : 2021.04.06 - 정규타과의뢰 시간대별 회신율 누적 수정 
**********************************************************************************************/    

AS
    
BEGIN
      OPEN OUT_CURSOR FOR 
                          --U113_UCOS(운영통계)_타과의뢰회신정보
					      WITH MAIN AS (
    							           SELECT A.RPLY_DEPT_CD				--회신부서코드
                                                , A.RPLY_DT						--회신일자
                                                , A.HSP_TP_CD					--병원구분코드
                                                , A.RPLY_DEPT_CD_NM				--회신부서코드명
                                                , A.RPLY_YY						--회신 년
                                                , A.RPLY_MM						--회신 월
                                                , A.RPLY_DY						--회신 일
                                                , A.RPLY_WHL_CNT				--전체회신수
                                                , A.RPLY_IN_6TM_CNT				--6시간이내회신수
                                                , A.RPLY_IN_12TM_CNT			--12시간이내회신수
                                                , A.RPLY_IN_24TM_CNT			--24시간이내회신수
                                                , A.RPLY_IN_36TM_CNT			--36시간이내회신수
                                                , A.RPLY_IN_48TM_CNT			--48시간이내회신수
                                                , A.RPLY_IN_60TM_CNT			--60시간이내회신수
                                                , A.UNTC_REPLY_WHL_CNT			--비대면전체회신수
                                                , A.UNTC_RPLY_IN_6TM_CNT		--비대면6시간이내회신수
                                                , A.UNTC_RPLY_IN_12TM_CNT		--비대면12시간이내회신수
                                                , A.UNTC_RPLY_IN_24TM_CNT		--비대면24시간이내회신수
                                                , A.UNTC_RPLY_IN_36TM_CNT		--비대면36시간이내회신수
                                                , A.UNTC_RPLY_IN_48TM_CNT		--비대면48시간이내회신수
                                                , A.UNTC_RPLY_IN_60TM_CNT		--비대면60시간이내회신수
                                                , A.EMGR_RPLY_CNT				--응급회신수
                                                , A.EMGR_UNTC_RPLY_CNT			--응급비대면회신수
                                                , A.WKDY_RPLY_WHL_TM_AVG		--평일전체회신시간평균
                                                , A.WKDY_UNTC_RPLY_WHL_TM_AVG	--평일비대면전체회신시간평균
                                                , A.WKN_RPLY_WHL_TM_AVG			--주말전체회신시간평균
                                                , A.WKN_UNTC_RPLY_WHL_TM_AVG	--주말비대면전체회신시간평균
                                                , A.RPLY_EXCS_60TM_CNT          --60시간초과회신수
                                                , A.UNTC_RPLY_EXCS_60TM_CNT     --비대면60시간초과회신수
    							             FROM HICU.UCOSCOSD A    --U113_UCOS(운영통계)_타과의뢰회신정보
    							            WHERE A.RPLY_DT BETWEEN TRUNC(IN_FROM_DTM)
    							                                AND TRUNC(IN_TO_DTM)
    							              AND A.HSP_TP_CD     = IN_HSP_TP_CD 
							           ),
							           SUM_DATA AS (
							               SELECT SUM(1)                            AS SUM_DAY_CNT
							                    , SUM(A.RPLY_WHL_CNT)				AS RPLY_WHL_CNT--전체회신수
                                                , SUM(A.RPLY_IN_6TM_CNT)			AS RPLY_IN_6TM_CNT--6시간이내회신수
                                                , SUM(A.RPLY_IN_12TM_CNT)			AS RPLY_IN_12TM_CNT--12시간이내회신수
                                                , SUM(A.RPLY_IN_24TM_CNT)			AS RPLY_IN_24TM_CNT--24시간이내회신수
                                                , SUM(A.RPLY_IN_36TM_CNT)			AS RPLY_IN_36TM_CNT--36시간이내회신수
                                                , SUM(A.RPLY_IN_48TM_CNT)			AS RPLY_IN_48TM_CNT--48시간이내회신수-
                                                , SUM(A.RPLY_IN_60TM_CNT)			AS RPLY_IN_60TM_CNT--60시간이내회신수 
                                                , SUM(A.RPLY_EXCS_60TM_CNT)         AS RPLY_EXCS_60TM_CNT--60시간초과회신수
                                                , SUM(A.UNTC_REPLY_WHL_CNT)			AS UNTC_REPLY_WHL_CNT--비대면전체회신수
                                                , SUM(A.UNTC_RPLY_IN_6TM_CNT)		AS UNTC_RPLY_IN_6TM_CNT--비대면6시간이내회신수
                                                , SUM(A.UNTC_RPLY_IN_12TM_CNT)		AS UNTC_RPLY_IN_12TM_CNT--비대면12시간이내회신수
                                                , SUM(A.UNTC_RPLY_IN_24TM_CNT)		AS UNTC_RPLY_IN_24TM_CNT--비대면24시간이내회신수
                                                , SUM(A.UNTC_RPLY_IN_36TM_CNT)		AS UNTC_RPLY_IN_36TM_CNT--비대면36시간이내회신수
                                                , SUM(A.UNTC_RPLY_IN_48TM_CNT)		AS UNTC_RPLY_IN_48TM_CNT--비대면48시간이내회신수
                                                , SUM(A.UNTC_RPLY_IN_60TM_CNT)		AS UNTC_RPLY_IN_60TM_CNT--비대면60시간이내회신수    
                                                , SUM(A.UNTC_RPLY_EXCS_60TM_CNT)    AS UNTC_RPLY_EXCS_60TM_CNT --비대면60시간초과회신수
                                                , SUM(A.EMGR_RPLY_CNT)				AS EMGR_RPLY_CNT--응급회신수
                                                , SUM(A.EMGR_UNTC_RPLY_CNT)			AS EMGR_UNTC_RPLY_CNT--응급비대면회신수
                                                , SUM(A.WKDY_RPLY_WHL_TM_AVG)		AS WKDY_RPLY_WHL_TM_AVG--평일전체회신시간평균
                                                , SUM(A.WKDY_UNTC_RPLY_WHL_TM_AVG)	AS WKDY_UNTC_RPLY_WHL_TM_AVG--평일비대면전체회신시간평균
                                                , SUM(A.WKN_RPLY_WHL_TM_AVG)		AS WKN_RPLY_WHL_TM_AVG	--주말전체회신시간평균
                                                , SUM(A.WKN_UNTC_RPLY_WHL_TM_AVG)	AS WKN_UNTC_RPLY_WHL_TM_AVG--주말비대면전체회신시간평균
							                 FROM MAIN A
							           ),
							           --정규 시간대별 회신율 누적
							           ACCM_SUM_DATA AS (    
							               SELECT ROUND(NVL(A.RPLY_IN_6TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_6TM_CNT--6시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_IN_12TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_12TM_CNT--12시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_IN_24TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_24TM_CNT--24시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_IN_36TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_36TM_CNT--36시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_IN_48TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_48TM_CNT--48시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_IN_60TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_60TM_CNT--60시간이내회신수(누적)
                                                , ROUND(NVL(A.RPLY_EXCS_60TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_EXCS_60TM_CNT--60시간초과회신수(누적)
                                                FROM SUM_DATA A
							           ), 
							           --비대면 시간대별 회신율 누적
							           UNTC_ACCM_SUM_DATA AS (    
							               SELECT ROUND(NVL(A.UNTC_RPLY_IN_6TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1)  AS RPLY_IN_6TM_CNT	--비대면6시간이내회신수(누적)
                                                , ROUND(NVL(A.UNTC_RPLY_IN_12TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_12TM_CNT--비대면12시간이내회신수(누적)
                                                , ROUND(NVL(A.UNTC_RPLY_IN_24TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_24TM_CNT--비대면24시간이내회신수(누적)
                                                , ROUND(NVL(A.UNTC_RPLY_IN_36TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_36TM_CNT--비대면36시간이내회신수(누적)
                                                , ROUND(NVL(A.UNTC_RPLY_IN_48TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_48TM_CNT--비대면48시간이내회신수(누적)
                                                , ROUND(NVL(A.UNTC_RPLY_IN_60TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_IN_60TM_CNT--비대면60시간이내회신수(누적)    
                                                , ROUND(NVL(A.UNTC_RPLY_EXCS_60TM_CNT, 0) / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1) AS RPLY_EXCS_60TM_CNT --비대면60시간초과회신수(누적)
							                 FROM SUM_DATA A
							           ),
							           CHART_TYPE_TB AS (
                    		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                 , A.COMN_CD      AS COMN_CD
                                                 , A.COMN_CD_NM   AS COMN_CD_NM
                                                 , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                              FROM (
                                                     SELECT 'ODRPY_CRCCM'               AS COMN_GRP_CD
                                                          , 'RPLY_WHL_CNT'              AS COMN_CD
                                                          , '정규타과의뢰_전체회신수'    AS COMN_CD_NM 
                                                          , '1'                         AS COMN_CD_EXPL
                                                       FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'RPLY_IN_24TM_CNT', '정규타과의뢰_전체24시간이내회신수', '1' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_REPLY_WHL_CNT', '정규타과의뢰_비대면협진전체회신수', '1' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_RPLY_IN_24TM_CNT', '정규타과의뢰_비대면협진24시간이내회신수', '1' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'EMGR_RPLY_CNT', '비대면협진참여현황_응급전체회신수', '2' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'EMGR_UNTC_RPLY_CNT', '비대면협진참여현황_응급비대면회신수', '2' FROM DUAL 
                                                     ) A
                                          ORDER BY A.COMN_GRP_CD
                    		           ),   
							           RTO_CHART_TYPE_TB AS (
                    		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                 , A.COMN_CD      AS COMN_CD
                                                 , A.COMN_CD_NM   AS COMN_CD_NM
                                                 , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                              FROM (
                                                     SELECT 'ODRPY_TM_TYPE'    AS COMN_GRP_CD
                                                          , 'RPLY_IN_6TM_CNT'  AS COMN_CD
                                                          , '~6hr'             AS COMN_CD_NM 
                                                          , '1'                AS COMN_CD_EXPL
                                                       FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_12TM_CNT', '~12hr', '2' FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_24TM_CNT', '~24hr', '3' FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_36TM_CNT', '~36hr', '4' FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_48TM_CNT', '~48hr', '5' FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_IN_60TM_CNT', '~60hr', '6' FROM DUAL UNION ALL
                                                     SELECT 'ODRPY_TM_TYPE', 'RPLY_EXCS_60TM_CNT', '60hr~', '7' FROM DUAL UNION ALL 
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_6TM_CNT', '~6hr' , '1'FROM DUAL UNION ALL    
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_12TM_CNT', '~12hr', '2' FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_24TM_CNT', '~24hr', '3' FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_36TM_CNT', '~36hr', '4' FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_48TM_CNT', '~48hr', '5' FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_IN_60TM_CNT', '~60hr', '6' FROM DUAL UNION ALL
                                                     SELECT 'UNTC_ODRPY_TM_TYPE', 'RPLY_EXCS_60TM_CNT', '60hr~', '7' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'RPLY_IN_24TM_RTO', '정규타과의뢰_전체24시간이내회신율', '1' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_RPLY_IN_24TM_WHL_RTO', '정규타과의뢰_비대면협진24시간이내회신율', '1' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_REPLY_WHL_RTO', '비대면협진참여현황_비대면협진참여율', '2' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'UNTC_RPLY_IN_24TM_RTO', '24시간이내응답비대면협진_협진율', '3' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'EMGR_UNTC_RPLY_RTO', '비대면협진참여현황_응급비대면협진회신율', '2' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKDY_RPLY_WHL_TM_AVG', '평일_전체회신시간평균', '4' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKDY_UNTC_RPLY_WHL_TM_AVG', '평일_비대면협진회신시간평균', '4' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKN_RPLY_WHL_TM_AVG', '주말_전체회신시간평균', '4' FROM DUAL UNION ALL
										             SELECT 'ODRPY_CRCCM', 'WKN_UNTC_RPLY_WHL_TM_AVG', '주말_비대면협진회신시간평균', '4' FROM DUAL 
                                                     ) A
                                          ORDER BY A.COMN_GRP_CD
                    		           ), 
                    		           FLOW_RTO_CHART_TYPE_TB AS (
                    		                SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                                                 , A.COMN_CD      AS COMN_CD
                                                 , A.COMN_CD_NM   AS COMN_CD_NM
                                                 , A.COMN_CD_EXPL AS COMN_CD_EXPL
                                              FROM (
                                                     SELECT 'AVG_FLOW'    AS COMN_GRP_CD
                                                          , '1'           AS COMN_CD
                                                          , '전년월평균'  AS COMN_CD_NM 
                                                          , '1'           AS COMN_CD_EXPL
                                                       FROM DUAL UNION ALL
                                                     SELECT 'AVG_FLOW', '2', '당년월평균', '2' FROM DUAL UNION ALL
                                                     SELECT 'AVG_FLOW', '3', '전년당월', '3' FROM DUAL
                                                     ) A
                                          ORDER BY A.COMN_GRP_CD
                    		           ), 
							           ODRPY_CRCCM AS (
							               SELECT RPLY_WHL_CNT               --타과의뢰회신 전체수
                                                , RPLY_IN_24TM_CNT           --24시간 이내 타과의뢰회신 수
                                                , ROUND(NVL(RPLY_IN_24TM_CNT, 0) / DECODE(RPLY_WHL_CNT, 0, NULL, RPLY_WHL_CNT) * 100, 1)                    AS RPLY_IN_24TM_RTO         --24시간이내회신율
                                                , UNTC_REPLY_WHL_CNT         --비대면 협진 전체 회신수
                                                , UNTC_RPLY_IN_24TM_CNT      --비대면 협진 24시간 이내 회신수 
                                                , ROUND(NVL(UNTC_RPLY_IN_24TM_CNT, 0) / DECODE(UNTC_REPLY_WHL_CNT, 0, NULL, UNTC_REPLY_WHL_CNT) * 100, 1)   AS UNTC_RPLY_IN_24TM_WHL_RTO--비대면협진 24시간이내회신율
                                                , ROUND(NVL(UNTC_REPLY_WHL_CNT, 0) / DECODE(RPLY_WHL_CNT, 0, NULL, RPLY_WHL_CNT) * 100, 1)                  AS UNTC_REPLY_WHL_RTO       --타과회신 중 비대면협진율 
                                                , ROUND(NVL(UNTC_RPLY_IN_24TM_CNT, 0) / DECODE(RPLY_IN_24TM_CNT, 0, NULL, RPLY_IN_24TM_CNT) * 100, 1)       AS UNTC_RPLY_IN_24TM_RTO    --24시간이내 타과회신 중 24시간이내 비대면협진율 
                                                , EMGR_RPLY_CNT              --응급 타과의뢰회신 전체수
                                                , EMGR_UNTC_RPLY_CNT         --응급 비대면 회신수
                                                , ROUND(NVL(EMGR_UNTC_RPLY_CNT, 0) / DECODE(EMGR_RPLY_CNT, 0, NULL, EMGR_RPLY_CNT) * 100, 1)                AS EMGR_UNTC_RPLY_RTO    --응급 비대면 타과의뢰 회신율  
                                                , ROUND(NVL(WKDY_RPLY_WHL_TM_AVG, 0) / DECODE(SUM_DAY_CNT, 0, NULL, SUM_DAY_CNT), 1)                        AS WKDY_RPLY_WHL_TM_AVG  --평일 전체 회신시간 평균 
                                                , ROUND(NVL(WKDY_UNTC_RPLY_WHL_TM_AVG, 0) / DECODE(SUM_DAY_CNT, 0, NULL, SUM_DAY_CNT), 1)                   AS WKDY_UNTC_RPLY_WHL_TM_AVG  --평일 비대면협진 회신시간 평균
                                                , ROUND(NVL(WKN_RPLY_WHL_TM_AVG, 0) / DECODE(SUM_DAY_CNT, 0, NULL, SUM_DAY_CNT), 1)                         AS WKN_RPLY_WHL_TM_AVG        --주말 전체 회신시간 평균
                                                , ROUND(NVL(WKN_UNTC_RPLY_WHL_TM_AVG, 0) / DECODE(SUM_DAY_CNT, 0, NULL, SUM_DAY_CNT), 1)                    AS WKN_UNTC_RPLY_WHL_TM_AVG   --주말 비대면 협진 회신시간 평균
                                             FROM SUM_DATA
							           ),
							           /*******************************************************************************
                                		 *연환자, 연병상 추이 전년월별평균, 당년월평균, 전년당월평균, 이전 12개월별 평균 
                                		********************************************************************************/ 
                                	   FLOW_MAIN AS (
            											SELECT A.RPLY_DEPT_CD
                                                             , A.RPLY_DT
                                                             , A.HSP_TP_CD
                                                             , A.RPLY_DEPT_CD_NM
                                                             , A.RPLY_YY
                                                             , A.RPLY_MM
                                                             , A.RPLY_DY
                                                             , A.RPLY_WHL_CNT
                                                             , A.RPLY_IN_6TM_CNT
                                                             , A.RPLY_IN_12TM_CNT
                                                             , A.RPLY_IN_24TM_CNT
                                                             , A.RPLY_IN_36TM_CNT
                                                             , A.RPLY_IN_48TM_CNT
                                                             , A.RPLY_IN_60TM_CNT
                                                             , A.UNTC_REPLY_WHL_CNT
                                                             , A.UNTC_RPLY_IN_6TM_CNT
                                                             , A.UNTC_RPLY_IN_12TM_CNT
                                                             , A.UNTC_RPLY_IN_24TM_CNT
                                                             , A.UNTC_RPLY_IN_36TM_CNT
                                                             , A.UNTC_RPLY_IN_48TM_CNT
                                                             , A.UNTC_RPLY_IN_60TM_CNT
                                                             , A.EMGR_RPLY_CNT
                                                             , A.EMGR_UNTC_RPLY_CNT
                                                             , A.WKDY_RPLY_WHL_TM_AVG
                                                             , A.WKDY_UNTC_RPLY_WHL_TM_AVG
                                                             , A.WKN_RPLY_WHL_TM_AVG
                                                             , A.WKN_UNTC_RPLY_WHL_TM_AVG
                                                             , A.LOD_DTM
                                                             , A.RPLY_EXCS_60TM_CNT
                                                             , A.UNTC_RPLY_EXCS_60TM_CNT
            											     , A.RPLY_YY || '-' || A.RPLY_MM                                               AS DATE_TYPE --날짜타입
            											  FROM HICU.UCOSCOSD A    --U113_UCOS(운영통계)_타과의뢰회신정보
            											 WHERE A.HSP_TP_CD          = IN_HSP_TP_CD
            						   ),
                                	   --전년 
                                	   BF_YEAR_MAN_DAYS AS (    SELECT SUM(A.RPLY_WHL_CNT)               AS RPLY_WHL_CNT              --전체회신수
                                        				             , SUM(A.RPLY_IN_24TM_CNT)           AS RPLY_IN_24TM_CNT          --24시간이내
                                							         , SUM(A.UNTC_REPLY_WHL_CNT)         AS UNTC_REPLY_WHL_CNT        --비대면전체회신수  
                                							         , SUM(A.UNTC_RPLY_IN_24TM_CNT)      AS UNTC_RPLY_IN_24TM_CNT        --24시간이내
                                        				          FROM FLOW_MAIN A    
                                        			             WHERE A.RPLY_DT BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM')
                                        			                                 AND TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DTM, -12), 'YYYY') || '-12-31' ,'YYYY-MM-DD')
                                					         --GROUP BY A.DATE_TYPE  
                                	   ), 
                                	   --당년 
                                	   MON_YEAR_MAN_DAYS AS (   SELECT SUM(A.RPLY_WHL_CNT)               AS RPLY_WHL_CNT              --전체회신수
                                        				             , SUM(A.RPLY_IN_24TM_CNT)           AS RPLY_IN_24TM_CNT          --24시간이내
                                							         , SUM(A.UNTC_REPLY_WHL_CNT)         AS UNTC_REPLY_WHL_CNT        --비대면전체회신수  
                                							         , SUM(A.UNTC_RPLY_IN_24TM_CNT)      AS UNTC_RPLY_IN_24TM_CNT        --24시간이내
                                        				          FROM FLOW_MAIN A 
                                        			             WHERE A.RPLY_DT BETWEEN TRUNC(IN_TO_DTM, 'YYYY')
                                        			                                 AND TO_DATE(TO_CHAR(IN_TO_DTM, 'YYYY') || '-12-31' ,'YYYY-MM-DD')
                                					          --GROUP BY A.DATE_TYPE
                                	   ),
                                	   --전년 당월 
                                	   BF_MON_MAN_DAYS AS (
                                        	                    SELECT A.DATE_TYPE
                                        							 , SUM(A.RPLY_WHL_CNT)               AS RPLY_WHL_CNT              --전체회신수
                                        				             , SUM(A.RPLY_IN_24TM_CNT)           AS RPLY_IN_24TM_CNT          --24시간이내
                                							         , SUM(A.UNTC_REPLY_WHL_CNT)         AS UNTC_REPLY_WHL_CNT        --비대면전체회신수  
                                							         , SUM(A.UNTC_RPLY_IN_24TM_CNT)      AS UNTC_RPLY_IN_24TM_CNT        --24시간이내
                                        	                      FROM FLOW_MAIN A
                                        	                     WHERE A.RPLY_DT BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -12), 'MM')
                    												                 AND TRUNC(LAST_DAY(ADD_MONTHS(IN_TO_DTM, -12)))
                    									      GROUP BY A.DATE_TYPE -- 주석해제 2025-08-03 GROUP BY 에러  
                                	   ),
                                	   -- 12개월 별 연간 추이 X 축
                                	   FROM_TO_DATE_TYPE AS (
                                	                    SELECT TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYY-MM') AS DATE_TYPE
                                                             , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YY.MM')   AS DT_CD_NM
                                                             , TO_CHAR(ADD_MONTHS(IN_TO_DTM, 1- LEVEL ), 'YYYYMM')  AS DT_CD
                                                          FROM DUAL
                                                    CONNECT BY LEVEL - 1 <= 11 
                                	   ),
                                	   --조회기간 부터 이전 11개월 전 
                                	   FROM_TO_MAN_DAYS AS (    SELECT A.DATE_TYPE
                                        							 , SUM(A.RPLY_WHL_CNT)               AS RPLY_WHL_CNT              --전체회신수
                                        				             , SUM(A.RPLY_IN_24TM_CNT)           AS RPLY_IN_24TM_CNT          --24시간이내
                                							         , SUM(A.UNTC_REPLY_WHL_CNT)         AS UNTC_REPLY_WHL_CNT        --비대면전체회신수  
                                							         , SUM(A.UNTC_RPLY_IN_24TM_CNT)      AS UNTC_RPLY_IN_24TM_CNT        --24시간이내
                                        	                      FROM FLOW_MAIN A
                                	                             WHERE A.RPLY_DT BETWEEN TRUNC(ADD_MONTHS(IN_TO_DTM, -11), 'MM') 
                                	                                                 AND TRUNC(LAST_DAY(IN_TO_DTM))
            									              GROUP BY A.DATE_TYPE
                                	   )            

							           

							/********************
							* INDICATORS OUT DTO
							*********************/  
                            SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
							     , B.COMN_CD                AS COMN_CD
							     , B.COMN_CD_NM             AS COMN_CD_NM       
							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
							     , TO_CHAR(NVL(A.DTRL1_NM, 0))       AS DTRL1_NM 
							     , TO_CHAR(NVL(A.DTRL2_NM, 0))       AS DTRL2_NM
							  FROM (
										SELECT 'ODRPY_CRCCM'       AS COMN_GRP_CD
										     , COMN_CD             AS COMN_CD
										     , DTRL1_NM            AS DTRL1_NM 
										     , NULL                AS DTRL2_NM
										  FROM ODRPY_CRCCM
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (RPLY_WHL_CNT          
										                    , RPLY_IN_24TM_CNT       
										                    , UNTC_REPLY_WHL_CNT
										                    , UNTC_RPLY_IN_24TM_CNT
										                    , EMGR_RPLY_CNT
										                    , EMGR_UNTC_RPLY_CNT
										                    )
										       )       
								 ) A
								 , CHART_TYPE_TB B 	
							 WHERE B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
							   AND B.COMN_CD      = A.COMN_CD (+) 
							   
					     UNION ALL
					 	   
						    SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
							     , B.COMN_CD                AS COMN_CD
							     , B.COMN_CD_NM             AS COMN_CD_NM       
							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
							     , RTRIM(TO_CHAR(NVL(A.DTRL1_NM, 0), 'FM9990.9'), '.')      AS DTRL1_NM   
							     , TO_CHAR(NVL(A.DTRL2_NM, 0))       AS DTRL2_NM
							  FROM (    
							            SELECT 'ODRPY_CRCCM'       AS COMN_GRP_CD
										     , COMN_CD             AS COMN_CD
										     , DTRL1_NM            AS DTRL1_NM 
										     , NULL                AS DTRL2_NM
										  FROM ODRPY_CRCCM
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (RPLY_IN_24TM_RTO       
										                    , UNTC_RPLY_IN_24TM_WHL_RTO
										                    , UNTC_REPLY_WHL_RTO
										                    , UNTC_RPLY_IN_24TM_RTO 
										                    , EMGR_UNTC_RPLY_RTO
										                    , WKDY_RPLY_WHL_TM_AVG
										                    , WKDY_UNTC_RPLY_WHL_TM_AVG
										                    , WKN_RPLY_WHL_TM_AVG
										                    , WKN_UNTC_RPLY_WHL_TM_AVG
										                    )
										       )       
										       
									 UNION ALL 
									 
							            SELECT 'ODRPY_TM_TYPE'     AS COMN_GRP_CD
										     , COMN_CD             AS COMN_CD
										     , DTRL1_NM            AS DTRL1_NM 
										     , NULL                AS DTRL2_NM
										  FROM ACCM_SUM_DATA
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (RPLY_IN_6TM_CNT
                                                            , RPLY_IN_12TM_CNT
                                                            , RPLY_IN_24TM_CNT
                                                            , RPLY_IN_36TM_CNT
                                                            , RPLY_IN_48TM_CNT
                                                            , RPLY_IN_60TM_CNT
                                                            , RPLY_EXCS_60TM_CNT
										                    )
										       )             
										
									 UNION ALL
									 
									    SELECT 'UNTC_ODRPY_TM_TYPE'     AS COMN_GRP_CD
										     , COMN_CD                  AS COMN_CD
										     , DTRL1_NM                 AS DTRL1_NM 
										     , NULL                     AS DTRL2_NM
										  FROM UNTC_ACCM_SUM_DATA
									   UNPIVOT (DTRL1_NM FOR COMN_CD
										                  IN (RPLY_IN_6TM_CNT
                                                            , RPLY_IN_12TM_CNT
                                                            , RPLY_IN_24TM_CNT
                                                            , RPLY_IN_36TM_CNT
                                                            , RPLY_IN_48TM_CNT
                                                            , RPLY_IN_60TM_CNT
                                                            , RPLY_EXCS_60TM_CNT
										                    )
										       )  
								 ) A
								 , RTO_CHART_TYPE_TB B 	
							 WHERE B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
							   AND B.COMN_CD      = A.COMN_CD (+) 
							
						 UNION ALL   
						
							SELECT B.COMN_GRP_CD            AS COMN_GRP_CD
							     , B.COMN_CD                AS COMN_CD
							     , B.COMN_CD_NM             AS COMN_CD_NM       
							     , B.COMN_CD_EXPL           AS COMN_CD_EXPL
							     , RTRIM(TO_CHAR(NVL(A.DTRL1_NM, 0), 'FM9990.9'), '.')       AS DTRL1_NM   
							     , RTRIM(TO_CHAR(NVL(A.DTRL2_NM, 0), 'FM9990.9'), '.')       AS DTRL2_NM 
							     --, TO_CHAR(NVL(A.DTRL2_NM, 0))       AS DTRL2_NM
							  FROM (
									 --전년 월, 당년 월 전체회신수평균, 비대면전체회신수평균 / 전년 당월 전체회신수, 비대면전체회신수
									 
									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
										     , '1'            AS COMN_CD  
										     --, '전년월평균'   AS COMN_CD_NM
										     , NVL(ROUND(A.RPLY_IN_24TM_CNT / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1), 0)                     AS DTRL1_NM       --전년 전체회신수 회신율 24시간이내
                                             , NVL(ROUND(A.UNTC_RPLY_IN_24TM_CNT / DECODE(A.UNTC_REPLY_WHL_CNT, 0, NULL, A.UNTC_REPLY_WHL_CNT) * 100, 1), 0)    AS DTRL2_NM       --전년 비대면 협진 회신율 24시간이내
									      FROM BF_YEAR_MAN_DAYS A
									 
									 UNION ALL
									 
									    SELECT 'AVG_FLOW'     AS COMN_GRP_CD
										     , '2'            AS COMN_CD  
										     --, '당년월평균'   AS COMN_CD_NM
										     , NVL(ROUND(A.RPLY_IN_24TM_CNT / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1), 0)                     AS DTRL1_NM       --당년 전체회신수 평균
                                             , NVL(ROUND(A.UNTC_RPLY_IN_24TM_CNT / DECODE(A.UNTC_REPLY_WHL_CNT, 0, NULL, A.UNTC_REPLY_WHL_CNT) * 100, 1), 0)    AS DTRL2_NM  --전년 비대면 협진 회신율 24시간이내
									      FROM MON_YEAR_MAN_DAYS A 
									 
									 UNION ALL
									 
									    SELECT 'AVG_FLOW'        AS COMN_GRP_CD
										     , '3'               AS COMN_CD  
										     --, '전년당월'        AS COMN_CD_NM
										     , NVL(ROUND(A.RPLY_IN_24TM_CNT / DECODE(A.RPLY_WHL_CNT, 0, NULL, A.RPLY_WHL_CNT) * 100, 1), 0)                     AS DTRL1_NM       --전년 당월 전체회신수  
                                             , NVL(ROUND(A.UNTC_RPLY_IN_24TM_CNT / DECODE(A.UNTC_REPLY_WHL_CNT, 0, NULL, A.UNTC_REPLY_WHL_CNT) * 100, 1), 0)    AS DTRL2_NM  --전년 당월 비대면 협진 회신율 24시간이내
									      FROM BF_MON_MAN_DAYS A 
								 ) A
								 , FLOW_RTO_CHART_TYPE_TB B 	
							 WHERE B.COMN_GRP_CD  = A.COMN_GRP_CD (+)
							   AND B.COMN_CD      = A.COMN_CD (+) 	
							 
						 --당년 월별 전체회신수, 비대면전체회신수 평균 
					 	 UNION ALL
					 	 
							SELECT 'AVG_MSTS'                            AS COMN_GRP_CD
							     , A.DT_CD                               AS COMN_CD  
							     , A.DT_CD_NM                            AS COMN_CD_NM 
							     , NULL                                  AS COMN_CD_EXPL
							     , RTRIM(TO_CHAR(NVL(ROUND(B.RPLY_IN_24TM_CNT / DECODE(B.RPLY_WHL_CNT, 0, NULL, B.RPLY_WHL_CNT) * 100, 1), 0), 'FM9990.9'), '.')                     AS DTRL1_NM --당년 월별 전체회신수 
                                 , RTRIM(TO_CHAR(NVL(ROUND(B.UNTC_RPLY_IN_24TM_CNT / DECODE(B.UNTC_REPLY_WHL_CNT, 0, NULL, B.UNTC_REPLY_WHL_CNT) * 100, 1), 0), 'FM9990.9'), '.')    AS DTRL2_NM --전년 당월 비대면 협진 회신율 24시간이내
							  FROM FROM_TO_DATE_TYPE A
							     , FROM_TO_MAN_DAYS  B
							 WHERE A.DATE_TYPE = B.DATE_TYPE(+)    
							 
					
			  			  ORDER BY COMN_GRP_CD, COMN_CD_EXPL, COMN_CD, COMN_CD_NM		   
							;      
        			           
  END PC_EICU_CENTER_ODRPY_STTS;
