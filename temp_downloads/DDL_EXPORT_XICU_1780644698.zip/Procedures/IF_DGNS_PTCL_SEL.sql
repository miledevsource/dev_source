
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_DGNS_PTCL_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2      -- 병원구분코드
																							   , IN_SEQ       	      IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2      -- 환자번호  
																							   , IN_PACT_ID          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
      SELECT DIAGNOSIS_DT   -- 진단일 (YYYYMMDD)
           , DIAGNOSIS_CD   -- 상병코드
           , DGNS_NM        -- 진단명
        FROM DGNS_PTCL_SEL
        WHERE DIAGNOSIS_DT >= (
        SELECT MAX(DIAGNOSIS_DT)
        FROM DGNS_PTCL_SEL
        ) - 3
       ORDER BY DIAGNOSIS_DT DESC;
END IF_DGNS_PTCL_SEL;
