
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_BATCH_MORTALITY" 
                          ( IN_PRMR_STR_DTM   IN  DATE
                          , IN_PRMR_END_DTM   IN  DATE
                          , IN_HSP_TP_CD      IN  VARCHAR2
                          , IO_ERR_YN         IN OUT  VARCHAR2    --  ERROR Y/N
                          , IO_ERR_MSG        IN OUT  VARCHAR2    --  ERROR MESSAGE
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_BATCH_MORTALITY
*    CREATEDATE     : 2021.02.09
*    Author         : 신솔
*    Description    : 중환자실 사망률 데이터 배치
*    Change History : 2021.02.09, 신솔, 최초작성
**********************************************************************************************/
BEGIN
    /**********************************************************************************************
    *    중환자실사망지표기본 ( UICICSDM ) BATCH
    *
    **********************************************************************************************/
    BEGIN
        -- 신규생성 또는 업데이트 데이터를 기준으로 삭제하고 데이터를 적재한다.
        DELETE 
          FROM HICU.UICICSDM
         WHERE PACT_ID IN ( SELECT X.PACT_ID
                              FROM HICU.UICICRID X
                             WHERE X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                               AND X.HSP_TP_CD   = IN_HSP_TP_CD
                             UNION ALL
                            SELECT Y.PACT_ID
                              FROM HICU.UICICRPM Y
                             WHERE Y.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                               AND Y.HSP_TP_CD   = IN_HSP_TP_CD )
        ;   
        COMMIT; 
    END;
    
    BEGIN
        MERGE INTO HICU.UICICSDM A  --중환자실사망지표기본
             USING (
                       WITH CHOT_DATA AS (
                            --퇴원환자
                            SELECT
                                   A.CIPT_ETRM_CHOT_ID         AS CIPT_ETRM_CHOT_ID
                                 , A.PACT_ID                   AS PACT_ID
                                 , A.HSP_TP_CD                 AS HSP_TP_CD
                                 , A.PT_NO                     AS PT_NO
                                 , B.PT_NM                     AS PT_NM
                                 , B.ADS_DT                    AS ADS_DT
                                 , B.DS_EXPT_DT                AS DS_EXPT_DT
                                 , B.SEX_TP_CD                 AS SEX_TP_CD
                                 , B.AGE                       AS AGE
                                 , B.AGE_MRK_NM                AS AGE_MRK_NM
                                 , B.ADS_PATH_CD               AS ADS_PATH_CD
                                 , B.ADS_PATH_CD_NM            AS ADS_PATH_CD_NM
                                 , A.MED_DEPT_CD               AS MED_DEPT_CD
                                 , A.MED_DEPT_CD_NM            AS MED_DEPT_CD_NM
                                 , A.RPRN_MED_DEPT_CD          AS RPRN_MED_DEPT_CD
                                 , A.RPRN_MED_DEPT_CD_NM       AS RPRN_MED_DEPT_CD_NM
                                 , A.ETRM_DTM                  AS ETRM_DTM
                                 , A.ETRM_WD_DEPT_CD           AS ETRM_WD_DEPT_CD
                                 , A.ETRM_WD_DEPT_CD_NM        AS ETRM_WD_DEPT_CD_NM
                                 , A.ETRM_PRM_NO               AS ETRM_PRM_NO
                                 , A.ETRM_BED_NO               AS ETRM_BED_NO
                                 , A.EMRG_BED_YN               AS EMRG_BED_YN
                                 , A.ISLT_BED_YN               AS ISLT_BED_YN
                                 , A.ICU_ETRM_PATH_CLS_CD      AS ICU_ETRM_PATH_CLS_CD
                                 , A.ICU_ETRM_PATH_CLS_CD_NM   AS ICU_ETRM_PATH_CLS_CD_NM
                                 , A.CHOT_DTM                  AS CHOT_DTM
                                 , A.ICU_CHOT_PLC_TP_CD        AS ICU_CHOT_PLC_TP_CD
                                 , A.ICU_CHOT_PLC_TP_CD_NM     AS ICU_CHOT_PLC_TP_CD_NM
                                 , A.CHOT_WD_MTD_CD            AS CHOT_WD_MTD_CD
                                 , A.CHOT_WD_MTD_CD_NM         AS CHOT_WD_MTD_CD_NM
                                 , C.INPT_DTM                  AS APCS_REC_INPT_DTM
                                 , C.WRT_SEQ                   AS APCS_REC_WRT_SEQ
                                 , C.APCS_PT_STS_CD            AS APCS_PT_STS_CD
                                 , C.APCS_PT_STS_CD_NM         AS APCS_PT_STS_CD_NM
                                 , C.SUM_SCR                   AS APCS_SUM_SCR
                                 , DENSE_RANK() OVER (PARTITION BY A.CIPT_ETRM_CHOT_ID, A.HSP_TP_CD ORDER BY C.INPT_DTM DESC, C.WRT_SEQ DESC) AS RANK
                                 , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND A.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                        WHEN (B.LST_LOD_DTM IS NOT NULL AND B.LST_LOD_DTM > NVL(A.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD')) AND B.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN B.LST_LOD_DTM
                                        ELSE C.LST_LOD_DTM END AS LST_LOD_DTM
                              FROM HICU.UICICRID A --중환자실입실퇴실시간정보
                                 , HICU.UICICRPM B --중환자기본
                                 , HICU.UICICRAD C --아파치스코어기록정보
                             WHERE A.PACT_ID         = B.PACT_ID
                               AND A.HSP_TP_CD       = B.HSP_TP_CD
                               AND A.HSP_TP_CD       = IN_HSP_TP_CD
                               AND A.CHOT_DTM        <= SYSDATE  /*미래자 퇴실일자는 제외*/
                               AND A.USE_YN          = 'Y'
                               AND A.LST_YN          = 'Y'
                               AND A.PACT_TP_CD      = 'I'
                               AND C.PT_NO(+)        = A.PT_NO
                               AND C.PACT_ID(+)      = A.PACT_ID
                               AND C.HSP_TP_CD(+)    = A.HSP_TP_CD
                               AND C.PACT_TP_CD(+)   = A.PACT_TP_CD
                               AND C.ICU_ETRM_DTM(+) = A.ETRM_DTM
                               AND C.WD_DEPT_CD(+)   = A.ETRM_WD_DEPT_CD
                               AND C.USE_YN(+)       = 'Y'
                               AND C.LST_YN(+)       = 'Y'
                               AND C.PACT_TP_CD(+)   = 'I'
                               AND C.INPT_DTM(+)     BETWEEN TRUNC(A.ETRM_DTM) AND TRUNC(A.CHOT_DTM)
                               AND (A.LST_LOD_DTM    BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  B.LST_LOD_DTM    BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                OR  C.LST_LOD_DTM    BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)
                            )
                          , DIE_DATA AS (
                            --사망환자
                            SELECT
                                   A.CIPT_ETRM_CHOT_ID         AS CIPT_ETRM_CHOT_ID
                                 , A.PACT_ID                   AS PACT_ID
                                 , A.HSP_TP_CD                 AS HSP_TP_CD
                                 , A.PT_NO                     AS PT_NO
                                 , A.PT_NM                     AS PT_NM
                                 , A.ETRM_WD_DEPT_CD           AS ETRM_WD_DEPT_CD
                                 , A.ETRM_DTM                  AS ETRM_DTM
                                 , B.REC_DTM                   AS DTH_DGCT_WRT_DTM
                                 , C.DTH_TP_CD                 AS DTH_TP_CD
                                 , C.DTH_DT                    AS DTH_DT
                                 , CASE WHEN (B.LST_LOD_DTM IS NOT NULL AND B.LST_LOD_DTM > NVL(C.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN B.LST_LOD_DTM
                                        ELSE C.LST_LOD_DTM END AS LST_LOD_DTM
                              FROM CHOT_DATA A
                                 , (SELECT HSP_TP_CD
                                         , PT_NO
                                         , REC_DTM
                                         , LST_LOD_DTM
                                      FROM (SELECT Y.HSP_TP_CD
                                                 , Y.PT_NO
                                                 , Y.REC_DTM
                                                 , Y.LST_LOD_DTM
                                                 , ROW_NUMBER() OVER(PARTITION BY Y.PT_NO ORDER BY MDF_REC_DTM DESC) AS RN
                                              FROM (SELECT * FROM HICU.UICICRCD X WHERE X.HSP_TP_CD = IN_HSP_TP_CD AND X.LST_YN = 'Y' AND X.MDRC_DC_TP_CD = 'C' AND X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM) Y)
                                     WHERE RN = 1)  B --진료기록사망진단서정보
                                 , (SELECT Z.HSP_TP_CD
                                         , Z.PT_NO 
                                         , Z.DTH_TP_CD
                                         , Z.DTH_DT
                                         , Z.LST_LOD_DTM
                                      FROM HICU.UICICRDD Z
                                     WHERE Z.HSP_TP_CD   = IN_HSP_TP_CD
                                       AND Z.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM)        C --진료분석사망정보
                             WHERE A.ICU_CHOT_PLC_TP_CD IN('06', '07')
                               AND A.PT_NO              = B.PT_NO(+)
                               AND A.HSP_TP_CD          = B.HSP_TP_CD(+)
                               AND C.DTH_TP_CD(+)       IS NOT NULL
                               AND C.PT_NO(+)           = A.PT_NO
                               AND C.HSP_TP_CD(+)       = A.HSP_TP_CD
                            )     
                       
                       --최종적재일시 이후 적재된 중환자실사망지표 조회
                       SELECT
                              A.CIPT_ETRM_CHOT_ID         AS CIPT_ETRM_CHOT_ID
                            , A.HSP_TP_CD                 AS HSP_TP_CD
                            , A.PACT_ID                   AS PACT_ID
                            , A.PT_NO                     AS PT_NO
                            , A.PT_NM                     AS PT_NM
                            , A.ADS_DT                    AS ADS_DT
                            , A.DS_EXPT_DT                AS DS_EXPT_DT
                            , A.SEX_TP_CD                 AS SEX_TP_CD
                            , A.AGE                       AS AGE
                            , A.AGE_MRK_NM                AS AGE_MRK_NM
                            , A.ADS_PATH_CD               AS ADS_PATH_CD
                            , A.ADS_PATH_CD_NM            AS ADS_PATH_NM
                            , A.MED_DEPT_CD               AS MED_DEPT_CD
                            , A.MED_DEPT_CD_NM            AS MED_DEPT_CD_NM
                            , A.RPRN_MED_DEPT_CD          AS RPRN_MED_DEPT_CD
                            , A.RPRN_MED_DEPT_CD_NM       AS RPRN_MED_DEPT_CD_NM
                            , A.ETRM_DTM                  AS ETRM_DTM
                            , A.ETRM_WD_DEPT_CD           AS ETRM_WD_DEPT_CD
                            , A.ETRM_WD_DEPT_CD_NM        AS ETRM_WD_DEPT_CD_NM
                            , A.ETRM_PRM_NO               AS ETRM_PRM_NO
                            , A.ETRM_BED_NO               AS ETRM_BED_NO
                            , A.EMRG_BED_YN               AS EMRG_BED_YN
                            , A.ISLT_BED_YN               AS ISLT_BED_YN
                            , A.ICU_ETRM_PATH_CLS_CD      AS ICU_ETRM_PATH_CLS_CD
                            , A.ICU_ETRM_PATH_CLS_CD_NM   AS ICU_ETRM_PATH_CLS_CD_NM
                            , A.CHOT_DTM                  AS CHOT_DTM
                            , A.ICU_CHOT_PLC_TP_CD        AS ICU_CHOT_PLC_TP_CD
                            , A.ICU_CHOT_PLC_TP_CD_NM     AS ICU_CHOT_PLC_TP_CD_NM
                            , A.CHOT_WD_MTD_CD            AS CHOT_WD_MTD_CD
                            , A.CHOT_WD_MTD_CD_NM         AS CHOT_WD_MTD_CD_NM
                            , A.APCS_REC_INPT_DTM         AS APCS_REC_INPT_DTM
                            , A.APCS_REC_WRT_SEQ          AS APCS_REC_WRT_SEQ
                            , A.APCS_PT_STS_CD            AS APCS_PT_STS_CD
                            , A.APCS_PT_STS_CD_NM         AS APCS_PT_STS_CD_NM
                            , A.APCS_SUM_SCR              AS APCS_SUM_SCR
                            , B.DTH_DGCT_WRT_DTM          AS DTH_DGCT_WRT_DTM
                            , B.DTH_TP_CD                 AS DTH_TP_CD
                            , B.DTH_DT                    AS DTH_DT
                            , CASE WHEN (A.LST_LOD_DTM IS NOT NULL AND A.LST_LOD_DTM > NVL(B.LST_LOD_DTM, TO_DATE('1900-01-01', 'YYYY-MM-DD'))) THEN A.LST_LOD_DTM
                                   ELSE B.LST_LOD_DTM END AS LST_LOD_DTM
                         FROM CHOT_DATA A --퇴원환자
                            , DIE_DATA  B --사망환자
                        WHERE A.CIPT_ETRM_CHOT_ID = B.CIPT_ETRM_CHOT_ID(+)
                          AND (A.RANK = 1 OR A.RANK IS NULL)
                        ORDER BY A.CIPT_ETRM_CHOT_ID, A.PACT_ID, A.PT_NO
                   ) B
                ON (       A.HSP_TP_CD         = B.HSP_TP_CD
                     AND   A.CIPT_ETRM_CHOT_ID = B.CIPT_ETRM_CHOT_ID
                   )
             WHEN MATCHED
             THEN UPDATE SET A.PACT_ID                 = B.PACT_ID
                           , A.PT_NO                   = B.PT_NO
                           , A.PT_NM                   = B.PT_NM
                           , A.ADS_DT                  = B.ADS_DT
                           , A.DS_EXPT_DT              = B.DS_EXPT_DT
                           , A.SEX_TP_CD               = B.SEX_TP_CD
                           , A.AGE                     = B.AGE
                           , A.AGE_MRK_NM              = B.AGE_MRK_NM
                           , A.ADS_PATH_CD             = B.ADS_PATH_CD
                           , A.ADS_PATH_NM             = B.ADS_PATH_NM
                           , A.MED_DEPT_CD             = B.MED_DEPT_CD
                           , A.MED_DEPT_CD_NM          = B.MED_DEPT_CD_NM
                           , A.RPRN_MED_DEPT_CD        = B.RPRN_MED_DEPT_CD
                           , A.RPRN_MED_DEPT_CD_NM     = B.RPRN_MED_DEPT_CD_NM
                           , A.ETRM_DTM                = B.ETRM_DTM
                           , A.ETRM_WD_DEPT_CD         = B.ETRM_WD_DEPT_CD
                           , A.ETRM_WD_DEPT_CD_NM      = B.ETRM_WD_DEPT_CD_NM
                           , A.ETRM_PRM_NO             = B.ETRM_PRM_NO
                           , A.ETRM_BED_NO             = B.ETRM_BED_NO
                           , A.EMRG_BED_YN             = B.EMRG_BED_YN
                           , A.ISLT_BED_YN             = B.ISLT_BED_YN
                           , A.ICU_ETRM_PATH_CLS_CD    = B.ICU_ETRM_PATH_CLS_CD
                           , A.ICU_ETRM_PATH_CLS_CD_NM = B.ICU_ETRM_PATH_CLS_CD_NM
                           , A.CHOT_DTM                = B.CHOT_DTM
                           , A.ICU_CHOT_PLC_TP_CD      = B.ICU_CHOT_PLC_TP_CD
                           , A.ICU_CHOT_PLC_TP_CD_NM   = B.ICU_CHOT_PLC_TP_CD_NM
                           , A.CHOT_WD_MTD_CD          = B.CHOT_WD_MTD_CD
                           , A.CHOT_WD_MTD_CD_NM       = B.CHOT_WD_MTD_CD_NM
                           , A.APCS_REC_INPT_DTM       = B.APCS_REC_INPT_DTM
                           , A.APCS_REC_WRT_SEQ        = B.APCS_REC_WRT_SEQ
                           , A.APCS_PT_STS_CD          = B.APCS_PT_STS_CD
                           , A.APCS_PT_STS_CD_NM       = B.APCS_PT_STS_CD_NM
                           , A.APCS_SUM_SCR            = B.APCS_SUM_SCR
                           , A.DTH_DGCT_WRT_DTM        = B.DTH_DGCT_WRT_DTM
                           , A.DTH_TP_CD               = B.DTH_TP_CD
                           , A.DTH_DT                  = B.DTH_DT
                           , A.LST_LOD_DTM             = SYSDATE
             WHEN NOT MATCHED
             THEN INSERT ( A.CIPT_ETRM_CHOT_ID
                         , A.HSP_TP_CD
                         , A.PACT_ID
                         , A.PT_NO
                         , A.PT_NM
                         , A.ADS_DT
                         , A.DS_EXPT_DT
                         , A.SEX_TP_CD
                         , A.AGE
                         , A.AGE_MRK_NM
                         , A.ADS_PATH_CD
                         , A.ADS_PATH_NM
                         , A.MED_DEPT_CD
                         , A.MED_DEPT_CD_NM
                         , A.RPRN_MED_DEPT_CD
                         , A.RPRN_MED_DEPT_CD_NM
                         , A.ETRM_DTM
                         , A.ETRM_WD_DEPT_CD
                         , A.ETRM_WD_DEPT_CD_NM
                         , A.ETRM_PRM_NO
                         , A.ETRM_BED_NO
                         , A.EMRG_BED_YN
                         , A.ISLT_BED_YN
                         , A.ICU_ETRM_PATH_CLS_CD
                         , A.ICU_ETRM_PATH_CLS_CD_NM
                         , A.CHOT_DTM
                         , A.ICU_CHOT_PLC_TP_CD
                         , A.ICU_CHOT_PLC_TP_CD_NM
                         , A.CHOT_WD_MTD_CD
                         , A.CHOT_WD_MTD_CD_NM
                         , A.APCS_REC_INPT_DTM
                         , A.APCS_REC_WRT_SEQ
                         , A.APCS_PT_STS_CD
                         , A.APCS_PT_STS_CD_NM
                         , A.APCS_SUM_SCR
                         , A.DTH_DGCT_WRT_DTM
                         , A.DTH_TP_CD
                         , A.DTH_DT
                         , A.FST_LOD_DTM
                         , A.LST_LOD_DTM
                         )
                  VALUES ( B.CIPT_ETRM_CHOT_ID
                         , B.HSP_TP_CD
                         , B.PACT_ID
                         , B.PT_NO
                         , B.PT_NM
                         , B.ADS_DT
                         , B.DS_EXPT_DT
                         , B.SEX_TP_CD
                         , B.AGE
                         , B.AGE_MRK_NM
                         , B.ADS_PATH_CD
                         , B.ADS_PATH_NM
                         , B.MED_DEPT_CD
                         , B.MED_DEPT_CD_NM
                         , B.RPRN_MED_DEPT_CD
                         , B.RPRN_MED_DEPT_CD_NM
                         , B.ETRM_DTM
                         , B.ETRM_WD_DEPT_CD
                         , B.ETRM_WD_DEPT_CD_NM
                         , B.ETRM_PRM_NO
                         , B.ETRM_BED_NO
                         , B.EMRG_BED_YN
                         , B.ISLT_BED_YN
                         , B.ICU_ETRM_PATH_CLS_CD
                         , B.ICU_ETRM_PATH_CLS_CD_NM
                         , B.CHOT_DTM
                         , B.ICU_CHOT_PLC_TP_CD
                         , B.ICU_CHOT_PLC_TP_CD_NM
                         , B.CHOT_WD_MTD_CD
                         , B.CHOT_WD_MTD_CD_NM
                         , B.APCS_REC_INPT_DTM
                         , B.APCS_REC_WRT_SEQ
                         , B.APCS_PT_STS_CD
                         , B.APCS_PT_STS_CD_NM
                         , B.APCS_SUM_SCR
                         , B.DTH_DGCT_WRT_DTM
                         , B.DTH_TP_CD
                         , B.DTH_DT
                         , SYSDATE
                         , SYSDATE
                         )
        ;    
        
        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '1) 중환자실사망지표기본 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
            RETURN;
    END;
    
    
    /**********************************************************************************************
    *    중환자실사망중증도분류정보 ( UICICSDD )  BATCH
    *
    **********************************************************************************************/
    BEGIN
        -- 신규생성 또는 업데이트 데이터를 기준으로 삭제하고 데이터를 적재한다.
        DELETE 
          FROM HICU.UICICSDD
         WHERE PT_SILLM_CTG_REC_ID IN ( SELECT X.PT_SILLM_CTG_REC_ID
                                          FROM HICU.UICICRSD X --환자중증도분류기록정보
                                         WHERE X.LST_LOD_DTM BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                                           AND X.HSP_TP_CD   = IN_HSP_TP_CD )
        ;   
        COMMIT; 
    END;
    
    BEGIN
        MERGE INTO HICU.UICICSDD A  --중환자실사망중증도분류정보
             USING (
                       SELECT B.PT_SILLM_CTG_REC_ID    AS PT_SILLM_CTG_REC_ID
                            , B.WRT_SEQ                AS PT_SILLM_CTG_REC_WRT_SEQ
                            , B.HSP_TP_CD              AS HSP_TP_CD
                            , B.PACT_ID                AS PACT_ID
                            , B.PT_NO                  AS PT_NO
                            , A.CIPT_ETRM_CHOT_ID      AS CIPT_ETRM_CHOT_ID
                            , B.CTG_DTM                AS PT_SILLM_CTG_DTM
                            , B.WD_DEPT_CD             AS WD_DEPT_CD
                            , B.WD_DEPT_CD_NM          AS WD_DEPT_CD_NM
                            , B.PT_SILLM_CTG_TL_ID     AS PT_SILLM_CTG_TL_ID
                            , B.PT_SILLM_CTG_TL_NM     AS PT_SILLM_CTG_TL_NM
                            , B.PT_SILLM_CTG_TP_CD     AS PT_SILLM_CTG_TP_CD
                            , B.PT_SILLM_CTG_TP_CD_NM  AS PT_SILLM_CTG_TP_CD_NM
                            , B.PT_SILLM_CTG_GRP_CD    AS PT_SILLM_CTG_GRP_CD
                            , B.PT_SILLM_CTG_GRP_CD_NM AS PT_SILLM_CTG_GRP_CD_NM
                            , B.PT_SILLM_CTG_SCR_SUM   AS PT_SILLM_CTG_SCR_SUM
                         FROM HICU.UICICRID A --중환자실입실퇴실시간정보
                            , HICU.UICICRSD B --환자중증도분류기록정보
                        WHERE A.HSP_TP_CD          = IN_HSP_TP_CD
                          AND A.CHOT_DTM           <= SYSDATE  /*미래자 퇴실일자는 제외*/
                          AND A.USE_YN             = 'Y'
                          AND A.LST_YN             = 'Y'
                          AND A.PACT_TP_CD         = 'I'
                          AND A.ICU_CHOT_PLC_TP_CD IN('06', '07')
                          AND A.HSP_TP_CD          = B.HSP_TP_CD
                          AND A.PT_NO              = B.PT_NO
                          AND A.PACT_ID            = B.PACT_ID
                          AND A.ETRM_WD_DEPT_CD    = B.WD_DEPT_CD
                          AND B.LST_LOD_DTM        BETWEEN IN_PRMR_STR_DTM AND IN_PRMR_END_DTM
                   ) B
                ON (       A.PT_SILLM_CTG_REC_ID      = B.PT_SILLM_CTG_REC_ID
                     AND   A.PT_SILLM_CTG_REC_WRT_SEQ = B.PT_SILLM_CTG_REC_WRT_SEQ
                     AND   A.HSP_TP_CD                = B.HSP_TP_CD
                   )
             WHEN MATCHED
             THEN UPDATE SET A.PACT_ID               = B.PACT_ID
                           , A.PT_NO                 = B.PT_NO
                           , A.CIPT_ETRM_CHOT_ID     = B.CIPT_ETRM_CHOT_ID
                           , A.PT_SILLM_CTG_DTM      = B.PT_SILLM_CTG_DTM
                           , A.WD_DEPT_CD            = B.WD_DEPT_CD
                           , A.WD_DEPT_CD_NM         = B.WD_DEPT_CD_NM
                           , A.PT_SILLM_CTG_TL_ID    = B.PT_SILLM_CTG_TL_ID
                           , A.PT_SILLM_CTG_TL_NM    = B.PT_SILLM_CTG_TL_NM
                           , A.PT_SILLM_CTG_TP_CD    = B.PT_SILLM_CTG_TP_CD
                           , A.PT_SILLM_CTG_TP_CD_NM = B.PT_SILLM_CTG_TP_CD_NM
                           , A.PT_SILLM_CTG_GRP_CD   = B.PT_SILLM_CTG_GRP_CD
                           , A.PT_SILLM_CTG_GRP_CD_NM= B.PT_SILLM_CTG_GRP_CD_NM
                           , A.PT_SILLM_CTG_SCR_SUM  = B.PT_SILLM_CTG_SCR_SUM
                           , A.LST_LOD_DTM           = SYSDATE
             WHEN NOT MATCHED
             THEN INSERT ( A.PT_SILLM_CTG_REC_ID
                         , A.PT_SILLM_CTG_REC_WRT_SEQ
                         , A.HSP_TP_CD
                         , A.PACT_ID
                         , A.PT_NO
                         , A.CIPT_ETRM_CHOT_ID
                         , A.PT_SILLM_CTG_DTM
                         , A.WD_DEPT_CD
                         , A.WD_DEPT_CD_NM
                         , A.PT_SILLM_CTG_TL_ID
                         , A.PT_SILLM_CTG_TL_NM
                         , A.PT_SILLM_CTG_TP_CD
                         , A.PT_SILLM_CTG_TP_CD_NM
                         , A.PT_SILLM_CTG_GRP_CD
                         , A.PT_SILLM_CTG_GRP_CD_NM
                         , A.PT_SILLM_CTG_SCR_SUM
                         , A.FST_LOD_DTM
                         , A.LST_LOD_DTM
                         )
                  VALUES ( B.PT_SILLM_CTG_REC_ID
                         , B.PT_SILLM_CTG_REC_WRT_SEQ
                         , B.HSP_TP_CD
                         , B.PACT_ID
                         , B.PT_NO
                         , B.CIPT_ETRM_CHOT_ID
                         , B.PT_SILLM_CTG_DTM
                         , B.WD_DEPT_CD
                         , B.WD_DEPT_CD_NM
                         , B.PT_SILLM_CTG_TL_ID
                         , B.PT_SILLM_CTG_TL_NM
                         , B.PT_SILLM_CTG_TP_CD
                         , B.PT_SILLM_CTG_TP_CD_NM
                         , B.PT_SILLM_CTG_GRP_CD
                         , B.PT_SILLM_CTG_GRP_CD_NM
                         , B.PT_SILLM_CTG_SCR_SUM
                         , SYSDATE
                         , SYSDATE
                         )
        ;
        
        EXCEPTION
            WHEN OTHERS THEN
                IO_ERR_YN  := 'Y';
                IO_ERR_MSG := '2) 중환자실사망중증도분류정보 MERGE INTO 시 오류발생. ERRCODE = ' || TO_CHAR(SQLCODE);
            RETURN;
    END;    
END PC_EICU_BATCH_MORTALITY;
