
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_LD_UICIISPM_SAVE" (  IN_HSP_TP_CD    IN VARCHAR2         -- 02.병원구분코드
                                        , IN_WD_DEPT_CD   IN VARCHAR2         -- 02.병동구분코드
                                        , IN_FROM_DTE     IN DATE             -- 03.조회시작일자
                                        , IN_TO_DTE       IN DATE             -- 03.조회종료일자                                         
                                        , IO_ERRYN        IN OUT  VARCHAR2    -- 04. ERROR Y/N
                                        , IO_ERRMSG       IN OUT  VARCHAR2)   -- 05. ERROR MESSAGE 
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_LD_UICIISPM_SAVE                                               
*    CREATEDATE     : 2021.03.15
*    Author         : 오지민                                                                     
*    Description    : 운영시스템>임상지표 관련 UICIISPM 데이터 적재(신규 데이터 생성 및 업데이트)
*    Change History : 2021.03.15                                                
**********************************************************************************************/
 AS  
BEGIN     
    IO_ERRYN := 'N';
    IO_ERRMSG := '';
    
    /* ODS-UICIIRID(격리병동입퇴실시간정보)와 UICIIRPD(격리병동환자기본)에 신규 생성 또는 업데이트 데이터를 기준으로 삭제하고 데이터를 적재한다.
     * UICIIRID(격리병동환자기본)이 전과전등테이블기준으로 적재가 되기때문에 입실일자와 퇴실일자 기준으로 데이터를 합칠 필요가 있어서 그렇게 하기로 함.*/
    BEGIN
	   /*격리병동지표 기본에서 삭제 조건*/
	   DELETE FROM HICU.UICIISPM
	    WHERE PACT_ID IN ( SELECT PACT_ID
	                         FROM HICU.UICIIRID
	                        WHERE LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE
	                        UNION ALL
	                       SELECT PACT_ID
	                         FROM HICU.UICIIRPD X
	                        WHERE X.LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE)
	   ;   
	   COMMIT; 
	END;
	
    BEGIN
        /* FST_REC_DTM, SND_REC_DTM은 법정감염병서식 조회 기준일자로 사용.
         * FST_REC_DTM : 격리병동에 입실일자부터 퇴실 일자 사이에  첫번째로 작성 된 법정감염병신고서 작성 일자
         * SND_REC_DMT : FST_REC_DTM이 없을 사용 할 작성 일자로 입원일자부터 입실일자 사이에 마지막으로 작성된 법정 감염병 신고서 작성일자
         *               혹 응급실 접수 ID가 있다면 응급실도착일시부터 입실일자 사이에 마지막으로 작성된 법정 감염병 신고서 작성일자를 조회한다.
         */
        MERGE INTO HICU.UICIISPM A  --격리병동환자지표기본
                 USING (
                            WITH SDATA AS(
                               SELECT B.PACT_ID PACT_ID
                                    , B.PT_NO
                            	    , B.APY_STR_DT
                            	    , B.HSP_TP_CD
                            	    , A.PT_NM
                            	    , A.DS_EXPT_DT
                            	    , A.ADS_DT	                                              --응급실도착일시
                            	    , A.SEX_TP_CD
                            	    , A.AGE
                            	    , A.AGE_MRK_NM
                            	    , A.ADS_PATH_CD
                            	    , A.ADS_PATH_CD_NM
                            	    , B.MED_DEPT_CD
                            	    , B.MED_DEPT_CD_NM
                            	    , B.RPRN_MED_DEPT_CD
                            	    , B.RPRN_MED_DEPT_CD_NM
                            	    , B.ETRM_WD_DEPT_CD
                            	    , B.ETRM_WD_DEPT_CD_NM
                            	    , '' ETRM_PRM_NO
                            	    , '' ETRM_BED_NO
                            	    , '' EMRG_BED_YN
                            	    , '' ICU_ETRM_PATH_CLS_CD
                            	    , '' ICU_ETRM_PATH_CLS_CD_NM
                            	    , DECODE(SIHS_YN, 'Y', TO_DATE('9999-12-31', 'YYYY-MM-DD'), B.APY_END_DT) APY_END_DT
                                    , '' ICU_CHOT_PLC_TP_CD
                                    , '' ICU_CHOT_PLC_TP_CD_NM
                                    , '' CHOT_WD_MTD_CD
                                    , '' CHOT_WD_MTD_CD_NM
                            	    , A.EMRG_PACT_ID                                                 --응급원무접수ID
                            	    , A.EMRM_ARVL_DTM                                                --응급실도착시간
--                            	    , ( SELECT MIN(REC_DTM)
--                                          FROM HICU.UICIIRED X
--                                         WHERE B.PACT_ID = X.PACT_ID
--                                           AND B.HSP_TP_CD = X.HSP_TP_CD
--                                           AND X.LST_YN = 'Y'
--                                           AND X.MDRC_DC_TP_CD = 'C'
--                                           AND X.REC_DTM BETWEEN B.APY_STR_DT AND B.APY_END_DT + 0.99999
--                                           AND X.INFC_DCLR_CMPL_CD IN ('H','N')) FST_REC_DTM
--                                    , ( SELECT MAX(REC_DTM)
--                                          FROM HICU.UICIIRED X
--                                         WHERE X.PACT_ID IN (A.PACT_ID, A.EMRG_PACT_ID)
--                                           AND X.HSP_TP_CD  = B.HSP_TP_CD
--                                           AND X.LST_YN = 'Y'
--                                           AND X.MDRC_DC_TP_CD = 'C'
--                                           AND X.REC_DTM BETWEEN DECODE(A.EMRG_PACT_ID, NULL, A.ADS_DT, TRUNC(A.EMRM_ARVL_DTM)) AND B.APY_STR_DT + 0.99999
--                                           AND X.INFC_DCLR_CMPL_CD IN ('H','N')) SND_REC_DTM
                                FROM HICU.UICIIRPD A   --격리병동환자기본
                                   , (SELECT PACT_ID
                                           , HSP_TP_CD
                                           , PT_NO
                                           , MAX(CASE WHEN RANK = 1 THEN DATA1.MED_DEPT_CD END)      MED_DEPT_CD
                                           , MAX(CASE WHEN RANK = 1 THEN DATA1.MED_DEPT_CD_NM END)   MED_DEPT_CD_NM
                                           , ETRM_WD_DEPT_CD     ETRM_WD_DEPT_CD
                                           , ETRM_WD_DEPT_CD_NM
                                           , MAX(CASE WHEN RANK = 1 THEN DATA1.RPRN_MED_DEPT_CD END)       RPRN_MED_DEPT_CD
                                           , MAX(CASE WHEN RANK = 1 THEN DATA1.RPRN_MED_DEPT_CD_NM END)    RPRN_MED_DEPT_CD_NM
                                           , MIN(DTM) APY_STR_DT
                                           , MAX(DTM) APY_END_DT
                                           , MAX(SIHS_YN)                                                   SIHS_YN
                                       FROM (
                                                SELECT DISTINCT PACT_ID
                                                      , HSP_TP_CD
                                                      , PT_NO
                                                      , ETRM_WD_DEPT_CD
                                                      , ETRM_WD_DEPT_CD_NM
                                                      , MED_DEPT_CD
                                             	      , MED_DEPT_CD_NM
                                                      , RPRN_MED_DEPT_CD
                                                      , RPRN_MED_DEPT_CD_NM
                                                      , SIHS_YN
                                                      , DTM
                                                      , DTM-ROWNUM BASE
                                                      , DENSE_RANK() OVER (PARTITION BY PACT_ID ,HSP_TP_CD ,PT_NO ,ETRM_WD_DEPT_CD, DTM-ROWNUM ORDER BY DTM) RANK
                                                   FROM (
                                                          SELECT PACT_ID
                                                               , HSP_TP_CD
                                                               , PT_NO
                                                               , ETRM_WD_DEPT_CD
                                                               , ETRM_WD_DEPT_CD_NM
                                                               , MED_DEPT_CD
                                                               , MED_DEPT_CD_NM
                                                               , RPRN_MED_DEPT_CD
                                                               , RPRN_MED_DEPT_CD_NM
                                                               , DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), 'Y' , 'N') SIHS_YN
                                                               , DT_CD DTM
                                                          FROM HICU.UICIIRID A
                                                             , HICU.UICIIRHD B
                                                         WHERE A.APCN_YN  = 'N'
                                                           AND A.ETRM_WD_DEPT_CD = IN_WD_DEPT_CD
                                                           AND B.DT_CD BETWEEN  A.ETRM_DTM AND DECODE(A.CHOT_DTM, TO_DATE('9999-12-31', 'YYYY-MM-DD'), SYSDATE + 1 , A.CHOT_DTM)
                                                           AND A.PACT_ID IN (SELECT PACT_ID
                                                                               FROM HICU.UICIIRID AA
                                                                              WHERE LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE 
                                                                              UNION ALL
                                                                             SELECT PACT_ID
														                       FROM HICU.UICIIRPD X
														                      WHERE X.LST_LOD_DTM BETWEEN IN_FROM_DTE  AND IN_TO_DTE)
                                                         ORDER BY PACT_ID, DTM
                                                        )
                                                  ORDER BY  PACT_ID
                                                      , HSP_TP_CD
                                                      , PT_NO
                                                      , ETRM_WD_DEPT_CD
                                                      , DTM
                                                      , BASE) DATA1
                                      GROUP BY PACT_ID
                                             , HSP_TP_CD
                                             , PT_NO
                                             , ETRM_WD_DEPT_CD
                                             , ETRM_WD_DEPT_CD_NM
                                             , DTM-ROWNUM) B   --전과전등정보
                                WHERE A.HSP_TP_CD = B.HSP_TP_CD
                                  AND B.PT_NO     = A.PT_NO
                                  AND B.PACT_ID   = A.PACT_ID)
                             SELECT DATA.PACT_ID
                                  , DATA.PT_NO
                                  , DATA.APY_STR_DT      ETRM_DTM
                                  , DATA.HSP_TP_CD
                                  , DATA.PT_NM
                                  , DATA.DS_EXPT_DT
                                  , DATA.ADS_DT
                                  , DATA.SEX_TP_CD
                                  , DATA.AGE
                                  , DATA.ADS_PATH_CD
                                  , DATA.ADS_PATH_CD_NM
                                  , DATA.MED_DEPT_CD
                                  , DATA.MED_DEPT_CD_NM
                                  , DATA.RPRN_MED_DEPT_CD
                                  , DATA.RPRN_MED_DEPT_CD_NM
                                  , DATA.ETRM_WD_DEPT_CD
                                  , DATA.ETRM_WD_DEPT_CD_NM
                                  , DATA.ETRM_PRM_NO
                                  , DATA.ETRM_BED_NO
                                  , DATA.EMRG_BED_YN
                                  , DATA.ICU_ETRM_PATH_CLS_CD
                                  , DATA.ICU_ETRM_PATH_CLS_CD_NM
                                  , DATA.APY_END_DT       CHOT_DTM
                                  , DATA.ICU_CHOT_PLC_TP_CD
                                  , DATA.ICU_CHOT_PLC_TP_CD_NM
                                  , DATA.CHOT_WD_MTD_CD
                                  , DATA.CHOT_WD_MTD_CD_NM
                                  , DATA.EMRG_PACT_ID
                                  , DATA.EMRM_ARVL_DTM  
                                  , DATA.AGE_MRK_NM
--                                  , CASE WHEN DATA2.STTT_INFC_ILNS_CD IN ('158') THEN '3'
--                                         WHEN DATA2.STTT_INFC_ILNS_CD IN('53','153') THEN '2'
--                                         WHEN DATA2.STTT_INFC_ILNS_CD IN('52','152') THEN '1'
--                                         ELSE '4' END INFC_MCB_TP_CD 
                                  , ''        INFC_MCB_TP_CD 
                              FROM SDATA DATA   
--                                 , HICU.UICIIRED DATA2 --ODS-진료기록법정전염병정보
--                             WHERE DATA2.PACT_ID IN (DATA.PACT_ID, DATA.EMRG_PACT_ID)
--                               AND DATA2.HSP_TP_CD = DATA.HSP_TP_CD
--                               AND DATA2.REC_DTM = NVL(DATA.FST_REC_DTM, DATA.SND_REC_DTM)
--                               AND DATA2.LST_YN = 'Y'
--                               AND DATA2.MDRC_DC_TP_CD = 'C'
--                               AND DATA2.INFC_DCLR_CMPL_CD IN ('H','N')
                               ) B
                   ON (       A.ETRM_DTM                        = B.ETRM_DTM
                        AND   A.HSP_TP_CD                       = B.HSP_TP_CD
                        AND   A.PACT_ID                         = B.PACT_ID
                        AND   A.PT_NO                           = B.PT_NO
                      )
                 WHEN MATCHED THEN
                  UPDATE SET
                      A.DS_EXPT_DT                    = B.DS_EXPT_DT
                    , A.ADS_DT                        = B.ADS_DT
                    , A.SEX_TP_CD                     = B.SEX_TP_CD
                    , A.AGE                           = B.AGE
                    , A.ADS_PATH_CD                   = B.ADS_PATH_CD
                    , A.ADS_PATH_NM                   = B.ADS_PATH_CD_NM
                    , A.MED_DEPT_CD                   = B.MED_DEPT_CD
                    , A.MED_DEPT_CD_NM                = B.MED_DEPT_CD_NM
                    , A.RPRN_MED_DEPT_CD              = B.RPRN_MED_DEPT_CD
                    , A.RPRN_MED_DEPT_CD_NM           = B.RPRN_MED_DEPT_CD_NM
                    , A.ETRM_WD_DEPT_CD               = B.ETRM_WD_DEPT_CD
                    , A.ETRM_WD_DEPT_CD_NM            = B.ETRM_WD_DEPT_CD_NM
                    , A.ETRM_PRM_NO	                  = B.ETRM_PRM_NO
                    , A.ETRM_BED_NO	                  = B.ETRM_BED_NO
                    , A.EMRG_BED_YN	                  = B.EMRG_BED_YN
                    , A.ICU_ETRM_PATH_CLS_CD          = B.ICU_ETRM_PATH_CLS_CD
                    , A.ICU_ETRM_PATH_CLS_CD_NM	      = B.ICU_ETRM_PATH_CLS_CD_NM
                    , A.CHOT_DTM	                  = B.CHOT_DTM
                    , A.ICU_CHOT_PLC_TP_CD	          = B.ICU_CHOT_PLC_TP_CD
                    , A.ICU_CHOT_PLC_TP_CD_NM         = B.ICU_CHOT_PLC_TP_CD_NM
                    , A.CHOT_WD_MTD_CD	              = B.CHOT_WD_MTD_CD
                    , A.CHOT_WD_MTD_CD_NM	          = B.CHOT_WD_MTD_CD_NM
                    , A.EMRG_PACT_ID	              = B.EMRG_PACT_ID
                    , A.EMRM_ARVL_DTM                 = B.EMRM_ARVL_DTM 
                    , A.AGE_MRK_NM                    = B.AGE_MRK_NM
                    , A.INFC_MCB_TP_CD                = B.INFC_MCB_TP_CD
                    , A.LST_LOD_DTM                   = SYSDATE
                WHEN NOT MATCHED THEN
                  INSERT (
                             A.PACT_ID
                           , A.PT_NO
                           , A.ETRM_DTM
                           , A.HSP_TP_CD
                           , A.PT_NM
                           , A.DS_EXPT_DT
                           , A.ADS_DT
                           , A.SEX_TP_CD
                           , A.AGE
                           , A.ADS_PATH_CD
                           , A.ADS_PATH_NM
                           , A.MED_DEPT_CD
                           , A.MED_DEPT_CD_NM
                           , A.RPRN_MED_DEPT_CD
                           , A.RPRN_MED_DEPT_CD_NM
                           , A.ETRM_WD_DEPT_CD
                           , A.ETRM_WD_DEPT_CD_NM
                           , A.ETRM_PRM_NO
                           , A.ETRM_BED_NO
                           , A.EMRG_BED_YN
                           , A.ICU_ETRM_PATH_CLS_CD
                           , A.ICU_ETRM_PATH_CLS_CD_NM
                           , A.CHOT_DTM
                           , A.ICU_CHOT_PLC_TP_CD
                           , A.ICU_CHOT_PLC_TP_CD_NM
                           , A.CHOT_WD_MTD_CD
                           , A.CHOT_WD_MTD_CD_NM
                           , A.EMRG_PACT_ID
                           , A.EMRM_ARVL_DTM 
                           , A.AGE_MRK_NM
                           , A.INFC_MCB_TP_CD
                           , A.FST_LOD_DTM
                           , A.LST_LOD_DTM
                    )
                  VALUES (
                             B.PACT_ID
                           , B.PT_NO
                           , B.ETRM_DTM
                           , B.HSP_TP_CD
                           , B.PT_NM
                           , B.DS_EXPT_DT
                           , B.ADS_DT
                           , B.SEX_TP_CD
                           , B.AGE
                           , B.ADS_PATH_CD
                           , B.ADS_PATH_CD_NM
                           , B.MED_DEPT_CD
                           , B.MED_DEPT_CD_NM
                           , B.RPRN_MED_DEPT_CD
                           , B.RPRN_MED_DEPT_CD_NM
                           , B.ETRM_WD_DEPT_CD
                           , B.ETRM_WD_DEPT_CD_NM
                           , B.ETRM_PRM_NO
                           , B.ETRM_BED_NO
                           , B.EMRG_BED_YN
                           , B.ICU_ETRM_PATH_CLS_CD
                           , B.ICU_ETRM_PATH_CLS_CD_NM
                           , B.CHOT_DTM
                           , B.ICU_CHOT_PLC_TP_CD
                           , B.ICU_CHOT_PLC_TP_CD_NM
                           , B.CHOT_WD_MTD_CD
                           , B.CHOT_WD_MTD_CD_NM
                           , B.EMRG_PACT_ID
                           , B.EMRM_ARVL_DTM
                           , B.AGE_MRK_NM
                           , B.INFC_MCB_TP_CD
                           , SYSDATE
                           , SYSDATE
                      )
        ;
        COMMIT;
    EXCEPTION
        WHEN OTHERS THEN
            IO_ERRYN := 'Y';
            IO_ERRMSG := '(XICU.PC_EICU_LD_UICIISPM_SAVE): HSP_TP_CD = '|| IN_HSP_TP_CD || ', IN_WD_DEPT_CD = ' || IN_WD_DEPT_CD || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
            RETURN ;
    END;      
END PC_EICU_LD_UICIISPM_SAVE;
