
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_REGION_MANAGE_SUMMARY" 
                          ( IN_FROM_DTE      IN  DATE
                          , IN_TO_DTE        IN  DATE     
                          , IN_EPCN_GRP_CD   IN VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )    
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_REGION_MANAGE_SUMMARY                                               
*    CREATEDATE     : 2021.03.31                                                               
*    Author         : 오지민                                                                     
*    Description    : 통합관제 운영통계 권역별 병원통합지표현황
*    Change History : 2021.02.24, 오지민, 최초작성              
*    Change History : 2025.11.24, 윤재림, 병상가동율, NEWS 추가                                               
**********************************************************************************************/
BEGIN
    BEGIN 
       OPEN OUT_CURSOR FOR   
             WITH UNTACT_RECORD AS
             (
                 --비대면 협진 기록 Summary
                 SELECT HSP_TP_CD
                      , SUM(WHL_CSLT_CNT)            AS WHL_CSLT_CNT
                   FROM HICU.UCOSCNSD
--                  WHERE TO_DATE(UNTC_REC_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
                  WHERE UNTC_REC_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                    AND HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
                  GROUP BY HSP_TP_CD)
            , UNTACT_VIDEO AS (   --비대면 영상 Summary
                 SELECT HSP_TP_CD
                      , SUM(WHL_TELC_CNT)            AS WHL_TELC_CNT
                   FROM HICU.UCOSNFLD A
--                  WHERE TO_DATE(UNTC_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
                     WHERE UNTC_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                    AND HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
                  GROUP BY  HSP_TP_CD
              )
            , RRS AS (    --RRS SUMMARY
                 SELECT SUM(WHL_PT_CNT)        AS WHL_PT_CNT
                      , SUM(OCUR_PT_CNT)       AS OCUR_PT_CNT
                      , SUM(SBP_OCUR_CNT)      AS SBP_OCUR_CNT
                      , SUM(PR_OCUR_CNT)       AS PR_OCUR_CNT
                      , SUM(SPO2_OCUR_CNT)     AS SPO2_OCUR_CNT
                   FROM HICU.UCOSRRSD
--                  WHERE TO_DATE(OCUR_DT, 'YYYY-MM-DD') BETWEEN IN_FROM_DTE  AND IN_TO_DTE
                  WHERE OCUR_DT BETWEEN TO_CHAR(IN_FROM_DTE, 'YYYYMMDD')  AND TO_CHAR(IN_TO_DTE, 'YYYYMMDD')
                    AND HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y')
                      )            
                      
            -- //―2025/ez고도화로 인한 작업―YJR
            , NEWS_SRC AS (
              SELECT
                s.HSP_TP_CD,
                s.ENT_DT,         -- 이미 DATE로 변환된 값
                s.NEWS_NUM
              FROM (
                SELECT
                  r.HSP_TP_CD,
                  CASE
                    WHEN REGEXP_LIKE(TRIM(r.ENT_DT), '^\d{8}$') THEN
                         TO_DATE(TRIM(r.ENT_DT), 'YYYYMMDD')
                    WHEN REGEXP_LIKE(TRIM(r.ENT_DT), '^\d{4}-\d{2}-\d{2}$') THEN
                         TO_DATE(TRIM(r.ENT_DT), 'YYYY-MM-DD')
                    ELSE NULL
                  END AS ENT_DT,
                  CASE
                    WHEN REGEXP_LIKE(TRIM(r.NEWS), '^\d{1,2}([.,]\d)?$') THEN
                         TO_NUMBER(REPLACE(TRIM(r.NEWS), ',', '.'))
                    ELSE NULL
                  END AS NEWS_NUM
                FROM RRS_VALUE r
                UNION ALL
                SELECT
                  r.HSP_TP_CD,
                  CASE
                    WHEN REGEXP_LIKE(TRIM(r.ENT_DT), '^\d{8}$') THEN
                         TO_DATE(TRIM(r.ENT_DT), 'YYYYMMDD')
                    WHEN REGEXP_LIKE(TRIM(r.ENT_DT), '^\d{4}-\d{2}-\d{2}$') THEN
                         TO_DATE(TRIM(r.ENT_DT), 'YYYY-MM-DD')
                    ELSE NULL
                  END AS ENT_DT,
                  CASE
                    WHEN REGEXP_LIKE(TRIM(r.NEWS), '^\d{1,2}([.,]\d)?$') THEN
                         TO_NUMBER(REPLACE(TRIM(r.NEWS), ',', '.'))
                    ELSE NULL
                  END AS NEWS_NUM
                FROM RRS_VALUE_H r
              ) s
              WHERE s.ENT_DT IS NOT NULL
                AND s.ENT_DT BETWEEN TRUNC(IN_FROM_DTE) AND TRUNC(IN_TO_DTE)
            ),
            NEWS_BY_HSP AS (         -- (2) 병원별 평균
              SELECT TRIM(s.HSP_TP_CD) AS HSP_TP_CD,
                     ROUND(AVG(s.NEWS_NUM), 1) AS NEWS_AVG
                FROM NEWS_SRC s
                JOIN HICU.UCCOCHRD chrd
                  ON TRIM(chrd.HSP_TP_CD) = TRIM(s.HSP_TP_CD)
                 AND chrd.USE_YN  = 'Y'
                 AND chrd.EPCN_YN = 'Y'
               WHERE chrd.EPCN_GRP_CD = IN_EPCN_GRP_CD
               GROUP BY TRIM(s.HSP_TP_CD)
            ),
            NEWS_TOTAL AS (      -- (3) 권역 전체 평균
              SELECT ROUND(AVG(s.NEWS_NUM), 1) AS NEWS_AVG
                FROM NEWS_SRC s
                JOIN HICU.UCCOCHRD chrd
                  ON TRIM(chrd.HSP_TP_CD) = TRIM(s.HSP_TP_CD)
                 AND chrd.USE_YN  = 'Y'
                 AND chrd.EPCN_YN = 'Y'
               WHERE chrd.EPCN_GRP_CD = IN_EPCN_GRP_CD
            )
             
                      
             SELECT '01'                                                                     AS LARGE_CATEGORY
                  , CODE                                                                     AS SMALL_CATEGORY
                  , '비대면 협진건수'                                                              AS TITLE
                  , '병동코드'                                                                  AS VALUE01_NAME
                  , 'C'                                                                     AS VALUE01_TYPE
                  , HSP_NM                                                                  AS VALUE01
                  , '발생건수'                                                                   AS VALUE02_NAME
                  , 'D0'                                                                     AS VALUE02_TYPE
                  , NVL(TO_CHAR(WHL_CSLT_CNT), '0')                                          AS VALUE02
                   , ''                                                                       AS VALUE03_NAME
                   , 'C'                                                                      AS VALUE03_TYPE
                  , ''                                                                       AS VALUE03  
               FROM (SELECT '01'                                 AS CODE
                       , '전체'                                AS HSP_NM
                       , SUM(WHL_CSLT_CNT)                    AS WHL_CSLT_CNT
                       , 1                                    AS SORT_SEQ
                    FROM UNTACT_RECORD
                  UNION ALL
                     SELECT '02'                       CODE
                             , A.HSP_NM
                          , NVL(B.WHL_CSLT_CNT, 0)     AS WHL_CSLT_CNT
                             , SORT_SEQ
                       FROM (SELECT CGPM.EPCN_GRP_NM --권역코드
                               , CGPM.EPCN_GRP_CD
                               , CHRD.HSP_TP_CD
                               , CHPM.HSP_NM
                               , CHRD.SORT_SEQ
                            FROM HICU.UCCOCGPM CGPM                                   
                               , HICU.UCCOCHRD CHRD
                               , HICU.UCCOCHPM CHPM
                           WHERE CGPM.EPCN_GRP_CD = IN_EPCN_GRP_CD
                             AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD
                             AND CHRD.HSP_TP_CD = CHPM.HSP_TP_CD
                             AND CHRD.USE_YN = 'Y'
                             AND CGPM.USE_YN = 'Y'
                             AND CHPM.USE_YN = 'Y') A
                          , UNTACT_RECORD B
                      WHERE A.HSP_TP_CD = B.HSP_TP_CD (+)
                        AND A.HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y' AND EPCN_YN = 'Y' )
                      ORDER BY CODE, SORT_SEQ)
             UNION ALL
             SELECT '02'                                                                     AS LARGE_CATEGORY
                  , CODE                                                                     AS SMALL_CATEGORY
                  , '비대면 영상건수'                                                              AS TITLE
                  , '병동코드'                                                                  AS VALUE01_NAME
                  , 'C'                                                                     AS VALUE01_TYPE
                  , HSP_NM                                                                  AS VALUE01
                  , '발생건수'                                                                   AS VALUE02_NAME
                  , 'D0'                                                                     AS VALUE02_TYPE
                  , NVL(TO_CHAR(WHL_TELC_CNT), '0')                                          AS VALUE02   
                   , ''                                                                       AS VALUE03_NAME
                   , 'C'                                                                      AS VALUE03_TYPE
                  , ''                                                                       AS VALUE03  
              FROM (
                     SELECT '01'                                 AS CODE
                       , '전체'                                AS HSP_NM
                       , SUM(WHL_TELC_CNT)                    AS WHL_TELC_CNT
                       , 1                                    AS SORT_SEQ
                    FROM UNTACT_VIDEO
                  UNION ALL
                     SELECT '02'                       CODE
                             , A.HSP_NM
                          , NVL(B.WHL_TELC_CNT, 0)     AS WHL_TELC_CNT
                             , SORT_SEQ
                       FROM (SELECT CGPM.EPCN_GRP_NM --권역코드
                               , CGPM.EPCN_GRP_CD
                               , CHRD.HSP_TP_CD
                               , CHPM.HSP_NM
                               , CHRD.SORT_SEQ
                            FROM HICU.UCCOCGPM CGPM                                   
                               , HICU.UCCOCHRD CHRD
                               , HICU.UCCOCHPM CHPM
                           WHERE CGPM.EPCN_GRP_CD = IN_EPCN_GRP_CD
                             AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD
                             AND CHRD.HSP_TP_CD = CHPM.HSP_TP_CD
                             AND CHRD.USE_YN = 'Y'
                             AND CGPM.USE_YN = 'Y'
                             AND CHPM.USE_YN = 'Y') A
                          , UNTACT_VIDEO B
                      WHERE A.HSP_TP_CD = B.HSP_TP_CD (+)
                        AND A.HSP_TP_CD IN (SELECT HSP_TP_CD FROM HICU.UCCOCHRD WHERE EPCN_GRP_CD = IN_EPCN_GRP_CD AND USE_YN = 'Y' AND EPCN_YN = 'Y' )
                      ORDER BY CODE, SORT_SEQ)
             UNION ALL
             SELECT '03'                                                                       AS LARGE_CATEGORY
                  , '01'                                                                       AS SMALL_CATEGORY
                  , 'RRS-발생연환자수'                                                              AS TITLE
                  , '전체건수'                                                                   AS VALUE01_NAME
                  , 'D0'                                                                        AS VALUE01_TYPE
                  , NVL(TO_CHAR(WHL_PT_CNT), '0')                                              AS VALUE01
                  , '발생건수'                                                                  AS VALUE02_NAME
                  , 'D0'                                                                       AS VALUE02_TYPE
                  , NVL(TO_CHAR(OCUR_PT_CNT), '0')                                             AS VALUE02
                   , '발생률(%)'                                                               AS VALUE03_NAME
                   , 'C'                                                                      AS VALUE03_TYPE
                  , nvl(TRIM(TO_CHAR((DECODE(OCUR_PT_CNT,NULL,0,OCUR_PT_CNT) /DECODE(WHL_PT_CNT,0,NULL,WHL_PT_CNT))*100,'99990.9')), '0')   VALUE03  --병상가동률
               FROM RRS
              UNION ALL
             SELECT '03'                                                                       AS LARGE_CATEGORY
                  , '02'                                                                       AS SMALL_CATEGORY
                  , 'RRS-발생건수'                                                              AS TITLE
                  , COMN_CD_NM                                                                   AS VALUE01_NAME
                  , 'D0'                                                                        AS VALUE01_TYPE
                  , NVL(TO_CHAR(COUNT), '0')                                                    AS VALUE01
                  , '발생건수'                                                                  AS VALUE02_NAME
                  , 'D0'                                                                       AS VALUE02_TYPE
                  , ''                                                                        AS VALUE02     
                   , ''                                                                       AS VALUE03_NAME
                   , 'C'                                                                      AS VALUE03_TYPE
                  , ''                                                                       AS VALUE03  
              FROM (
                      SELECT A.COMN_CD_NM
                           , B.COUNT
                        FROM HICU.UCCOCSTE A
                           , (SELECT DECODE(CNT, 1, '01', 2, '02', 3, '03') COMN_CD
                                   , DECODE(CNT, 1, SBP_OCUR_CNT,
                                                 2, PR_OCUR_CNT,
                                                 3, SPO2_OCUR_CNT)          COUNT
                               FROM (
                                       SELECT SUM(SBP_OCUR_CNT)   AS SBP_OCUR_CNT
                                            , SUM(PR_OCUR_CNT)    AS PR_OCUR_CNT
                                            , SUM(SPO2_OCUR_CNT)  AS SPO2_OCUR_CNT
                                         FROM RRS)
                                 , (SELECT LEVEL CNT FROM DUAL CONNECT BY LEVEL <4)) B
                       WHERE A.COMN_CD =  B.COMN_CD(+)
                         AND A.USE_YN = 'Y'
                         AND A.COMN_GRP_CD = 'IC019'
                       ORDER BY A.SORT_SEQ) 
                       
            -- //―2025/ez고도화로 인한 작업―YJR LARGE_CATEGORY 04, 05 추가 (병상가동율, NEWS) 
                  UNION ALL
            SELECT '04'                                   AS LARGE_CATEGORY
                 , '01'                                   AS SMALL_CATEGORY
                 , '병상가동율'                            AS TITLE
                 , '병동코드'                              AS VALUE01_NAME
                 , 'C'                                    AS VALUE01_TYPE
                 , HSP_NM                                 AS VALUE01
                 , '총 병상'                              AS VALUE02_NAME
                 , 'D0'                                   AS VALUE02_TYPE
                 , NVL(TO_CHAR(TOT_WD_CNT), '0')          AS VALUE02     
                 , '입원 환자'                            AS VALUE03_NAME
                 , 'D0'                                   AS VALUE03_TYPE
                 , NVL(TO_CHAR(IN_CNT), '0')              AS VALUE03
            FROM (
                SELECT '01'            AS CODE
                     , '전체'          AS HSP_NM
                     , SUM(v.TOT_WD_CNT) AS TOT_WD_CNT
                     , SUM(v.IN_CNT)      AS IN_CNT
                     , 1               AS SORT_SEQ
                FROM xicu.EMNI001V v
                JOIN HICU.UCCOCHRD chrd
                  ON chrd.HSP_TP_CD = v.HSP_CD
                WHERE chrd.EPCN_GRP_CD = IN_EPCN_GRP_CD
                  AND chrd.USE_YN = 'Y'
                  AND chrd.EPCN_YN = 'Y'
            
                UNION ALL
            
                SELECT '02'                    AS CODE
                     , a.HSP_NM                AS HSP_NM
                     , NVL(v.TOT_WD_CNT, 0)    AS TOT_WD_CNT
                     , NVL(v.IN_CNT, 0)        AS IN_CNT
                     , a.SORT_SEQ              AS SORT_SEQ
                FROM (
                    SELECT CGPM.EPCN_GRP_NM
                         , CGPM.EPCN_GRP_CD
                         , CHRD.HSP_TP_CD
                         , CHPM.HSP_NM
                         , CHRD.SORT_SEQ
                    FROM HICU.UCCOCGPM CGPM
                    JOIN HICU.UCCOCHRD CHRD
                      ON CHRD.EPCN_GRP_CD = CGPM.EPCN_GRP_CD
                    JOIN HICU.UCCOCHPM CHPM
                      ON CHPM.HSP_TP_CD = CHRD.HSP_TP_CD
                    WHERE CGPM.EPCN_GRP_CD = IN_EPCN_GRP_CD
                      AND CHRD.USE_YN = 'Y'
                      AND CGPM.USE_YN = 'Y'
                      AND CHPM.USE_YN = 'Y'
                      AND CHRD.EPCN_YN = 'Y'
                ) a
                LEFT JOIN xicu.EMNI001V v
                  ON v.HSP_CD = a.HSP_TP_CD
            ) t        
            
                   UNION ALL
               SELECT '05'                                   AS LARGE_CATEGORY
                    , '01'                                   AS SMALL_CATEGORY
                    , 'NEWS 평균'                             AS TITLE
                    , '병동코드'                              AS VALUE01_NAME
                    , 'C'                                     AS VALUE01_TYPE
                    , HSP_NM                                  AS VALUE01
                    , 'NEWS 평균'                              AS VALUE02_NAME
                    , 'D0'                                    AS VALUE02_TYPE
                    , TO_CHAR(NVL(NEWS_AVG, 0), 'FM9990D0')   AS VALUE02
                    , ''                                      AS VALUE03_NAME
                    , 'C'                                     AS VALUE03_TYPE
                    , ''                                      AS VALUE03
               FROM (
                 SELECT '01' AS CODE,
                        '전체' AS HSP_NM,
                        COALESCE(
                          (SELECT NEWS_AVG FROM NEWS_TOTAL),                       -- 1) 권역 평균
                          (SELECT ROUND(AVG(s.NEWS_NUM),1) FROM NEWS_SRC s)        -- 2) 기간 전체 평균
                        ) AS NEWS_AVG,
                        1 AS SORT_SEQ
                 FROM DUAL
               
                 UNION ALL
               
                 SELECT '02',
                        a.HSP_NM,
                        COALESCE(
                          n.NEWS_AVG,                                              -- 1) 병원별 평균
                          (SELECT NEWS_AVG FROM NEWS_TOTAL),                       -- 2) 권역 평균
                          (SELECT ROUND(AVG(s.NEWS_NUM),1) FROM NEWS_SRC s)        -- 3) 기간 전체 평균
                        ) AS NEWS_AVG,
                        a.SORT_SEQ
                 FROM (
                       SELECT
                              CGPM.EPCN_GRP_NM,
                              CGPM.EPCN_GRP_CD,
                              CHRD.HSP_TP_CD,
                              CHPM.HSP_NM,
                              CHRD.SORT_SEQ
                       FROM HICU.UCCOCGPM CGPM,
                            HICU.UCCOCHRD CHRD,
                            HICU.UCCOCHPM CHPM
                       WHERE CGPM.EPCN_GRP_CD = IN_EPCN_GRP_CD
                         AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD
                         AND CHRD.HSP_TP_CD = CHPM.HSP_TP_CD
                         AND CHRD.USE_YN = 'Y'
                         AND CGPM.USE_YN = 'Y'
                         AND CHPM.USE_YN = 'Y'
                         AND CHRD.EPCN_YN = 'Y'
                      ) a
                 LEFT JOIN NEWS_BY_HSP n
                   ON TRIM(n.HSP_TP_CD) = TRIM(a.HSP_TP_CD)
               ) t
                     ;
                 END;

END PC_EICU_REGION_MANAGE_SUMMARY;
