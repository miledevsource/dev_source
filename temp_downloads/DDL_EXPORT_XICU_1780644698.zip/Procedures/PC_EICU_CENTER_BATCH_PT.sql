
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_BATCH_PT" (                     IN_FROM_DTM         IN DATE
                                                              , IN_TO_DTM           IN DATE
                                                              , IN_HSP_TP_CD        IN VARCHAR2
                                                              , IO_ERRYN            IN OUT  VARCHAR2    --  ERROR Y/N
                                                              , IO_ERRMSG           IN OUT  VARCHAR2   --  ERROR MESSAGE    
                                                            )
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_BATCH_PT
*    CREATEDATE     : 2021.02.22
*    Author         : 한가혜
*    Description    : 통합관제 임상지표 중환자실 환자현황 데이터 일마감 배치 
*    Change History : 
**********************************************************************************************/    

AS
    V_CURSOR          SYS_REFCURSOR;   
    
    V_COMN_GRP_CD	  VARCHAR2(50);
    V_COMN_CD	      VARCHAR2(50);
    V_COMN_CD_NM	  VARCHAR2(50);
    V_COMN_CD_EXPL	  VARCHAR2(100);
    V_DTRL1_NM	      VARCHAR2(50);
    V_DTRL2_NM	      VARCHAR2(50); 
    V_DTRL4_NM		  VARCHAR2(50);
    V_DTRL5_NM		  VARCHAR2(50);
    
    N_DAYCNT          NUMBER := 0;
    V_SEARCH_DT       DATE   := TRUNC(IN_FROM_DTM);       --조회 날짜 
    
    V_HLDY_YN         VARCHAR(2) := 'N'; --휴일 여부
    
BEGIN 
     N_DAYCNT := TRUNC(IN_TO_DTM) - TRUNC(IN_FROM_DTM) + 1; --조회 기간  
     
     BEGIN 
       FOR I IN 1..N_DAYCNT LOOP 
    
    /*******************************************
     * 병원 별 중환자실 코드 조회
     * 운영 지표 조회
     *******************************************/ 
    DECLARE CURSOR DEPT_CD_CURSOR IS          SELECT X.DEPT_CD        AS WD_DEPT_CD
                                                   , X.RMK_CNTE       AS WD_DEPT_CD_NM
                                                FROM HICU.UCCOCDPM X   --U111_UCCO(설정)_부서기본
                                               WHERE HSP_TP_CD        = IN_HSP_TP_CD
                                            ORDER BY SORT_SEQ 
                                            ;   
         
         REC  DEPT_CD_CURSOR%ROWTYPE;          
         
         BEGIN  
              OPEN DEPT_CD_CURSOR;                             
              LOOP FETCH DEPT_CD_CURSOR INTO REC;
              EXIT WHEN DEPT_CD_CURSOR%NOTFOUND; 
              
                  BEGIN  --운영지표조회
                         XICU.PC_EICU_PT_STATISTICS (  V_SEARCH_DT         --IN_FROM_DT
                                                     , V_SEARCH_DT         --IN_TO_DT
                                                     , REC.WD_DEPT_CD      
                                                     , IN_HSP_TP_CD      --IN_HSP_TP_CD
                                                     , V_CURSOR          --SYS_REFCURSOR
                                                     );
                    END; 
                    
                   BEGIN
                        LOOP
                        FETCH V_CURSOR INTO V_COMN_GRP_CD
                                          , V_COMN_CD 
                                          , V_COMN_CD_NM 
                                          , V_COMN_CD_EXPL 
                                          , V_DTRL1_NM 
                                          , V_DTRL2_NM 
                                          , V_DTRL4_NM 
                                          , V_DTRL5_NM 
                                          ;  
                        EXIT WHEN V_CURSOR%NOTFOUND;
                          
                        IF V_COMN_GRP_CD != 'MED_DEPT_TYPE' THEN
                           
                        BEGIN
                             SELECT A.HLDY_YN
                               INTO V_HLDY_YN 
                               FROM HICU.UICIIRHD A--U121_UICI(ODS)_휴일정보
                              WHERE A.DT_CD = V_SEARCH_DT
                              ;
                          END;
                         /********************************************
                         * 통합중환자실환자지표기본(UCCICSPM)  BATCH
                         **********************************************/ 
                          BEGIN
                                 --UPDATE OR INSERT   
                                 MERGE INTO HICU.UCCICSPM A  --통합중환자실환자지표기본
                                          USING DUAL
                                             ON (
                                                 A.WD_DEPT_CD		= V_DTRL4_NM    --병동부서코드(pk)
                                             AND A.ETRM_DT_SEQ      = V_DTRL5_NM    --입실일자번호(pk) 
                                             AND A.HSP_TP_CD        = IN_HSP_TP_CD
                                                 )   
                                                  
                                           WHEN MATCHED THEN
                                         UPDATE 
                                            SET  A.WD_DEPT_CD_NM = REC.WD_DEPT_CD_NM
                                               , A.HLDY_YN   = V_HLDY_YN --휴일 여부
                                               , A.YY_PT_CNT = DECODE(V_COMN_CD, 'YY_PT_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.YY_PT_CNT, 0)) --연환자수
                                               , A.YY_BED_CNT = DECODE(V_COMN_CD, 'YY_BED_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.YY_BED_CNT, 0)) --연병상수
                                               , A.ETRM_PT_CNT = DECODE(V_COMN_CD, 'ETRM_PT_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.ETRM_PT_CNT, 0))--입실환자수
                                               , A.SIRM_PT_CNT = DECODE(V_COMN_CD, 'SIRM_PT_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_PT_CNT, 0))--재실환자수
                                               --, A.SIRM_DYS_AVG_VAL = DECODE(V_COMN_CD, 'SIRM_DYS_AVG_VAL', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_DYS_AVG_VAL, 0))--재실일수평균값
                                               , A.SEX_MALE_CNT = DECODE(V_COMN_CD, 'SEX_MALE_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SEX_MALE_CNT, 0))--성별남수
                                               , A.SEX_FEML_CNT = DECODE(V_COMN_CD, 'SEX_FEML_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SEX_FEML_CNT, 0))--성별여수
                                               , A.AGE_10_GRP_BLW_CNT = DECODE(V_COMN_CD, 'AGE_10_GRP_BLW_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_10_GRP_BLW_CNT, 0))--연령10대이하수
                                               , A.AGE_20_GRP_CNT = DECODE(V_COMN_CD, 'AGE_20_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_20_GRP_CNT, 0))--연령20대수
                                               , A.AGE_30_GRP_CNT = DECODE(V_COMN_CD, 'AGE_30_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_30_GRP_CNT, 0))--연령30대수
                                               , A.AGE_40_GRP_CNT = DECODE(V_COMN_CD, 'AGE_40_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_40_GRP_CNT, 0))--연령40대수
                                               , A.AGE_50_GRP_CNT = DECODE(V_COMN_CD, 'AGE_50_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_50_GRP_CNT, 0))--연령50대수
                                               , A.AGE_60_GRP_CNT = DECODE(V_COMN_CD, 'AGE_60_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_60_GRP_CNT, 0))--연령60대수
                                               , A.AGE_70_GRP_UPR_CNT = DECODE(V_COMN_CD, 'AGE_70_GRP_UPR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGE_70_GRP_UPR_CNT, 0))--연령70대이상수
                                               , A.PT_SILLM_CTG_1_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_1_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_1_GRP_CNT, 0))--환자중증도분류그룹1군수
                                               , A.PT_SILLM_CTG_2_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_2_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_2_GRP_CNT, 0))--환자중증도분류그룹2군수
                                               , A.PT_SILLM_CTG_3_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_3_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_3_GRP_CNT, 0))--환자중증도분류그룹3군수
                                               , A.PT_SILLM_CTG_4_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_4_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_4_GRP_CNT, 0))--환자중증도분류그룹4군수
                                               , A.PT_SILLM_CTG_5_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_5_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_5_GRP_CNT, 0))--환자중증도분류그룹5군수
                                               , A.PT_SILLM_CTG_6_GRP_CNT = DECODE(V_COMN_CD, 'PT_SILLM_CTG_6_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.PT_SILLM_CTG_6_GRP_CNT, 0))--환자중증도분류그룹6군수
                                               , A.APCS_SUM_10_SCR_BLW_CNT = DECODE(V_COMN_CD, 'APCS_SUM_10_SCR_BLW_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_10_SCR_BLW_CNT, 0))--아파치스코어합계점수10점이하수
                                               , A.APCS_SUM_20_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_20_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_20_SCR_CNT, 0))--아파치스코어합계점수20점수
                                               , A.APCS_SUM_30_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_30_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_30_SCR_CNT, 0))--아파치스코어합계점수30점수
                                               , A.APCS_SUM_40_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_40_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_40_SCR_CNT, 0))--아파치스코어합계점수40점수
                                               , A.APCS_SUM_50_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_50_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_50_SCR_CNT, 0))--아파치스코어합계점수50점수
                                               , A.APCS_SUM_60_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_60_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_60_SCR_CNT, 0))--아파치스코어합계점수60점수
                                               , A.APCS_SUM_70_SCR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_70_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_70_SCR_CNT, 0))--아파치스코어합계점수70점수
                                               , A.APCS_SUM_80_SCR_UPR_CNT = DECODE(V_COMN_CD, 'APCS_SUM_80_SCR_UPR_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.APCS_SUM_80_SCR_UPR_CNT, 0))--아파치스코어합계점수80점이상수
                                               , A.SIRM_6_TM_IN_CNT = DECODE(V_COMN_CD, 'SIRM_6_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_6_TM_IN_CNT, 0))--재실시간6시간이내수
                                               , A.SIRM_12_TM_IN_CNT = DECODE(V_COMN_CD, 'SIRM_12_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_12_TM_IN_CNT, 0))--재실시간12시간이내수
                                               , A.SIRM_18_TM_IN_CNT = DECODE(V_COMN_CD, 'SIRM_18_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_18_TM_IN_CNT, 0))--재실시간18시간이내수
                                               , A.SIRM_24_TM_IN_CNT = DECODE(V_COMN_CD, 'SIRM_24_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_24_TM_IN_CNT, 0))--재실시간24시간이내수
                                               , A.SIRM_48_TM_IN_CNT = DECODE(V_COMN_CD, 'SIRM_48_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_48_TM_IN_CNT, 0))--재실시간48시간이내수
                                               , A.SIRM_48_TM_EXCS_CNT = DECODE(V_COMN_CD, 'SIRM_48_TM_EXCS_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.SIRM_48_TM_EXCS_CNT, 0))--재실시간48시간초과수
                                               , A.AGPY_AOM_CNT        = DECODE(V_COMN_CD, 'AGPY_AOM_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGPY_AOM_CNT, 0))   --혈관조영시술수
                                               , A.AGPY_AOM_EMRG_CNT   = DECODE(V_COMN_CD, 'AGPY_AOM_EMRG_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.AGPY_AOM_EMRG_CNT, 0))   --혈관조영시술응급수
                                               , A.LOD_DTM = SYSDATE--적재일시
                                               , A.CHOT_PT_CNT         = DECODE(V_COMN_CD, 'CHOT_PT_CNT', TO_NUMBER(V_DTRL1_NM), NVL(A.CHOT_PT_CNT, 0))  --퇴실환자수
                                               , A.WHL_SIRM_DYS        = DECODE(V_COMN_CD, 'WHL_SIRM_DYS', TO_NUMBER(V_DTRL1_NM), NVL(A.WHL_SIRM_DYS, 0))--전체재실일수
                                          
                                           --최초적재
                                           WHEN NOT MATCHED THEN
                                         INSERT(
                                                     A.WD_DEPT_CD								--병동부서코드(pk)
                                                   , A.ETRM_DT_SEQ								--입실일자번호(pk)
                                                   , A.HSP_TP_CD									--병원코드(pk)
                                                   , A.WD_DEPT_CD_NM								--병동부서코드명
                                                   , A.ETRM_YY									--입실년도
                                                   , A.ETRM_MM									--입실월
                                                   , A.ETRM_DY									--입실일
                                                   , A.HLDY_YN									--휴일여부
                                                   , A.YY_PT_CNT									--연환자수
                                                   , A.YY_BED_CNT								--연병상수
                                                   , A.ETRM_PT_CNT								--입실환자수
                                                   , A.SIRM_PT_CNT								--재실환자수
                                                   , A.SEX_MALE_CNT								--성별남수
                                                   , A.SEX_FEML_CNT								--성별여수
                                                   , A.AGE_10_GRP_BLW_CNT						--연령10대이하수
                                                   , A.AGE_20_GRP_CNT							--연령20대수
                                                   , A.AGE_30_GRP_CNT							--연령30대수
                                                   , A.AGE_40_GRP_CNT							--연령40대수
                                                   , A.AGE_50_GRP_CNT							--연령50대수
                                                   , A.AGE_60_GRP_CNT							--연령60대수
                                                   , A.AGE_70_GRP_UPR_CNT						--연령70대이상수
                                                   , A.PT_SILLM_CTG_1_GRP_CNT					--환자중증도분류그룹1군수
                                                   , A.PT_SILLM_CTG_2_GRP_CNT					--환자중증도분류그룹2군수
                                                   , A.PT_SILLM_CTG_3_GRP_CNT					--환자중증도분류그룹3군수
                                                   , A.PT_SILLM_CTG_4_GRP_CNT					--환자중증도분류그룹4군수
                                                   , A.PT_SILLM_CTG_5_GRP_CNT					--환자중증도분류그룹5군수
                                                   , A.PT_SILLM_CTG_6_GRP_CNT					--환자중증도분류그룹6군수
                                                   , A.APCS_SUM_10_SCR_BLW_CNT					--아파치스코어합계점수10점이하수
                                                   , A.APCS_SUM_20_SCR_CNT						--아파치스코어합계점수20점수
                                                   , A.APCS_SUM_30_SCR_CNT						--아파치스코어합계점수30점수
                                                   , A.APCS_SUM_40_SCR_CNT						--아파치스코어합계점수40점수
                                                   , A.APCS_SUM_50_SCR_CNT						--아파치스코어합계점수50점수
                                                   , A.APCS_SUM_60_SCR_CNT						--아파치스코어합계점수60점수
                                                   , A.APCS_SUM_70_SCR_CNT						--아파치스코어합계점수70점수
                                                   , A.APCS_SUM_80_SCR_UPR_CNT					--아파치스코어합계점수80점이상수
                                                   , A.SIRM_6_TM_IN_CNT							--재실시간6시간이내수
                                                   , A.SIRM_12_TM_IN_CNT							--재실시간12시간이내수
                                                   , A.SIRM_18_TM_IN_CNT							--재실시간18시간이내수
                                                   , A.SIRM_24_TM_IN_CNT							--재실시간24시간이내수
                                                   , A.SIRM_48_TM_IN_CNT							--재실시간48시간이내수
                                                   , A.SIRM_48_TM_EXCS_CNT						--재실시간48시간초과수
                                                   , A.AGPY_AOM_CNT								--혈관조영시술수
                                                   , A.AGPY_AOM_EMRG_CNT							--혈관조영시술응급수
                                                   , A.LOD_DTM									--적재일시
                                                   , A.CHOT_PT_CNT  --퇴실환자수
                                                   , A.WHL_SIRM_DYS --전체재실일수
                                         )
                                         VALUES(
                                                     REC.WD_DEPT_CD                                --병동부서코드(pk)
                                                   , V_DTRL5_NM         --입실일자번호(pk)
                                                   , IN_HSP_TP_CD                                 --병원코드(pk)
                                                   , REC.WD_DEPT_CD_NM                                --병동부서코드명
                                                   , TO_CHAR(V_SEARCH_DT, 'YYYY')              --입실년도
                                                   , TO_CHAR(V_SEARCH_DT, 'MM')                --입실월
                                                   , TO_CHAR(V_SEARCH_DT, 'DD')                --입실일
                                                   , V_HLDY_YN                                          --휴일여부
                                                   , DECODE(V_COMN_CD, 'YY_PT_CNT', TO_NUMBER(V_DTRL1_NM), NULL) --연환자수
                                                   , DECODE(V_COMN_CD, 'YY_BED_CNT', TO_NUMBER(V_DTRL1_NM), NULL) --연병상수
                                                   , DECODE(V_COMN_CD, 'ETRM_PT_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--입실환자수
                                                   , DECODE(V_COMN_CD, 'SIRM_PT_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실환자수
                                                   , DECODE(V_COMN_CD, 'SEX_MALE_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--성별남수
                                                   , DECODE(V_COMN_CD, 'SEX_FEML_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--성별여수
                                                   , DECODE(V_COMN_CD, 'AGE_10_GRP_BLW_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령10대이하수
                                                   , DECODE(V_COMN_CD, 'AGE_20_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령20대수
                                                   , DECODE(V_COMN_CD, 'AGE_30_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령30대수
                                                   , DECODE(V_COMN_CD, 'AGE_40_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령40대수
                                                   , DECODE(V_COMN_CD, 'AGE_50_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령50대수
                                                   , DECODE(V_COMN_CD, 'AGE_60_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령60대수
                                                   , DECODE(V_COMN_CD, 'AGE_70_GRP_UPR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--연령70대이상수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_1_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹1군수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_2_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹2군수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_3_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹3군수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_4_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹4군수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_5_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹5군수
                                                   , DECODE(V_COMN_CD, 'PT_SILLM_CTG_6_GRP_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--환자중증도분류그룹6군수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_10_SCR_BLW_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수10점이하수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_20_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수20점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_30_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수30점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_40_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수40점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_50_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수50점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_60_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수60점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_70_SCR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수70점수
                                                   , DECODE(V_COMN_CD, 'APCS_SUM_80_SCR_UPR_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--아파치스코어합계점수80점이상수
                                                   , DECODE(V_COMN_CD, 'SIRM_6_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간6시간이내수
                                                   , DECODE(V_COMN_CD, 'SIRM_12_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간12시간이내수
                                                   , DECODE(V_COMN_CD, 'SIRM_18_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간18시간이내수
                                                   , DECODE(V_COMN_CD, 'SIRM_24_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간24시간이내수
                                                   , DECODE(V_COMN_CD, 'SIRM_48_TM_IN_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간48시간이내수
                                                   , DECODE(V_COMN_CD, 'SIRM_48_TM_EXCS_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--재실시간48시간초과수
                                                   , DECODE(V_COMN_CD, 'AGPY_AOM_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--혈관조영시술수
                                                   , DECODE(V_COMN_CD, 'AGPY_AOM_EMRG_CNT', TO_NUMBER(V_DTRL1_NM), NULL)--혈관조영시술응급수
                                                   , SYSDATE--적재일시 
                                                   , DECODE(V_COMN_CD, 'CHOT_PT_CNT', TO_NUMBER(V_DTRL1_NM), NULL)  --퇴실환자수
                                                   , DECODE(V_COMN_CD, 'WHL_SIRM_DYS', TO_NUMBER(V_DTRL1_NM), NULL) --전체재실일수
                                         );
                                         
                           EXCEPTION
                		        WHEN OTHERS THEN
                		            IO_ERRYN  := 'Y';
                		            IO_ERRMSG := '(XICU.PC_EICU_CENTER_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || 'MERGE INTO HICU.UCCICSPM :' || TO_CHAR(V_SEARCH_DT, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
                		            RETURN ;
                		            
                            END; --통합중환자실환자지표기본(UCCICSPM)  BATCH END                                     
                         
                     ELSE 
                         /***************************************************
                         * 통합중환자실환자지표진료과정보(UCCICSPD)  BATCH
                         ****************************************************/
                          BEGIN
                                  MERGE INTO HICU.UCCICSPD A  --통합중환자실환자지표진료과정보  
                                  USING DUAL
                                     ON (
                                         A.WD_DEPT_CD		= V_DTRL4_NM    --병동부서코드(pk)
                                     AND A.ETRM_DT_SEQ      = V_DTRL5_NM    --입실일자번호(pk) 
                                     AND A.HSP_TP_CD        = IN_HSP_TP_CD
                                     AND A.RPRN_MED_DEPT_CD = V_COMN_CD     --대표진료부서코드(pk)
                                         )   
                                          
                                   WHEN MATCHED THEN
                                 UPDATE 
                                    SET A.RPRN_MED_DEPT_CD_NM = V_COMN_CD_NM
                                      , A.SIRM_PT_CNT         = TO_NUMBER(NVL(V_DTRL1_NM, A.SIRM_PT_CNT))
                                      , A.LOD_DTM             = SYSDATE
                                   
                                   --최초적재 
                                   WHEN NOT MATCHED THEN
                                 INSERT(  A.WD_DEPT_CD            --병동부서코드(pk)
                                        , A.ETRM_DT_SEQ           --입실일자번호(pk)
                                        , A.RPRN_MED_DEPT_CD      --대표진료부서코드(pk)
                                        , A.HSP_TP_CD             --병원코드(pk)
                                        , A.RPRN_MED_DEPT_CD_NM   --대표진료부서코드명
                                        , A.SIRM_PT_CNT           --재실환자수
                                        , A.LOD_DTM               --적재일시
                                      )
                                 VALUES( REC.WD_DEPT_CD
                                       , V_DTRL5_NM 
                                       , V_COMN_CD
                                       , IN_HSP_TP_CD
                                       , V_COMN_CD_NM
                                       , TO_NUMBER(NVL(V_DTRL1_NM, '0'))
                                       , SYSDATE                                              
                                      );
                                      
                           EXCEPTION
                		        WHEN OTHERS THEN
                		            IO_ERRYN  := 'Y';
                		            IO_ERRMSG := '(XICU.PC_EICU_CENTER_BATCH_PT): HSP_TP_CD = '|| IN_HSP_TP_CD || 'MERGE INTO HICU.UCCICSPD :' || TO_CHAR(V_SEARCH_DT, 'YYYY-MM-DD') || ', ERRCODE = '|| TO_CHAR(SQLCODE) || ', ERR MESSAGE = ' || SQLERRM;
                		            RETURN ;
                                  
                            END; --통합중환자실환자지표진료과정보(UCCICSPD)  BATCH  END    
                        END IF; 
                            
                        END LOOP;  --임상지표 조회
                        COMMIT;       
                      END;  --MERGE INTO USING 절                       
                      
     END LOOP; --중환자실 코드 별 조회 
     CLOSE DEPT_CD_CURSOR;
     END;
     
           V_SEARCH_DT := V_SEARCH_DT + 1;
    END LOOP;
    END; 
END PC_EICU_CENTER_BATCH_PT;
