
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_SELECT_MENULIST" 
                          ( IN_HSP_TP_CD  IN  VARCHAR2       /*병원코드 */
                          , OUT_CURSOR OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_SELECT_MENULIST
*    CREATEDATE     : 2021.01.12
*    Author         : 이창우
*    Description    : 로그인 사용자가 사용할 수 있는 병원공통 메뉴를 조회한다.
*    Change History : 
**********************************************************************************************/
BEGIN
  BEGIN
    OPEN OUT_CURSOR FOR
         SELECT CUCD.STCI_STU_NO
              , CUCD.OWN_IFY_NO 
              , CUCD.WD_DEPT_CD 
              , CUSE.STCI_CD 
              , CSTM.PRGM_SCLS_CD 
              , CSTM.USR_SCR_NM  
              , CSTM.UI_PATH_NM
              , CSTE.COMN_CD_NM
           FROM HICU.UCCOCUCD CUCD  --통계지표설정정보
              , HICU.UCCOCUSE CUSE  --통계지표설정상세
              , HICU.UCCOCSTM CSTM  --통계지표기본
              , HICU.UCCOCSTE CSTE  --공통그룹코드상세
          WHERE CUCD.HSP_TP_CD = IN_HSP_TP_CD
            AND CUCD.USE_YN = 'Y'
            AND CUCD.MENU_USE_TP = '02' --메뉴사용구분 IC001 : 02/ICU운영
            AND CUCD.OWN_IFY_TP_CD = '1'
            AND CUSE.HSP_TP_CD = IN_HSP_TP_CD
            AND CUSE.USE_YN = 'Y'
            AND CSTM.HSP_TP_CD = IN_HSP_TP_CD
            AND CSTM.USE_YN = 'Y'
            AND SYSDATE BETWEEN CSTM.AVL_STR_DTM AND CSTM.AVL_END_DTM 
            AND CSTE.HSP_TP_CD = IN_HSP_TP_CD
            AND CSTE.USE_YN = 'Y'
            AND CSTE.COMN_GRP_CD = 'IC003'
            AND CUCD.HSP_TP_CD = CUSE.HSP_TP_CD
            AND CUCD.STCI_STU_NO = CUSE.STCI_STU_NO 
            AND CUSE.STCI_CD = CSTM.STCI_CD
            AND CSTM.PRGM_SCLS_CD = CSTE.COMN_CD
          ORDER BY CSTE.SORT_SEQ, CUSE.SORT_SEQ ;

/*    
    
         SELECT CUCD.STCI_STU_NO
              , CUCD.OWN_IFY_NO 
              , CUCD.WD_DEPT_CD 
              , MENUINF.STCI_CD 
              , MENUINF.PRGM_SCLS_CD 
              , MENUINF.USR_SCR_NM  
              , MENUINF.UI_PATH_NM
              , CSTE.COMN_CD_NM
           FROM UCCOCUCD CUCD --통계지표설정정보
              , (
                 SELECT CUSE.STCI_STU_NO, CUSE.PRGM_SCLS_CD, CUSE.STCI_GRP_CD STCI_CD, MAX(CSTM.USR_SCR_NM) USR_SCR_NM,
                        SUBSTR(       
                               XMLAGG(
                                      XMLELEMENT(COL, ',', CUSE.RPRN_DEPT_CD||':'||CSTM.UI_PATH_NM) ORDER BY CUSE.SORT_SEQ 
                                     ).EXTRACT('//text()').GETSTRINGVAL()
                              , 2) UI_PATH_NM 
                   FROM UCCOCUSE CUSE --통계지표설정상세
                      , UCCOCSTM CSTM --통계지표기본
                  WHERE CUSE.HSP_TP_CD = IN_HSP_TP_CD
                    AND CUSE.USE_YN = 'Y'
                    AND CSTM.USE_YN = 'Y'
                    AND SYSDATE BETWEEN CSTM.AVL_STR_DTM AND CSTM.AVL_END_DTM
                    AND CUSE.STCI_CD = CSTM.STCI_CD
                  GROUP BY CUSE.STCI_STU_NO, CUSE.PRGM_SCLS_CD, CUSE.STCI_GRP_CD
                ) MENUINF
              , UCCOCSTE CSTE  --공통그룹코드상세
          WHERE CUCD.HSP_TP_CD = IN_HSP_TP_CD
            AND CUCD.USE_YN = 'Y'
            AND CUCD.OWN_IFY_TP_CD = '1'
            AND CUCD.STCI_STU_NO = MENUINF.STCI_STU_NO
            AND CSTE.COMN_GRP_CD = 'IC003'
            AND MENUINF.PRGM_SCLS_CD = CSTE.COMN_CD
          ORDER BY CSTE.SORT_SEQ;
         ;*/
  END;
END PC_EICU_SELECT_MENULIST;
