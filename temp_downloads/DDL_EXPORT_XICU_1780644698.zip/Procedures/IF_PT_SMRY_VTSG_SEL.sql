
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."IF_PT_SMRY_VTSG_SEL" ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN  VARCHAR2
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
	 SELECT
        S.HSP_NM,
        A.PT_NM,
        S.VITAL_SIGN_TIME,
				S.SBP,
				S.DBP,
				S.PR,
				S.RR,
				S.BT
    FROM PT_SMRY_VTSG_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE 1=1
      AND A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.SEQ       = IN_SEQ
      AND A.PT_NO  = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.VITAL_SIGN_TIME >= (
        SELECT MAX(VITAL_SIGN_TIME)
        FROM PT_SMRY_VTSG_SEL
        ) - 3
      
    ORDER BY VITAL_SIGN_TIME DESC;
END;
