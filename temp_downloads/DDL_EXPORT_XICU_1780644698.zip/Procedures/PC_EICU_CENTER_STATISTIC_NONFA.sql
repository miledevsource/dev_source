
  CREATE OR REPLACE EDITIONABLE PROCEDURE "XICU"."PC_EICU_CENTER_STATISTIC_NONFA" 
                          ( IN_FROM_DT        IN  DATE
                          , IN_TO_DT          IN  DATE
                          , IN_HIS_HSP_TP_CD  IN  VARCHAR2
                          , OUT_CURSOR        OUT SYS_REFCURSOR
                          )
IS
/**********************************************************************************************
*    SERVICENAME    : PC_EICU_CENTER_STATISTIC_NONFA
*    CREATEDATE     : 2021.04.01
*    Author         : 신솔
*    Description    : 비대면 협진현황
*    Change History : 2021.04.01, 신솔, 최초작성     
                      2021.06.24, 김국경, 01인 경우 제외 처리(UCCOCDPM, UCCOCSTE 테이블 값 중복) : 공통코드의 국가지정병상으로 유지  
**********************************************************************************************/
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
            /**********************
            INDICATORS OUT DTO
            ************************/
            WITH CHARTGUB AS (
                 /* 차트 구분 공통코드 */
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                      , A.COMN_CD_EXPL AS COMN_CD_EXPL
                   FROM (SELECT 'CSLT_TYPE' AS COMN_GRP_CD, '1' AS COMN_CD, '단순 문의' AS COMN_CD_NM, '의뢰유형' AS COMN_CD_EXPL FROM DUAL UNION ALL
                         SELECT 'CSLT_TYPE', '2', '환자 상태 체크', '의뢰유형' FROM DUAL UNION ALL
                         SELECT 'CSLT_TYPE', '3', '모니터링', '의뢰유형' FROM DUAL UNION ALL
                         SELECT 'CSLT_TYPE', '4', '기타', '의뢰유형' FROM DUAL UNION ALL
                         SELECT 'CSLT_TYPE', '5', '타과 회신', '의뢰유형' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '1', '일', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '2', '월', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '3', '화', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '4', '수', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '5', '목', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '6', '금', '요일별 상담시간' FROM DUAL UNION ALL
                         SELECT 'EZOTC_DAY_TYPE', '7', '토', '요일별 상담시간' FROM DUAL) A
                  ORDER BY A.COMN_GRP_CD
                 )
               , MONTHGUB AS (
                 /* 년간 추이 공통코드 */
                 SELECT TO_CHAR(A.YMD, 'YYYY-MM') AS DTM
                  FROM (
                        SELECT ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) AS YMD
                          FROM DUAL
                       CONNECT BY ADD_MONTHS(IN_TO_DT, -(LEVEL-1)) >= ADD_MONTHS(IN_TO_DT, -11)
                       ) A
                 )
               , BF_MONTH AS (
                 SELECT TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY-MM') AS DTM
                   FROM DUAL
                 )
               , BF_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '12', 'YYYYMM'), TO_DATE(TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , CUR_YEAR AS (
                 SELECT TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM'), LEVEL - 1), 'YYYY-MM') AS DTM
                  FROM DUAL
                CONNECT BY LEVEL <= MONTHS_BETWEEN(TO_DATE(TO_CHAR(IN_TO_DT, 'YYYYMM'), 'YYYYMM'), TO_DATE(TO_CHAR(IN_TO_DT, 'YYYY') || '01', 'YYYYMM')) + 1
                 )
               , RECDATA AS(
                 SELECT A.RER_DEPT_CD          AS WD_DEPT_CD
                      , SUM(A.WHL_CSLT_CNT)    AS WHL_CSLT_CNT
                      , SUM(A.SGL_CSLT_CNT)    AS SGL_CSLT_CNT
                      , SUM(A.MIX_CSLT_CNT)    AS MIX_CSLT_CNT
                      , SUM(A.OTDP_RPLY_CNT)   AS OTDP_RPLY_CNT
                      , SUM(A.SMP_IQRY_CNT)    AS SMP_IQRY_CNT
                      , SUM(A.PT_STS_INSP_CNT) AS PT_STS_INSP_CNT
                      , SUM(A.MNTR_CNT)        AS MNTR_CNT
                      , SUM(A.ETC_CNT)         AS ETC_CNT
                   FROM HICU.UCOSCNSD A
                  WHERE A.UNTC_REC_DT BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')
                    AND A.HSP_TP_CD = IN_HIS_HSP_TP_CD
                  GROUP BY A.RER_DEPT_CD
                 )
               , RECDATA_FOR_ANNU AS(
                 SELECT TO_CHAR(TO_DATE(A.UNTC_REC_DT, 'YYYY-MM-DD'), 'YYYY-MM') AS REC_DTM
                      , SUM(A.WHL_CSLT_CNT)    AS WHL_CSLT_CNT
                      , SUM(A.SGL_CSLT_CNT)    AS SGL_CSLT_CNT
                      , SUM(A.MIX_CSLT_CNT)    AS MIX_CSLT_CNT
                      , SUM(A.OTDP_RPLY_CNT)   AS OTDP_RPLY_CNT
                      , SUM(A.SMP_IQRY_CNT)    AS SMP_IQRY_CNT
                      , SUM(A.PT_STS_INSP_CNT) AS PT_STS_INSP_CNT
                      , SUM(A.MNTR_CNT)        AS MNTR_CNT
                      , SUM(A.ETC_CNT)         AS ETC_CNT
                   FROM HICU.UCOSCNSD A
                  WHERE A.UNTC_REC_DT BETWEEN TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '0101' AND TO_CHAR(LAST_DAY(IN_TO_DT), 'YYYYMMDD')
                    AND A.HSP_TP_CD = IN_HIS_HSP_TP_CD
                  GROUP BY TO_CHAR(TO_DATE(A.UNTC_REC_DT, 'YYYY-MM-DD'), 'YYYY-MM')
                 )
               , CALLDATA AS(
                 SELECT A.PT_WD_DEPT_CD          AS WD_DEPT_CD
                      , SUM(A.WHL_TELC_CNT)      AS WHL_TELC_CNT
                      , SUM(A.SGL_UNTC_TELC_CNT) AS SGL_UNTC_TELC_CNT
                      , SUM(A.MIX_UNTC_TELC_CNT) AS MIX_UNTC_TELC_CNT
                      , SUM(A.SDY_CNSL_TM)       AS SDY_CNSL_TM
                      , SUM(A.MDY_CNSL_TM)       AS MDY_CNSL_TM
                      , SUM(A.UDY_CNSL_TM)       AS UDY_CNSL_TM
                      , SUM(A.WDY_CNSL_TM)       AS WDY_CNSL_TM
                      , SUM(A.TRDY_CNSL_TM)      AS TRDY_CNSL_TM
                      , SUM(A.FDY_CNSL_TM)       AS FDY_CNSL_TM
                      , SUM(A.ADY_CNSL_TM)       AS ADY_CNSL_TM
                   FROM HICU.UCOSNFLD A
                  WHERE A.UNTC_DT BETWEEN TO_CHAR(IN_FROM_DT, 'YYYYMMDD') AND TO_CHAR(IN_TO_DT, 'YYYYMMDD')   
                    AND A.HSP_TP_CD = IN_HIS_HSP_TP_CD
                  GROUP BY A.PT_WD_DEPT_CD
                 )
               , CALLDATA_FOR_ANNU AS(
                 SELECT TO_CHAR(TO_DATE(A.UNTC_DT, 'YYYY-MM-DD'), 'YYYY-MM') AS CALL_DTM
                      , SUM(A.WHL_TELC_CNT)      AS WHL_TELC_CNT
                      , SUM(A.SGL_UNTC_TELC_CNT) AS SGL_UNTC_TELC_CNT
                      , SUM(A.MIX_UNTC_TELC_CNT) AS MIX_UNTC_TELC_CNT
                      , SUM(A.SDY_CNSL_TM)       AS SDY_CNSL_TM
                      , SUM(A.MDY_CNSL_TM)       AS MDY_CNSL_TM
                      , SUM(A.UDY_CNSL_TM)       AS UDY_CNSL_TM
                      , SUM(A.WDY_CNSL_TM)       AS WDY_CNSL_TM
                      , SUM(A.TRDY_CNSL_TM)      AS TRDY_CNSL_TM
                      , SUM(A.FDY_CNSL_TM)       AS FDY_CNSL_TM
                      , SUM(A.ADY_CNSL_TM)       AS ADY_CNSL_TM
                   FROM HICU.UCOSNFLD A
                  WHERE A.UNTC_DT BETWEEN TO_CHAR(ADD_MONTHS(IN_TO_DT, -12), 'YYYY') || '0101' AND TO_CHAR(LAST_DAY(IN_TO_DT), 'YYYYMMDD')
                    AND A.HSP_TP_CD = IN_HIS_HSP_TP_CD
                  GROUP BY TO_CHAR(TO_DATE(A.UNTC_DT, 'YYYY-MM-DD'), 'YYYY-MM')
                 )
               , EPCN_CSLT AS(
                 SELECT 'EPCN_CSLT'     AS COMN_GRP_CD
                      , DECODE(C.DEPT_CD, 'ETC', C.RMK_CNTE, C.DEPT_CD) AS COMN_CD
                      , C.RMK_CNTE      AS COMN_CD_NM
                      , '비대면 협진환자'     AS COMN_CD_EXPL
                      , TO_CHAR(NVL(A.WHL_CSLT_CNT, 0)) AS DTRL1_NM
                      , TO_CHAR(NVL(B.WHL_TELC_CNT, 0)) AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM RECDATA  A
                      , CALLDATA B
                      , (
                         SELECT X.DEPT_CD  AS DEPT_CD
                              , X.RMK_CNTE AS RMK_CNTE
                              , X.SORT_SEQ AS SORT_SEQ
                           FROM HICU.UCCOCDPM X
                          WHERE X.HSP_TP_CD = IN_HIS_HSP_TP_CD
                         UNION
                         SELECT Y.COMN_CD    AS DEPT_CD
                              , Y.COMN_CD_NM AS RMK_CNTE
                              , 99           AS SORT_SEQ
                           FROM HICU.UCCOCSTE Y
                          WHERE Y.HSP_TP_CD = IN_HIS_HSP_TP_CD
                            AND Y.COMN_GRP_CD = 'IC018'
                         UNION
                         SELECT 'ETC', '기타', 100 FROM DUAL
                        ) C
                  WHERE C.DEPT_CD   = A.WD_DEPT_CD(+)
                    AND C.DEPT_CD   = B.WD_DEPT_CD(+)  
                    /* 2021-06.24, 김국경 : 39병동 중복나는 현상.. 제외처리 */
                    AND CASE WHEN C.DEPT_CD    = '039' AND C.SORT_SEQ = 99 THEN 'N'   
			            ELSE 'Y'
			            END = 'Y' 
                  ORDER BY C.SORT_SEQ
                 )
               , PRTP_TYPE AS(
                 SELECT 'PRTP_TYPE' AS COMN_GRP_CD
                      , 'PRTP_TYPE' AS COMN_CD
                      , 'PRTP_TYPE' AS COMN_CD_NM
                      , '협진참여방식'   AS COMN_CD_EXPL
                      , TO_CHAR(NVL(SUM(A.WHL_CSLT_CNT), 0)) AS DTRL1_NM
                      , TO_CHAR(NVL(SUM(A.SGL_CSLT_CNT), 0)) AS DTRL2_NM
                      , TO_CHAR(NVL(SUM(A.MIX_CSLT_CNT), 0)) AS DTRL3_NM
                   FROM RECDATA A
                 )
               , CSLT_TYPE AS(
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                      , A.COMN_CD_EXPL AS COMN_CD_EXPL
                      , TO_CHAR(NVL(DTRL1_NM, 0)) AS DTRL1_NM
                      , '' AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM CHARTGUB A
                      , ( SELECT DECODE(COMN_CD, 'CT1', '1', 'CT2', '2', 'CT3', '3', 'CT4', '4', '5') AS COMN_CD
                               , DTRL1_NM AS DTRL1_NM
                            FROM (SELECT SUM(A.OTDP_RPLY_CNT)   AS CT5
                                       , SUM(A.SMP_IQRY_CNT)    AS CT1
                                       , SUM(A.PT_STS_INSP_CNT) AS CT2
                                       , SUM(A.MNTR_CNT)        AS CT3
                                       , SUM(A.ETC_CNT)         AS CT4
                                    FROM RECDATA A
                                 )
                         UNPIVOT (DTRL1_NM FOR COMN_CD
                                            IN (CT1
                                              , CT2
                                              , CT3
                                              , CT4
                                              , CT5
                                              )
                                 )
                        ) B
                  WHERE A.COMN_GRP_CD = 'CSLT_TYPE'
                    AND A.COMN_CD     = B.COMN_CD(+)
                  ORDER BY A.COMN_CD
                 )
               , EZOTC_SUM AS(
                 SELECT 'EZOTC_SUM' AS COMN_GRP_CD
                      , 'EZOTC_SUM' AS COMN_CD
                      , 'EZOTC_SUM' AS COMN_CD_NM
                      , '비대면 영상 사용' AS COMN_CD_EXPL
                      , TO_CHAR(NVL(SUM(A.WHL_TELC_CNT), 0)) AS DTRL1_NM
                      , '' AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM CALLDATA A
                 )
               , EZOTC_CALL_TYPE AS(
                 SELECT 'EZOTC_CALL_TYPE' AS COMN_GRP_CD
                      , 'EZOTC_CALL_TYPE' AS COMN_CD
                      , 'EZOTC_CALL_TYPE' AS COMN_CD_NM
                      , '영상참여방식' AS COMN_CD_EXPL
                      , TO_CHAR(NVL(SUM(A.SGL_UNTC_TELC_CNT), 0) + NVL(SUM(A.MIX_UNTC_TELC_CNT), 0)) AS DTRL1_NM
                      , TO_CHAR(NVL(SUM(A.SGL_UNTC_TELC_CNT), 0)) AS DTRL2_NM
                      , TO_CHAR(NVL(SUM(A.MIX_UNTC_TELC_CNT), 0)) AS DTRL3_NM
                   FROM CALLDATA A
                 )
               , EZOTC_DAY_TYPE AS(
                 SELECT A.COMN_GRP_CD  AS COMN_GRP_CD
                      , A.COMN_CD      AS COMN_CD
                      , A.COMN_CD_NM   AS COMN_CD_NM
                      , A.COMN_CD_EXPL AS COMN_CD_EXPL
                      , CASE WHEN A.COMN_CD = '1' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(SDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             WHEN A.COMN_CD = '2' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(MDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             WHEN A.COMN_CD = '3' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(UDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             WHEN A.COMN_CD = '4' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(WDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             WHEN A.COMN_CD = '5' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(TRDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             WHEN A.COMN_CD = '6' THEN (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(FDY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA)
                             ELSE (SELECT RTRIM(TO_CHAR(ROUND(NVL(SUM(ADY_CNSL_TM) / 60 / 24, 0), 1), 'FM9990.9'), '.') FROM CALLDATA) END AS DTRL1_NM
                      , '' AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM CHARTGUB A
                  WHERE A.COMN_GRP_CD = 'EZOTC_DAY_TYPE'
                  ORDER BY A.COMN_CD
                 )
               , EZOTC_CALL_TIME AS(
                 SELECT 'EZOTC_CALL_TIME' AS COMN_GRP_CD
                      , 'EZOTC_CALL_TIME' AS COMN_CD
                      , 'EZOTC_CALL_TIME' AS COMN_CD_NM
                      , '전체 상담시간' AS COMN_CD_EXPL
                      , TO_CHAR(NVL(ROUND(SUM(TO_NUMBER(A.DTRL1_NM)), 1), 0)) AS DTRL1_NM
                      , '' AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM EZOTC_DAY_TYPE A
                 )
               , AVGTABLE AS(
                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'BF_YEAR'  AS COMN_CD
                      , '전년월평균'   AS COMN_CD_NM
                      , '비대면 협진/영상사용 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(CEIL(SUM(A.REC_CNT) / COUNT(*)))  AS DTRL1_NM
                      , TO_CHAR(CEIL(SUM(A.CALL_CNT) / COUNT(*))) AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM (SELECT A.DTM      AS DTM
                              , A.REC_CNT  AS REC_CNT
                              , B.CALL_CNT AS CALL_CNT
                           FROM (SELECT X.DTM                       AS DTM
                                      , NVL(SUM(Y.WHL_CSLT_CNT), 0) AS REC_CNT
                                   FROM BF_YEAR          X
                                      , RECDATA_FOR_ANNU Y
                                  WHERE X.DTM = Y.REC_DTM(+)
                                  GROUP BY X.DTM
                                  ORDER BY X.DTM) A
                              , (SELECT X.DTM                       AS DTM
                                      , NVL(SUM(Y.WHL_TELC_CNT), 0) AS CALL_CNT
                                   FROM BF_YEAR           X
                                      , CALLDATA_FOR_ANNU Y
                                  WHERE X.DTM = Y.CALL_DTM(+)
                                  GROUP BY X.DTM
                                  ORDER BY X.DTM) B
                          WHERE A.DTM = B.DTM) A
            
                 UNION ALL
            
                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'CUR_YEAR' AS COMN_CD
                      , '당년월평균'   AS COMN_CD_NM
                      , '비대면 협진/영상사용 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(CEIL(SUM(A.REC_CNT) / COUNT(*)))  AS DTRL1_NM
                      , TO_CHAR(CEIL(SUM(A.CALL_CNT) / COUNT(*))) AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM (SELECT A.DTM      AS DTM
                              , A.REC_CNT  AS REC_CNT
                              , B.CALL_CNT AS CALL_CNT
                           FROM (SELECT X.DTM                       AS DTM
                                      , NVL(SUM(Y.WHL_CSLT_CNT), 0) AS REC_CNT
                                   FROM CUR_YEAR         X
                                      , RECDATA_FOR_ANNU Y
                                  WHERE X.DTM = Y.REC_DTM(+)
                                  GROUP BY X.DTM
                                  ORDER BY X.DTM) A
                              , (SELECT X.DTM                       AS DTM
                                      , NVL(SUM(Y.WHL_TELC_CNT), 0) AS CALL_CNT
                                   FROM CUR_YEAR          X
                                      , CALLDATA_FOR_ANNU Y
                                  WHERE X.DTM = Y.CALL_DTM(+)
                                  GROUP BY X.DTM
                                  ORDER BY X.DTM) B
                          WHERE A.DTM = B.DTM) A
            
                 UNION ALL
            
                 SELECT 'ANNU_AVG' AS COMN_GRP_CD
                      , 'BF_MON'   AS COMN_CD
                      , '전년당월'    AS COMN_CD_NM
                      , '비대면 협진/영상사용 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(A.REC_CNT)  AS DTRL1_NM
                      , TO_CHAR(B.CALL_CNT) AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM (SELECT X.DTM                       AS DTM
                              , NVL(SUM(Y.WHL_CSLT_CNT), 0) AS REC_CNT
                           FROM BF_MONTH         X
                              , RECDATA_FOR_ANNU Y
                          WHERE X.DTM = Y.REC_DTM(+)
                          GROUP BY X.DTM) A
                      , (SELECT X.DTM                       AS DTM
                              , NVL(SUM(Y.WHL_TELC_CNT), 0) AS CALL_CNT
                           FROM BF_MONTH          X
                              , CALLDATA_FOR_ANNU Y
                          WHERE X.DTM = Y.CALL_DTM(+)
                          GROUP BY X.DTM) B
                  WHERE A.DTM = B.DTM
                 )
               , TRENDTABLE AS(
                 SELECT 'ANNU_TREND' AS COMN_GRP_CD
                      , A.DTM AS COMN_CD
                      , A.DTM AS COMN_CD_NM
                      , '비대면 협진/영상사용 년간추이' AS COMN_CD_EXPL
                      , TO_CHAR(NVL(B.WHL_CSLT_CNT, 0)) AS DTRL1_NM
                      , TO_CHAR(NVL(C.WHL_TELC_CNT, 0)) AS DTRL2_NM
                      , '' AS DTRL3_NM
                   FROM MONTHGUB A
                      , RECDATA_FOR_ANNU  B
                      , CALLDATA_FOR_ANNU C
                  WHERE A.DTM = B.REC_DTM(+)
                    AND A.DTM = C.CALL_DTM(+)
                  ORDER BY A.DTM
                 )
            
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM EPCN_CSLT A
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM PRTP_TYPE  B
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM CSLT_TYPE  C
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM EZOTC_SUM  D
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM EZOTC_CALL_TYPE E
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM EZOTC_CALL_TIME F
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM EZOTC_DAY_TYPE  G
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM AVGTABLE   H
            UNION ALL
            SELECT COMN_GRP_CD, COMN_CD, COMN_CD_NM, COMN_CD_EXPL, DTRL1_NM, DTRL2_NM, DTRL3_NM FROM TRENDTABLE I            
        ;
    END;
END PC_EICU_CENTER_STATISTIC_NONFA;
