
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FT_RRT_NEWSSCORE" ( IN_HSP_TP_CD     IN  VARCHAR2
                                                 , IN_PT_NO         IN  VARCHAR2
                                                 , IN_RRT_ITEM_CD   IN  VARCHAR2
                                                 , IN_ITEM_REC_DTM  IN  DATE
                                                 , IN_RRT_VALUE     IN  VARCHAR2 )
							   
RETURN VARCHAR2
/*===================================================================================
* 서비스이름      : FT_RRT_NEWSSCORE
* 최초 작성일     : 2020,03
* 최초 작성자     : 하만석
* DESCRIPTION     : RRT NEWS 계산 함수
* 변경이력관리    : 
===================================================================================*/
IS
	V_NEWS NUMBER := 0;

BEGIN
    select case when DETL_CD = 'HR' then  -- HR
                     case when to_number(IN_RRT_VALUE) >= 41 and to_number(IN_RRT_VALUE) <= 50 THEN 1
                          when to_number(IN_RRT_VALUE) >= 51 and to_number(IN_RRT_VALUE) <= 90 THEN 0
                          when to_number(IN_RRT_VALUE) >= 91 and to_number(IN_RRT_VALUE) <= 110 THEN 1
                          when to_number(IN_RRT_VALUE) >= 111 and to_number(IN_RRT_VALUE) <= 130 THEN 2
                          when to_number(IN_RRT_VALUE) <= 40 or to_number(IN_RRT_VALUE) >= 131 THEN 3
                          else 0
                      end
                when DETL_CD = 'RR' then  -- RR
                        case when to_number(IN_RRT_VALUE) >= 9 and to_number(IN_RRT_VALUE) <= 11 THEN 1
                             when to_number(IN_RRT_VALUE) >= 12 and to_number(IN_RRT_VALUE) <= 20 THEN 0
                             when to_number(IN_RRT_VALUE) >= 21 and to_number(IN_RRT_VALUE) <= 24 THEN 2
                             when to_number(IN_RRT_VALUE) <= 8 or to_number(IN_RRT_VALUE) >= 25 THEN 3
                             ELSE 0
                        END
                when DETL_CD = 'BT' then  --BT
                        case when to_number(IN_RRT_VALUE) <= 35 THEN 3
                             when to_number(IN_RRT_VALUE) >= 35.1 and to_number(IN_RRT_VALUE) <= 36 THEN 1
                             when to_number(IN_RRT_VALUE) >= 36.1 and to_number(IN_RRT_VALUE) <= 38 THEN 0
                             when to_number(IN_RRT_VALUE) >= 38.1 and to_number(IN_RRT_VALUE) <= 39 THEN 1
                             when to_number(IN_RRT_VALUE) >= 39.1 THEN 2
                             ELSE 0
                        END
                when DETL_CD = 'SPO2' then  -- SPO2
                        case when to_number(IN_RRT_VALUE) <= 91 THEN 3
                             when to_number(IN_RRT_VALUE) >= 92 and to_number(IN_RRT_VALUE) <= 93 THEN 2
                             when to_number(IN_RRT_VALUE) >= 94 and to_number(IN_RRT_VALUE) <= 95 THEN 1
                             when to_number(IN_RRT_VALUE) >= 96 THEN 0
                             ELSE 0
                        END
                when DETL_CD = 'SBP' then  -- SBP  210010
                        case when to_number(IN_RRT_VALUE) <= 90 THEN 3
                             when to_number(IN_RRT_VALUE) >= 91 and to_number(IN_RRT_VALUE) <= 100 THEN 2
                             when to_number(IN_RRT_VALUE) >= 101 and to_number(IN_RRT_VALUE) <= 110 THEN 1
                             when to_number(IN_RRT_VALUE) >= 111 and to_number(IN_RRT_VALUE) <= 219 THEN 0
                             when to_number(IN_RRT_VALUE) >= 220 THEN 3
                             ELSE 0
                        END
                when DETL_CD = 'GCS' then  -- AVPU   20001010
                    case when instr(UPPER(IN_RRT_VALUE), 'ALERT') > 0 THEN 0
                         when LENGTH(IN_RRT_VALUE) > 0 THEN 3
                         else 0
                    END
                when DETL_CD = 'OXYGEN' then  -- OXYGEN   210270
                    case when LENGTH(IN_RRT_VALUE) > 0 then 2
				          else 0 end
       end r_value
      into V_NEWS
      from HICU.RRS_DETAIL
     where MSTR_CD = 'VITAL'
       and HSP_TP_CD = IN_HSP_TP_CD
       and ( DETL_CD_1 = IN_RRT_ITEM_CD or DETL_CD_2 = IN_RRT_ITEM_CD or DETL_CD_3 = IN_RRT_ITEM_CD or DETL_CD_4 = IN_RRT_ITEM_CD )
       and USE_YN = 'Y'
    ;
    
    RETURN nvl(V_NEWS, 0);
    
END FT_RRT_NEWSSCORE;
