
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."IF_FN_CODE_SEL" (
IN_COMKDCD   IN VARCHAR2,  --공통분류코드
IN_CDBS      IN VARCHAR2,  --공통코드
IN_GUBN      IN VARCHAR2 DEFAULT 'CDNM' -- 조회항목 (기본값: CDNM) 
) 
RETURN VARCHAR2
/*
정의: 공통코드의 공통코드명을 가져오는 함수
*/
IS
    V_COMN_CD_NM VARCHAR2(500);
BEGIN
    SELECT DECODE(IN_GUBN, 'CDNM',   CDNM 
                         , 'CDDES1', CDDES1
                         , 'CDDES2', CDDES2
                         , 'CDDES3', CDDES3
                         , CDNM)
      INTO V_COMN_CD_NM
      FROM ARPA_CD_LIST A
     WHERE COMKDCD = IN_COMKDCD
       AND CDBS    = IN_CDBS;
       
     RETURN (V_COMN_CD_NM);
END;
