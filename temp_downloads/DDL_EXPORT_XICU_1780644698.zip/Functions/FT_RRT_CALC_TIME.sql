
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FT_RRT_CALC_TIME" ( IN_DATE IN  DATE)

RETURN VARCHAR2
IS        
/*===================================================================================
* 서비스이름      : FT_RRT_CALC_TIME
* 최초 작성일     : 2020.03
* 최초 작성자     : 하만석
* DESCRIPTION     : RRT 입력 및 확인 시간 변환
* 변경이력관리    
===================================================================================*/
    V_RETURN VARCHAR2(20) := '';
BEGIN    
    BEGIN
        IF IN_DATE = NULL THEN
            V_RETURN := '';
        ELSE	
            BEGIN
--                select case when DIFF_MINUTE < 20 then '방금 전'  -- when DIFF_HOUR < 1 then '방금 전'  -- 'Now'
--                            when DIFF_MINUTE < 60 then trunc(DIFF_MINUTE) || ' 분전'  --' Min'
--                            else TO_CHAR(IN_DATE, 'mm-dd') || CHR(10) || TO_CHAR(IN_DATE, 'hh24:mi') end CALC_DTM   
--                   INTO V_RETURN
--                    from (
--		                    SELECT ROUND(((SYSDATE-IN_DATE)*24),3) AS DIFF_HOUR
--		                         , ROUND(((SYSDATE-IN_DATE)*24*60),3) AS DIFF_MINUTE
--		                      fROM DUAL
--		                 );
                select TO_CHAR(IN_DATE, 'mm-dd') || CHR(10) || TO_CHAR(IN_DATE, 'hh24:mi') CALC_DTM
                 INTO V_RETURN
                 from DUAL ;
            
                EXCEPTION
                    WHEN NO_DATA_FOUND THEN
                         V_RETURN := ''; 	
            END;
		END IF;
	END;       
                   
    RETURN(V_RETURN);
    
END FT_RRT_CALC_TIME;
