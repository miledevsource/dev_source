
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FT_RRT_STATE" ( IN_PT_NO         IN  VARCHAR2
                           , IN_HSP_TP_CD     IN  VARCHAR2)

RETURN VARCHAR2
IS
/*===================================================================================
* 서비스이름      : FT_RRT_STATE
* 최초 작성일     : 2020.06
* 최초 작성자     : 하만석
* DESCRIPTION     : RRT 환자 상태 전달 함수    조치, 관찰 만 표현하고 관찰이 상위상태임
* 변경이력관리
===================================================================================*/
    V_RETURN VARCHAR2(6) := '';
BEGIN
	BEGIN
		SELECT TITLE
          INTO V_RETURN
  		  FROM (
				   SELECT decode(RRS_STATE_CD, 'M', D.DETL_CD_NM
		                                 , 'P', D.DETL_CD_NM
		                                 , '') TITLE
		          , decode(RRS_STATE_CD, 'M', 1
		                               , 'P', 2
		                               , '') DISP_SEQ
				  fROM HICU.RRS_STATE o
				    , HICU.RRS_DETAIL D
				 WHERE o.HSP_TP_CD = IN_HSP_TP_CD
				   and o.HSP_TP_CD = d.HSP_TP_CD
				   AND o.PT_NO     = IN_PT_NO
				   AND o.HIST_SEQ = 0
				   AND o.RRS_STATE_CD in ('M','P')
				   AND D.MSTR_CD = 'STAT_CD'
				   AND O.RRS_STATE_CD = D.detl_cd
           AND ROWNUM  = 1
			)
		     ;
		EXCEPTION
    	    WHEN NO_DATA_FOUND THEN
    		     V_RETURN := '';

	END;

    RETURN(V_RETURN);

END FT_RRT_STATE;
