
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FT_EICU_STRING_TABLE" ( P_STRING IN VARCHAR2, P_DEL IN VARCHAR2) RETURN xcom.TYPE_STRING_TABLE
AS
    L_STRING        LONG DEFAULT P_STRING || P_DEL;
    L_DATA          xcom.TYPE_STRING_TABLE :=  xcom.TYPE_STRING_TABLE();
    N               NUMBER;
BEGIN
/*
1. 정의: 문자열을 테이블형태로 반환하는 프로시저를 사용하여 SQL 구조 개선에 사용
         일반 스트링을 구분자(P_DEL) (',')로 나누어 테이블 형태로 공급할 수 있도록 하는 함수
         INSTR('STRING', COLUMN) > 0 의 비교를 제거
2. 작성자: 신솔 (ASIS 함수: XREC.FT_STRING_TABLE_TYPE 이관)
3. 작성일자: 2021.02.18
*/
LOOP
      EXIT WHEN L_STRING IS NULL;
      N := INSTR( L_STRING, P_DEL );
      L_DATA.EXTEND;
      L_DATA(L_DATA.COUNT) := LTRIM( RTRIM( SUBSTR( L_STRING, 1, N-1 ) ) );
      L_STRING := SUBSTR( L_STRING, N+1 );
 END LOOP;

 RETURN L_DATA;
END;
