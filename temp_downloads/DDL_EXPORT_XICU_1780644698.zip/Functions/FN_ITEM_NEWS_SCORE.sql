
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FN_ITEM_NEWS_SCORE" ( I_HSP_TP_CD IN VARCHAR2  --병원구분코드
                           , I_TYPE      IN VARCHAR2  --항목명 대문자
                           , T_VALUE     IN VARCHAR2  --수치값
                           ) RETURN VARCHAR2
/*============================================================
 * 서비스 이름       : FN_GET_ITEM_NEWS_SCORE
 * 최초작성일/작성자  : 2026.01.29 이지케어텍
 * DESCRIPTION      : (PKG_NEORRS_MAIN.PC_RRS_PAT_EACH_LIST)RRS 각 항목당 수치에 대한 NEWS 값
===============================================================
 * 변경이력          : 
 * 변경일            : 
===============================================================*/
IS
    V_RECRSLT   VARCHAR2(1000);
    V_TARGET_CD VARCHAR2(20);
BEGIN    
  --NEWS (National Early Warning Score) 
  --NEWS 측정 7개 항목 (호흡 + SpO2 + 산소상요 + 체온 + 혈압 + 맥박 = 총 6개 + 의식수준)    
  ----210050    BT     Body Temperature                        체온            신체 온도(도)
  ----30250     LOC(AVPU)                                                                 
  ----210030    HR     Heart Rate                              심박수          1분당 심장 박동수(bpm)
  ----210270    OXYGEN Oxyen Supplementation                   산소 투여 여부   산소 치료 중인지 여부       
  ----210040    RR     Respiratory                             Rate  호흡수     1분간 호흡 횟수  
  ----210010    SBP    Systolic Blood Presure                  수축기 혈압     심장이 수축할 때의 혈압(mmHg)
  ----10370     SPO2   Perpheral Capillary Oxygen Saturation   말초산소포화도   맥박산소측정기로 측정
   
  --공통관리 수치 NUMBER 값으로 체크    
  IF I_TYPE IN ('BT','HR','PR','RR','SBP','SPO2') THEN
    BEGIN
      SELECT MAX(COMN_CD_NM)
        INTO V_RECRSLT 
       FROM UCCOCSTE
      WHERE COMN_GRP_CD = '001'
        AND COMN_CD LIKE I_TYPE||'%'
        AND HSP_TP_CD  = I_HSP_TP_CD
        AND USE_YN = 'Y'
        AND TO_NUMBER(T_VALUE) BETWEEN TO_NUMBER(DTRL1_NM) AND TO_NUMBER(DTRL2_NM);
        
    EXCEPTION
        WHEN OTHERS THEN
            V_RECRSLT := '';
    END;
  --공통관리 텍스트값 TEXT
  ELSE
    BEGIN
      SELECT MAX(COMN_CD_NM)
        INTO V_RECRSLT 
        FROM UCCOCSTE
       WHERE COMN_GRP_CD = '001'
         AND COMN_CD LIKE I_TYPE||'%'
         AND HSP_TP_CD  = I_HSP_TP_CD
         AND USE_YN = 'Y'
         AND UPPER(T_VALUE) = UPPER(DTRL3_NM);
       
    EXCEPTION
        WHEN OTHERS THEN
            V_RECRSLT := '';
    END;
  END IF;

    RETURN V_RECRSLT;

  
--select DISTINCT
--       SUBSTR(COMN_CD, 1, INSTR(COMN_CD, '-') - 1) COMN_CD
--     , COMN_CD_EXPL
--  FROM UCCOCSTE
-- WHERE COMN_GRP_CD = '001'
--   AND USE_YN = 'Y'
-- ORDER BY 2;
--COMN_CD  COMN_CD_EXPL;

--BT  NUMBER
--HR  NUMBER
--PR  NUMBER
--RR  NUMBER
--SBP  NUMBER
--SPO2  NUMBER
--LOC  TEXT
--OXYGEN  TEXT

EXCEPTION
    WHEN OTHERS THEN
        RETURN NULL;
END;
