
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FT_GET_VITAL_RSLT" (IN_ALL_RSLT IN VARCHAR2, IN_ITEM IN VARCHAR2 )

RETURN VARCHAR2
IS        
/*===================================================================================
* 서비스이름      : FT_GET_VITAL_RSLT
* 최초 작성일     : 2020.03
* 최초 작성자     : 하만석
* DESCRIPTION     : RRT 활성화 정보 조회 시 개별 결과
* 변경이력관리    
===================================================================================*/
    V_RETURN VARCHAR2(20) := '';
BEGIN    
    BEGIN
        SELECT replace(RESULT, IN_ITEM ||':', '') RESULT 
          INTO V_RETURN 
          FROM (
            SELECT trim(regexp_substr(multidata, '[^|]+', 1, ROWNUM)) as result
              FROM ( SELECT IN_ALL_RSLT as multidata FROM DUAL) a
           CONNECT BY ROWNUM <= length(regexp_replace(multidata, '[^|]+')) + 1
          ) 
         WHERE RESULT like IN_ITEM || ':%'
         ;

        EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 V_RETURN := ''; 	

	END;       
             
    RETURN(V_RETURN);
    
END FT_GET_VITAL_RSLT;
