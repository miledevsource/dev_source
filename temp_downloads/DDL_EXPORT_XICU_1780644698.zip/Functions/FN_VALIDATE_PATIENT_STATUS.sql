
  CREATE OR REPLACE EDITIONABLE FUNCTION "XICU"."FN_VALIDATE_PATIENT_STATUS" (
    P_HSP_TP_CD         IN VARCHAR2,
    P_SEQ               IN NUMBER,
    P_PT_NO             IN VARCHAR2,
    P_PACT_ID           IN VARCHAR2,
    P_TRNF_PRGR_STS_CD  IN VARCHAR2  -- NULL이면 단순조회, 값이 있으면 업데이트 요청
) RETURN VARCHAR2


IS
    V_TRNF_PRGR_STS_CD  VARCHAR2(2);
    V_STATUS_STS_CD     VARCHAR2(1);
    V_PREV_CD           VARCHAR2(2);
    V_CANCEL_REASON     VARCHAR2(1000);
BEGIN
    -- 현재 상태 조회
    SELECT TRNF_PRGR_STS_CD
         , STATUS_STS_CD
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = P_HSP_TP_CD
       AND SEQ       = P_SEQ
       AND PT_NO     = P_PT_NO
       AND P_PACT_ID = P_PACT_ID;   

    -- P_TRNF_PRGR_STS_CD 가 NULL이면 단순조회: 무조건 Y 리턴
    IF P_TRNF_PRGR_STS_CD IS NULL THEN
        RETURN 'Y';
    END IF;

    -- 업데이트 요청인 경우 분기
    V_PREV_CD := IF_FN_CODE_SEL('TRNF_PRGR_STS_CD', P_TRNF_PRGR_STS_CD, 'CDDES1');
			
    IF (V_TRNF_PRGR_STS_CD = V_PREV_CD AND V_STATUS_STS_CD = 'A') THEN
        RETURN 'Y'; -- 프로시저에서 업데이트 진행     
        
    ELSIF V_STATUS_STS_CD = 'D' THEN
        RETURN '해당 환자는 삭제된 환자입니다.';         
        
    ELSIF V_STATUS_STS_CD = 'Y' THEN 
        RETURN '해당 환자는 협진완료된 환자입니다.';      
        
    ELSIF V_STATUS_STS_CD = 'N' THEN 
        RETURN '해당 환자는 이송불가처리된 환자입니다.';   
        
    ELSIF V_STATUS_STS_CD = 'E' THEN
        RETURN '해당 환자는 이송종료된 환자입니다.'; 
        
    ELSIF V_STATUS_STS_CD = 'C' THEN
        RETURN '해당 환자는 취소된 환자입니다. 사유: ' || V_CANCEL_REASON;  
    ELSE
        RETURN '해당 환자는 현재 ' 
               || IF_FN_CODE_SEL('TRNF_PRGR_STS_CD', V_TRNF_PRGR_STS_CD + 10, 'CDNM')
               || ' 진행 대기중으로 화면 재조회 바랍니다.';
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RETURN SQLERRM;
END FN_VALIDATE_PATIENT_STATUS;
