
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_EZONTHECALL_EICU" 
IS 
     TYPE RETURNCURSOR IS REF CURSOR;    
    /**********************************************************************************************
    * Service Name : PC_EZOTC_INSERT_LOG
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    * 2021-03-18   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/
    PROCEDURE PC_EZOTC_INSERT_LOG (
        IN_INSERTSTAFFNUMBER          IN LOG_EZOTC_EICU.INSERTSTAFFNUMBER%TYPE,
        IN_ICU                        IN LOG_EZOTC_EICU.ICU%TYPE,
        IN_STATUS                     IN LOG_EZOTC_EICU.STATUS%TYPE,
        IN_PATIENTNUMBER              IN LOG_EZOTC_EICU.PATIENTNUMBER%TYPE,
        IN_ROOMNAME                   IN LOG_EZOTC_EICU.ROOMNAME%TYPE,
        IN_DEPSTAFFNUMBER             IN LOG_EZOTC_EICU.DEPSTAFFNUMBER%TYPE,      
        IN_DESSTAFFNUMBER             IN LOG_EZOTC_EICU.DESSTAFFNUMBER%TYPE,
        IN_CALLSTARTTIME              IN LOG_EZOTC_EICU.CALLSTARTTIME%TYPE,
        IN_CALLENDTIME                IN LOG_EZOTC_EICU.CALLENDTIME%TYPE,
        IN_MULTICALLYN                IN LOG_EZOTC_EICU.MULTICALLYN%TYPE,      
        IN_AUDIOFILEPATH              IN LOG_EZOTC_EICU.AUDIOFILEPATH%TYPE,
        IN_HOSPITALCODE               IN LOG_EZOTC_EICU.HOSPITALCODE%TYPE,
        IN_DESCRIPTION                IN LOG_EZOTC_EICU.DESCRIPTION%TYPE 
    )
    IS
    BEGIN
      INSERT INTO LOG_EZOTC_EICU
             (ID
             ,INSERTSTAFFNUMBER  
             ,ICU
             ,STATUS
             ,PATIENTNUMBER  
             ,ROOMNAME
             ,DEPSTAFFNUMBER
             ,DESSTAFFNUMBER
             ,CALLSTARTTIME
             ,CALLENDTIME
             ,MULTICALLYN
             ,AUDIOFILEPATH
             ,HOSPITALCODE
             ,DESCRIPTION)
      VALUES (--SEQ_LOG_EZOTC_EICU_ID.NEXTVAL
              1
             ,IN_INSERTSTAFFNUMBER  
             ,IN_ICU
             ,IN_STATUS
             ,IN_PATIENTNUMBER  
             ,IN_ROOMNAME
             ,IN_DEPSTAFFNUMBER
             ,IN_DESSTAFFNUMBER
             ,IN_CALLSTARTTIME
             ,IN_CALLENDTIME
             ,IN_MULTICALLYN
             ,IN_AUDIOFILEPATH
             ,IN_HOSPITALCODE
             ,IN_DESCRIPTION);
    END PC_EZOTC_INSERT_LOG; 
                          
          
    /**********************************************************************************************
    * Service Name : PC_EZOTC_SELECT_LOG
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    *       2021-03-18   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/
    PROCEDURE PC_EZOTC_SELECT_LOG (
        IN_ROOMNAME                   IN LOG_EZOTC_EICU.ROOMNAME%TYPE,        
        IN_HOSPITALCODE               IN LOG_EZOTC_EICU.HOSPITALCODE%TYPE,        
        RETURN_TABLE                  OUT SYS_REFCURSOR  
    )
    IS 
    BEGIN
    OPEN RETURN_TABLE FOR   
	    	SELECT A.INSERTSTAFFNUMBER
	    	      ,A.ICU            
	    	      ,A.STATUS     
	    		  ,A.PATIENTNUMBER   
	    		  ,A.ROOMNAME
	    		  ,A.DEPSTAFFNUMBER
	    		  ,A.DESSTAFFNUMBER
	    		  ,A.CALLSTARTTIME
	    		  ,A.CALLENDTIME
	    		  ,A.MULTICALLYN
	    		  ,A.AUDIOFILEPATH
	    		  ,A.HOSPITALCODE
	    		  ,A.DESCRIPTION     
--	    		  ,(SELECT INSERTDATE
--                      FROM LOG_EZONTHECALL_NURSECALL
--                     WHERE ID =  (SELECT MAX(ID)
--                                    FROM LOG_EZONTHECALL_NURSECALL
--                                   WHERE STATUS            = 'BeforeTreating'
--                                     AND PATIENTNUMBER     = A.PATIENTNUMBER
--                                     AND NURSENUMBER       = A.NURSENUMBER
--                                     AND TRUNC(INSERTDATE) = TRUNC(A.INSERTDATE)
--                                  )
--                   ) CONNECTTIME
	    	  FROM LOG_EZOTC_EICU A
	    	 WHERE ROOMNAME  = IN_ROOMNAME  ;
    END PC_EZOTC_SELECT_LOG;     
                                    
    
   /**********************************************************************************************
    * Service Name : PC_EZOTC_SELECT_PATIENTINFO
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    *       2021-03-18   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/                                                                                    
    PROCEDURE PC_EZOTC_SELECT_PATIENTINFO (
        IN_PT_NO                      IN PCTPCPAM_DAMO.PT_NO%TYPE,        
        IN_PT_NM                      IN PCTPCPAM_DAMO.PT_NM%TYPE,        
        RETURN_TABLE                  OUT SYS_REFCURSOR    
    )
    IS
    BEGIN  
     OPEN RETURN_TABLE FOR   
	    	SELECT A.PT_NO
	    	      ,A.PT_NM            
	    	      ,A.SEX_TP_CD     
	    		  ,A.AGE
	    		  ,A.MED_DEPT_CD     --진료과
	    		  ,A.MED_DEPT_CD_NM  --진료과명
	    		  ,A.PT_CUR_PSTN_CD  --현위치
	    		  ,A.PT_CUR_PSTN_NM  --현위치명  
	    	  FROM XICU.EMEI012V A
	    	 WHERE A.PT_NO  = IN_PT_NO
	    	    OR A.PT_NM  = IN_PT_NM ;
    END PC_EZOTC_SELECT_PATIENTINFO;
    
    /**********************************************************************************************
    * Service Name : PC_EZOTC_SELECT_PATIENTINFO
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    * 2021-03-23   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/                                                                                    
    PROCEDURE PC_EZOTC_SELECT_USERLIST (
        RETURN_TABLE                  OUT SYS_REFCURSOR
    )
    IS 
    BEGIN
     OPEN RETURN_TABLE FOR   
	    	SELECT A.HSP_TP_CD                      
	    	      ,A.HIS_STF_NO
	    	      ,A.USR_NM    
	    	      ,A.WD_DEPT_CD
	    	      ,A.EPCN_YN
	    	  FROM HICU.UCCOCULH A    
	    	 WHERE A.LGOT_DTM IS NULL;
    
    END PC_EZOTC_SELECT_USERLIST;     
    
                      
   /**********************************************************************************************
    * Service Name : PC_EZOTC_SELECT_STAFFINFO
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    * 2021-03-23   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/                                                                                    
    PROCEDURE PC_EZOTC_SELECT_STAFFINFO (
        IN_HSP_TP_CD                 IN CNLRRUSD.HSP_TP_CD%TYPE,   
        IN_USR_NM                    IN CNLRRUSD.KOR_SRNM_NM%TYPE,  
        RETURN_TABLE                 OUT SYS_REFCURSOR
    )
    IS
    BEGIN
     OPEN RETURN_TABLE FOR   
	    	SELECT A.AADP_CD
				  ,A.STF_NM        USR_NM
				  ,A.TEL_NO
	    	  FROM XICU.EMEI013V A  -- 직원정보 조회
	    	 WHERE 1=1
--	    	   AND A.HSP_TP_CD = IN_HSP_TP_CD
	    	   AND A.STF_NM  LIKE ('%'+IN_USR_NM+'%') ;
    END PC_EZOTC_SELECT_STAFFINFO;                                                                   
END Pkg_ezOntheCall_EICU;
