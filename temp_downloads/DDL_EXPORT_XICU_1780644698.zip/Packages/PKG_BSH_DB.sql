
  CREATE OR REPLACE EDITIONABLE PACKAGE "XICU"."PKG_BSH_DB" 
IS
TYPE RETURNCURSOR IS REF CURSOR;

/*===================================================================================
* 서비스이름      : PC_BSH_IP_ADDR_BSTB_ISTL_INF
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : IP ADDRESS 로 BESTBOARD 설치 정보 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_SETTING_BY_IPADDR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_IP_ADDR_BSTB_ISTL_INF   ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_USR_LGIN
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : BESTBOARD 사용자 로그인.
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_USER_LOGIN
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_USR_LGIN                ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_LGIN_PWD      IN    VARCHAR2       /* 일반   비밀번호 */
                                         , IN_SEC_LGIN_PWD  IN    VARCHAR2       /* 암호화 비밀번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_ADS_PT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 입원환자 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_ADS_PT_LIST         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_RM_NO         IN    VARCHAR2      /* 실번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SYSDATETIME
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : DB 현재시간 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_GET_SYSDATETIME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SYSDATETIME             ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_ADS_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동 입원환자 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WARD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_ADS_PT_LIST          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_CP_PRM_CRCCM
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동별 병실현황조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_CP_PRM_CRCCM         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_DEPT_CD    IN    VARCHAR2      /* 병동번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 환자 리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_PT_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EMRM_CLS_CD   IN    VARCHAR2      /* 응급실분류코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_BSTB_MTD_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : BESTBOARD 진료과 리스트 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_BSTB_MTD_LIST           ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_TEAM_CB_PT_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 구역별 환자 수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_LOC_COUNT
*                 : 구역별(성인/소아/외상)이었으나 TO-BE 에서는 팀별로 변경.
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_TEAM_CB_PT_CNT     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_ALL_ITEM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 조회(모든항목)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_VITALSIGN_ALL_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_ALL_ITEM   ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_IO_ITEM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 I/O 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_VITAL_IO_BY_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_IO_ITEM    ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_SIHM_STS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 재원환자 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_STAY_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_SIHM_STS            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_INFC_MGMT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 감염관리 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_INFC_MGMT           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_DGNS_NM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 진단명 가져오기
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_DISEASE_NAME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_DGNS_NM_ASK          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID       IN    VARCHAR2      /* 원무접수ID */
                                         , IN_MED_DP_CD     IN    VARCHAR2      /* 진료과 코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_OP_NM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 수술명 가져오기
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_OPERATION_NAME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_OP_NM_ASK            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;


/*===================================================================================
* 서비스이름      : PC_BSH_DVAL_MDFM_CLA
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기본기록조회 환경반환
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DEFAULT_NOTETYPE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_DVAL_MDFM_CLA           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_TP           IN    VARCHAR2      /* 원무접수구분*/
                                       , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                       , IN_DR_STF_NO         IN    VARCHAR2      /* 의사직원번호 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_MDFM_CLS_PRD
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기록종류별 기간 설정 반환
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NOTETYPE_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_MDFM_CLS_PRD            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDFM_CLS_CD       IN    VARCHAR2      /* 서식지구분코드 */
                                         , IN_ALL_DP_YN         IN    VARCHAR2      /* 전체과체크여부  */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_PRD_MDFM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기록 기간별 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_SEARCH_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_PRD_MDFM             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDFM_CLS_CD       IN    VARCHAR2      /* 서식지구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_FULL_CHK          IN    VARCHAR2      /* 전체과체크여부 */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;
/*===================================================================================
* 서비스이름      : PC_BSH_PT_REC_HME_HST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 의무기록수진이력조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_MOBILE.PC_SEL_PATIENT_MED_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_REC_HME_HST          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_SEL_PT_REC_HME_HST_RCDC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 의무기록수진이력별기록지조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_MOBILE.PC_SEL_RECORDS_MED_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_SEL_PT_REC_HME_HST_RCDC     ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_PACT_TP           IN    VARCHAR2      /* 원무접수코드*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_USE_EQUP_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 사용 장비 카운트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_USE_EQUIP_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_USE_EQUP_CNT        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_MV_INOT_PT_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU별 일주일간 전출입 환자 수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PT_IN_OUT_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_MV_INOT_PT_CNT      ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : pc_sel_icu_mv_use_count
* 최초 작성일 : 2011.11
* 최초 작성자 : 이지케어텍 김승기
* description : ICU 별 MV(Management Ventilator) 사용현황
                (AC(VC,PC), SIMV(VC,PC), PSV,   CPAP, BIBAP) -> MICU만 해당
                (HFOV,      SIMV(VC,PC), NCPAP, HFS        ) -> NICU만 해당
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_MV_USE_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_MV_USE_STS          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_MEMO
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 조회(모든항목)
                  : IN_ASKTYPE : SINGLE
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : 210130(MEMO)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_RECORD_MEMO
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_RECORD_MEMO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_MEMO       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXMRAD_CATEGORY
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 영상검사 Filter 항목조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXMRAD_CATEGORY         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_USE_YN        IN    VARCHAR2      /* 사용여부  */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(진검)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMSPC_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMRAD_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(영상)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMRAD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMRAD_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMFUN_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     :  검사결과 조회(기능) 
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMFUN_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMFUN_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMPAT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(병리)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMPAT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMPAT_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_DAY
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 일별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_DAY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_DAY             ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_STATUS        IN    VARCHAR2      /* 상태 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_WEEK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 주별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_WEEK
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_WEEK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_MONTH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 월별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_MONTH
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_MONTH           ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASK_MON       IN    VARCHAR2      /* 조회월 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_ORD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별 오더조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_ORD_ASK              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* DEVICE ID */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병원구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 시작일자 */
                                         , IN_TODATE        IN    VARCHAR2      /* 종료일자 */
                                         , IN_SORT          IN    VARCHAR2      /* 1 */
                                         , IN_INCLUDE       IN    VARCHAR2      /* NULL */
                                         , IN_DP_CD         IN    VARCHAR2      /* NULL */
                                         , IN_PACT_TP       IN    VARCHAR2      /* NULL */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 ALERT 정보 조회 (AS-IS 38~42통합)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_DRUG
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_ETC
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_INFECTION
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ETC
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ADE_SIGNAL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_ALERT_ASK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR_ALRG  OUT   RETURNCURSOR  /* 환자알러지정보 */
                                         , OUT_CURSOR_INFC  OUT   RETURNCURSOR  /* 환자감염정보 */
                                         , OUT_CURSOR_SYMP  OUT   RETURNCURSOR  /* 환자증상정보 */
                                         , OUT_CURSOR_PRGN  OUT   RETURNCURSOR  /* 환자임신수유정보 */
                                         , OUT_CURSOR_SYMP_MASTER  OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_GET_EXAM_TOTAL
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 모든검사 결과 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_GET_EXAM_TOTAL          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_USE_YN        IN    VARCHAR2      /* 사용여부  */
                                         , OUT_CURSOR1      OUT   RETURNCURSOR  /* 환자별 검체검사 커서 */
                                         , OUT_CURSOR2      OUT   RETURNCURSOR  /* 환자별 영상검사 커서 */
                                         , OUT_CURSOR3      OUT   RETURNCURSOR  /* 환자별 기능검사 커서 */
                                         , OUT_CURSOR4      OUT   RETURNCURSOR )/* 환자별 병리검사 커서 */
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMRAD_FILTER
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(영상) - 필터
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMRAD_FILTER          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_EXRS_CTG_ID   IN    VARCHAR2      /* 영상검사 필터 불류코드 (',') 형식으로  */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_AMS_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 투약내역조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MEDICATION
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_AMS_ASK              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_ORD_DT        IN    VARCHAR2      /* 오더일자 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_NDRC_PRD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 간호일지조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NURSE_CARE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_NDRC_PRD_ASK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CHRM_CRCCM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장 대기 현황조회 - 고위험 산모실만
                    분만장 수술 현황조회 
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WAIT_EBBDVLMT
                    PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NICU_OPINFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHRM_CRCCM              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_WAIT_CURSOR  OUT   RETURNCURSOR 
                                         , OUT_OP_CURSOR    OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_ITEM_PRD
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검체검사 항목별 기간별 검사결과 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAM_SPC_ITEM_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_ITEM_PRD        ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_TST_CD        IN    VARCHAR2      /* 검사항목(|검사항목ID1|검사항목ID2|)*/
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_WEIGHT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰 기록 기간별 체중 조회
                  : IN_ASKTYPE : SINGLE
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : 21006(WEIGHT)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_RECORD_WEIGHT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_WEIGHT        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                            , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                            , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                            , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                            , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                            , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                            , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                            , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                            , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                            , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                            , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_PT_DTL_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병실환자상세조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_PATIENT_DETAIL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_PT_DTL_ASK           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_PT_DTL_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU환자상세조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PAT_RECENT_VITAL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_PT_DTL_ASK          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_NICU_INIT_NR_REC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : NICU 초기간호기록 - 출생,체중,주수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NICU_MRFNDT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_NICU_INIT_NR_REC        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_ODRER_INF
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 타과의뢰 정보
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_CONSULT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_ODRER_INF          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : pc_BSH_EMRM_SIHS_PT_STTS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 재원환자 통계
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE pc_BSH_EMRM_SIHS_PT_STTS       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ASK_DATE          IN    VARCHAR2      /* 조회일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_NR_CHOV
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별간호인수인계
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NURSE_TAKING_OVER
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_NR_CHOV              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE            IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_WRK_DR
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실근무의사
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_WORK_DOCTOR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_WRK_DR             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_BED_CRCCM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU병상현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_ICU_BED_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_BED_CRCCM           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_LGIN_STF_TAG_ID
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 직원 TAG ID 를 통한 로그인
* AS-IS 쿼리 정보 : 61.PKG_SMARTCARE_DASHBOARD.PC_SEL_LOGIN_BY_TAG_ID
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_LGIN_STF_TAG_ID         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_STF_TAG_ID    IN    VARCHAR2      /* 직원증 TAG ID */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_PT_NR_ELS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동환자별간호경과
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_PT_NR_ELS            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_INIT_NR_REC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자초기간호기록 (응급, 병동)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_INIT_NR_REC          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PSNY_ODRER_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 본인타과의뢰목록
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_REQ_PATIENT_BY_DR_ID
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PSNY_ODRER_LIST         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_DR_STF_NO         IN    VARCHAR2      /* 의사직원번호 */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 시작일자 */
                                         , IN_TODATE            IN    VARCHAR2      /* 종료일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PSNY_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 본인환자리스트조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_MY_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PSNY_PT_LIST            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WHL_PT_SRCH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 전체환자검색조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WHL_PT_SRCH             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_VTLR_MODE_VAL
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별인공호흡기모드값
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_LAST_VENT_VALUE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_VTLR_MODE_VAL        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASK_DATE          IN    VARCHAR2      /* 조회일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_SEL_DP_FORM_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 과별서식리스트조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_MEDDEPT_RECORD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_SEL_DP_FORM_LIST            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDRC_ID           IN    VARCHAR2      /* 의무기록서식ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_OP_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 수술장환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OP_PT_LIST              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_OPDATE            IN    VARCHAR2      /* 수술일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;
/*===================================================================================
* 서비스이름      : PC_BSH_OP_NM_TRAN_LST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 수술명 치환 리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_REPLACE_OPNAME_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OP_NM_TRAN_LST          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_ITEM_CHBR_STS
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 항목별분만상태
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_MRCRINT_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ITEM_CHBR_STS           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR1          OUT   RETURNCURSOR  /* 임신주수 리턴 커서*/
                                         , OUT_CURSOR2          OUT   RETURNCURSOR )/* 분류코드 산과 리턴커서 */
;

/*===================================================================================
* 서비스이름      : PC_BSH_OBSS_LBPN_REC_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 산과진통기록리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PARTO_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OBSS_LBPN_REC_LIST      ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_OBSS_LBPN_REC_DTL
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 산과진통기록상세
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_PARTO_DETAIL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OBSS_LBPN_REC_DTL       ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_MDRC_ID       IN    VARCHAR2      /* 진료기록ID */
                                         , IN_MDRC_FOM_SEQ  IN    VARCHAR2      /* 진료기록개정순번 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SCAN_LDAT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자스캔자료리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SCAN_IMAGE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SCAN_LDAT_LIST       ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE        IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_SCAN_FORM_CD  IN    VARCHAR2      /* SCAN서식코드*/
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드*/
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_GCS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별임상관찰기록GCS
                  : IN_ASKTYPE : CTG
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : GCS
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENT_GCS_DATA
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_GCS        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_PT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_PT_LIST         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EXRM_CD       IN    VARCHAR2      /* 검사실코드 OUT_CURSOR1 리턴값*/
                                         , IN_EXRM_CD1      IN    VARCHAR2      /* 검사실코드 OUT_CURSOR2 리턴값*/
                                         , IN_EXRM_CD2      IN    VARCHAR2      /* 검사실코드 OUT_CURSOR3 리턴값*/
                                         , OUT_CURSOR1      OUT   RETURNCURSOR  /* 혈관조영실 환자리스트 */
                                         , OUT_CURSOR2      OUT   RETURNCURSOR  /* 혈관조영실 시술환자 */
                                         , OUT_CURSOR3      OUT   RETURNCURSOR  /* 혈관조영실 시술환자 카운트 */
                                         , OUT_CURSOR4      OUT   RETURNCURSOR )/* 혈관조영실 공지사항 */
;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_AOM_PT
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 시술환자
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_OP_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_AOM_PT          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EXRM_CD       IN    VARCHAR2      /* 검사실코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_ANPN
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 공지사항
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_NOTICE_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_ANPN           ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_RRT_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : RRT환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_RRT_PT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_RRT_PT_LIST             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_WD_NO             IN    VARCHAR2      /* 병동번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_OP_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동별수술환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PT_LIST_BY_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_OP_PT_LIST           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_WD_NO             IN    VARCHAR2      /* 병동번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_LIST2
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_PT_LIST         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR1          OUT   RETURNCURSOR  /* 분만장환자리스트 */
                                         , OUT_CURSOR2          OUT   RETURNCURSOR )/* 분만장현황황조회 */
;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_CRCCM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장현황황조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_CRCCM_ASK       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_SCHD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장스케쥴조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_SCHEDULE_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_SCHD_ASK        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_BLOD_RDY_STS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자혈액준비상태
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_BLOOD_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_BLOD_RDY_STS         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH_ACV
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색(ACTIVE)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_ACTIVE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH_ACV             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH_INAT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색(INACTIVE)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_INACTIVE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH_INAT            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_HME_HST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자수진이력
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_RECORD_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_HME_HST              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH                 ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , IN_LOGIN_SID         IN    VARCHAR2
                                         , IN_LOGIN_DEPT_CD     IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_RAD_CTG_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 영상검사 FILTER 정보
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_RAD_CTG_ASK             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_USE_YN            IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAM_LIST_CNT
* 최초 작성일     : 2014.01
* 최초 작성자     : 조은영
* DESCRIPTION     : 모든검사 리스트 카운트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAM_LIST_CNT           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE            IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST_FILTER
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 검체 필터 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST_FILTER    ( IN_SQL_ID       IN    VARCHAR2      /* SQL ID */
                                    , IN_STF_NO       IN    VARCHAR2      /* 직원번호 */
                                    , IN_IP_ADDR      IN    VARCHAR2      /* IP ADDRESS */
                                    , IN_HSP_TP_CD    IN    VARCHAR2      /* 병동구분코드 */
                                    , IN_PT_NO        IN    VARCHAR2      /* 환자번호 */
                                    , IN_FRDATE       IN    VARCHAR2      /* 조회 시작일 */
                                    , IN_TODATE       IN    VARCHAR2      /* 조회 종료일 */
                                    , IN_TYPE         IN    VARCHAR2      /* 구분 */
                                    , OUT_CURSOR      OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_FILTER_VALUE
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 조회(진검 필터 항목 선택시)
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_FILTER_VALUE    ( IN_SQL_ID       IN    VARCHAR2      /* SQL ID */
                                   , IN_STF_NO       IN    VARCHAR2      /* 직원번호 */
                                   , IN_IP_ADDR      IN    VARCHAR2      /* IP ADDRESS */
                                   , IN_HSP_TP_CD    IN    VARCHAR2      /* 병동구분코드 */
                                   , IN_PT_NO        IN    VARCHAR2      /* 환자번호 */
                                   , IN_FRDATE       IN    VARCHAR2      /* 조회 시작일 */
                                   , IN_TODATE       IN    VARCHAR2      /* 조회 종료일 */
                                   , IN_START        IN    VARCHAR2      /* 조회시작 인덱스 */
                                         , IN_END          IN    VARCHAR2      /* 조회종료 인덱스 */
                                   , IN_TYPE         IN    VARCHAR2      /* 구분 */
                                   , IN_EXAMCODE     IN    VARCHAR2      /* 검사코드 */
                                   , OUT_CURSOR      OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST_PAGING
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 조회(진검) 페이징
* AS-IS 쿼리 정보 :          
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST_PAGING     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_START         IN    VARCHAR2      /* 조회시작 인덱스 */
                                         , IN_END           IN    VARCHAR2      /* 조회종료 인덱스 */
                                         , IN_TYPE          IN    VARCHAR2      /* 구분 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
; 

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_STDPT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_STDPT               ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_JOBGUBN           IN    VARCHAR2      /* W:병동별, D:진료과별 */
                                         , IN_GUBN              IN    VARCHAR2      /* 작업구분 (병동별 조회 시만 : 3)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일 */
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일 */
                                         , IN_JOBTYPE           IN    VARCHAR2      /* IN_JOBTYPE : 104 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_STAYPTMNG
* 최초 작성일     : 2013.05
* 최초 작성자     : 김승기
* DESCRIPTION     : 재원환자관리
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_STAYPTMNG           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2
                                         , IN_MED_DEPT_CD       IN    VARCHAR2
                                         , IN_WD_DEPT_CD        IN    VARCHAR2
                                         , IN_CHDR_STF_NO       IN    VARCHAR2
                                         , IN_ANDR_STF_NO       IN    VARCHAR2  
                                         , IN_CPCD              IN    VARCHAR2   
                                         , IN_STAYDAY_FR        IN    VARCHAR2
                                         , IN_STAYDAY_TO        IN    VARCHAR2
                                         , IN_STAYMNG           IN    VARCHAR2
                                         , IN_SPCMNG            IN    VARCHAR2   
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_BSH_IMAF_SRAF_TP
* 최초 작성일 : 2012.08
* 최초 작성자 : 이지케어텍 김승기
* DESCRIPTION : 진료과별 내/외과계 구분
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_IMAF_SRAF_TP            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_GUBN              IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_BSH_UPD_RRT_STS
* 최초 작성일 : 2011.11
* 최초 작성자 : 이지케어텍 김승기
* description : RRT 환자 정보 업데이트
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_UPD_RRT_STS           ( IN_SQL_ID            IN    VARCHAR2   /* SQL ID */
                                       , IN_STF_NO            IN    VARCHAR2   /* 직원번호 */
                                       , IN_IP_ADDR           IN    VARCHAR2   /* IP ADDRESS */
                                       , IN_HSP_TP_CD         IN    VARCHAR2   /* 병동구분코드 */
                                       , IN_RRT_DTL_ID        IN    VARCHAR2   /* RRT 상세 ID */
                                       , IN_PACT_ID           IN    VARCHAR2   /* 원무접수ID */
                                       , IN_REC_CFMT_STS      IN    VARCHAR2   /* 결과 상태  */
                                       , IN_RRT_CCLT_RSN_CNTE IN    VARCHAR2   /* 해제 사유 */
                                       , IO_ERRYN             IN OUT VARCHAR2  /* ERROR Y/N */
                                       , IO_ERRMSG            IN OUT VARCHAR2 )/* MESSAGE */
;

/*===================================================================================
* 서비스이름      : PC_BSH_FTP_INFO
* 최초 작성일     : 2017.02.20
* 최초 작성자     : 조은영
* DESCRIPTION     : FTP 접근 정보 (기능검사 - 이미지 결과)
* AS-IS 쿼리 정보 :          
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_FTP_INFO     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                              , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                              , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                              , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                              , OUT_CURSOR       OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_PT_ACCESS_REASON
* 최초 작성일     : 2017-05-23
* 최초 작성자     : 김진균
* DESCRIPTION     : 환자 선택 사유 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_PT_ACCESS_REASON ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_PT_PROTECTED
* 최초 작성일     : 2017-05-30
* 최초 작성자     : 김진균
* DESCRIPTION     : 환자 사생활 및 정보 보호 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_PT_PROTECTED ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                  , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                  , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                  , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */ 
                                  , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                  , IN_WK_SID            IN    VARCHAR2      /* SID */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_DO_MEDDEPT_INFO
* 최초 작성일     : 2017-07-04
* 최초 작성자     : 김태운
* DESCRIPTION     : 의사별 진료과 등록정보 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_DO_MEDDEPT_INFO ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                     , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */ 
                                     , IN_WK_SID            IN    VARCHAR2      /* SID */
                                     , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_DO_CNLMRPAD_INFO
* 최초 작성일     : 2017-07-04
* 최초 작성자     : 김태운
* DESCRIPTION     : 의사별,환자별 의사 협진정보 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_DO_CNLMRPAD_INFO ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
                                      , IN_WK_SID            IN    VARCHAR2      /* SID */
                                      , IN_PT_NO             IN    VARCHAR2      /* 등록번호 */ 
                                      , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */ 
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_BSH_INS_BESTBOARD_LOG
* 최초 작성일 : 2017.2.14
* 최초 작성자 : 네오젠소프트 김진균
* description : Lob Table에 삽입
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_INS_BESTBOARD_LOG           ( IN_SYS_NM                       IN     VARCHAR2   /* 시스템 명 */
                                             , IN_CLIENT_IP_ADDR               IN     VARCHAR2   /* 클라이언트 IP */
                                             , IN_CLIENT_DEPT_CD               IN     VARCHAR2   /* 부서 코드 */
                                             , IN_CLIENT_PC_MEMORY             IN     VARCHAR2   /* 메모리 사용량 */
                                             , IN_LOGIN_STF_NO                 IN     VARCHAR2   /* 로그인 직원 사번 */
                                             , IN_ACCESS_SERVER                IN     VARCHAR2   /* 접근 서버 IP */
                                             , IN_PROC_TYPE                    IN     VARCHAR2   /* 프로시저 타입  */
                                             , IN_PROC_NM                      IN     VARCHAR2   /* 프로시저 명 */
                                             , IN_PROC_COMMENT                 IN     VARCHAR2   /* 프로시저 설명 */
                                             , IN_PROC_PARAM_INFO              IN     VARCHAR2   /* 파라미터 정보 */
                                             , IN_DB_CALL_START_DTM            IN     VARCHAR2   /* 데이터베이스 호출 시작시간 */
                                             , IN_DB_CALL_END_DTM              IN     VARCHAR2   /* 데이터베이스 호출 종료시간 */
                                             , IN_CLIENT_BINDING_END_DTM       IN     VARCHAR2   /* 클라이언트 바인딩 완료시간 */
                                             , IN_DB_CALL_PROGRESS_TM          IN     VARCHAR2   /* 데이터베이스 호출 경과시간(초) */
                                             , IN_CLIENT_BINDING_PROGRESS_TM   IN     VARCHAR2   /* 클라이언트 바인딩 경과시간(초) */
                                             , IN_ALL_PROCESS_PROGRESS_TM      IN     VARCHAR2   /* 데이터베이스 호출 + 클라이언트 바인딩 경과시간(초) */
                                             , IN_DATA_SIZE                    IN     VARCHAR2   /* 조회한 데이터 사이즈(Byte) */
                                             , IN_CLIENT_LOGIC_PATH            IN     VARCHAR2   /* 클라이언트 바인딩 로직 구간 경로 */
                                             , IO_ERRYN                        IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG                       IN OUT VARCHAR2 ) /* MESSAGE */
;

/*==================================================================================
* 서비스이름  : PC_INS_PT_ACCESS_LOG
* 최초 작성일 : 2017.05.22
* 최초 작성자 : 김진균
* DESCRIPTION : 선택사유 입력 저장
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_INS_PT_ACCESS_LOG( IN_SQL_ID                    IN     VARCHAR2      /* SQL ID */
                                  , IN_STF_NO                  IN     VARCHAR2      /* 직원번호 */
                                  , IN_IP_ADDR                  IN     VARCHAR2      /* IP 주소 */
                                  , IN_HSP_TP_CD               IN     VARCHAR2      /* 병원구분코드 */
                                  , IN_SID                     IN     VARCHAR2      /* SID */
                                  , IN_PT_NO               IN     VARCHAR2     /* 환자번호  */
                                  , IN_IFSC_PT_RDNG_APLC_RSN_CD        IN     VARCHAR2  /* 정보보호환자열람신청사유 코드  */
                                  , IN_MTD_DEPT_CD             IN     VARCHAR2     /* 진료과부서코드  */
                                  , IN_PACT_TP_CD              IN     VARCHAR2     /* 원무접수 코드   */
                                  , IN_PT_CHC_CNTE               IN     VARCHAR2     /* 환자선택 내용  */
                                  , IN_PT_AVT_YN               IN     VARCHAR2   /* 환자활성여부  */
                                  , IN_NRV_PSYC_YN             IN     VARCHAR2    /* 신경정신과 여부 */
                                  , IN_MDREC_PT_CHC_YN             IN     VARCHAR2  /*  의무기록환자 선택여부  */
                                  , IO_ERRYN                   IN OUT VARCHAR2
                                  , IO_ERRMSG                  IN OUT VARCHAR2 )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LIST
* 최초 작성일     : 2018.01.02
* 최초 작성자     : 김태운
* DESCRIPTION     : MFICU(고위험산모치료실) 대기 환자 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LIST          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LOG_LIST
* 최초 작성일     : 2018.01.02
* 최초 작성자     : 김태운
* DESCRIPTION     : MFICU(고위험산모치료실) 저장 로그 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LOG_LIST      ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_BSH_UPD_MFICU_LOG_LIST
* 최초 작성일 : 2018.01.02
* 최초 작성자 : 김태운
* DESCRIPTION : MFICU(고위험산모치료실) 환자 로그 수정
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_UPD_MFICU_LOG_LIST  ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                     , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                     , IN_PACT_ID           IN     VARCHAR2     /* 원무접수아이디 */
                                     , IN_PT_NO             IN     VARCHAR2     /* 환자번호 */
                                     , IN_MED_DEPT_CD       IN     VARCHAR2     /* 진료부서코드 */
                                     , IN_WD_DEPT_CD        IN     VARCHAR2     /* 병동부서코드 */
                                     , IN_CLCTN_WD_DEPT_CD  IN     VARCHAR2     /* 현위치병동부서코드 */
                                     , IN_USE_YN            IN     VARCHAR2     /* 사용여부 */  
                                     , IO_ERRYN             IN OUT VARCHAR2     /* ERROR Y/N */
                   , IO_ERRMSG            IN OUT VARCHAR2 )   /* MESSAGE */
;

/*==================================================================================
* 서비스이름  : PC_MOM_SEL_NURDUTY_WORKLIST
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 worklist 조회 (D/E/N에 따라 시간대별로 조회)
*               Duty별 시간표출조건
*               D 07:00 ~ 15:59
*               E 15:00 ~ 23:59
*               N 22:00 ~ 07:59 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_SEL_NURDUTY_WORKLIST ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_PLWK_WRK_CLS_CD   IN     VARCHAR2      /* DUTY */ 
                                      , IN_WRK_DT            IN     VARCHAR2      /* 기준일자 */
                                      , IN_NR_TEAM_TP_CD     IN     VARCHAR2      /* 간호팀구분코드*/
                                      , IN_PLWK_DEPT_CD      IN     VARCHAR2      /* 근무지부서코드 */
                                      , OUT_CURSOR           OUT    RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_MOM_SEL_EM_WORKLIST
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 응급실 worklist 조회 (N0000085) 팀 선택 하여 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_SEL_EM_WORKLIST      ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_EMRM_TEAM_CTG_CD  IN     VARCHAR2      /* 응급팀구분코드*/
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_MOM_NURSING_DUTY_INFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 부서팀 정보
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_NURDEPT_TEAM_INFO    ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_PLWK_DEPT_CD      IN     VARCHAR2      /* 부서코드*/
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;                                                                                                                                                                              

/*==================================================================================
* 서비스이름  : PC_MOM_PLCWRK_DEPTINFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호행정에서 사용하는 근무부서 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_PLCWRK_DEPTINFO      ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;

/*==================================================================================
* 서비스이름  : PC_MOM_EM_TEAMINFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 응급실에서 사용하는 팀 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_EM_TEAMINFO          ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
;
      
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 입실/퇴실 예정 환자 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_LIST      ( IN_SQL_ID           IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;       
                                         
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_COUNT
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_COUNT    ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;   
                                         
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_OP_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 수술 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_OP_LIST    ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;     
                                         
/*==================================================================================
* 서비스이름  : PC_EICU_INS_TEST_OP_INFO
* 최초 작성일 : 2021.03
* 최초 작성자 : 네오젠소프트 이원희
* description : 대시보드에서 검사 시술 내역 저장
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_INS_TEST_OP_INFO           ( IN_SQL_ID           IN     VARCHAR2      /* SQL ID */
                       , IN_STF_NO           IN     VARCHAR2      /* 직원번호 */
                                          , IN_IP_ADDR          IN     VARCHAR2      /* IP ADDRESS */
                                             , IN_ICU_TP_CD        IN     VARCHAR2
                       , IN_PT_NO            IN     VARCHAR2 
                       , IN_INPUT_DT         IN     VARCHAR2  /* 'hh24:mi'  */
                       , IN_HIST_SEQ         IN     VARCHAR2 
                       , IN_HSP_TP_CD        IN     VARCHAR2   
                       , IN_ITEM_TP_CD       IN     VARCHAR2
                       , IN_ITEM_CD          IN     VARCHAR2
                       , IN_ITEM_SUB_CD      IN     VARCHAR2 
                       , IN_MEMO             IN     VARCHAR2
                                             , IO_ERRYN            IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG           IN OUT VARCHAR2 ) /* MESSAGE */
                                             ;      
                                             
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_OP_INFO
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사 시술 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_OP_INFO       ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;       

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_COUNT
* 최초 작성일     : 2021.04.01
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술 카운트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_COUNT         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_ICU_TP_CD         IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;       
  
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_ITEM
* 최초 작성일     : 2021.04.05
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술 하위 항목 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_ITEM         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;
                                           
/*===================================================================================
* 서비스이름      : PC_EICU_TST_OP_LIST_DELETE
* 최초 작성일     : 2021.04.07
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술, 수술 삭제
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TST_OP_LIST_DELETE      ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */ 
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HIST_SEQ          IN    VARCHAR2      /* 순번 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */                                                 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
                                         ;                                           
                                           
  
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : 병원별 ICU 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_LIST    ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
																	, IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
;
                                                                                                                                                                             
END PKG_BSH_DB;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_BSH_DB" 
IS
/*======================================================================================================================
* SELECT   수정해야 될 부분 (201212 로 표시.
========================================================================================================================
* 01.PC_BSH_IP_ADDR_BSTB_ISTL_INF         : IP ADDRESS 로 BESTBOARD 설치 정보 조회 (AS-IS 정보 01.PKG_SMARTCARE_DASHBOARD.PC_SEL_SETTING_BY_IPADDR)
* 02.PC_BSH_USR_LGIN                      : BESTBOARD 사용자 로그인                (AS-IS 정보 02.PKG_SMARTCARE_DASHBOARD.PC_SEL_USER_LOGIN)
* 03.                                     : 사용안함                               (AS-IS 정보 03.PKG_SMARTCARE_DASHBOARD.PC_SEL_USER_LOGIN_BY_DEPT)
* 04.PC_BSH_ICU_ADS_PT_LIST               : ICU 입원환자 조회                      (AS-IS 정보 04.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST)
* 05.                                     : 사용안함                               (AS-IS 정보 05.PKG_SMARTCARE_DASHBOARD.PC_SEL_ROOMCOUNT_BY_WARD)
* 06.PC_BSH_SYSDATETIME                   : DB 현재시간 조회                       (AS-IS 정보 06.PKG_SMARTCARE_DASHBOARD.PC_SEL_GET_SYSDATETIME)
* 07.                                     : 사용안함                               (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WARD_VIEW)
* 08.PC_BSH_WD_ADS_PT_LIST                : 병동 입원환자 조회                     (AS-IS 정보 08.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WARD_LIST)
* 09.PC_BSH_WD_CP_PRM_CRCCM               : 병동별 병실현황조회                    (AS-IS 정보 09.PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_STATUS)
* 10.PC_BSH_EMRM_PT_LIST                  : 응급실 환자 리스트 조회                (AS-IS 정보 09.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_LIST)
* 11.PC_BSH_BSTB_MTD_LIST                 : BESTBOARD 진료과 리스트 조회           (AS-IS 정보 11.PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_LIST)
* 12.PC_BSH_EMRM_TEAM_CB_PT_CNT           : 응급실 구역별 환자 수                  (AS-IS 정보 12.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_LOC_COUNT)
* 13.PC_BSH_CLCO_REC_PRD_ALL_ITEM         : 임상관찰기록 기간별 조회(모든항목)     (AS-IS 정보 13.PKG_SMARTCARE_DASHBOARD.PC_SEL_VITALSIGN_ALL_ITEM)
* 14.                                     : 사용안함                               (AS-IS 정보 14.PKG_SMARTCARE_DASHBOARD.PC_SEL_VITALSIGN_BY_ITEM)
* 15.PC_BSH_CLCO_REC_PRD_IO_ITEM          : 임상관찰기록 기간별 I/O 조회           (AS-IS 정보 15.PKG_SMARTCARE_DASHBOARD.PC_SEL_VITAL_IO_BY_ITEM)
* 16.PC_BSH_ICU_SIHM_STS                  : ICU 재원환자 현황                      (AS-IS 정보 16.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_STAY_STATUS)
* 17.PC_BSH_ICU_INFC_MGMT                 : ICU 감염관리 현황                      (AS-IS 정보 17.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR)
* 18.PC_BSH_PT_DGNS_NM_ASK                : 환자의 진단명 가져오기                 (AS-IS 정보 18.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_DISEASE_NAME)
* 19.PC_BSH_PT_OP_NM_ASK                  : 환자의 수술명 가져오기                 (AS-IS 정보 19.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_OPERATION_NAME)
* 20.PC_BSH_DVAL_MDFM_CLA                 : 기본 기록조회 환경 반환                  (AS-IS 정보 29.PKG_SMARTCARE_DASHBOARD.PC_SEL_DEFAULT_NOTETYPE)
* 21.PC_BSH_MDFM_CLS_PRD                  : 기록종류별 기간 설정 반환                (AS-IS 정보 29.PKG_SMARTCARE_DASHBOARD.PC_SEL_NOTETYPE_PERIOD)
* 22.PC_BSH_PT_PRD_MDFM                   : 기록 기간별 조회                         (AS-IS 정보 29.PKG_SMARTCARE_DASHBOARD.PC_SEL_SEARCH_PERIOD)
* 23.PC_BSH_PT_REC_HME_HST                : 의무기록 수진이력 조회                   (AS-IS 정보 29.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MED_HISTORY)
* 24.PC_SEL_PT_REC_HME_HST_RCDC           : 의무기록 수진이력 별 기록지 조회         (AS-IS 정보 30.PKG_SMARTCARE_DASHBOARD.PC_SEL_RECORDS_MED_HISTORY)
* 25.PC_BSH_ICU_USE_EQUP_CNT              : ICU 사용 장비 카운트                   (AS-IS 정보 25.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_USE_EQUIP_COUNT)
* 26.PC_BSH_ICU_MV_INOT_PT_CNT            : ICU별 일주일간 전출입 환자 수          (AS-IS 정보 25.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PT_IN_OUT_COUNT)
* 27.PC_BSH_ICU_MV_USE_STS                : ICU 별 MV(MANAGEMENT VENTILATOR) 사용현황            (AS-IS 정보 25.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_MV_USE_COUNT)
* 28.PC_BSH_CLCO_REC_PRD_MEMO             : 임상관찰기록 기간별 조회(MEMO)         (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_RECORD_MEMO)
* 29.28항목과 통합                        : 임상관찰기록 기간별 조회(MEMO)         (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_RECORD_MEMO)
* 29.PC_BSH_EXMRAD_CATEGORY               : 영상검사 Filter 항목조회               (신규 : 통합된 29번 대신 추가)
* 30.PC_BSH_EXAMSPC_LIST                  : 검사결과 조회(진검)                    (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMSPC_LIST)
* 31.PC_BSH_EXAMRAD_LIST                  : 검사결과 조회(영상)                    (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMRAD_LIST)
* 32.PC_BSH_EXAMFUN_LIST                  : 검사결과 조회(기능)                    (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMFUN_LIST)
* 33.PC_BSH_EXAMPAT_LIST                  : 검사결과 조회(병리)                    (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMPAT_LIST)
* 34.PC_BSH_ORD_STS_DAY                   : 특정일 오더 상태 조회 - TIMELINE DAY   (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_DAY)
* 35.PC_BSH_ORD_STS_WEEK                  : 특정일 오더 상태 조회 - TIMELINE WEEK  (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_WEEK)
* 36.PC_BSH_ORD_STS_MONTH                 : 특정일 오더 상태 조회 - TIMELINE MONTH (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_MONTH)
* 37.PC_BSH_PT_ORD_ASK                    : 환자별 오더조회                        (AS-IS 정보 28.PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER)
* 38.PC_BSH_PT_ALERT_ASK (비고:38~42통합) : 환자의 ALERT 정보 조회                 (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_DRUG)
* 39.PC_BSH_GET_EXAM_TOTAL                : 38 번으로 통합                         (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_ETC)
* 40.PC_BSH_EXAMRAD_FILTER                : 검사결과 조회(영상) - 필터
* 41.                                     : 38 번으로 통합                         (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ETC)
* 42.                                     : 38 번으로 통합                         (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ADE_SIGNAL)
* 43.PC_BSH_PT_AMS_ASK                    : 투약내역조회                           (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MEDICATION)
* 44.PC_BSH_NDRC_PRD_ASK                  : 간호일지 조회                          (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NURSE_CARE)
* 45.PC_BSH_CHRM_CRCCM                    : 분만장 대기 현황조회 - 고위험 산모실만 (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WAIT_EBBDVLMT)
* 46.PC_BSH_CHRM_CRCCM (45번 1개로 통합)  : 분만장 수술 현황조회                   (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NICU_OPINFO)
* 47.                                     : 사용안함                               (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NO_EXAM_ORDER)
* 48.PC_BSH_EXAMSPC_ITEM_PRD              : 검체검사 항목별 기간별 검사결과 조회   (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAM_SPC_ITEM_PERIOD)
* 49.PC_BSH_CLCO_REC_PRD_WEIGHT           : 임상관찰 기록 기간별 체중 조회         (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_RECORD_WEIGHT)
* 50.                                     : 사용안함 08로 대체                     (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_PATIENT_LIST_NEW)
* 51.PC_BSH_WD_PT_DTL_ASK                 : 병실환자상세조회                       (AS-IS 정보 07.PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_PATIENT_DETAIL)
* 52.PC_BSH_ICU_PT_DTL_ASK                : ICU환자상세조회                        (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PAT_RECENT_VITAL)
* 53.PC_BSH_NICU_INIT_NR_REC              : NICU 초기간호기록 - 출생,체중,주수     (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_NICU_MRFNDT_INFO)
* 54.PC_BSH_EMRM_ODRER_INF                : 응급실 타과의뢰 정보                   (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_CONSULT_INFO)
* 55.PC_BSH_EMRM_SIHS_PT_STTS             : 응급실 재원환자 통계                   (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_STATUS)
* 56.PC_BSH_PT_NR_CHOV                    : 환자별간호인수인계                     (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_NURSE_TAKING_OVER)
* 57.PC_BSH_EMRM_WRK_DR                   : 응급실 근무의사                        (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_WORK_DOCTOR)
* 58.사용안함                             : 응급실 환자 상세 정보                  (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_DETAIL)
* 59.사용안함                             : 응급실 구역별 통계                     (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_LOCATION_STATUS)
* 60.PC_BSH_ICU_BED_CRCCM                 : ICU병상현황                            (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_ICU_BED_STATUS)
* 61.PC_BSH_LGIN_STF_TAG_ID               : 직원 TAG ID 를 통한 로그인             (AS-IS 정보 61.PKG_SMARTCARE_DASHBOARD.PC_SEL_LOGIN_BY_TAG_ID)
* 62.사용안함                             : 분만장 환자 리스트 조회(85번 사용)     (AS-IS 정보 61.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_LIST)
* 63.PC_BSH_WD_PT_NR_ELS                  : 병동환자별간호경과                     (AS-IS 정보 63.PKG_SMARTCARE_DASHBOARD.PC_SEL_NURSE_PROGRESS_WARD)
* 64.PC_BSH_PT_INIT_NR_REC                : 환자초기간호기록 (응급, 병동)          (AS-IS 정보 64.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_WARD)
* 65.64번 통합                            : 응급환자초기간호기록                   (AS-IS 정보 65.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_ER)
* 66.사용안함                             : 기록지통합으로 의미없음                (AS-IS 정보 65.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_VITALSIGN_ITEM) 
* 67.PC_BSH_PSNY_ODRER_LIST               : 본인타과의뢰목록                       (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_REQ_PATIENT_BY_DR_ID)
* 68.PC_BSH_PSNY_PT_LIST                  : 본인환자리스트조회                     (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.pc_sel_my_patient_list)
* 69.PC_BSH_WHL_PT_SRCH                   : 전체환자검색조회                       (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.pc_sel_patient_search)
* 70.PC_BSH_PT_VTLR_MODE_VAL              : 환자별인공호흡기모드값                 (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_LAST_VENT_VALUE)
* 71.PC_SEL_DP_FORM_LIST                  : 과별서식리스트조회                     (AS-IS 정보 38.PKG_SMARTCARE_DASHBOARD.PC_SEL_MEDDEPT_RECORD)
* 72.PC_BSH_OP_PT_LIST                    : 수술장환자리스트                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PATIENT_LIST, PC_SEL_OP_PATIENT_LIST2) -- 72, 92
* 73.PC_BSH_OP_NM_TRAN_LST                : 수술명치환리스트                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_REPLACE_OPNAME_LIST)
* 74.PC_BSH_ITEM_CHBR_STS                 : 항목별분만상태                       (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_MRCRINT_ITEM)
* 75.PC_BSH_OBSS_LBPN_REC_LIST            : 산과진통기록리스트                   (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PARTO_LIST)
* 76.PC_BSH_OBSS_LBPN_REC_DTL             : 산과진통기록상세                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_PARTO_DETAIL)
* 77.PC_BSH_PT_SCAN_LDAT_LIST             : 환자스캔자료리스트                   (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SCAN_IMAGE)
* 78.PC_BSH_CLCO_REC_PRD_GCS              : 환자별임상관찰기록GCS                (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENT_GCS_DATA)
* 79.PC_BSH_AGPY_RM_PT_LIST               : 혈관조영실 환자리스트                (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_PATIENT_LIST)
* 80.79번으로 통합                        : 혈관조영실 시술환자                  (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_OP_PATIENT_LIST)
* 81.79번으로 통합                        : 혈관조영실 공지사항                  (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_NOTICE_INFO)
* 82.PC_BSH_RRT_PT_LIST                   : RRT환자리스트                        (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.pc_sel_rrt_pt_info)
* 83.PC_BSH_WD_OP_PT_LIST                 : 병동별수술환자리스트                 (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PT_LIST_BY_WARD)
* 84.72번 같이 사용                       : 수술장환자리스트                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PATIENT_LIST2, PC_SEL_OP_PATIENT_LIST2) -- 72, 92
* 85.PC_BSH_CHBR_RM_PT_LIST               : 분만장환자리스트                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_LIST2)
* 86.85 와 통합                           : 분만장현황황조회                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_STATUS)
* 87.PC_BSH_CHBR_RM_SCHD_ASK              : 분만장스케쥴조회                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_SCHEDULE_LIST)
* 88.PC_BSH_PT_BLOD_RDY_STS               : 환자혈액준비상태                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_BLOOD_STATUS)
* 89.PC_BSH_PT_SRCH_ACV                   : 환자검색(ACTIVE)                     (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_ACTIVE)
* 90.PC_BSH_PT_SRCH_INAT                  : 환자검색(INACTIVE)                   (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_INACTIVE)
* 91.PC_BSH_PT_HME_HST                    : 환자수진이력                         (AS-IS 정보 73.PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_RECORD_HISTORY)
* 92.PC_BSH_PT_SRCH                       : 환자검색 
* 93.PC_BSH_RAD_CTG_ASK                   : 영상검사 FILTER 정보  
* 94.PC_BSH_EXAM_LIST_CNT                 : 검사결과 리스트 카운트 조회
* 95.PC_BSH_EXAMSPC_LIST_FILTER           : 검사결과 조회(진검 필터)                  2014.03.19 조은영 생성 (페이징 기법을 위해 생성)      
* 96.PC_BSH_EXAMSPC_FILTER_VALUE          : 검사결과 조회(진검 필터 항목 선택시)      2014.03.21 조은영 생성 (페이징 기법을 위해 생성) 
* 97.PC_BSH_EXAMSPC_LIST_PAGING           : 검사결과 조회(진검) 페이징                2014.03.21 조은영 생성 (페이징 기법을 위해 생성)
* 98.PC_BSH_FTP_INFO                      : FTP 접근 정보 (기능검사 - 이미지 결과)    2017.02.20 조은영
* 99.PC_BSH_SEL_PT_ACCESS_REASON          : 환자 선택 사유 조회                       2017.05.24 김진균
*100.PC_BSH_SEL_PT_PROTECTED              : 환자 사생활 및 정보 보호 조회             2017.05.30 김진균
*101.PC_BSH_SEL_DO_MEDDEPT_INFO           : 의사별 진료과 등록정보 조회               2017.07.04 김태운
*102.PC_BSH_SEL_DO_CNLMRPAD_INFO          : 의사별,환자별 의사 협진정보 조회          2017.09.07 김태운
*110.PC_BSH_SEL_MFICU_LIST                : MFICU(고위험산모치료실) 대기 환자 조회    2018.01.02 김태운
*111.PC_BSH_SEL_MFICU_LOG_LIST            : MFICU(고위험산모치료실) 저장 로그 조회    2018.01.02 김태운
*112.PC_MOM_SEL_NURDUTY_WORKLIST          : 간호 worklist 조회 (D/E/N에 따라 시간대별로 조회)       2020.04.14 김태운
*113.PC_MOM_SEL_EM_WORKLIST               : 간호 응급실 worklist 조회 (N0000085) 팀 선택 하여 조회  2020.04.14 김태운
*114.PC_MOM_NURDEPT_TEAM_INFO             : 간호 부서팀 정보                                        2020.04.14 김태운
*115.PC_MOM_PLCWRK_DEPTINFO               : 간호행정에서 사용하는 근무부서 리스트 조회              2020.04.14 김태운
*116.PC_MOM_EM_TEAMINFO                   : 응급실에서 사용하는 팀 리스트 조회                      2020.04.14 김태운

*117.PC_EICU_SEL_ICU_PT_IO_LIST        : ICU 당일 입실/퇴실 예정 환자 리스트 조회            2021.03.16 이원희   
*118.PC_EICU_SEL_ICU_PT_IO_COUNT          : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회      2021.03.16 이원희 
*119.PC_EICU_SEL_ICU_PT_OP_LIST        : ICU 당일 수술 리스트 조회                               2021.03.16 이원희 
=====================================================================================
* 지표관리 재원일 조회.
=====================================================================================
*103.PC_BSH_SEL_STDPT                     : 재원/퇴원환자 평균재원일수조회
*104.PC_BSH_SEL_STAYPTMNG                 : 재원환자관리 조회함 (AS-IS : PKG_BIL_APD500.PC_APIPLIST_SELECT_EMR )
*105.PC_BSH_IMAF_SRAF_TP                  : 진료과별 내/외과계 구분
=====================================================================================
* UPDATE
=====================================================================================
*201.PC_BSH_UPD_RRT_STS                   : RRT 환자 정보 업데이트
*202.PC_BSH_UPD_MFICU_LOG_LIST            : MFICU(고위험산모치료실) 환자 로그 수정
=====================================================================================
* INSERT
=====================================================================================
*301.PC_BSH_INS_BESTBOARD_LOG             : BESTBOARD 로그 삽입
*302.PC_INS_PT_ACCESS_LOG                 : 환자선택사유 삽입             
*303.PC_EICU_INS_TEST_OP_INFO        : 대시보드에서 검사 시술 내역 저장      2021.03.16 이원희
=====================================================================================
* DELETE
=====================================================================================
*401.PC_EICU_TST_OP_LIST_DELETE        : ICU 환자 검사, 시술, 수술 삭제       2021.03.16 이원희
=====================================================================================
                      
/*===================================================================================
* 서비스이름      : PC_BSH_IP_ADDR_BSTB_ISTL_INF
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : IP ADDRESS 로 BESTBOARD 설치 정보 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_SETTING_BY_IPADDR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_IP_ADDR_BSTB_ISTL_INF   ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_IP_ADDR_BSTB_ISTL_INF */
       A.IP_ADDR                                   IP_ADDR
     , A.ISTL_DEPT_CD                              ISTL_DEPT_CD
     , DECODE(A.ISTL_DEPT_CD, 'SICU', 'SICU'
                            , 'MICU', 'MICU'
                            , 'NICU', 'NICU'
                            , 'CICU', 'CICU'
                            , '42B', '신생아실'
                            , '42D', '분만장'
                            , 'ER', '응급실'
                            , 'OR', '수술부'
                            , 'RDA', '혈관조영실'
                            , 'RRT', 'RRT'
                            , 'WORK', 'WORKLIST' --20200420 간호워크리스트 메뉴 추가
                            , B.DEPT_NM)           LIST_DSP_NM
     , A.SORT_SEQ                                  SORT_SEQ
     , A.SCRN_TP_CD                                SCRN_TP_CD
     , A.ISTL_PSTN_NM                              ISTL_PSTN_NM
     , A.LIST_DSP_YN                               LIST_DSP_YN
     , A.HSP_TP_CD                                 HSP_TP_CD
     , A.AUTO_LGOT_USE_YN                          AUTO_LGOT_USE_YN
     , A.AUTO_LGOT_STU_CHR_VAL                     AUTO_LGOT_STU_CHR_VAL
     , A.SCSV_USE_YN                               SCSV_USE_YN
     , A.SCSV_STU_CHR_VAL                          SCSV_STU_CHR_VAL
  --FROM BSHDBDPD A   
   FROM HICU.DSHDBDPD A
     , PDEDBMSM B
 WHERE A.IP_ADDR = IN_IP_ADDR
   AND A.ISTL_DEPT_CD    = B.DEPT_CD(+)
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_IP_ADDR_BSTB_ISTL_INF' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_IP_ADDR_BSTB_ISTL_INF;

/*======================================================================================================================
* 서비스이름      : PC_BSH_USR_LGIN
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : BESTBOARD 사용자 로그인.
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_USER_LOGIN
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_USR_LGIN                ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_LGIN_PWD      IN    VARCHAR2       /* 일반   비밀번호 */
                                         , IN_SEC_LGIN_PWD  IN    VARCHAR2       /* 암호화 비밀번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SEC_LGIN_PWD       VARCHAR2(1000);
    V_DAMO_HASH_STR_DATA VARCHAR2(1000);
    V_SRCH_CNTE          VARCHAR2(4000);
    V_LGIN_CHK_CD        VARCHAR2(1000);
BEGIN
    IF LENGTH(IN_LGIN_PWD) > 0 THEN
        BEGIN
            SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_USR_LGIN */
                   SEC_LGIN_PWD
                 , DAMO.HASH_STR_DATA(IN_LGIN_PWD)
                 , SUBSTR(XGAB.FT_RPP_CHKLOGIN(IN_STF_NO, '08'),1,1)
              INTO V_SEC_LGIN_PWD
                 , V_DAMO_HASH_STR_DATA
                 , V_LGIN_CHK_CD
              FROM XCOM.BSHRRUSV
             WHERE STF_NO = IN_STF_NO
               AND ROWNUM = 1
            ;
            
            IF V_LGIN_CHK_CD = 'E' THEN
             BEGIN
                 OPEN OUT_CURSOR FOR
                 SELECT '3'                                             ERR_YN         -- 0.에러 여부
                      , '인사상의 사유로 로그인이 제한됩니다.'          ERMSG          -- 1.에러메시지
                      , IN_STF_NO                                       STF_NO         -- 2.사용자 사번
                      , IN_LGIN_PWD                                     LGIN_PWD       -- 3.사용자 비밀번호
                      , ''                                              KOR_SRNM_NM    -- 4.사용자 성명
                      , ''                                              AADP_CD        -- 5.부서코드
                      , ''                                              AOA_WKDP_CD    -- 6.배치된 진료부서코드
                      , ''                                              AADP_CD_NM     -- 7.부서코드 명
                      , ''                                              AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                      , ''                                              USE_GRP_CD     -- 9.사용그룹코드
                      , ''                                              USE_GRP_DTL_CD -- 10.사용그룹상세코드
                      , ''                                              NP_YN          -- 11.정신과권한여부
                      , ''                                              DP_TP_CD       -- 12.내/외과계구분(1:내과, 2:외과, 3:기타)
                      , ''                                              SEC_LGIN_PWD   -- 13.암호화 비밀번호
                      , ''                                              SID            -- 14.사용자SID
                   FROM DUAL;
                  RETURN;
             END;
          END IF;

            EXCEPTION  --예외처리 
                WHEN NO_DATA_FOUND THEN
                    BEGIN
                        OPEN OUT_CURSOR FOR
                            SELECT '1'                       ERR_YN         -- 0.에러 여부
                                 , '사용자 정보가 없습니다.' ERR_MSG        -- 1.에러메시지
                                 , IN_STF_NO                 STF_NO         -- 2.사용자 사번
                                 , IN_LGIN_PWD               LGIN_PWD       -- 3.사용자 비밀번호
                                 , ''                        KOR_SRNM_NM    -- 4.사용자 성명
                                 , ''                        AADP_CD        -- 5.부서코드
                                 , ''                        AADP_CD_NM     -- 6.부서코드 명
                                 , ''                        AOA_WKDP_CD    -- 7.배치된 진료부서코드
                                 , ''                        AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                                 , ''                        USE_GRP_CD     -- 9.사용그룹코드
                                 , ''                        USE_GRP_DTL_CD -- 10.사용그룹상세코드
                                 , ''                        NP_YN          -- 11.정신과권한여부
                                 , ''                        DP_TP_CD       -- 12.내/외과계구분(1:내과, 2:외과, 3:기타)
                                 , ''                        SEC_LGIN_PWD   -- 13.암호화 비밀번호
                                 , ''                        SID            -- 14.사용자SID
                              FROM DUAL
                            ;
                            RETURN;
                    END;
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN : 로그인 사용자 비밀 번호 조회중 에러발생 ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
        END;
    ELSE
        V_SEC_LGIN_PWD       := IN_SEC_LGIN_PWD;
        V_DAMO_HASH_STR_DATA := IN_SEC_LGIN_PWD;
    END IF;

    IF V_SEC_LGIN_PWD = V_DAMO_HASH_STR_DATA THEN
        BEGIN
            OPEN OUT_CURSOR FOR
                SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_USR_LGIN */
                       '0'            ERR_YN         -- 0.에러 여부
                     , ''             ERR_MSG        -- 1.에러메시지
                     , IN_STF_NO      STF_NO         -- 2.사용자 사번
                     , IN_LGIN_PWD    LGIN_PWD       -- 3.사용자 비밀번호
                     , KOR_SRNM_NM    KOR_SRNM_NM    -- 4.사용자 성명
                     , AADP_CD        AADP_CD        -- 5.부서코드
                     , AADP_CD_NM     AADP_CD_NM     -- 6.부서코드 명
                     , AOA_WKDP_CD    AOA_WKDP_CD    -- 7.배치된 진료부서코드
                     , AOA_WKDP_CD_NM AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                     , USE_GRP_CD     USE_GRP_CD     -- 9.사용그룹코드
                     , USE_GRP_DTL_CD USE_GRP_DTL_CD -- 10.사용그룹상세코드
                     , ( SELECT DECODE(COUNT(*), 0, 'N', 'Y')
                           FROM CNLMRUDD
                          WHERE USE_SID     = IN_STF_NO
                            AND MED_DEPT_CD = 'NP'
                            AND ROWNUM = 1 )                      NP_YN         -- 11.정신과권한여부 (201212 - 수정필요)
                     , NVL(( SELECT DTRL1_NM
                               FROM CCCCCSTE
                              WHERE COMN_GRP_CD = 'SH0'
                                AND COMN_CD = AOA_WKDP_CD ), '3') DP_TP_CD      -- 12.내/외과계구분(1:내과, 2:외과, 3:기타)
                     , SEC_LGIN_PWD                               SEC_LGIN_PWD  -- 13.암호화 비밀번호
                     , SID                                        SID           -- 14.사용자SID
                  FROM XCOM.BSHRRUSV
                 WHERE STF_NO = IN_STF_NO
                   AND ROWNUM = 1
                ;
                EXCEPTION  --예외처리
                    WHEN OTHERS THEN
                        RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
        END;

        BEGIN
            V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                           'EXEC XMOB.' || IN_SQL_ID || '(' ||
                           ''''',''' || IN_STF_NO  || '''' ||
                           ',''' || IN_IP_ADDR  || '''' ||
                           ',''' || IN_HSP_TP_CD  || '''' ||
                           ',''' || IN_LGIN_PWD  || '''' ||
                           ',''' || IN_SEC_LGIN_PWD  || '''' ||
                           ',:C);';
        END;

        BEGIN
            XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
        END; 
        
        IF IN_STF_NO = '65287' THEN
          BEGIN
              XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, 'LOGIN_START', NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, 'LOGIN_TEST');
          END;
      END IF;

    ELSE
        BEGIN
            OPEN OUT_CURSOR FOR
                SELECT '2'                       ERR_YN         -- 0.에러 여부
                     , '비밀번호를 확인하세요.'  ERR_MSG        -- 1.에러메시지
                     , IN_STF_NO                 STF_NO         -- 2.사용자 사번
                     , IN_LGIN_PWD               LGIN_PWD       -- 3.사용자 비밀번호
                     , ''                        KOR_SRNM_NM    -- 4.사용자 성명
                     , ''                        AADP_CD        -- 5.부서코드
                     , ''                        AADP_CD_NM     -- 6.부서코드 명
                     , ''                        AOA_WKDP_CD    -- 7.배치된 진료부서코드
                     , ''                        AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                     , ''                        USE_GRP_CD     -- 9.사용그룹코드
                     , ''                        USE_GRP_DTL_CD -- 10.사용그룹상세코드
                     , ''                        NP_YN          -- 11.정신과권한여부
                     , ''                        DP_TP_CD       -- 12.내/외과계구분(1:내과, 2:외과, 3:기타)
                     , ''                        SEC_LGIN_PWD   -- 13.암호화 비밀번호
                     , ''                        SID            -- 14.사용자SID
                  FROM DUAL
                ;
        END;
    END IF;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_USR_LGIN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
END PC_BSH_USR_LGIN;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_ADS_PT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 입원환자 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_ADS_PT_LIST         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_RM_NO         IN    VARCHAR2      /* 실번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',''' || IN_RM_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_WD_NO, IN_RM_NO, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_ADS_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_ADS_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_SYSDATETIME
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : DB 현재시간 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_GET_SYSDATETIME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SYSDATETIME             ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_SYSDATETIME */
       TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS')  CURRENTTIME
  FROM DUAL
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SYSDATETIME' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SYSDATETIME;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_ADS_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동 입원환자 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WARD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_ADS_PT_LIST          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WARD_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_WD_NO, IN_DP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_ADS_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    --    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_ADS_PT_LIST_XXX' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    IF IN_STF_NO = '65287' THEN
       BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, 'LOGIN_END', NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, 'LOGIN_TEST');
     END;
  END IF;
  
END PC_BSH_WD_ADS_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_CP_PRM_CRCCM
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동별 병실현황조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_CP_PRM_CRCCM         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_DEPT_CD    IN    VARCHAR2      /* 병동부서코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WD_DEPT_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_WD_CP_PRM_CRCCM */
       RADP_CNT       -- 입원예정환자수
     , BED_CNT        -- 병상수
     , SIHS_PT_CNT    -- 재원환자수
     , EMPTY_CNT      -- 공병상수
     , DS_EXPT_PT_CNT -- 퇴원예정환자수
     , WD_DEPT_CD     -- 병동부서코드
     , XMED.FT_BSH_TDY_OP_STS('1', IN_WD_DEPT_CD, '08') TDY_OP_CNT    -- 병동별 당일 수술환자수
     , XMED.FT_BSH_TDY_OP_STS('2', IN_WD_DEPT_CD, '08') TDY_OP_EX_CNT -- 병동별 당일 수술 예정 환자수
  FROM XBIL.BSHROOMV
 WHERE WD_DEPT_CD = IN_WD_DEPT_CD
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_CP_PRM_CRCCM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_WD_CP_PRM_CRCCM;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 환자 리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_PT_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EMRM_CLS_CD   IN    VARCHAR2      /* 응급실분류코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_EMRM_CLS_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_EMRM_CLS_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EMRM_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EMRM_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_BSTB_MTD_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : BESTBOARD 진료과 리스트 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_BSTB_MTD_LIST           ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_BSTB_MTD_LIST */
       A.IP_ADDR                                   IP_ADDR
     , A.ISTL_DEPT_CD                              ISTL_DEPT_CD
     , DECODE(A.ISTL_DEPT_CD, 'ER', '응급실'
                            , 'RDA', '혈관조영실'
                            , 'RRT', 'RRT'
                            , 'WORK', 'WORKLIST' --20200420 간호워크리스트 메뉴 추가
                            , B.DEPT_NM)           ISTL_DEPT_NM
     , A.SORT_SEQ                                  SORT_SEQ
     , A.SCRN_TP_CD                                SCRN_TP_CD
     , A.ISTL_PSTN_NM                              ISTL_PSTN_NM
     , A.LIST_DSP_YN                               LIST_DSP_YN
     , A.AUTO_LGOT_USE_YN                          AUTO_LGOT_USE_YN
     , A.AUTO_LGOT_STU_CHR_VAL                     AUTO_LGOT_STU_CHR_VAL
     , A.SCSV_USE_YN                               SCSV_USE_YN
     , A.SCSV_STU_CHR_VAL                          SCSV_STU_CHR_VAL
  -- FROM BSHDBDPD A  
  FROM HICU.DSHDBDPD A
     , PDEDBMSM B
 WHERE LIST_DSP_YN = 'Y'
   AND A.ISTL_DEPT_CD    = B.DEPT_CD(+)
 ORDER BY SORT_SEQ
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_BSTB_MTD_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_BSTB_MTD_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_TEAM_CB_PT_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 구역별 환자 수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_LOC_COUNT
*                 : 구역별(성인/소아/외상)이었으나 TO-BE 에서는 팀별로 변경.
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_TEAM_CB_PT_CNT     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;


    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_EMRMTEAMCBPTCNT(IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EMRM_TEAM_CB_PT_CNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EMRM_TEAM_CB_PT_CNT;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_ALL_ITEM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 조회(모든항목)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_VITALSIGN_ALL_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_ALL_ITEM   ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASKTYPE  || '''' ||
                       ',''' || IN_ARRAY_NR_ITEM_ID  || '''' ||
                       ',''' || IN_NR_ITEM_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECPRDASK( IN_PT_NO
                                                       , IN_HSP_TP_CD
                                                       , IN_ASKTYPE
                                                       , IN_ARRAY_NR_ITEM_ID
                                                       , TO_NUMBER(IN_NR_ITEM_ID)
                                                       , TO_DATE(IN_FRDATE, 'YYYYMMDD')
                                                       , TO_DATE(IN_TODATE, 'YYYYMMDD')
                                                       , OUT_CURSOR);
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CLCO_REC_PRD_ALL_ITEM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CLCO_REC_PRD_ALL_ITEM;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_IO_ITEM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 I/O 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_VITAL_IO_BY_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_IO_ITEM    ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;


    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECIOPRDASK( IN_PT_NO
                                                         , IN_HSP_TP_CD
                                                         , TO_DATE(IN_FRDATE, 'YYYYMMDD')
                                                         , TO_DATE(IN_TODATE, 'YYYYMMDD')
                                                         , OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CLCO_REC_PRD_IO_ITEM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CLCO_REC_PRD_IO_ITEM;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_SIHM_STS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 재원환자 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_STAY_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_SIHM_STS            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_STAY_STATUS(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_ICU_TP, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_SIHM_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_SIHM_STS;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_INFC_MGMT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 감염관리 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_INFC_MGMT           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_ICU_TP, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_INFC_MGMT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_INFC_MGMT;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_DGNS_NM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 진단명 가져오기
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_DISEASE_NAME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_DGNS_NM_ASK          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID       IN    VARCHAR2      /* 원무접수ID */
                                         , IN_MED_DP_CD     IN    VARCHAR2      /* 진료과 코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_MED_DP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_DISEASE_NAME(IN_PT_NO, IN_MED_DP_CD, IN_PACT_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_DGNS_NM_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_DGNS_NM_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_OP_NM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 수술명 가져오기
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_OPERATION_NAME
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_OP_NM_ASK            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_PATIENT_OPNM(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_OP_NM_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_OP_NM_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_DVAL_MDFM_CLA
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기본기록조회 환경반환
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DEFAULT_NOTETYPE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_DVAL_MDFM_CLA           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_TP           IN    VARCHAR2      /* 원무접수구분*/
                                       , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                       , IN_DR_STF_NO         IN    VARCHAR2      /* 의사직원번호 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_TP  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',''' || IN_DR_STF_NO  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_DEFAULT_MDFM_CLS(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PACT_TP, IN_PT_NO, IN_DP_CD, IN_DR_STF_NO, IN_WK_SID, IN_PACT_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_DVAL_MDFM_CLA' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_DVAL_MDFM_CLA;

/*===================================================================================
* 서비스이름      : PC_BSH_MDFM_CLS_PRD
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기록종류별 기간 설정 반환
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NOTETYPE_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_MDFM_CLS_PRD            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDFM_CLS_CD       IN    VARCHAR2      /* 서식지구분코드 */
                                         , IN_ALL_DP_YN         IN    VARCHAR2      /* 전체과체크여부  */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MDFM_CLS_CD  || '''' ||
                       ',''' || IN_ALL_DP_YN  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_MDFM_CLS_PERIOD(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_MDFM_CLS_CD, IN_ALL_DP_YN, IN_DP_CD, IN_WK_SID, IN_PACT_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_MDFM_CLS_PRD' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_MDFM_CLS_PRD;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_PRD_MDFM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 기록 기간별 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_SEARCH_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_PRD_MDFM             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDFM_CLS_CD       IN    VARCHAR2      /* 서식지구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_FULL_CHK          IN    VARCHAR2      /* 전체과체크여부 */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_WK_SID            IN    VARCHAR2      /* 작업자사번 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MDFM_CLS_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_FULL_CHK  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_SEARCH_PERIOD(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_MDFM_CLS_CD, IN_FRDATE, IN_TODATE, IN_FULL_CHK, IN_DP_CD, IN_WK_SID, IN_PACT_ID,'08', OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_PRD_MDFM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_PRD_MDFM;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_REC_HME_HST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 의무기록수진이력조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_MOBILE.PC_SEL_PATIENT_MED_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_REC_HME_HST          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BHS_SEL_PT_MEDHISTORY(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_REC_HME_HST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_REC_HME_HST;

/*===================================================================================
* 서비스이름      : PC_SEL_PT_REC_HME_HST_RCDC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 의무기록수진이력별기록지조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_MOBILE.PC_SEL_RECORDS_MED_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_SEL_PT_REC_HME_HST_RCDC     ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_PACT_TP           IN    VARCHAR2      /* 원무접수코드*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_PACT_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_MDRC_MEDHST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, IN_PACT_TP, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_SEL_PT_REC_HME_HST_RCDC' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_SEL_PT_REC_HME_HST_RCDC;



/*===================================================================================
* 서비스이름      : PC_BSH_ICU_USE_EQUP_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU 사용 장비 카운트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_USE_EQUIP_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_USE_EQUP_CNT        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_INTFEQUPUSECOUNT(IN_ICU_TP, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_USE_EQUP_CNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_USE_EQUP_CNT;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_MV_INOT_PT_CNT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU별 일주일간 전출입 환자 수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PT_IN_OUT_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_MV_INOT_PT_CNT      ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUMVINMVOT(IN_ICU_TP, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_MV_INOT_PT_CNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_MV_INOT_PT_CNT;

/*==================================================================================
* 서비스이름  : pc_sel_icu_mv_use_count
* 최초 작성일 : 2011.11
* 최초 작성자 : 이지케어텍 김승기
* description : ICU 별 MV(Management Ventilator) 사용현황
                (AC(VC,PC), SIMV(VC,PC), PSV,   CPAP, BIBAP) -> MICU만 해당
                (HFOV,      SIMV(VC,PC), NCPAP, HFS        ) -> NICU만 해당
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_MV_USE_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_MV_USE_STS          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUVTLRUSECRCCM(IN_ICU_TP, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_MV_USE_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_MV_USE_STS;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_MEMO
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰기록 기간별 조회(모든항목)
                  : IN_ASKTYPE : SINGLE
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : 210130(MEMO)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_RECORD_MEMO
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_RECORD_MEMO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_MEMO       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASKTYPE  || '''' ||
                       ',''' || IN_ARRAY_NR_ITEM_ID  || '''' ||
                       ',''' || IN_NR_ITEM_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECPRDASK(IN_PT_NO, IN_HSP_TP_CD, IN_ASKTYPE, IN_ARRAY_NR_ITEM_ID, IN_NR_ITEM_ID, IN_FRDATE, IN_TODATE, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CLCO_REC_PRD_MEMO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CLCO_REC_PRD_MEMO;

/*===================================================================================
* 서비스이름      : PC_BSH_EXMRAD_CATEGORY
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 영상검사 Filter 항목조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXMRAD_CATEGORY         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_USE_YN        IN    VARCHAR2      /* 사용여부  */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_USE_YN  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_SEL_EXAMRAD_CATEGORY(IN_USE_YN, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXMRAD_CATEGORY - SPC' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXMRAD_CATEGORY;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(진검)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMSPC_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMSPC_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMSPC_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMSPC_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMRAD_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(영상)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMRAD_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMRAD_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMRAD_LIST(IN_PT_NO, IN_FRDATE, IN_TODATE, NVL(IN_HSP_TP_CD, '08'), OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMRAD_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMRAD_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMFUN_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     :  검사결과 조회(기능) 
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMFUN_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMFUN_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMFUN_LIST(IN_PT_NO, IN_FRDATE, IN_TODATE, NVL(IN_HSP_TP_CD, '08'), OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMFUN_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMFUN_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(병리)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAMPAT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMPAT_LIST            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMPAT_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, '20030501', '29991231', '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMPAT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMPAT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_DAY
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 일별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_DAY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_DAY             ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_STATUS        IN    VARCHAR2      /* 상태 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_STATUS  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_DAY(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, IN_STATUS, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ORD_STS_DAY' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ORD_STS_DAY;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_WEEK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 주별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_WEEK
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_WEEK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_WEEK(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ORD_STS_WEEK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ORD_STS_WEEK;

/*===================================================================================
* 서비스이름      : PC_BSH_ORD_STS_MONTH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 특정일 오더 상태 조회 - 월별
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_MONTH
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ORD_STS_MONTH           ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASK_MON       IN    VARCHAR2      /* 조회월 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASK_MON  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ORDER_STATUS_MONTH(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_ASK_MON, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ORD_STS_MONTH' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ORD_STS_MONTH;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_ORD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별 오더조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ORDER
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_ORD_ASK              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* DEVICE ID */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병원구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 시작일자 */
                                         , IN_TODATE        IN    VARCHAR2      /* 종료일자 */
                                         , IN_SORT          IN    VARCHAR2      /* 1 */
                                         , IN_INCLUDE       IN    VARCHAR2      /* NULL */
                                         , IN_DP_CD         IN    VARCHAR2      /* NULL */
                                         , IN_PACT_TP       IN    VARCHAR2      /* NULL */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_SORT  || '''' ||
                       ',''' || IN_INCLUDE  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',''' || IN_PACT_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ORDER(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, IN_SORT, IN_INCLUDE, IN_DP_CD, IN_PACT_TP, OUT_CURSOR);
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ORD_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_ORD_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_ALERT_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자의 ALERT 정보 조회 (AS-IS 38~42통합)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_DRUG
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ALLERGY_ETC
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_INFECTION
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ETC
                  : PKG_SMARTCARE_DASHBOARD.PC_SEL_PAT_ALERT_ADE_SIGNAL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_ALERT_ASK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR_ALRG  OUT   RETURNCURSOR  /* 환자알러지정보 */
                                         , OUT_CURSOR_INFC  OUT   RETURNCURSOR  /* 환자감염정보 */
                                         , OUT_CURSOR_SYMP  OUT   RETURNCURSOR  /* 환자증상정보 */
                                         , OUT_CURSOR_PRGN  OUT   RETURNCURSOR  /* 환자임신수유정보 */
                                         , OUT_CURSOR_SYMP_MASTER  OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_ALERT.PC_MOO_SELECT_PAT_ALLERGY(IN_PT_NO,IN_HSP_TP_CD, OUT_CURSOR_ALRG);        --환자알러지정보
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ALERT_ASK - ALLERGY ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MOO_ALERT.PC_MOO_SELECT_PAT_INFECTION(IN_PT_NO,IN_HSP_TP_CD, OUT_CURSOR_INFC);      --환자감염정보
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ALERT_ASK - INFECTION ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MOO_ALERT.PC_MOO_SELECT_PAT_SYMPTOM(IN_PT_NO,IN_HSP_TP_CD, OUT_CURSOR_SYMP);        --환자증상정보
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ALERT_ASK - SYMPTOM ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MOO_ALERT.PC_MOO_SELECT_PAT_PREGNANCY(IN_PT_NO,IN_HSP_TP_CD, OUT_CURSOR_PRGN);      --환자임신수유정보
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ALERT_ASK - PREGNANCY ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MOO_ALERT.PC_MOO_SELECT_SYMPTOMINFO(IN_HSP_TP_CD, OUT_CURSOR_SYMP_MASTER);      --증상정보마스터
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_ALERT_ASK - PREGNANCY ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_ALERT_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_GET_EXAM_TOTAL
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 모든검사 결과 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_GET_EXAM_TOTAL          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_USE_YN        IN    VARCHAR2      /* 사용여부  */
                                         , OUT_CURSOR1      OUT   RETURNCURSOR  /* 환자별 검체검사 커서 */
                                         , OUT_CURSOR2      OUT   RETURNCURSOR  /* 환자별 영상검사 커서 */
                                         , OUT_CURSOR3      OUT   RETURNCURSOR  /* 환자별 기능검사 커서 */
                                         , OUT_CURSOR4      OUT   RETURNCURSOR )/* 환자별 병리검사 커서 */

IS
BEGIN
    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMSPC_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, '08',OUT_CURSOR1);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_GET_EXAM_TOTAL - 검체검사' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMRAD_LIST(IN_PT_NO, IN_FRDATE, IN_TODATE, NVL(IN_HSP_TP_CD, '08'), OUT_CURSOR2);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_GET_EXAM_TOTAL - 영상검사' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMFUN_LIST(IN_PT_NO, IN_FRDATE, IN_TODATE, NVL(IN_HSP_TP_CD, '08'), OUT_CURSOR3);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_GET_EXAM_TOTAL - 기능검사' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMPAT_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, '20030501', '29991231','08',OUT_CURSOR4);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_GET_EXAM_TOTAL - 병리검사' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

END PC_BSH_GET_EXAM_TOTAL;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMRAD_FILTER
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검사결과 조회(영상) - 필터
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMRAD_FILTER          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_EXRS_CTG_ID   IN    VARCHAR2      /* 영상검사 필터 불류코드 (',') 형식으로  */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )

IS
    V_EXRS_CTG_ID        VARCHAR2(1000)  := NVL(IN_EXRS_CTG_ID, '0') ;
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_EXRS_CTG_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMRAD_FILTER(IN_PT_NO, IN_FRDATE, IN_TODATE, IN_HSP_TP_CD, V_EXRS_CTG_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMRAD_FILTER - 검사결과 조회(영상) - 필터' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMRAD_FILTER;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_AMS_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 투약내역조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MEDICATION
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_AMS_ASK              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_ORD_DT        IN    VARCHAR2      /* 오더일자 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',''' || IN_ORD_DT  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MEDICATION('','','',IN_PT_NO,IN_WD_NO,IN_ORD_DT, OUT_CURSOR);      --환자임신수유정보
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_AMS_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_AMS_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_NDRC_PRD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 간호일지조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NURSE_CARE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_NDRC_PRD_ASK            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
--        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_NDRCPRDASK(IN_PT_NO,IN_HSP_TP_CD, IN_FRDATE, IN_TODATE, OUT_CURSOR);
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_NDRCPRDASKDESC(IN_PT_NO, IN_HSP_TP_CD, TO_DATE(IN_FRDATE,'YYYYMMDD'), TO_DATE(IN_TODATE,'YYYYMMDD'), OUT_CURSOR);
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_NDRC_PRD_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_NDRC_PRD_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_CHRM_CRCCM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장 대기 현황조회 - 고위험 산모실만
                    분만장 수술 현황조회 
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WAIT_EBBDVLMT
                    PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NICU_OPINFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHRM_CRCCM              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_WAIT_CURSOR  OUT   RETURNCURSOR 
                                         , OUT_OP_CURSOR    OUT   RETURNCURSOR )IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHRMWAITCRCCM(IN_HSP_TP_CD, OUT_WAIT_CURSOR);

            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHRM_CRCCM - WAIT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHBROPCRCCM(IN_HSP_TP_CD, OUT_OP_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHRM_CRCCM - OP' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;    
END PC_BSH_CHRM_CRCCM;

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_ITEM_PRD
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 검체검사 항목별 기간별 검사결과 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_EXAM_SPC_ITEM_PERIOD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_ITEM_PRD        ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_TST_CD        IN    VARCHAR2      /* 검사항목(|검사항목ID1|검사항목ID2|)*/
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_TST_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMSPC_ITEM_PERIOD(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_FRDATE, IN_TODATE, IN_TST_CD,'08', OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMSPC_ITEM_PRD' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMSPC_ITEM_PRD;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_WEIGHT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 임상관찰 기록 기간별 체중 조회
                  : IN_ASKTYPE : SINGLE
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : 210070(WEIGHT)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_RECORD_WEIGHT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_WEIGHT        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                            , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                            , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                            , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                            , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                            , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                            , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                            , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                            , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                            , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                            , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASKTYPE  || '''' ||
                       ',''' || IN_ARRAY_NR_ITEM_ID  || '''' ||
                       ',''' || IN_NR_ITEM_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECPRDASK( IN_PT_NO
                                                       , IN_HSP_TP_CD
                                                       , IN_ASKTYPE
                                                       , IN_ARRAY_NR_ITEM_ID
                                                       , IN_NR_ITEM_ID
                                                       , TO_DATE(IN_FRDATE, 'YYYYMMDD')
                                                       , TO_DATE(IN_TODATE, 'YYYYMMDD')
                                                       , OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CLCO_REC_PRD_WEIGHT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CLCO_REC_PRD_WEIGHT;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_PT_DTL_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병실환자상세조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_WARD_PATIENT_DETAIL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_PT_DTL_ASK           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_WARD_PATIENT_DETAIL(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PACT_ID, IN_PT_NO, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_PT_DTL_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_WD_PT_DTL_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_PT_DTL_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU환자상세조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PAT_RECENT_VITAL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_PT_DTL_ASK          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUPTDTLASK(IN_PT_NO, IN_PACT_ID, OUT_CURSOR);	--'08',OUT_CURSOR); 	--20260424 YJR '08' 들어간 이유?

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_PT_DTL_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_PT_DTL_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_NICU_INIT_NR_REC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : NICU 초기간호기록 - 출생,체중,주수
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NICU_MRFNDT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_NICU_INIT_NR_REC        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_PACT_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_NICU_INIT_NR_REC */
       XMED.PKG_MRN_NURSENSCREEN.FT_MRN_INITNRINFITEMVALUE('MOM', 'PREGNANCYPERIOD'    , 'DELIVERY' , IN_PT_NO, IN_PACT_ID, IN_PACT_TP_CD, IN_HSP_TP_CD)  BIRTHWEEK
     , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_INITNRINFITEMVALUE('MOM', 'MOM-PREGNANCYPERIOD', 'DELIVERY' , IN_PT_NO, IN_PACT_ID, IN_PACT_TP_CD, IN_HSP_TP_CD)  CURRENTWEEK
     , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_INITNRINFITEMVALUE('MY' , 'BIRTHBODYWEIGHT'    , 'BABY'     , IN_PT_NO, IN_PACT_ID, IN_PACT_TP_CD, IN_HSP_TP_CD)  BIRTHWEIGHT
     , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_INITNRINFITEMVALUE('MY' , 'CLCO_BODYWEIGHT'    , 'CLCO_BABY', IN_PT_NO, IN_PACT_ID, IN_PACT_TP_CD, IN_HSP_TP_CD)  CURRENTWEIGHT
  FROM DUAL
;

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_NICU_INIT_NR_REC' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_NICU_INIT_NR_REC;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_ODRER_INF
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 타과의뢰 정보
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_CONSULT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_ODRER_INF          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_ERCONSULTINFO(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_PACT_ID, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EMRM_ODRER_INF' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EMRM_ODRER_INF;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_SIHS_PT_STTS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실 재원환자 통계
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_PATIENT_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_SIHS_PT_STTS       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ASK_DATE          IN    VARCHAR2      /* 조회일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ASK_DATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_EMRMPTSTTS(TO_DATE(IN_ASK_DATE, 'YYYYMMDD'), IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EMRM_SIHS_PT_STTS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EMRM_SIHS_PT_STTS;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_NR_CHOV
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별간호인수인계
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_NURSE_TAKING_OVER
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_NR_CHOV              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE            IN    VARCHAR2      /* 조회 종료일 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_NRCHOVCHOV(IN_PACT_ID, TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_NR_CHOV' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_NR_CHOV;

/*===================================================================================
* 서비스이름      : PC_BSH_EMRM_WRK_DR
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 응급실근무의사
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_WORK_DOCTOR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EMRM_WRK_DR             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ER_WORK_DOCTOR(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EMRM_WRK_DR' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EMRM_WRK_DR;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_BED_CRCCM
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : ICU병상현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ER_ICU_BED_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_BED_CRCCM           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUBEDCRCCM(IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_BED_CRCCM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_BED_CRCCM;

/*===================================================================================
* 서비스이름      : PC_BSH_LGIN_STF_TAG_ID
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 직원 TAG ID 를 통한 로그인
* AS-IS 쿼리 정보 : 61.PKG_SMARTCARE_DASHBOARD.PC_SEL_LOGIN_BY_TAG_ID
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_LGIN_STF_TAG_ID         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_STF_TAG_ID    IN    VARCHAR2      /* 직원증 TAG ID */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_STF_NO          VARCHAR2(100);
    V_SEC_LGIN_PWD    VARCHAR2(1000);
    V_SRCH_CNTE       VARCHAR2(4000);
    V_LGIN_CHK_CD     VARCHAR2(1000);
BEGIN
    BEGIN
        SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_LGIN_STF_TAG_ID */
               A.STF_NO
              ,SUBSTR(XGAB.FT_RPP_CHKLOGIN(A.STF_NO, '08'),1,1)
          INTO V_STF_NO
              ,V_LGIN_CHK_CD
          FROM XGAB.BSHDMDBV  A    -- TAG ID 와 사번 MATCHING VIEW
         WHERE CARD_NO = UPPER(IN_STF_TAG_ID)
           AND ROWNUM = 1
        ;
        
        IF V_LGIN_CHK_CD = 'E' THEN
           BEGIN
               OPEN OUT_CURSOR FOR
               SELECT '3'                                             ERR_YN         -- 0.에러 여부
                    , '인사상의 사유로 로그인이 제한됩니다.'          ERMSG          -- 1.에러메시지
                    , V_STF_NO                                        STF_NO         -- 2.사용자 사번
                    , ''                                              LGIN_PWD       -- 3.사용자 비밀번호
                    , ''                                              KOR_SRNM_NM    -- 4.사용자 성명
                    , ''                                              AADP_CD        -- 5.부서코드
                    , ''                                              AOA_WKDP_CD    -- 6.배치된 진료부서코드
                    , ''                                              AADP_CD_NM     -- 7.부서코드 명
                    , ''                                              AOA_WKDP_CD_NM -- 8.배치된 진료부서코드명
                    , ''                                              USE_GRP_CD     -- 9.사용그룹코드
                    , ''                                              USE_GRP_DTL_CD -- 10.사용그룹상세코드
                    , ''                                              NP_YN          -- 11.정신과권한여부
                    , ''                                              DP_TP_CD       -- 12.내/외과계구분(1:내과, 2:외과, 3:기타)
                    , ''                                              SEC_LGIN_PWD   -- 13.암호화 비밀번호
                    , ''                                              SID            -- 14.사용자SID
                 FROM DUAL;
                RETURN;
           END;
      END IF;
          
        EXCEPTION  --예외처리 
            WHEN NO_DATA_FOUND THEN  V_STF_NO := '';
    END;

    BEGIN
        SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_LGIN_STF_TAG_ID */
               SEC_LGIN_PWD
          INTO V_SEC_LGIN_PWD
          FROM XCOM.BSHRRUSV
         WHERE STF_NO = V_STF_NO
        ;
        EXCEPTION  --예외처리 
            WHEN NO_DATA_FOUND THEN  V_SEC_LGIN_PWD := '';
    END;

    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_STF_TAG_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    
    BEGIN
        XMOB.PKG_BSH_DB.PC_BSH_USR_LGIN('PKG_BSH_DB.PC_BSH_USR_LGIN', V_STF_NO, IN_IP_ADDR, '08', NULL, V_SEC_LGIN_PWD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_LGIN_STF_TAG_ID' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;

    END;
END PC_BSH_LGIN_STF_TAG_ID;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_PT_NR_ELS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동환자별간호경과
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_PT_NR_ELS            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_NRCHOVNRELS(IN_PACT_ID, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_PT_NR_ELS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_WD_PT_NR_ELS;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_INIT_NR_REC
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자초기간호기록 (응급, 병동)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_MRFNDT_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_INIT_NR_REC          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_ASK_TYPE VARCHAR2(100) := '';
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    IF IN_PACT_TP_CD = 'I' THEN
        V_ASK_TYPE := 'WDCHOV';
    ELSE
        V_ASK_TYPE := 'EMRMCHOV';
    END IF;

    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_PACT_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_INITNRINFSPCFITEMVAL(V_ASK_TYPE, IN_PT_NO, IN_HSP_TP_CD, IN_PACT_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_INIT_NR_REC' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_INIT_NR_REC;

/*===================================================================================
* 서비스이름      : PC_BSH_PSNY_ODRER_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 본인타과의뢰목록
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_REQ_PATIENT_BY_DR_ID
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PSNY_ODRER_LIST         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_DR_STF_NO         IN    VARCHAR2      /* 의사직원번호 */
                                         , IN_DP_CD             IN    VARCHAR2      /* 진료과코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 시작일자 */
                                         , IN_TODATE            IN    VARCHAR2      /* 종료일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_DR_STF_NO  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_SEL_RER_PTBYDR(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_DR_STF_NO, IN_DP_CD, IN_FRDATE, IN_TODATE, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PSNY_ODRER_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PSNY_ODRER_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_PSNY_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 본인환자리스트조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_MY_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PSNY_PT_LIST            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_MY_PATIENT_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_STF_NO, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PSNY_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PSNY_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_WHL_PT_SRCH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 전체환자검색조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WHL_PT_SRCH             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , IN_PACT_TP_CD        IN    VARCHAR2      /* 원무접수구분코드 */ 
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_PACT_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PACT_ID, IN_PT_NO, IN_PACT_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WHL_PT_SRCH' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_WHL_PT_SRCH;                      

/*===================================================================================
* 서비스이름      : PC_BSH_PT_VTLR_MODE_VAL
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별인공호흡기모드값
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_LAST_VENT_VALUE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_VTLR_MODE_VAL        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASK_DATE          IN    VARCHAR2      /* 조회일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASK_DATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_PATIENTVENTILATOR(IN_PT_NO, TO_DATE(IN_ASK_DATE, 'YYYYMMDD'), IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_VTLR_MODE_VAL' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_VTLR_MODE_VAL;

/*===================================================================================
* 서비스이름      : PC_SEL_DP_FORM_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 과별서식리스트조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_MEDDEPT_RECORD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_SEL_DP_FORM_LIST            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_MDRC_ID           IN    VARCHAR2      /* 의무기록서식ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MDRC_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_MEDDEPT_RECORD(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_MDRC_ID, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_SEL_DP_FORM_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_SEL_DP_FORM_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_OP_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 수술장환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OP_PT_LIST              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_OPDATE            IN    VARCHAR2      /* 수술일자 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_OPDATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_OP_PATIENT_LIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_OPDATE, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_OP_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_OP_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_OP_NM_TRAN_LST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 수술명 치환 리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_REPLACE_OPNAME_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OP_NM_TRAN_LST          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_OP_NM_TRAN_LST */
       COMN_CD_NM          COMN_CD_NM
     , DTRL1_NM            COMN_CD_EXPL
  FROM CCCCCSTE
 WHERE COMN_GRP_CD = 'SHDB003'
   AND USE_YN      = 'Y'
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_OP_NM_TRAN_LST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_OP_NM_TRAN_LST;

/*===================================================================================
* 서비스이름      : PC_BSH_ITEM_CHBR_STS
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 항목별분만상태
                  : IN_ASKTYPE = CTG
                  : IN_ARRAY_NR_ITEM_ID = NULL
                  : IN_NR_ITEM_ID = 21033
                  : IN_FRDATE = 입원일
                  : IN_TODATE = 오늘
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_MRCRINT_ITEM
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ITEM_CHBR_STS           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR1          OUT   RETURNCURSOR  /* 임신주수 리턴 커서*/
                                         , OUT_CURSOR2          OUT   RETURNCURSOR )/* 분류코드 산과 리턴커서 */
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASKTYPE  || '''' ||
                       ',''' || IN_ARRAY_NR_ITEM_ID  || '''' ||
                       ',''' || IN_NR_ITEM_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR1 FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_ITEM_CHBR_STS */
       XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNPRD', IN_PT_NO, IN_HSP_TP_CD)    PRGNPRD
     , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNDY',  IN_PT_NO, IN_HSP_TP_CD)    PRGNDY
     , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('CHBRDY',  IN_PT_NO, IN_HSP_TP_CD)    CHBRDY
  FROM DUAL
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ITEM_CHBR_STS - 임신정보 ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECPRDASK(IN_PT_NO,IN_HSP_TP_CD,IN_ASKTYPE,IN_ARRAY_NR_ITEM_ID,IN_NR_ITEM_ID,TO_DATE(IN_FRDATE, 'YYYYMMDD'),TO_DATE(IN_TODATE, 'YYYYMMDD'),OUT_CURSOR2);
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ITEM_CHBR_STS - 산과기록 ' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ITEM_CHBR_STS;

/*===================================================================================
* 서비스이름      : PC_BSH_OBSS_LBPN_REC_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 산과진통기록리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PARTO_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OBSS_LBPN_REC_LIST      ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_PARTOLIST(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_DP_CD, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_OBSS_LBPN_REC_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_OBSS_LBPN_REC_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_OBSS_LBPN_REC_DTL
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 산과진통기록상세
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_PARTO_DETAIL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_OBSS_LBPN_REC_DTL       ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_MDRC_ID       IN    VARCHAR2      /* 진료기록ID */
                                         , IN_MDRC_FOM_SEQ  IN    VARCHAR2      /* 진료기록개정순번 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_MDRC_ID  || '''' ||
                       ',''' || IN_MDRC_FOM_SEQ  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_BSH_SMARTCARE_DASHBOARD.PC_BSH_SEL_PT_PARTODETAIL(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_MDRC_ID, IN_MDRC_FOM_SEQ, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_OBSS_LBPN_REC_DTL' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_OBSS_LBPN_REC_DTL;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SCAN_LDAT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자스캔자료리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SCAN_IMAGE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SCAN_LDAT_LIST       ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE        IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_SCAN_FORM_CD  IN    VARCHAR2      /* SCAN서식코드*/
                                         , IN_DP_CD         IN    VARCHAR2      /* 진료과코드*/
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_SCAN_FORM_CD  || '''' ||
                       ',''' || IN_DP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_PATIENT_SCAN_IMAGE(IN_PT_NO, IN_FRDATE, IN_TODATE, IN_SCAN_FORM_CD, IN_DP_CD, IN_HSP_TP_CD,OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_SCAN_LDAT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_SCAN_LDAT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_CLCO_REC_PRD_GCS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자별임상관찰기록GCS
                  : IN_ASKTYPE : CTG
                  : IN_ARRAY_NR_ITEM_ID : NULL
                  : IN_NR_ITEM_ID : 21025
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENT_GCS_DATA
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CLCO_REC_PRD_GCS        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ASKTYPE           IN    VARCHAR2      /* 조회조건(ALL : 전체 항목, ARRAY : 여러개 항목을 구분자 '/' 로(예 123/234/231) , SINGLE : 단일항목 아이디)*/
                                         , IN_ARRAY_NR_ITEM_ID  IN    VARCHAR2      /* 간호항모ID(ARRAY)*/
                                         , IN_NR_ITEM_ID        IN    VARCHAR2      /* 간호항목ID(SINGLE)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_ASKTYPE  || '''' ||
                       ',''' || IN_ARRAY_NR_ITEM_ID  || '''' ||
                       ',''' || IN_NR_ITEM_ID  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CLCORECPRDASK(IN_PT_NO, IN_HSP_TP_CD, IN_ASKTYPE, IN_ARRAY_NR_ITEM_ID, IN_NR_ITEM_ID, TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CLCO_REC_PRD_GCS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CLCO_REC_PRD_GCS;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_PT_LIST
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_PT_LIST         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EXRM_CD       IN    VARCHAR2      /* 검사실코드 OUT_CURSOR1 리턴값*/
                                         , IN_EXRM_CD1      IN    VARCHAR2      /* 검사실코드 OUT_CURSOR2 리턴값*/
                                         , IN_EXRM_CD2      IN    VARCHAR2      /* 검사실코드 OUT_CURSOR3 리턴값*/
                                         , OUT_CURSOR1      OUT   RETURNCURSOR  /* 혈관조영실 환자리스트 */
                                         , OUT_CURSOR2      OUT   RETURNCURSOR  /* 혈관조영실 시술환자 */
                                         , OUT_CURSOR3      OUT   RETURNCURSOR  /* 혈관조영실 시술환자 카운트 */
                                         , OUT_CURSOR4      OUT   RETURNCURSOR )/* 혈관조영실 공지사항 */
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_EXRM_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_SR_ACPSEL_SIGNBOARD(IN_EXRM_CD, '08',OUT_CURSOR1);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_PT_LIST - PC_BSH_SR_ACPSEL_SIGNBOARD' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_DSBD_OPING_SIGNBOARD(IN_EXRM_CD1, '08',OUT_CURSOR2);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_PT_LIST - PC_BSH_DSBD_OPING_SIGNBOARD (IN_EXRM_CD = ' || IN_EXRM_CD1 || ') ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_DSBD_OPING_SIGNBOARD(IN_EXRM_CD2, '08',OUT_CURSOR3);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_PT_LIST - PC_BSH_DSBD_OPING_SIGNBOARD (IN_EXRM_CD = ' || IN_EXRM_CD2 || ') ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_SEL_SR_NOTICE_SIGNBOARD('08',OUT_CURSOR4);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_AGPY_RM_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_AOM_PT
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 시술환자
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_OP_PATIENT_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_AOM_PT          ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_EXRM_CD       IN    VARCHAR2      /* 검사실코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_EXRM_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_DSBD_OPING_SIGNBOARD(IN_EXRM_CD, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_AOM_PT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_AGPY_RM_AOM_PT;

/*===================================================================================
* 서비스이름      : PC_BSH_AGPY_RM_ANPN
* 최초 작성일     : 2012.11
* 최초 작성자     : 김승기
* DESCRIPTION     : 혈관조영실 공지사항
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_DA_NOTICE_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_AGPY_RM_ANPN            ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_SEL_SR_NOTICE_SIGNBOARD('08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_AGPY_RM_ANPN' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_AGPY_RM_ANPN;

/*===================================================================================
* 서비스이름      : PC_BSH_RRT_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : RRT환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_RRT_PT_INFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_RRT_PT_LIST             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_WD_NO             IN    VARCHAR2      /* 병동번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_BSH_RRT.PC_BSH_RRT_PT_LIST(IN_FRDATE, IN_TODATE, IN_WD_NO,'08', OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_RRT_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_RRT_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_WD_OP_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 병동별수술환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_OP_PT_LIST_BY_WARD
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_WD_OP_PT_LIST           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_WD_NO             IN    VARCHAR2      /* 병동번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_OP_PT_LIST_BY_WARD(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_FRDATE, IN_TODATE, IN_WD_NO, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_WD_OP_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_WD_OP_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_PT_LIST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장환자리스트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_LIST2
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_PT_LIST         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR1          OUT   RETURNCURSOR  /* 분만장환자리스트 */
                                         , OUT_CURSOR2          OUT   RETURNCURSOR )/* 분만장현황황조회 */
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHRMPTLIST(IN_HSP_TP_CD, OUT_CURSOR1);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHBR_RM_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHBRSTTS(TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), IN_HSP_TP_CD, OUT_CURSOR2);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHBR_RM_CRCCM_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CHBR_RM_PT_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_CRCCM_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장현황황조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_PATIENT_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_CRCCM_ASK       ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHBRSTTS(TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), IN_HSP_TP_CD,OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHBR_RM_CRCCM_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CHBR_RM_CRCCM_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_CHBR_RM_SCHD_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 분만장스케쥴조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_SCHEDULE_LIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHBR_RM_SCHD_ASK        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHRMSCHD(TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), IN_HSP_TP_CD,OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHBR_RM_SCHD_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_CHBR_RM_SCHD_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_BLOD_RDY_STS
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자혈액준비상태
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_42D_BLOOD_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_BLOD_RDY_STS         ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일자*/
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일자*/
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_TRFSORDSTS(IN_PT_NO, TO_DATE(IN_FRDATE, 'YYYYMMDD'), TO_DATE(IN_TODATE, 'YYYYMMDD'), IN_PACT_ID, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_BLOD_RDY_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_BLOD_RDY_STS;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH_ACV
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색(ACTIVE)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_ACTIVE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH_ACV             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PT_NM  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_MOBILE.PC_SEL_PATIENT_SEARCH_ACTIVE(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_PT_NM, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_SRCH_ACV' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_SRCH_ACV;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH_INAT
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색(INACTIVE)
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_SEARCH_INACTIVE
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH_INAT            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PT_NM  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_MOBILE.PC_SEL_PATIENT_SEARCH_INACTIVE(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, IN_PT_NM, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_SRCH_INAT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_SRCH_INAT;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_HME_HST
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자수진이력
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_RECORD_HISTORY
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_HME_HST              ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_MOBILE.PC_SEL_PATIENT_RECORD_HISTORY(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_PT_NO, '08',OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_HME_HST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_HME_HST;

/*===================================================================================
* 서비스이름      : PC_BSH_PT_SRCH
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 환자검색
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_PT_SRCH                 ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PT_NM             IN    VARCHAR2      /* 환자명 */
                                         , IN_LOGIN_SID         IN    VARCHAR2
                                         , IN_LOGIN_DEPT_CD     IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PT_NM  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_MOO_PT_SRCH(IN_HSP_TP_CD, IN_PT_NO, IN_PT_NM, IN_LOGIN_SID, IN_LOGIN_DEPT_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_PT_SRCH' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_PT_SRCH;

/*===================================================================================
* 서비스이름      : PC_BSH_RAD_CTG_ASK
* 최초 작성일     : 2012.12
* 최초 작성자     : 김승기
* DESCRIPTION     : 영상검사 FILTER 정보
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_RAD_CTG_ASK             ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_USE_YN            IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_USE_YN  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, '', V_SRCH_CNTE);
    END;

    BEGIN
        XSUP.PKG_BSH_SMARTCARE.PC_BSH_SEL_EXAMRAD_CATEGORY(IN_USE_YN,'08', OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_RAD_CTG_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_RAD_CTG_ASK;
                            

/*===================================================================================
* 서비스이름      : PC_BSH_EXAM_LIST_CNT
* 최초 작성일     : 2014.02
* 최초 작성자     : 조은영
* DESCRIPTION     : 모든검사 리스트 카운트 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAM_LIST_CNT ( IN_SQL_ID       IN    VARCHAR2      /* SQL ID */
                               , IN_STF_NO       IN    VARCHAR2      /* 직원번호 */
                               , IN_IP_ADDR      IN    VARCHAR2      /* IP ADDRESS */
                               , IN_HSP_TP_CD    IN    VARCHAR2      /* 병동구분코드 */
                               , IN_PT_NO        IN    VARCHAR2      /* 환자번호 */
                               , IN_FRDATE       IN    VARCHAR2      /* 조회 시작일 */
                               , IN_TODATE       IN    VARCHAR2      /* 조회 종료일 */
                               , OUT_CURSOR      OUT   RETURNCURSOR )

IS
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR 
        
     SELECT
       --검체
       (SELECT COUNT(*)
          FROM DUAL
         WHERE EXISTS
         (
           SELECT 1
             FROM XSUP.BSHMSELV B
            WHERE PT_NO = IN_PT_NO
              AND DEXM_RSLT_TP_CD = 'N'
              AND ACPT_DTM BETWEEN TO_DATE(IN_FRDATE, 'yyyymmdd')
                              AND TO_DATE(IN_TODATE, 'yyyymmdd') + 0.99999
         )) SPC_CNT

       --검체텍스트
       ,(SELECT COUNT(*)
           FROM DUAL
          WHERE EXISTS
          (
            SELECT 1
            FROM XSUP.BSHMSELV
             WHERE PT_NO = IN_PT_NO
             AND DEXM_RSLT_TP_CD = 'T'
             AND ACPT_DTM BETWEEN TO_DATE(IN_FRDATE, 'yyyymmdd')
                               AND TO_DATE(IN_TODATE, 'yyyymmdd') + 0.99999
          )) SPCTEXT_CNT

       --영상
       ,(SELECT COUNT(*)
           FROM DUAL
          WHERE EXISTS
          (
            SELECT 1
              FROM XSUP.BSHSMRRV
             WHERE PT_NO = IN_PT_NO
               AND EXEC_DTE BETWEEN TO_DATE(IN_FRDATE, 'YYYYMMDD')
                                AND TO_DATE(IN_TODATE, 'YYYYMMDD') + 0.99999
               AND EXM_PRGR_STS_CD IN ('E', 'D', 'N')
               AND HSP_TP_CD  = '08'
          ))RAD_CNT

       --기눙
       ,(SELECT COUNT(*)
           FROM DUAL
          WHERE EXISTS
          (
            SELECT 1
              FROM XSUP.BSHSMEFV
             WHERE PT_NO = IN_PT_NO
             AND ORD_DT BETWEEN TO_DATE(IN_FRDATE, 'YYYYMMDD')
                              AND TO_DATE(IN_TODATE, 'YYYYMMDD') + 0.99999
             AND EXM_PRGR_STS_CD IN ('E', 'D', 'N')
             AND HSP_TP_CD  = '08'
          )) FUN_CNT

       --병리 (개원일 부터 끝까지 조회)
       ,(SELECT COUNT(*)
           FROM DUAL
          WHERE EXISTS
          (
            SELECT 1
              FROM XSUP.BSHMSEPV
             WHERE PT_NO = IN_PT_NO
               AND ORD_DT BETWEEN TO_DATE('20030501', 'yyyymmdd')
                              AND TO_DATE('29991231', 'yyyymmdd') + 0.99999
          ))PAT_CNT

       FROM DUAL;
  
    
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAM_LIST_CNT - 모든검사 리스트 카운트 조회' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAM_LIST_CNT;
      
      
/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST_FILTER 
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 검체 필터 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST_FILTER     ( IN_SQL_ID       IN    VARCHAR2      /* SQL ID */
                                     , IN_STF_NO       IN    VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR      IN    VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD    IN    VARCHAR2      /* 병동구분코드 */
                                     , IN_PT_NO        IN    VARCHAR2      /* 환자번호 */
                                     , IN_FRDATE       IN    VARCHAR2      /* 조회 시작일 */
                                     , IN_TODATE       IN    VARCHAR2      /* 조회 종료일 */
                                     , IN_TYPE         IN    VARCHAR2      /* 구분 */
                                     , OUT_CURSOR      OUT   RETURNCURSOR )
IS
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
        
        SELECT  /* HIS.MS.EC.PS.EV.SelectExaminationResultMain.SelectTheFirstSpecimenExaminationFilterBrfg */
            /*+ USE_HASH (C)  INDEX (C MSELMEBM_SI06)*/
            A.MED_EXM_CTG_CD   EXM_CTG_CD
          , D.ORD_SLIP_CTG_NM  ORD_SLIP_CTG_NM
          , DECODE( NVL( C.DEXM_RSLT_TP_CD, 'N' ), 'T', 'T', '*', 'T', 'N' ) DEXM_RSLT_TP_CD
      FROM MSELMCED B
         , MSELMAID A
         , MSELMEBM C
         , CCOOCCSC D
     WHERE B.PT_NO = IN_PT_NO
       AND B.BRFG_DTM BETWEEN TO_DATE( IN_FRDATE, 'yyyymmdd' )
                          AND TO_DATE( IN_TODATE, 'yyyymmdd' ) + 0.99999
       AND A.SPCM_NO = B.SPCM_NO
       AND A.RSLT_BRFG_YN = 'Y'
       AND C.EXM_CD       = A.EXM_CD
       AND DECODE( NVL( C.DEXM_RSLT_TP_CD, 'N' ), 'T', 'T', '*', 'T', 'N' ) = IN_TYPE
       AND D.ORD_SLIP_CTG_CD = A.MED_EXM_CTG_CD
       --AND  A.MED_EXM_CTG_CD NOT IN ('L84')  -- 현장검사 제외
    GROUP BY A.MED_EXM_CTG_CD,D.ORD_SLIP_CTG_NM, DECODE( NVL( C.DEXM_RSLT_TP_CD, 'N' ), 'T', 'T', '*', 'T', 'N' )
    ORDER BY EXM_CTG_CD;
        
        
--    SELECT  DISTINCT A.MED_EXM_CTG_CD        --진료검사분류코드
--            , B.ORD_SLIP_CTG_NM       --처방전표분류명
--            , DECODE(NVL(C.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') DEXM_RSLT_TP_CD -- N : 검체 , T : 검체 텍스트
--      FROM MSELMAID A
--         , CCOOCCSC B
--         , MSELMEBM C
--         , MSELMCED D
--     WHERE A.PT_NO = IN_PT_NO
--       AND D.BRFG_DTM BETWEEN TO_DATE(IN_FRDATE, 'YYYYMMDD')
--                              AND TO_DATE(IN_TODATE, 'YYYYMMDD') + 0.99999
--       AND A.ACPT_DTM BETWEEN TO_DATE('20030301', 'yyyymmdd')
--                          AND TO_DATE(IN_TODATE, 'yyyymmdd') + 0.99999
--       AND A.MED_EXM_CTG_CD = B.ORD_SLIP_CTG_CD
--           AND A.EXM_CD = C.EXM_CD
--           AND D.SPCM_NO = A.SPCM_NO
--       AND DECODE(NVL(C.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') = IN_TYPE
----       AND A.MED_EXM_CTG_CD <> 'L84' 현장검사도 나오게 (2014.04.01)
--     ORDER BY A.MED_EXM_CTG_CD
--       ;

                          
    EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMSPC_LIST_FILTER' || ' ERRCODE = ' || SQLCODE || SQLERRM);                          
            
    END;
END PC_BSH_EXAMSPC_LIST_FILTER; 

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST_FILTER_VALUE 
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 조회(진검 필터 항목 선택시)
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_FILTER_VALUE     ( IN_SQL_ID       IN    VARCHAR2      /* SQL ID */
                                    , IN_STF_NO       IN    VARCHAR2      /* 직원번호 */
                                    , IN_IP_ADDR      IN    VARCHAR2      /* IP ADDRESS */
                                    , IN_HSP_TP_CD    IN    VARCHAR2      /* 병동구분코드 */
                                    , IN_PT_NO        IN    VARCHAR2      /* 환자번호 */
                                    , IN_FRDATE       IN    VARCHAR2      /* 조회 시작일 */
                                    , IN_TODATE       IN    VARCHAR2      /* 조회 종료일 */
                                    , IN_START        IN    VARCHAR2      /* 조회시작 인덱스 */
                                          , IN_END          IN    VARCHAR2      /* 조회종료 인덱스 */
                                    , IN_TYPE         IN    VARCHAR2      /* 구분 */
                                    , IN_EXAMCODE     IN    VARCHAR2      /* 검사코드 */
                                    , OUT_CURSOR      OUT   RETURNCURSOR )
IS
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
    SELECT  a.*
    FROM (
    SELECT --/*+ USE_NL(A.A A.B) */
             /*+ XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMSPC_LIST */
             A.PT_NO PT_NO -- 환자번호
            ,TO_CHAR(A.ORD_DT, 'yyyy-mm-dd') ORD_DTE -- 1순위 검사시행, 2순위 검사예약, 3순위 오더일
            ,TO_CHAR(A.ACPT_DTM, 'yyyy-mm-dd hh24:mi') REPT_DTE -- 접수일자
            ,A.SPCM_NO SPC_NO -- 검체번호
            ,A.ORD_SLIP_CTG_NM SLIP_NM -- 전표기표명/SLIP NAME
            ,A.SPCM_NM SPC_NM -- 검체명
            ,A.EITM_ABBR TST_SNM -- 검사항목명(약칭명)
            ,A.EXM_CD TST_CD -- 검사항목코드
            ,A.EXRS_CNTE TST_RSLT -- 검사결과
            ,A.RSLT_STAT RSLT_STAT --
            ,A.REF_VAL REF_VAL -- 참고치
            ,A.EXRS_UNIT TST_RSLTUNT -- 검사결과단위
            ,A.MED_EXM_CTG_CD TST_FRCT_CD -- 검사분류코드[진료용]
            ,A.SCRN_SORT_SEQ DIS_SEQ -- 나열순서
            ,TO_CHAR(A.BRFG_DTM, 'yyyy-mm-dd hh24:mi') RSLTDATE -- 결과 보고일시
            ,EXRS_RMK_CNTE TST_REMK -- 결과비고
            ,DEXM_RSLT_TP_CD DEXM_RSLT_TP_CD -- 결과유형 (T:텍스트, N:나머지(수치형등))
            ,TH2_EXRS_CNTE TH2_EXRS_CNTE -- 두번째검사결과 (4000BYTE 이상인 경우에만 있음)
            ,TO_CHAR(A.RCN_EXM_DTM, 'YYYY-MM-DD HH24:MI:SS') RCN_EXM_DTM -- 최근검사일시
            ,A.RCN_EXRS_CNTE -- 최근검사결과내용
            ,A.TH2_RCN_EXRS_CNTE -- 2번째최근검사결과내용 (4000BYTE 이상인 경우에만 있음)
            ,A.RCN_EXRS_RMK_CNTE -- 최근검사결과비고내용
            ,A.RCN_EXRS_RMK_DTM -- 최근검사결과비고일시
            ,A.RCN_EXRS_UNIT -- 최근검사결과단위
            ,RCN_RSLT_STAT -- 최근검사결과 상태
            ,RCN_REF_VAL -- 최근검사결과 참고치
            ,SCRN_SORT_SEQ2   --
          ,A.ACPT_DTM
      FROM   xsup.BSHMSELV A
--     WHERE   A.PT_NO = IN_PT_NO
--         AND ACPT_DTM BETWEEN TO_DATE(IN_FRDATE, 'yyyymmdd')
--                          AND TO_DATE(IN_TODATE, 'yyyymmdd') + 0.99999
         ) a,
--    (SELECT SPCM_NO
--           ,exm_Cd
--       FROM (SELECT ROWNUM rn
--                  , SPCM_NO,exm_Cd
--               FROM (SELECT /*+ USE_HASH (D) INDEX (B MSELMCED_SI19)  */
--                            A.SPCM_NO
--                           ,A.exm_Cd
--                       FROM MSELMAID A
--                          , MSELMEBM D
--                          , MSELMCED B
--                      WHERE A.PT_NO = IN_PT_NO
--                           AND B.BRFG_DTM BETWEEN TO_DATE(IN_FRDATE,  'yyyymmdd')
--                                               AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
--                        AND A.ACPT_DTM BETWEEN TO_DATE('20030301', 'yyyymmdd')
--                                           AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
--                        AND A.EXM_CD = D.EXM_CD
--                        AND B.SPCM_NO = A.SPCM_NO
--                        AND A.RSLT_BRFG_YN = 'Y'
--                        AND DECODE(NVL(D.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') IN(IN_TYPE)
--                        AND A.MED_EXM_CTG_CD IN( SELECT SUBSTR( IN_EXAMCODE
--                                          , INSTR( ',' || IN_EXAMCODE
--                                                         , ','
--                                                         , 1
--                                                         , LEVEL )
--                                                      , INSTR( IN_EXAMCODE || ','
--                                                             , ','
--                                                             , 1
--                                                             , LEVEL ) -
--                                                        INSTR( ',' || IN_EXAMCODE
--                                                             , ','
--                                                             , 1
--                                                             , LEVEL ) )v
--                                       FROM DUAL
--                                      CONNECT BY   LEVEL <= LENGTH( IN_EXAMCODE ) - LENGTH( REPLACE( IN_EXAMCODE, ',' ) ) + 1 )
--                      ORDER BY A.ACPT_DTM  DESC
--                        ,A.SPCM_NO
--                         ,A.MED_EXM_CTG_CD
--                         ,D.SCRN_SORT_SEQ
--                         ,A.EXM_CD))
--               WHERE rn BETWEEN IN_START AND IN_END
--               )b
  (SELECT ROW_INDEX,SPCM_NO
           ,exm_Cd
       FROM (SELECT ROWNUM AS ROW_INDEX,SPCM_NO,EXM_cD
               FROM (SELECT /*+ USE_HASH (D) INDEX (B MSELMCED_SI19)  */
                            A.SPCM_NO
                           ,A.exm_Cd
                       FROM MSELMAID A
                          , MSELMEBM D
                          , MSELMCED B
                      WHERE A.PT_NO = IN_PT_NO
                           AND B.BRFG_DTM BETWEEN TO_DATE(IN_FRDATE,  'yyyymmdd')
                                               AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
                        AND A.ACPT_DTM BETWEEN TO_DATE('20030301', 'yyyymmdd')
                                           AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
                        AND A.EXM_CD = D.EXM_CD
                        AND B.SPCM_NO = A.SPCM_NO
                        AND A.RSLT_BRFG_YN = 'Y'
                        AND DECODE(NVL(D.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') IN(IN_TYPE)
                        AND A.MED_EXM_CTG_CD IN( SELECT SUBSTR( IN_EXAMCODE
                                          , INSTR( ',' || IN_EXAMCODE
                                                         , ','
                                                         , 1
                                                         , LEVEL )
                                                      , INSTR( IN_EXAMCODE || ','
                                                             , ','
                                                             , 1
                                                             , LEVEL ) -
                                                        INSTR( ',' || IN_EXAMCODE
                                                             , ','
                                                             , 1
                                                             , LEVEL ) )v
                                       FROM DUAL
                                      CONNECT BY   LEVEL <= LENGTH( IN_EXAMCODE ) - LENGTH( REPLACE( IN_EXAMCODE, ',' ) ) + 1 )
                      ORDER BY A.ACPT_DTM  DESC
                        ,A.SPCM_NO
                         ,A.MED_EXM_CTG_CD
                         ,D.SCRN_SORT_SEQ
                         ,A.EXM_CD) ZZ
            WHERE ROWNUM <= IN_END      )
          WHERE ROW_INDEX >=IN_START
                   )b
           WHERE a.SPC_NO=b.SPCM_NO and a.TST_CD =b.exm_cd
           ORDER BY A.ACPT_DTM  DESC
                   ,A.SPC_NO
                 ,A.TST_FRCT_CD
                 ,A.SCRN_SORT_SEQ2
                 ,A.TST_CD; 
                          
    EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMSPC_LIST_FILTER' || ' ERRCODE = ' || SQLCODE || SQLERRM);                          
            
    END;
END PC_BSH_EXAMSPC_FILTER_VALUE;   

/*===================================================================================
* 서비스이름      : PC_BSH_EXAMSPC_LIST_PAGING
* 최초 작성일     : 2014.03
* 최초 작성자     : 조은영
* DESCRIPTION     : 검사결과 조회(진검) 페이징
* AS-IS 쿼리 정보 :          
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_EXAMSPC_LIST_PAGING     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO         IN    VARCHAR2      /* 환자번호 */
                                         , IN_FRDATE        IN    VARCHAR2      /* 조회 시작일 */
                                         , IN_TODATE        IN    VARCHAR2      /* 조회 종료일 */
                                         , IN_START         IN    VARCHAR2      /* 조회시작 인덱스 */
                                         , IN_END           IN    VARCHAR2      /* 조회종료 인덱스 */
                                         , IN_TYPE          IN    VARCHAR2      /* 구분 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
        SELECT  a.*
          FROM (
      SELECT --/*+ USE_NL(A.A A.B) */
               /*+ XSUP.PKG_BSH_SMARTCARE.PC_BSH_EXAMSPC_LIST */
               A.PT_NO PT_NO -- 환자번호
              ,TO_CHAR(A.ORD_DT, 'yyyy-mm-dd') ORD_DTE -- 1순위 검사시행, 2순위 검사예약, 3순위 오더일
              ,TO_CHAR(A.ACPT_DTM, 'yyyy-mm-dd hh24:mi') REPT_DTE -- 접수일자
              ,A.SPCM_NO SPC_NO -- 검체번호
              ,A.ORD_SLIP_CTG_NM SLIP_NM -- 전표기표명/SLIP NAME
              ,A.SPCM_NM SPC_NM -- 검체명
              ,A.EITM_ABBR TST_SNM -- 검사항목명(약칭명)
              ,A.EXM_CD TST_CD -- 검사항목코드
              ,A.EXRS_CNTE TST_RSLT -- 검사결과
              ,A.RSLT_STAT RSLT_STAT --                                        l
              ,A.REF_VAL REF_VAL -- 참고치
              ,A.EXRS_UNIT TST_RSLTUNT -- 검사결과단위
              ,A.MED_EXM_CTG_CD TST_FRCT_CD -- 검사분류코드[진료용]
              ,A.SCRN_SORT_SEQ DIS_SEQ -- 나열순서
              ,TO_CHAR(A.BRFG_DTM, 'yyyy-mm-dd hh24:mi') RSLTDATE -- 결과 보고일시
              ,EXRS_RMK_CNTE TST_REMK -- 결과비고
              ,DEXM_RSLT_TP_CD DEXM_RSLT_TP_CD -- 결과유형 (T:텍스트, N:나머지(수치형등))
              ,TH2_EXRS_CNTE TH2_EXRS_CNTE -- 두번째검사결과 (4000BYTE 이상인 경우에만 있음)
              ,TO_CHAR(A.RCN_EXM_DTM, 'YYYY-MM-DD HH24:MI:SS') RCN_EXM_DTM -- 최근검사일시
              ,A.RCN_EXRS_CNTE -- 최근검사결과내용
              ,A.TH2_RCN_EXRS_CNTE -- 2번째최근검사결과내용 (4000BYTE 이상인 경우에만 있음)
              ,A.RCN_EXRS_RMK_CNTE -- 최근검사결과비고내용
              ,A.RCN_EXRS_RMK_DTM -- 최근검사결과비고일시
              ,A.RCN_EXRS_UNIT -- 최근검사결과단위
              ,RCN_RSLT_STAT -- 최근검사결과 상태
              ,RCN_REF_VAL -- 최근검사결과 참고치
              ,SCRN_SORT_SEQ2   --
              ,A.ACPT_DTM
          FROM XSUP.BSHMSELV A
--         WHERE A.PT_NO = IN_PT_NO
--           AND ACPT_DTM BETWEEN TO_DATE(IN_FRDATE, 'yyyymmdd')
--                            AND TO_DATE(IN_TODATE, 'yyyymmdd') + 0.99999
           ) a,
--      (SELECT SPCM_NO,exm_Cd
--          FROM (SELECT ROWNUM rn
--                     , SPCM_NO,exm_Cd
--                  FROM (SELECT /*+ USE_HASH (D) INDEX (B MSELMCED_SI19)  */
--                               A.SPCM_NO
--                              ,A.exm_Cd
--                          FROM MSELMAID A
--                             , MSELMEBM D
--                             , MSELMCED B
--                 WHERE A.PT_NO = IN_PT_NO
--                   AND B.BRFG_DTM BETWEEN TO_DATE(IN_FRDATE,  'yyyymmdd')
--                                                    AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
--                   AND A.ACPT_DTM BETWEEN TO_DATE('20030301', 'yyyymmdd')
--                                      AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999
--                   AND A.EXM_CD = D.EXM_CD
--                   AND B.SPCM_NO = A.SPCM_NO
--                   AND A.RSLT_BRFG_YN = 'Y'
--                   AND DECODE(NVL(D.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') IN(IN_TYPE)
--                 ORDER BY   A.ACPT_DTM  DESC
--                           ,A.SPCM_NO
--                           ,A.MED_EXM_CTG_CD
--                           ,D.SCRN_SORT_SEQ
--                           ,A.EXM_CD
--                           ))
--                 WHERE rn BETWEEN IN_START AND IN_END
            (SELECT   ROW_INDEX, SPCM_NO,exm_Cd
              FROM   (SELECT   ROWNUM AS ROW_INDEX, SPCM_NO,exm_Cd
                        FROM   (  SELECT /*+ USE_HASH (CC)  INDEX (BB MSELMCED_SI19)*/
                                        aa.SPCM_NO,aa.exm_Cd
                                    FROM   MSELMAID AA, MSELMEBM CC, MSELMCED BB
                                   WHERE   AA.PT_NO = IN_PT_NO
                                       AND AA.ACPT_DTM BETWEEN TO_DATE('20030301', 'YYYY-MM-DD')
                                                          AND  TO_DATE(IN_TODATE, 'YYYY-MM-DD') + 0.99999
                                       AND BB.BRFG_DTM BETWEEN TO_DATE(IN_FRDATE,  'yyyymmdd')
                                                           AND TO_DATE(IN_TODATE,  'yyyymmdd') + 0.99999                         
                                       AND DECODE(NVL(CC.DEXM_RSLT_TP_CD, 'N'), 'T', 'T', '*', 'T', 'N') IN(IN_TYPE)
                                       AND CC.EXM_CD = AA.EXM_CD
                                       AND BB.SPCM_NO = AA.SPCM_NO
                                ORDER BY   AA.ACPT_DTM DESC
                                          ,AA.SPCM_NO
                                          ,AA.MED_EXM_CTG_CD
                                          ,CC.SCRN_SORT_SEQ
                                          ,AA.EXM_CD
                                   )ZZ
                       WHERE   ROWNUM <= IN_END)
             WHERE   ROW_INDEX >= IN_START
               )b
          where a.SPC_NO = b.SPCM_NO and a.TST_CD = b.exm_cd
          ORDER BY   A.ACPT_DTM  DESC
                    ,A.SPC_NO
                    ,A.TST_FRCT_CD
                    ,A.SCRN_SORT_SEQ2
                    ,A.TST_CD
          ;

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_EXAMSPC_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_EXAMSPC_LIST_PAGING;

/*===================================================================================
* 서비스이름      : PC_BSH_FTP_INFO
* 최초 작성일     : 2017.02.20
* 최초 작성자     : 조은영
* DESCRIPTION     : FTP 접근 정보 (기능검사 - 이미지 결과)
* AS-IS 쿼리 정보 :          
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_FTP_INFO     ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                              , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                              , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                              , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                              , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, '', V_SRCH_CNTE);
    END;

--    BEGIN
--        OPEN OUT_CURSOR FOR
--        
--        SELECT FTP_URL     -- FTP_URL
--             , FTP_PORT    -- FTP_PORT
--             , FTP_USER_ID -- FTP_USER_ID
--             , FTP_USER_PW -- FTP_USER_PW
--          FROM BSHMBFIM     -- FTP 접근 마스터 테이블
--         WHERE FTP_GRP_CD = 'SHDB001' -- BESTBoard 전용 구릅 코드
--           AND FTP_CD = 'DB_IMG_URL' -- BESTBoard 전용 FTP 코드
--           AND ROWNUM = 1 -- 예외 처리를 위해 rownum = 1 필수
--           ;
--        EXCEPTION  --예외처리
--            WHEN OTHERS THEN
--                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_FPT_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
--    END;
END PC_BSH_FTP_INFO;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_STDPT
* 최초 작성일     : 2013.05
* 최초 작성자     : 김승기
* DESCRIPTION     : 재원/퇴원환자 평균재원일수조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_STDPT               ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_JOBGUBN           IN    VARCHAR2      /* W:병동별, D:진료과별 */
                                         , IN_GUBN              IN    VARCHAR2      /* 작업구분 (병동별 조회 시만 : 3)*/
                                         , IN_FRDATE            IN    VARCHAR2      /* 조회시작일 */
                                         , IN_TODATE            IN    VARCHAR2      /* 조회종료일 */
                                         , IN_JOBTYPE           IN    VARCHAR2      /* IN_JOBTYPE : 104 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_JOBGUBN  || '''' ||
                       ',''' || IN_GUBN  || '''' ||
                       ',''' || IN_FRDATE  || '''' ||
                       ',''' || IN_TODATE  || '''' ||
                       ',''' || IN_JOBTYPE  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;


IF IN_JOBGUBN = 'W' THEN
    BEGIN
        XBIL.PKG_ACP_STAYMNG.PC_ACP_SEL_STDPT_CENTER(IN_GUBN, IN_FRDATE, IN_TODATE, IN_JOBTYPE, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_STDPT : PC_ACP_SEL_STDPT_CENTER' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
ELSIF IN_JOBGUBN = 'D' THEN
    BEGIN
        XBIL.PKG_ACP_STAYMNG.PC_ACP_SEL_STDPT_MEDDEPT(IN_FRDATE, IN_TODATE, IN_JOBTYPE, IN_HSP_TP_CD, OUT_CURSOR);
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_STDPT : PC_ACP_SEL_STDPT_MEDDEPT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END IF;

END PC_BSH_SEL_STDPT;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_STAYPTMNG
* 최초 작성일     : 2013.05
* 최초 작성자     : 김승기
* DESCRIPTION     : 재원환자관리
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_STAYPTMNG           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2
                                         , IN_MED_DEPT_CD       IN    VARCHAR2
                                         , IN_WD_DEPT_CD        IN    VARCHAR2
                                         , IN_CHDR_STF_NO       IN    VARCHAR2
                                         , IN_ANDR_STF_NO       IN    VARCHAR2  
                                         , IN_CPCD              IN    VARCHAR2   
                                         , IN_STAYDAY_FR        IN    VARCHAR2
                                         , IN_STAYDAY_TO        IN    VARCHAR2
                                         , IN_STAYMNG           IN    VARCHAR2
                                         , IN_SPCMNG            IN    VARCHAR2   
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MED_DEPT_CD  || '''' ||
                       ',''' || IN_WD_DEPT_CD  || '''' ||
                       ',''' || IN_CHDR_STF_NO  || '''' ||
                       ',''' || IN_ANDR_STF_NO  || '''' ||
                       ',''' || IN_CPCD  || '''' ||
                       ',''' || IN_STAYDAY_FR  || '''' ||
                       ',''' || IN_STAYDAY_TO  || '''' ||
                       ',''' || IN_STAYMNG  || '''' ||
                       ',''' || IN_SPCMNG  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        XBIL.PKG_ACP_STAYMNG.PC_ACP_SEL_STAYPTMNG( IN_PT_NO
                                                 , IN_MED_DEPT_CD
                                                 , IN_WD_DEPT_CD
                                                 , IN_CHDR_STF_NO
                                                 , IN_ANDR_STF_NO
                                                 , IN_CPCD
                                                 , IN_STAYDAY_FR
                                                 , IN_STAYDAY_TO
                                                 , IN_STAYMNG
                                                 , IN_SPCMNG
                                                 , IN_HSP_TP_CD
                                                 , OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_STAYPTMNG' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

END PC_BSH_SEL_STAYPTMNG;

/*==================================================================================
* 서비스이름  : PC_BSH_IMAF_SRAF_TP
* 최초 작성일 : 2012.08
* 최초 작성자 : 이지케어텍 김승기
* DESCRIPTION : 진료과별 내/외과계 구분
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_IMAF_SRAF_TP            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_GUBN              IN    VARCHAR2
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
BEGIN
    BEGIN
        OPEN OUT_CURSOR FOR
SELECT /*+ XMOB.PKG_BSH_DB.PC_BSH_IMAF_SRAF_TP */
       COMN_CD
     , DECODE(DTRL1_NM, '0', '센터', '1', '내과계', '2', '외과계', '3', '진료지원', '기타')  DP_TP
     , COMN_CD_NM
     , SCRN_MRK_SEQ
  FROM CCCCCSTE A
 WHERE COMN_GRP_CD = 'SHDB008'
   AND DTRL1_NM      = nvl(IN_GUBN, DTRL1_NM)
 ORDER BY DTRL1_NM, TO_NUMBER(SCRN_MRK_SEQ)
;
            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_IMAF_SRAF_TP' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_IMAF_SRAF_TP;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_PT_ACCESS_REASON
* 최초 작성일     : 2017-05-23
* 최초 작성자     : 김진균
* DESCRIPTION     : 환자 선택 사유 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_PT_ACCESS_REASON ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT COMN_CD
               , COMN_CD_NM
               , DTRL1_NM
            FROM CCCCCSTE
           WHERE COMN_GRP_CD = '436'
             AND USE_YN = 'Y'
             AND DTRL2_NM = 'DOC'
          ORDER BY COMN_CD ASC
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_PATIENT_ACCESS_REASON' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_PT_ACCESS_REASON;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_PT_PROTECTED
* 최초 작성일     : 2017-05-30
* 최초 작성자     : 김진균
* DESCRIPTION     : 환자 사생활 및 정보 보호 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_PT_PROTECTED ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                  , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                  , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                  , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */ 
                                  , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                  , IN_WK_SID            IN    VARCHAR2      /* SID */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
           SELECT XMED.FT_MOO_GET_ACCESS_RIGHT( IN_PT_NO
                                        , XCOM.FT_CNL_SELSTFINFO( '1'
                                                                , IN_WK_SID
                                                                , IN_HSP_TP_CD
                                                                , TO_CHAR(SYSDATE, 'YYYY-MM-DD'))
                                              , NULL
                                              , IN_HSP_TP_CD
                                              ) AS PT_PROTECTED_YN
            FROM DUAL
           ;

        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_PATIENT_ACCESS_REASON' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_PT_PROTECTED;


/*===================================================================================
* 서비스이름      : PC_BSH_SEL_DO_MEDDEPT_INFO
* 최초 작성일     : 2017-07-04
* 최초 작성자     : 김태운
* DESCRIPTION     : 의사별 진료과 등록정보 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_DO_MEDDEPT_INFO ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                     , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
                                     , IN_WK_SID            IN    VARCHAR2      /* SID */
                                     , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT USE_SID
               , MED_DEPT_CD
               , HSP_TP_CD
            FROM CNLMRUDD             --의사별진료과등록정보
           WHERE USE_SID = IN_WK_SID
             AND SYSDATE BETWEEN MED_STR_DT AND  MED_END_DT
          ORDER BY MED_STR_DT
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_DO_MEDDEPT_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_DO_MEDDEPT_INFO;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_DO_CNLMRPAD_INFO
* 최초 작성일     : 2017-07-04
* 최초 작성자     : 김태운
* DESCRIPTION     : 의사별,환자별 의사 협진정보 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_DO_CNLMRPAD_INFO ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
                                      , IN_WK_SID            IN    VARCHAR2      /* SID */
                                      , IN_PT_NO             IN    VARCHAR2      /* 등록번호 */ 
                                      , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */ 
                                      , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WK_SID  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
           SELECT PT_NO 
                , CTDR_STF_NO   
             FROM CNLMRPAD   --협진정보
            WHERE PT_NO = IN_PT_NO -- 등록번호
              AND HSP_TP_CD = IN_HSP_TP_CD -- 병원구분
              AND PACT_ID = IN_PACT_ID -- 원무접수ID
              AND CTDR_STF_NO IN (SELECT STF_NO FROM CNLRRUSD WHERE SID = IN_WK_SID) 
              AND CSLT_CNCL_DT IS NULL -- 협진 취소 일자
              AND ROWNUM = 1
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_DO_CNLMRPAD_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_DO_CNLMRPAD_INFO;

/*==================================================================================
* 서비스이름  : PC_BSH_UPD_RRT_STS
* 최초 작성일 : 2011.11
* 최초 작성자 : 이지케어텍 김승기
* description : RRT 환자 정보 업데이트
* 변경이력관리
===================================================================================*/
procedure PC_BSH_UPD_RRT_STS           ( IN_SQL_ID            IN    VARCHAR2   /* SQL ID */
                                       , IN_STF_NO            IN    VARCHAR2   /* 직원번호 */
                                       , IN_IP_ADDR           IN    VARCHAR2   /* IP ADDRESS */
                                       , IN_HSP_TP_CD         IN    VARCHAR2   /* 병동구분코드 */
                                       , IN_RRT_DTL_ID        IN    VARCHAR2   /* RRT 상세 ID */
                                       , IN_PACT_ID           IN    VARCHAR2   /* 원무접수ID */
                                       , IN_REC_CFMT_STS      IN    VARCHAR2   /* 결과 상태  */
                                       , IN_RRT_CCLT_RSN_CNTE IN    VARCHAR2   /* 해제 사유 */
                                       , IO_ERRYN             IN OUT VARCHAR2  /* ERROR Y/N */
                                       , IO_ERRMSG            IN OUT VARCHAR2 )/* MESSAGE */
IS
BEGIN
    BEGIN
        XMED.PKG_BSH_RRT.PC_BSH_UPD_RRT(IN_HSP_TP_CD, IN_RRT_DTL_ID, IN_PACT_ID, IN_REC_CFMT_STS, IN_STF_NO, 'BESTBOARD', IN_IP_ADDR, IN_RRT_CCLT_RSN_CNTE);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                IO_ERRYN := 'Y';
                IO_ERRMSG := 'PC_BSH_UPD_RRT_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM;
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_UPD_RRT_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_UPD_RRT_STS;

/*==================================================================================
* 서비스이름  : PC_BSH_INS_BESTBOARD_LOG
* 최초 작성일 : 2017.2.14
* 최초 작성자 : 네오젠소프트 김진균
* description : Lob Table에 삽입
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_INS_BESTBOARD_LOG           ( IN_SYS_NM                       IN     VARCHAR2   /* 시스템 명 */
                                             , IN_CLIENT_IP_ADDR               IN     VARCHAR2   /* 클라이언트 IP */
                                             , IN_CLIENT_DEPT_CD               IN     VARCHAR2   /* 부서 코드 */
                                             , IN_CLIENT_PC_MEMORY             IN     VARCHAR2   /* 메모리 사용량 */
                                             , IN_LOGIN_STF_NO                 IN     VARCHAR2   /* 로그인 직원 사번 */
                                             , IN_ACCESS_SERVER                IN     VARCHAR2   /* 접근 서버 IP */
                                             , IN_PROC_TYPE                    IN     VARCHAR2   /* 프로시저 타입  */
                                             , IN_PROC_NM                      IN     VARCHAR2   /* 프로시저 명 */
                                             , IN_PROC_COMMENT                 IN     VARCHAR2   /* 프로시저 설명 */
                                             , IN_PROC_PARAM_INFO              IN     VARCHAR2   /* 파라미터 정보 */
                                             , IN_DB_CALL_START_DTM            IN     VARCHAR2   /* 데이터베이스 호출 시작시간 */
                                             , IN_DB_CALL_END_DTM              IN     VARCHAR2   /* 데이터베이스 호출 종료시간 */
                                             , IN_CLIENT_BINDING_END_DTM       IN     VARCHAR2   /* 클라이언트 바인딩 완료시간 */
                                             , IN_DB_CALL_PROGRESS_TM          IN     VARCHAR2   /* 데이터베이스 호출 경과시간(초) */
                                             , IN_CLIENT_BINDING_PROGRESS_TM   IN     VARCHAR2   /* 클라이언트 바인딩 경과시간(초) */
                                             , IN_ALL_PROCESS_PROGRESS_TM      IN     VARCHAR2   /* 데이터베이스 호출 + 클라이언트 바인딩 경과시간(초) */
                                             , IN_DATA_SIZE                    IN     VARCHAR2   /* 조회한 데이터 사이즈(Byte) */
                                             , IN_CLIENT_LOGIC_PATH            IN     VARCHAR2   /* 클라이언트 바인딩 로직 구간 경로 */
                                             , IO_ERRYN                        IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG                       IN OUT VARCHAR2 ) /* MESSAGE */
IS
BEGIN     
   BEGIN
      INSERT INTO BSHPMLOG ( SYS_NM
                           , CLIENT_IP_ADDR
                           , CLIENT_DEPT_CD
                           , CLIENT_PC_MEMORY
                           , LOGIN_STF_NO
                           , ACCESS_SERVER
                           , PROC_TYPE
                           , PROC_NM
                           , PROC_COMMENT
                           , PROC_PARAM_INFO
                           , DB_CALL_START_DTM
                           , DB_CALL_END_DTM
                           , CLIENT_BINDING_END_DTM
                           , DB_CALL_PROGRESS_TM
                           , CLIENT_BINDING_PROGRESS_TM
                           , ALL_PROCESS_PROGRESS_TM
                           , DATA_SIZE
                           , CLIENT_LOGIC_PATH
                           )
                      VALUES
                           ( IN_SYS_NM
                           , IN_CLIENT_IP_ADDR
                           , IN_CLIENT_DEPT_CD
                           , TO_NUMBER(IN_CLIENT_PC_MEMORY)
                           , IN_LOGIN_STF_NO
                           , IN_ACCESS_SERVER
                           , IN_PROC_TYPE
                           , IN_PROC_NM
                           , IN_PROC_COMMENT
                           , IN_PROC_PARAM_INFO
                           , TO_DATE(IN_DB_CALL_START_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_DATE(IN_DB_CALL_END_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_DATE(IN_CLIENT_BINDING_END_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_NUMBER(IN_DB_CALL_PROGRESS_TM)
                           , TO_NUMBER(IN_CLIENT_BINDING_PROGRESS_TM)
                           , TO_NUMBER(IN_ALL_PROCESS_PROGRESS_TM)
                           , TO_NUMBER(IN_DATA_SIZE)
                           , IN_CLIENT_LOGIC_PATH
                           )
                           ;
      EXCEPTION  --예외처리
            WHEN OTHERS THEN
                IO_ERRYN := 'Y';
                IO_ERRMSG := 'PC_BSH_INS_BESTBOARD_LOG' || ' ERRCODE = ' || SQLCODE || SQLERRM;
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_INS_BESTBOARD_LOG' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
      END;
END PC_BSH_INS_BESTBOARD_LOG;

/*==================================================================================
* 서비스이름  : PC_INS_PT_ACCESS_LOG
* 최초 작성일 : 2017.05.22
* 최초 작성자 : 김진균
* DESCRIPTION : 선택사유 입력 저장
* 변경이력관리 : 2026-01-08, 환자선택사유 교직원 여부 및 부서 정보 추가로 인한 파라미터 추가 
===================================================================================*/
PROCEDURE PC_BSH_INS_PT_ACCESS_LOG( IN_SQL_ID                    IN     VARCHAR2      /* SQL ID */
                                  , IN_STF_NO                  IN     VARCHAR2      /* 직원번호 */
                                  , IN_IP_ADDR                  IN     VARCHAR2      /* IP 주소 */
                                  , IN_HSP_TP_CD               IN     VARCHAR2      /* 병원구분코드 */
                                  , IN_SID                     IN     VARCHAR2      /* SID */
                                  , IN_PT_NO               IN     VARCHAR2     /* 환자번호  */
                                  , IN_IFSC_PT_RDNG_APLC_RSN_CD        IN     VARCHAR2  /* 정보보호환자열람신청사유 코드  */
                                  , IN_MTD_DEPT_CD             IN     VARCHAR2     /* 진료과부서코드  */
                                  , IN_PACT_TP_CD              IN     VARCHAR2     /* 원무접수 코드   */
                                  , IN_PT_CHC_CNTE               IN     VARCHAR2     /* 환자선택 내용  */
                                  , IN_PT_AVT_YN               IN     VARCHAR2   /* 환자활성여부  */
                                  , IN_NRV_PSYC_YN             IN     VARCHAR2    /* 신경정신과 여부 */
                                  , IN_MDREC_PT_CHC_YN             IN     VARCHAR2  /*  의무기록환자 선택여부  */
                                  , IO_ERRYN                   IN OUT VARCHAR2
                                  , IO_ERRMSG                  IN OUT VARCHAR2    )
IS
BEGIN
    BEGIN   
       XMED.PKG_MOO_CNL_MRIRD.PC_MOOPTSAD_INSERT( IN_PT_NO
                              ,IN_SID
                              ,IN_IFSC_PT_RDNG_APLC_RSN_CD
                              ,IN_MTD_DEPT_CD
                              ,IN_PACT_TP_CD
                              ,IN_PT_CHC_CNTE
                              ,IN_PT_AVT_YN
                              ,IN_NRV_PSYC_YN
                              ,IN_MDREC_PT_CHC_YN
--                              ,NULL                  -- 추후 IN_PT_CHC_PATH_NM 환자선택경로명 파라미터 추가해야함 20170627
--                                                 ,NULL                  -- (SR:202511-00662) 의무기록열람이력모니터링 화면 수정 (동일 부서 교직원 의무기록 열람 통제 관련) 파라미터추가
--                                                 ,NULL                  -- (SR:202511-00662) 의무기록열람이력모니터링 화면 수정 (동일 부서 교직원 의무기록 열람 통제 관련) 파라미터추가
--                                                 ,NULL                  -- (SR:202511-00662) 의무기록열람이력모니터링 화면 수정 (동일 부서 교직원 의무기록 열람 통제 관련) 파라미터추가                               
                              ,IN_HSP_TP_CD
                              ,IN_STF_NO
                              ,'BESTBoard'
                              ,IN_IP_ADDR
                              ,IO_ERRYN
                              ,IO_ERRMSG);    
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_INS_PT_ACCESS_LOG' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;    
END PC_BSH_INS_PT_ACCESS_LOG;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LIST
* 최초 작성일     : 2018.01.02
* 최초 작성자     : 김태운
* DESCRIPTION     : MFICU(고위험산모치료실) 대기 환자 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LIST          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT A.PT_NO                                                                              PT_NO
               , B.PT_NM                                                                              PT_NM
               , XBIL.FT_PCT_AGE ( 'AUTO' , SYSDATE , B.PT_BRDY_DT )                                  PT_AGE
               , A.WD_DEPT_CD                                                                         WD_DEPT_CD
               , A.CLCTN_WD_DEPT_CD                                                                   CLCTN_WD_DEPT_CD
               , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNPRD',A.PT_NO,A.HSP_TP_CD)              CHBR_AGE
               , XMED.FT_MOO_DIAGNOSIS(A.PT_NO , NULL, A.MED_DEPT_CD, A.PACT_ID, A.HSP_TP_CD, 'L')    PT_DIAGNOSIS
               , A.PACT_ID                                                                            PACT_ID
               , A.MED_DEPT_CD                                                                        MED_DEPT_CD
               , A.HSP_TP_CD                                                                          HSP_TP_CD
               , 'Y'                                                                                  USE_YN
            FROM ACPPRAAM A             --입원접수기본
               , PCTPCPAM_DAMO B
           WHERE A.PT_NO = B.PT_NO
             AND ( A.CLCTN_WD_DEPT_CD IN('42MF', 'MFICU' ) --42MF (고위험산모태아집중치료실 전체 OR 041 병동 이면서  산부인과 진료과에 ALERT(임신) 정보 )
                 OR ( A.CLCTN_WD_DEPT_CD IN('041') AND A.MED_DEPT_CD = 'OG' AND XMED.FT_MOO_INFECT_CLS( A.PT_NO , NULL , A.HSP_TP_CD, '7') = 'A9998' )
                 )
             AND A.SIHS_YN = 'Y'
             AND NVL(A.DS_EXPT_DT,TO_DATE('2999-12-31','YYYY-MM-DD')) >= TRUNC(SYSDATE)  --퇴원예정일자 체크
             AND A.APCN_YN = 'N'
             AND A.HSP_TP_CD = IN_HSP_TP_CD
           ORDER BY DECODE(A.CLCTN_WD_DEPT_CD,'42MF',1,'MFICU',1,'041',2,A.CLCTN_WD_DEPT_CD) , A.PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_MFICU_LIST;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LOG_LIST
* 최초 작성일     : 2018.01.02
* 최초 작성자     : 김태운
* DESCRIPTION     : MFICU(고위험산모치료실) 저장 로그 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LOG_LIST      ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT A.PT_NO                                                                              PT_NO
               , B.PT_NM                                                                              PT_NM
               , XBIL.FT_PCT_AGE ( 'AUTO' , SYSDATE , B.PT_BRDY_DT )                                  PT_AGE
               , A.WD_DEPT_CD                                                                         WD_DEPT_CD
               , A.CLCTN_WD_DEPT_CD                                                                   CLCTN_WD_DEPT_CD
               , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNPRD',A.PT_NO,A.HSP_TP_CD)              CHBR_AGE
               , XMED.FT_MOO_DIAGNOSIS(A.PT_NO , NULL, A.MED_DEPT_CD, A.PACT_ID, A.HSP_TP_CD, 'L')    PT_DIAGNOSIS
               , A.PACT_ID                                                                            PACT_ID
               , A.MED_DEPT_CD                                                                        MED_DEPT_CD
               , A.HSP_TP_CD                                                                          HSP_TP_CD
               , A.USE_YN                                                                             USE_YN
            FROM BSHMFLOG A
               , PCTPCPAM_DAMO B
           WHERE A.PT_NO = B.PT_NO
             AND A.USE_YN = 'Y'
             AND A.PACT_ID IN ( SELECT PACT_ID
                                  FROM ACPPRAAM
                                 WHERE PACT_ID = A.PACT_ID
                                   AND SIHS_YN = 'Y'
                                   AND NVL(DS_EXPT_DT,TO_DATE('2999-12-31','YYYY-MM-DD')) >= TRUNC(SYSDATE)   --퇴원예정일자 체크
                                   AND APCN_YN = 'N' )
             AND ( A.CLCTN_WD_DEPT_CD IN('42MF','MFICU') --42MF (고위험산모태아집중치료실 전체 OR 041 병동 이면서  산부인과 진료과에 ALERT(임신) 정보 )
                 OR ( A.CLCTN_WD_DEPT_CD IN('041') AND A.MED_DEPT_CD = 'OG' AND XMED.FT_MOO_INFECT_CLS( A.PT_NO , NULL , A.HSP_TP_CD, '7') = 'A9998' )
                 )
             AND A.HSP_TP_CD = IN_HSP_TP_CD
           ORDER BY DECODE(A.CLCTN_WD_DEPT_CD,'42MF',1,'MFICU',1,'041',2,A.CLCTN_WD_DEPT_CD) , A.PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_MFICU_LOG_LIST;



/*==================================================================================
* 서비스이름  : PC_BSH_UPD_MFICU_LOG_LIST
* 최초 작성일 : 2018.01.02
* 최초 작성자 : 김태운
* DESCRIPTION : MFICU(고위험산모치료실) 환자 로그 수정
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_UPD_MFICU_LOG_LIST  ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                     , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                     , IN_PACT_ID           IN     VARCHAR2     /* 원무접수아이디 */
                                     , IN_PT_NO             IN     VARCHAR2     /* 환자번호 */
                                     , IN_MED_DEPT_CD       IN     VARCHAR2     /* 진료부서코드 */
                                     , IN_WD_DEPT_CD        IN     VARCHAR2     /* 병동부서코드 */
                                     , IN_CLCTN_WD_DEPT_CD  IN     VARCHAR2     /* 현위치병동부서코드 */
                                     , IN_USE_YN            IN     VARCHAR2     /* 사용여부 */  
                                     , IO_ERRYN             IN OUT VARCHAR2     /* ERROR Y/N */
                   , IO_ERRMSG            IN OUT VARCHAR2 )   /* MESSAGE */
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MED_DEPT_CD  || '''' ||
                       ',''' || IN_WD_DEPT_CD  || '''' ||
                       ',''' || IN_CLCTN_WD_DEPT_CD  || '''' ||
                       ',''' || IN_USE_YN  || '''' ||  
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        
        INSERT INTO BSHMFLOG ( PACT_ID
                             , HSP_TP_CD
                             , PT_NO
                             , MED_DEPT_CD
                             , WD_DEPT_CD
                             , CLCTN_WD_DEPT_CD
                             , USE_YN
                             , FSR_DTM
                             , FSR_STF_NO
                             , FSR_PRGM_NM
                             , FSR_IP_ADDR
                             , LSH_DTM
                             , LSH_STF_NO
                             , LSH_PRGM_NM
                             , LSH_IP_ADDR
                             )
                      VALUES ( IN_PACT_ID
                             , IN_HSP_TP_CD
                             , IN_PT_NO
                             , IN_MED_DEPT_CD
                             , IN_WD_DEPT_CD
                             , IN_CLCTN_WD_DEPT_CD
                             , IN_USE_YN
                             , SYSDATE
                             , NVL(IN_STF_NO,'C0EMR')
                             , 'BESTBoard'
                             , IN_IP_ADDR
                             , SYSDATE
                             , NVL(IN_STF_NO,'C0EMR')
                             , 'BESTBoard'
                             , IN_IP_ADDR
                             ) ;

       EXCEPTION
           WHEN DUP_VAL_ON_INDEX THEN
               BEGIN
                   UPDATE BSHMFLOG
                   SET USE_YN = IN_USE_YN
                        , LSH_STF_NO = NVL(IN_STF_NO,'C0EMR')
                        , LSH_DTM = SYSDATE
                        , LSH_PRGM_NM = 'BESTBoard'
                        , LSH_IP_ADDR = IN_IP_ADDR
                    WHERE PACT_ID = IN_PACT_ID
                      AND HSP_TP_CD = NVL(IN_HSP_TP_CD, '08') ;
       
                   EXCEPTION
                       WHEN OTHERS THEN
                           IO_ERRYN  := 'Y';
                           IO_ERRMSG := 'PC_BSH_UPD_MFICU_LOG_LIST : 사용여부 변경중 에러 발생  : ' || TO_CHAR(SQLCODE);
                           RETURN;
               END;
           WHEN OTHERS THEN
             IO_ERRYN  := 'Y';
             IO_ERRMSG := 'PC_BSH_UPD_MFICU_LOG_LIST : 신규등록중 에러 발생  : ' || TO_CHAR(SQLCODE);
             RETURN;                 
    END;
     EXCEPTION  --예외처리
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_UPD_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
END PC_BSH_UPD_MFICU_LOG_LIST;

/*==================================================================================
* 서비스이름  : PC_MOM_SEL_NURDUTY_WORKLIST
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 worklist 조회 (D/E/N에 따라 시간대별로 조회)
*               Duty별 시간표출조건
*               D 07:00 ~ 15:59
*               E 15:00 ~ 23:59
*               N 22:00 ~ 07:59 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_SEL_NURDUTY_WORKLIST ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_PLWK_WRK_CLS_CD   IN     VARCHAR2      /* DUTY */ 
                                      , IN_WRK_DT            IN     VARCHAR2      /* 기준일자 */
                                      , IN_NR_TEAM_TP_CD     IN     VARCHAR2      /* 간호팀구분코드*/
                                      , IN_PLWK_DEPT_CD      IN     VARCHAR2      /* 근무지부서코드 */
                                      , OUT_CURSOR           OUT    RETURNCURSOR )

 
IS
    V_SRCH_CNTE          VARCHAR2(4000);
    
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PLWK_WRK_CLS_CD  || '''' ||
                       ',''' || IN_WRK_DT  || '''' ||
                       ',''' || IN_NR_TEAM_TP_CD  || '''' ||
                       ',''' || IN_PLWK_DEPT_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;
    
    BEGIN
        /* 이혜정, BESTBoard worklist 현위치, 원무위치 조건 추가 (SR:202601-00845) 현위치 파라미터추가 */
        XMED.PKG_MOM_NURWORKINFO.PC_MOM_SEL_NURDUTY_WORKLIST(IN_PLWK_WRK_CLS_CD, IN_WRK_DT, IN_NR_TEAM_TP_CD, IN_PLWK_DEPT_CD, 'L', IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_MOM_SEL_NURDUTY_WORKLIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
END PC_MOM_SEL_NURDUTY_WORKLIST;

/*==================================================================================
* 서비스이름  : PC_MOM_SEL_EM_WORKLIST
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 응급실 worklist 조회 (N0000085) 팀 선택 하여 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_SEL_EM_WORKLIST      ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_EMRM_TEAM_CTG_CD  IN     VARCHAR2      /* 응급팀구분코드*/
                                      , OUT_CURSOR           OUT   RETURNCURSOR )

IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_EMRM_TEAM_CTG_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;
    
    BEGIN
        XMED.PKG_MOM_NURWORKINFO.PC_MOM_SEL_EM_WORKLIST(IN_EMRM_TEAM_CTG_CD, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_MOM_SEL_EM_WORKLIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
END PC_MOM_SEL_EM_WORKLIST;

/*==================================================================================
* 서비스이름  : PC_MOM_NURSING_DUTY_INFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호 부서팀 정보
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_NURDEPT_TEAM_INFO    ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , IN_PLWK_DEPT_CD      IN     VARCHAR2      /* 부서코드*/
                                      , OUT_CURSOR           OUT   RETURNCURSOR )


IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PLWK_DEPT_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;
    
    BEGIN
        XMED.PKG_MOM_NURWORKINFO.PC_MOM_NURDEPT_TEAM_INFO(IN_PLWK_DEPT_CD, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_MOM_NURDEPT_TEAM_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
END PC_MOM_NURDEPT_TEAM_INFO;

/*==================================================================================
* 서비스이름  : PC_MOM_PLCWRK_DEPTINFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 간호행정에서 사용하는 근무부서 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_PLCWRK_DEPTINFO      ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )

IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;
    
    BEGIN
        XMED.PKG_MOM_NURWORKINFO.PC_MOM_PLCWRK_DEPTINFO(IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_MOM_PLCWRK_DEPTINFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
END PC_MOM_PLCWRK_DEPTINFO;

/*==================================================================================
* 서비스이름  : PC_MOM_EM_TEAMINFO
* 최초 작성일 : 2020.04.14
* 최초 작성자 : 김태운
* DESCRIPTION : 응급실에서 사용하는 팀 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_MOM_EM_TEAMINFO          ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                      , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                      , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                      , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                      , OUT_CURSOR           OUT   RETURNCURSOR )

IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;
    
    BEGIN
        XMED.PKG_MOM_NURWORKINFO.PC_MOM_EM_TEAMINFO(IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_MOM_EM_TEAMINFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
    
END PC_MOM_EM_TEAMINFO;

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 입실/퇴실 예정 환자 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_LIST      ( IN_SQL_ID           IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
           SELECT PT_IO
               , PT_LOC
              , PT_NO
              , PT_NM
              , PT_SEX
              , PT_AGE
              , PT_DEPT_CD
              , WD_DEPT_CD
              , HSP_CD
             FROM EMNI007V
            WHERE WD_DEPT_CD = IN_WD_DEPT_CD
              AND HSP_CD = IN_HSP_TP_CD 
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_IO_LIST;
       
 
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_COUNT
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_COUNT    ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT WD_DEPT_CD       --01. 환자실병동부서코드' 
               , TOL_WD_CNT    --02. 전체 병상 
           , USE_WD_CNT       --03. 사용 병상 수
           , EMPT_WD_CNT      --04. 공 병상 수
           , ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)
           , ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
           , ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
           , IN_WD_CNT        --08. 입실예정 환자 수
           , OUT_WD_CNT       --09. 퇴실예정 환자 수
           , OP_CNT           --10. 수술 수
       fROM EMEI001V         
            WHERE WD_DEPT_CD = IN_WD_DEPT_CD
              -- AND HSP_CD = IN_HSP_TP_CD
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_IO_COUNT;
 
      
      

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_OP_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 수술 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_OP_LIST    ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT HSP_CD
         , PT_NO
         , OP_TITL
         , OP_RSV_NO
              FROM EMNI008V
             WHERE HSP_CD = IN_HSP_TP_CD
               AND PT_NO  = IN_PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_OP_LIST; 



                      
/*==================================================================================
* 서비스이름  : PC_EICU_INS_TEST_OP_INFO
* 최초 작성일 : 2021.03
* 최초 작성자 : 네오젠소프트 이원희
* description : 대시보드에서 검사 시술 내역 저장
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_INS_TEST_OP_INFO           ( IN_SQL_ID           IN     VARCHAR2      /* SQL ID */
                       , IN_STF_NO           IN     VARCHAR2      /* 직원번호 */
                                          , IN_IP_ADDR          IN     VARCHAR2      /* IP ADDRESS */
                                             , IN_ICU_TP_CD        IN     VARCHAR2
                       , IN_PT_NO            IN     VARCHAR2 
                       , IN_INPUT_DT         IN     VARCHAR2    /* 'hh24:mi'  */
                       , IN_HIST_SEQ         IN     VARCHAR2 
                       , IN_HSP_TP_CD        IN     VARCHAR2   
                       , IN_ITEM_TP_CD       IN     VARCHAR2
                       , IN_ITEM_CD          IN     VARCHAR2
                       , IN_ITEM_SUB_CD      IN     VARCHAR2 
                       , IN_MEMO             IN     VARCHAR2
                                             , IO_ERRYN            IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG           IN OUT VARCHAR2 ) /* MESSAGE */
IS
BEGIN   
  BEGIN  
--     V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
--                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
--                       ;
----                       ''''',''' || IN_STF_NO  || '''' ||
----                       ',''' || IN_IP_ADDR  || '''' ||
----                       ',''' || IN_PT_NO  || '''' || 
----                       ',''' || IN_HSP_TP_CD  || '''' ||
----                       ',:C);';                  
--                       
--        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
--        
      INSERT INTO HICU.BSHDBLST ( ICU_TP_CD
              , PT_NO
              , INPUT_DT
              , HIST_SEQ
              , HSP_TP_CD
              , ITEM_TP_CD
              , ITEM_CD
              , ITEM_SUB_CD
              , MEMO                  
              , REG_DTM
              , REG_ID 
                           )
                      VALUES
                           ( IN_ICU_TP_CD
              , IN_PT_NO
              , IN_INPUT_DT
              , nvl((select max(HIST_SEQ)+ 1 from HICU.BSHDBLST
                                    where ICU_TP_CD = IN_ICU_TP_CD
                                    and PT_NO       = IN_PT_NO ), 1)
              , IN_HSP_TP_CD
              , IN_ITEM_TP_CD
              , IN_ITEM_CD
              , IN_ITEM_SUB_CD
              , IN_MEMO   
              , sysdate
              , IN_STF_NO
                           )
                           ;
      EXCEPTION  --예외처리
            WHEN OTHERS THEN
                IO_ERRYN := 'Y';
                IO_ERRMSG := 'PC_EICU_INS_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM;
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_INS_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
      END;
END PC_EICU_INS_TEST_OP_INFO;


/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_OP_INFO
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사 시술 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_OP_INFO       ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_PT_NO  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);

       OPEN OUT_CURSOR FOR
           SELECT ICU_TP_CD
        , PT_NO
        , INPUT_DT
        , HIST_SEQ
        , HSP_TP_CD
        , ITEM_TP_CD
        , ITEM_CD
        , ITEM_SUB_CD
        , MEMO                  
        , REG_DTM
        , REG_ID
             FROM HICU.BSHDBLST
            WHERE HSP_TP_CD = IN_HSP_TP_CD
              AND PT_NO     = IN_PT_NO 
              and reg_dtm >= trunc(sysdate)
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_TEST_OP_INFO;    

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_COUNT
* 최초 작성일     : 2021.04.01
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술 카운트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_COUNT         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_ICU_TP_CD         IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_ICU_TP_CD  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_ICU_TP_CD, V_SRCH_CNTE);

       OPEN OUT_CURSOR FOR
           SELECT COUNT(DISTINCT PT_NO)
             FROM HICU.BSHDBLST
            WHERE HSP_TP_CD = IN_HSP_TP_CD
              AND ICU_TP_CD = IN_ICU_TP_CD
              AND REG_DTM >= trunc(sysdate)
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_TEST_COUNT;     
   
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_ITEM
* 최초 작성일     : 2021.04.05
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술 하위 항목 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_ITEM         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
--                       ''''',''' || IN_STF_NO  || '''' ||
--                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_ITEM_TP_CD  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', '', IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), '', IN_ITEM_TP_CD, V_SRCH_CNTE);

  IF IN_ITEM_TP_CD = 'A' THEN
       OPEN OUT_CURSOR FOR
      -- 검사
      select DETL_CD
            , DETL_CD_NM 
             from HICU.RRS_DETAIL
        where HSP_TP_CD = IN_HSP_TP_CD
           and MSTR_CD = 'DB_TEST'
           and USE_YN = 'Y'
        ORDER BY DISP_SEQ 
          ;
     ELSIF IN_ITEM_TP_CD = 'B' THEN
        OPEN OUT_CURSOR FOR
      -- 시술
      select DETL_CD
           , DETL_CD_NM 
        from HICU.RRS_DETAIL
       where HSP_TP_CD = IN_HSP_TP_CD
         and MSTR_CD = 'DB_OP'
         and USE_YN = 'Y'
        ORDER BY DISP_SEQ      
          ;
    END IF;
    
              
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_ITEM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;

    END;
END PC_EICU_SEL_TEST_ITEM;     
   
/*===================================================================================
* 서비스이름      : PC_EICU_TST_OP_LIST_DELETE
* 최초 작성일     : 2021.04.07
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 환자 검사, 시술, 수술 삭제
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TST_OP_LIST_DELETE      ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */ 
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HIST_SEQ          IN    VARCHAR2      /* 순번 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */                                                 
                                         , OUT_CURSOR           OUT   RETURNCURSOR 
                                         )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||    
                       ',''' || IN_ITEM_TP_CD  || '''' ||
                       ',''' || IN_HIST_SEQ  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);

--       OPEN OUT_CURSOR FOR
           DELETE FROM HICU.BSHDBLST
            WHERE HSP_TP_CD  = IN_HSP_TP_CD
              AND PT_NO      = IN_PT_NO
              AND ITEM_TP_CD = IN_ITEM_TP_CD 
              AND HIST_SEQ   = IN_HIST_SEQ
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TST_OP_LIST_DELETE' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_TST_OP_LIST_DELETE;   

               
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : 병원별 ICU 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_LIST    ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
																	, IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )    
IS                                  
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR             
			SELECT HSP_TP_CD
			     , DEPT_CD
			     , DEPT_NM
			     , RMK_CNTE
			  FROM HICU.UCCOCDPM
			 WHERE HSP_TP_CD = IN_HSP_TP_CD
			   AND USE_YN = 'Y'
			 ORDER BY SORT_SEQ
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_ICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_LIST; 
 
 
END PKG_BSH_DB;
