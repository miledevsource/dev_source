
  CREATE OR REPLACE EDITIONABLE PACKAGE "XICU"."PKG_CALL_CONTACT_MANAGE" 
IS
    TYPE REF_CURSOR IS REF CURSOR;

    /**********************************************************************************************
    * Procedure Name : PC_EICU_SELECT_EMPLOYEE_LIST
    * Description    : 직원 목록 조회
    **********************************************************************************************/
    PROCEDURE PC_EICU_SELECT_EMPLOYEE_LIST (
        IN_HSP_TP_CD  IN UCCOCUSM.HSP_TP_CD%TYPE,
        IN_USR_NM     IN UCCOCUSM.USR_NM%TYPE,
        OUT_CURSOR    OUT REF_CURSOR
    );

    /**********************************************************************************************
    * Procedure Name : PC_EICU_INSERT_EMPLOYEE_LIST
    * Description    : 직원 정보 등록
    **********************************************************************************************/
    PROCEDURE PC_EICU_INSERT_EMPLOYEE_LIST (
        IN_HSP_TP_CD     IN UCCOCUSM.HSP_TP_CD%TYPE,
        IN_USR_NM        IN UCCOCUSM.USR_NM%TYPE,
        IN_HIS_STF_NO    IN UCCOCUSM.HIS_STF_NO%TYPE,
        IN_RMK_CNTE      IN UCCOCUSM.RMK_CNTE%TYPE,
        IN_DEPT_NM       IN UCCOCUSM.DEPT_NM%TYPE,
        IN_TEL_NO        IN UCCOCUSM.TEL_NO%TYPE,  
        IN_FSR_STF_NO    IN UCCOCUSM.FSR_STF_NO%TYPE,
        IN_FSR_PRGM_NM   IN UCCOCUSM.FSR_PRGM_NM%TYPE,
        IN_FSR_IP_ADDR   IN UCCOCUSM.FSR_IP_ADDR%TYPE,
        OUT_CURSOR       OUT REF_CURSOR
    );

    /**********************************************************************************************
    * Procedure Name : PC_EICU_UPDATE_EMPLOYEE_LIST
    * Description    : 직원 정보 수정
    **********************************************************************************************/
    PROCEDURE PC_EICU_UPDATE_EMPLOYEE_LIST (
        IN_ID            IN VARCHAR2,
        IN_HSP_TP_CD     IN UCCOCUSM.HSP_TP_CD%TYPE,
        IN_USR_NM        IN UCCOCUSM.USR_NM%TYPE,
        IN_HIS_STF_NO    IN UCCOCUSM.HIS_STF_NO%TYPE,
        IN_USE_YN        IN UCCOCUSM.USE_YN%TYPE,
        IN_RMK_CNTE      IN UCCOCUSM.RMK_CNTE%TYPE,
        IN_DEPT_NM       IN UCCOCUSM.DEPT_NM%TYPE,
        IN_TEL_NO        IN UCCOCUSM.TEL_NO%TYPE,   
        IN_LSH_STF_NO    IN UCCOCUSM.LSH_STF_NO%TYPE,
        IN_LSH_PRGM_NM   IN UCCOCUSM.LSH_PRGM_NM%TYPE,
        IN_LSH_IP_ADDR   IN UCCOCUSM.LSH_IP_ADDR%TYPE,
        OUT_CURSOR       OUT REF_CURSOR
    );

END PKG_CALL_CONTACT_MANAGE;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_CALL_CONTACT_MANAGE" 
IS

    /**********************************************************************************************
    * Procedure Name : PC_EICU_SELECT_EMPLOYEE_LIST
    * Description    : 직원 목록 조회
    **********************************************************************************************/
    PROCEDURE PC_EICU_SELECT_EMPLOYEE_LIST (
        IN_HSP_TP_CD  IN UCCOCUSM.HSP_TP_CD%TYPE,
        IN_USR_NM     IN UCCOCUSM.USR_NM%TYPE,
        OUT_CURSOR    OUT REF_CURSOR
    )
    IS
    BEGIN
        OPEN OUT_CURSOR FOR
            SELECT ID,
                   HSP_TP_CD,
                   USR_NM,
                   HIS_STF_NO,
                   RMK_CNTE,
                   DEPT_NM,
                   TEL_NO
              FROM UCCOCUSM
             WHERE (IN_HSP_TP_CD IS NULL 
                OR TRIM(IN_HSP_TP_CD) = ''
                OR HSP_TP_CD = IN_HSP_TP_CD)
               AND USR_NM LIKE '%' || IN_USR_NM || '%'
               AND USE_YN = 'Y'
             ORDER BY SORT_SEQ, USR_NM;
    END PC_EICU_SELECT_EMPLOYEE_LIST;


    /**********************************************************************************************
    * Procedure Name : PC_EICU_INSERT_EMPLOYEE_LIST
    * Description    : 직원 정보 등록
    **********************************************************************************************/
    PROCEDURE PC_EICU_INSERT_EMPLOYEE_LIST (
        IN_HSP_TP_CD     IN UCCOCUSM.HSP_TP_CD%TYPE,
        IN_USR_NM        IN UCCOCUSM.USR_NM%TYPE,
        IN_HIS_STF_NO    IN UCCOCUSM.HIS_STF_NO%TYPE,
        IN_RMK_CNTE      IN UCCOCUSM.RMK_CNTE%TYPE,
        IN_DEPT_NM       IN UCCOCUSM.DEPT_NM%TYPE,
        IN_TEL_NO        IN UCCOCUSM.TEL_NO%TYPE,   
        IN_FSR_STF_NO    IN UCCOCUSM.FSR_STF_NO%TYPE,
        IN_FSR_PRGM_NM   IN UCCOCUSM.FSR_PRGM_NM%TYPE,
        IN_FSR_IP_ADDR   IN UCCOCUSM.FSR_IP_ADDR%TYPE,
        OUT_CURSOR       OUT REF_CURSOR
    )
    IS
        V_ID UCCOCUSM.ID%TYPE;
        V_ERR_MSG VARCHAR2(4000);
    BEGIN
        INSERT INTO UCCOCUSM (
            ID,
            USR_SID,
            HSP_TP_CD,
            USR_NM,
            HIS_USR_SID,
            HIS_STF_NO,
            AVL_STR_DTM,
            AVL_END_DTM,
            USE_YN,
            RMK_CNTE,
            DEPT_NM,
            TEL_NO, 
            FSR_STF_NO,
            FSR_DTM,
            FSR_PRGM_NM,
            FSR_IP_ADDR,
            LSH_STF_NO,
            LSH_DTM,
            LSH_PRGM_NM,
            LSH_IP_ADDR
        )
        VALUES (
		    SEQ_UCCOCUSM.NEXTVAL,
		    SUBSTR(IN_HIS_STF_NO, 1, 6),
		    IN_HSP_TP_CD,
		    IN_USR_NM,
		    SUBSTR(IN_HIS_STF_NO, 1, 6),
		    SUBSTR(IN_HIS_STF_NO, 1, 6),
		    SYSDATE,
		    NULL,
		    'Y',
		    IN_RMK_CNTE,            
		    IN_DEPT_NM,
		    IN_TEL_NO,
		    SUBSTR(IN_FSR_STF_NO, 1, 6),
		    SYSDATE,
		    IN_FSR_PRGM_NM,
		    IN_FSR_IP_ADDR,
		    SUBSTR(IN_FSR_STF_NO, 1, 6),
		    SYSDATE,
		    IN_FSR_PRGM_NM,
		    IN_FSR_IP_ADDR    
		)
        RETURNING ID INTO V_ID;

	    OPEN OUT_CURSOR FOR
	        SELECT 'S' AS O_RTN_CD,
	               '정상적으로 저장되었습니다.' AS O_RTN_MSG,
	               V_ID AS O_ID
	          FROM DUAL;
	
	EXCEPTION
	    WHEN OTHERS THEN
			 V_ERR_MSG := SQLERRM;
	
	        OPEN OUT_CURSOR FOR
	            SELECT 'E' AS O_RTN_CD,
	                   V_ERR_MSG AS O_RTN_MSG,
	                   NULL AS O_ID
	              FROM DUAL;

    END PC_EICU_INSERT_EMPLOYEE_LIST;


    /**********************************************************************************************
    * Procedure Name : PC_EICU_UPDATE_EMPLOYEE_LIST
    * Description    : 직원 정보 수정
    **********************************************************************************************/
	PROCEDURE PC_EICU_UPDATE_EMPLOYEE_LIST (
	    IN_ID            IN VARCHAR2,
	    IN_HSP_TP_CD     IN UCCOCUSM.HSP_TP_CD%TYPE,
	    IN_USR_NM        IN UCCOCUSM.USR_NM%TYPE,
	    IN_HIS_STF_NO    IN UCCOCUSM.HIS_STF_NO%TYPE,
	    IN_USE_YN        IN UCCOCUSM.USE_YN%TYPE,
	    IN_RMK_CNTE      IN UCCOCUSM.RMK_CNTE%TYPE,
	    IN_DEPT_NM       IN UCCOCUSM.DEPT_NM%TYPE,
	    IN_TEL_NO        IN UCCOCUSM.TEL_NO%TYPE,
	    IN_LSH_STF_NO    IN UCCOCUSM.LSH_STF_NO%TYPE,
	    IN_LSH_PRGM_NM   IN UCCOCUSM.LSH_PRGM_NM%TYPE,
	    IN_LSH_IP_ADDR   IN UCCOCUSM.LSH_IP_ADDR%TYPE,
	    OUT_CURSOR       OUT REF_CURSOR
	)
	IS
	BEGIN
	
	    -- 기존 데이터 종료 처리
	    UPDATE UCCOCUSM
	       SET AVL_END_DTM = SYSDATE,
	           USE_YN      = 'N',
	           LSH_STF_NO  = IN_LSH_STF_NO,
	           LSH_DTM     = SYSDATE,
	           LSH_PRGM_NM = IN_LSH_PRGM_NM,
	           LSH_IP_ADDR = IN_LSH_IP_ADDR
	     WHERE ID = TO_NUMBER(TRIM(IN_ID));
	
	    -- 신규 활성 데이터 생성
	    IF IN_USE_YN = 'Y' THEN
	
	        INSERT INTO UCCOCUSM
	        (
	            ID,
	            USR_SID,
	            HSP_TP_CD,
	            USR_NM,
	            HIS_USR_SID,
	            HIS_STF_NO,
	            AVL_STR_DTM,
	            AVL_END_DTM,
	            USE_YN,
	            RMK_CNTE,
	            DEPT_NM,
	            TEL_NO,
	            FSR_STF_NO,
	            FSR_DTM,
	            FSR_PRGM_NM,
	            FSR_IP_ADDR,
	            LSH_STF_NO,
	            LSH_DTM,
	            LSH_PRGM_NM,
	            LSH_IP_ADDR
	        )
	        VALUES
	        (
	            SEQ_UCCOCUSM.NEXTVAL,
	            SUBSTR(IN_HIS_STF_NO, 1, 6),
	            IN_HSP_TP_CD,
	            IN_USR_NM,
	            SUBSTR(IN_HIS_STF_NO, 1, 6),
	            SUBSTR(IN_HIS_STF_NO, 1, 6),
	            SYSDATE,
	            NULL,
	            'Y',
	            IN_RMK_CNTE,
	            IN_DEPT_NM,
	            IN_TEL_NO,
	            IN_LSH_STF_NO,
	            SYSDATE,
	            IN_LSH_PRGM_NM,
	            IN_LSH_IP_ADDR,
	            IN_LSH_STF_NO,
	            SYSDATE,
	            IN_LSH_PRGM_NM,
	            IN_LSH_IP_ADDR
	        );
	
	    END IF;
	
	END PC_EICU_UPDATE_EMPLOYEE_LIST;

END PKG_CALL_CONTACT_MANAGE;
