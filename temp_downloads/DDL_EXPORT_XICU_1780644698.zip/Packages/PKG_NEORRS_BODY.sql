
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_NEORRS" 
IS  
  
  
/*===================================================================================  
* 서비스이름      : PC_INS_RRT  
* 최초 작성일     : 2020.03  
* 최초 작성자     : 하만석  
* DESCRIPTION     : RRS 데이터 입력  
* 변경이력관리  
===================================================================================*/  
PROCEDURE PC_INS_RRT        ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */  
                            , IN_PACT_ID          IN VARCHAR2   /* 원무접수ID */  
                            , IN_PT_NO            IN VARCHAR2   /* 환자번호 */  
                            , IN_RRS_ITEM_TP      IN VARCHAR2   /* 1:간호(임상관찰기록) : V, 2:진검(검사항목) : L */  
                            , IN_RRS_ITEM_CD      IN VARCHAR2   /* 항목ID (간호:MRITEM_ID, 진검:TST_CD) */  
                            , IN_RRS_ITEM_NM      IN VARCHAR2   /* 항목명 (간호 항목명, 진검 검사명) */  
                            , IN_UITM_DTM         DATE          /* 항목 입력 일자 */  
                            , IN_REC_CNTE         IN VARCHAR2   /* 결과값 */  
                            , IN_STF_NO           IN VARCHAR2   /* 입력 직원번호 */  
                            , IN_PRGM_NM          IN VARCHAR2   /* 프로그램명 */  
                            , IN_IP_ADDR          IN VARCHAR2 ) /* 입력 PC-IPADDRESS (AS_IS NULL 가능)*/  
  
IS  
    V_SYSDATE DATE := SYSDATE;  
    V_HIST_SEQ NUMBER := 0;  
    V_CNT NUMBER := 0;  
    V_AGE VARCHAR2(40) :='';  
    V_GET_MINAGE NUMBER := 0;  
  
    V_INSERT_YN_CNT NUMBER := 0;  
BEGIN  
  
    BEGIN     
        ---------------------------------------------------------------------------------------------------------------------------------------------  
        -- 검사항목 존재여부 판단  
        select count(*)  
          into V_CNT  
          from HICU.RRS_DETAIL  
         where ( (IN_RRS_ITEM_TP = 'L' and mstr_Cd in ( 'LAB', 'LAB_ADD') )  
              or (IN_RRS_ITEM_TP = 'V' and mstr_Cd in ( 'VITAL', 'VITAL_ADD') ) )  
           and HSP_TP_CD = IN_HSP_TP_CD  
           and USE_YN = 'Y'  
           and ( DETL_CD_1 = IN_RRS_ITEM_CD or DETL_CD_2 = IN_RRS_ITEM_CD or DETL_CD_3 = IN_RRS_ITEM_CD or DETL_CD_4 = IN_RRS_ITEM_CD )  
         ;  
        if V_CNT = 0 THEN  
            return;  
        end if;  
  
        ---------------------------------------------------------------------------------------------------------------------------------------------  
        -- 이력 번호 확인  
        select count(*)  
          into V_HIST_SEQ  
          from HICU.RRS_MOBRRSMT  
         where PACT_ID = IN_PACT_ID  
         ;  
  
        ---------------------------------------------------------------------------------------------------------------------------------------------  
        -- 데이터 등록  
        INSERT INTO HICU.RRS_MOBRRSMT ( PACT_ID  
                             , HIST_SEQ  
                             , HSP_TP_CD  
                             , PT_NO  
                             , RRT_ITEM_TP  -- RRT항목구분(VITAL : V, LIS : L)';  
                             , RRT_ITEM_CD  
                             , RRT_ITEM_NM  
                             , UITM_DTM  
                             , ENT_DT  
                             , RRT_RSLT_VAL  
                             , REC_CFMT_YN  
  
                             , FSR_DTM  
                             , FSR_STF_NO  
                             , FSR_PRGM_NM  
                             , FSR_IP_ADDR  
                             , LSH_DTM  
                             , LSH_STF_NO  
                             , LSH_PRGM_NM  
                             , LSH_IP_ADDR  
                             )  
                      VALUES ( IN_PACT_ID  
                             , V_HIST_SEQ  
                             , IN_HSP_TP_CD  
                             , IN_PT_NO  
                             , IN_RRS_ITEM_TP  
                             , IN_RRS_ITEM_CD  
                             , IN_RRS_ITEM_NM  
                             , IN_UITM_DTM  
                             , to_char(V_SYSDATE, 'yyyymmdd')  
                             , IN_REC_CNTE  
                             , 'X'  
                             , V_SYSDATE  
                             , IN_STF_NO  
                             , IN_PRGM_NM  
                             , IN_IP_ADDR  
                             , TO_DATE('29991231', 'YYYYMMDD')  
                             , IN_STF_NO  
                             , IN_PRGM_NM  
                             , IN_IP_ADDR  
                             )  
        ;  
        EXCEPTION  
            WHEN OTHERS THEN  
                RAISE_APPLICATION_ERROR(-20002, 'PC_CNUH_INS_RRT - INSERTING MOBRRTMT' || 'ERROR CODE : ' || SQLCODE || 'ERROR MESSAGE :' || SQLERRM );  
    END;  
  
END PC_INS_RRT;  
  
  
  
/*===================================================================================  
* 서비스이름      : PC_RRSDATA_INS  
* 최초 작성일     : 2020.03  
* 최초 작성자     : 하만석  
* DESCRIPTION   : RRS 데이터 입력  
* 변경이력관리    : --2025/중증도 --> NEWS 변경
===================================================================================*/  
PROCEDURE PC_RRSDATA_INS ( IN_HSP_TP_CD        IN VARCHAR2 )  /* 병원구분코드 */  
IS  
    V_SYSDATE DATE;  
  
    V_CNT_1 NUMBER := 0;  
    V_CNT_2 NUMBER := 0;  
    V_CUR_STATE VARCHAR2(1) := ''; -- 현재 상태  
    V_FLOW_YN VARCHAR2(1) := 'N';  
    V_TOT_NEWS NUMBER := 0;        -- 전체 NEWS 값  
    V_SMS_TXT VARCHAR2(2000) := ''; -- 문자 내용  
  
    V_ASDR_SID VARCHAR2(8) := ''; -- 담당의  사번  
    V_TEL_NO VARCHAR2(100) := ''; -- 담당의 핸드폰번호  
  
    V_OVER_7_SMS VARCHAR2(1) := 'N'; -- 7점 이상인경우 의사에게 문자전송 할지말지 결정  
    V_CALLBACK_PHONE VARCHAR2(20) := '01000000000'; -- SMS 연락받을 번호  
  
    V_EACH_ITEM_NEWS VARCHAR2(2) := '00';  
  
    V_WD_DEPT_CD     VARCHAR2(5) := '';  
    V_PRM_NO         VARCHAR2(4) := '';  
    V_BED_NO         VARCHAR2(2) := '';  
    
BEGIN  
    V_SYSDATE := SYSDATE; 
    
--DBMS_OUTPUT.PUT_LINE('1.V_SYSDATE...' || TO_CHAR(V_SYSDATE, 'YYYYMMDDHH24MISS'));  
    FOR X IN ( SELECT V.PACT_ID  
					, V.HSP_TP_CD  
					, V.PT_NO  
					, V.NR_ITEM_ID        RRT_ITEM_CD  
					, V.NR_ITEM_NM  
					, TO_CHAR(V.ITEM_REC_DTM, 'YYYY-MM-DD HH24:MI:SS') ITEM_REC_DTM  
					, TO_CHAR(V.ITEM_REC_DTM, 'YYYY-MM-DD')            ITEM_REC_DTE
					, V.REC_CNTE          RRT_RSLT_VAL  
					, V.LSH_STF_NO  
					, V.PT_CLCTN_DEPT_CD  
					, TO_CHAR(V.LSH_DTM, 'YYYY-MM-DD HH24:MI') LSH_DTM
					, DECODE(NVL(R.MSTR_CD, 'VITAL'), 'VITAL', 'V', 'L') RRT_ITEM_TP  
				 FROM XICU.EMNI009V V  
				    , ( SELECT HSP_TP_CD, DETL_CD_1, MSTR_CD  
				          FROM HICU.RRS_DETAIL  
				         WHERE HSP_TP_CD = IN_HSP_TP_CD  
				           AND MSTR_CD IN ('VITAL', 'LAB') ) R  
				WHERE V.HSP_TP_CD  = IN_HSP_TP_CD  
				  AND V.NR_ITEM_ID = R.DETL_CD_1(+)   
				  AND V.LSH_DTM >= SYSDATE - 1/24/60 * 20 /* 현재일시 -20분 전 */
    )  
    LOOP  
        BEGIN  
            ---------------------------------------------------------------------------------------------------------------------------------------------  
            -- 등록한 환자 패스  
            SELECT COUNT(*)  
              INTO V_CNT_1   
			  FROM HICU.RRS_VALUE_H R  
			 WHERE HSP_TP_CD   = X.HSP_TP_CD  
			   AND PT_NO       = X.PT_NO  
			   AND PACT_ID     = X.PACT_ID          
			   AND ENT_DT      = SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8)  
			   AND RRS_ITEM_CD = X.RRT_ITEM_CD  
			   AND REG_DTM     = TO_DATE(X.LSH_DTM, 'YYYY-MM-DD HH24:MI')
            ;  
             
--DBMS_OUTPUT.PUT_LINE('2.DIFF...' ||V_CNT_1 || '==' || X.HSP_TP_CD || '==' || X.PT_NO || '==' || X.PACT_ID || '==' || X.ITEM_REC_DTM || '==' || X.RRT_ITEM_CD || '==' ||  X.LSH_DTM || '--' || SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8) ); 
            IF V_CNT_1 > 0 THEN  
                CONTINUE;  
            END IF;  
                   
            V_CNT_1 := 0;  
-- DBMS_OUTPUT.PUT_LINE('2.DIFF...CONTINUE...' ) ;
             
            ---------------------------------------------------------------------------------------------------------------------------------------------  
            -- 중지 상태로 환자 변경하면 더이상 확인 불필요  
            SELECT COUNT(*)  
              INTO V_CNT_1  
              FROM HICU.RRS_STATE  
             WHERE PT_NO        = X.PT_NO  
               AND HSP_TP_CD    = IN_HSP_TP_CD  
               AND HIST_SEQ     = 0  
               AND RRS_STATE_CD IN ('X', 'R') 
               ;  
  
            IF V_CNT_1 > 0 THEN  
                CONTINUE;  
            END IF;  
  
            ---------------------------------------------------------------------------------------------------------------------------------------------  
            -- 등록된 값 확인  
            SELECT COUNT(PT_NO)  
              INTO V_CNT_2  
              FROM HICU.RRS_VALUE  
             WHERE PT_NO       = X.PT_NO  
               AND ENT_DT      = TO_CHAR(V_SYSDATE, 'YYYYMMDD')  
               AND RRS_ITEM_CD = X.RRT_ITEM_CD  
               AND HSP_TP_CD   = X.HSP_TP_CD  
               ;  
  
--    DBMS_OUTPUT.PUT_LINE('1.22.INPUT/.///.V_CNT_2 : ' || V_CNT_2); 
    
    
            IF V_CNT_2 = 0 THEN -- 신규 입력     
            	BEGIN  
            	DBMS_OUTPUT.PUT_LINE('1.2...' || X.RRT_RSLT_VAL);  
                ---------------------------------------------------------------------------------------------------------------------------------------------  
                -- 검사입력범위 확인  
                SELECT IN_YN INTO V_FLOW_YN  
                  FROM (  
                      -- 참고치 없으면 통과 안했는데 없어도 그냥 진행  
                    SELECT CASE WHEN    TO_NUMBER(NVL(MAX_VAL, '9999')) >= TO_NUMBER(X.RRT_RSLT_VAL)  
                                    AND TO_NUMBER(NVL(MIN_VAL, '-9999')) <= TO_NUMBER(X.RRT_RSLT_VAL) THEN 'N'  
                                ELSE 'Y' END IN_YN  
                      FROM HICU.RRS_ITEM_STD  
                     WHERE ( (X.RRT_ITEM_TP = 'L' AND MSTR_CD IN ( 'LAB', 'LAB_ADD') )  
                          OR (X.RRT_ITEM_TP = 'V' AND MSTR_CD IN ( 'VITAL', 'VITAL_ADD') ) )  
                       AND HSP_TP_CD = X.HSP_TP_CD  
                       AND DEPT_CD = X.PT_CLCTN_DEPT_CD
                       AND AGE_GRP = 'A'  
                       AND HIST_SEQ = 0  
                       AND ITEM_CD = X.RRT_ITEM_CD  
                       AND ITEM_CD NOT IN (  
                           SELECT DETL_CD_1  
                             FROM HICU.RRS_DETAIL  
                            WHERE MSTR_CD   = 'VITAL'  
                              AND HSP_TP_CD = X.HSP_TP_CD  
                              AND DETL_CD IN ('GCS','OXYGEN')  
                        )  
                    UNION  
                    SELECT CASE WHEN DETL_CD = 'GCS' AND '' = 'A' THEN 'N'  
                                WHEN DETL_CD = 'OXYGEN' THEN 'Y'  
                                ELSE 'Y' END  
                      FROM HICU.RRS_DETAIL  
                     WHERE MSTR_CD   = 'VITAL'  
                       AND HSP_TP_CD = X.HSP_TP_CD  
                       AND DETL_CD IN ('GCS','OXYGEN')  
                       AND (   DETL_CD_1 = X.RRT_ITEM_CD 
                            OR DETL_CD_2 = X.RRT_ITEM_CD 
                            OR DETL_CD_3 = X.RRT_ITEM_CD 
                            OR DETL_CD_4 = X.RRT_ITEM_CD 
                           )  
                   )  
                   ;  
--      DBMS_OUTPUT.PUT_LINE('1.22..V_FLOW_YN : ' || V_FLOW_YN); 
                IF NVL(V_FLOW_YN, 'Y') = 'N' THEN  
                    CONTINUE;  
                END IF;  
  
                ---------------------------------------------------------------------------------------------------------------------------------------------  
                -- 해당 값 등록    
                INSERT  
                  INTO HICU.RRS_VALUE ( PT_NO, ENT_DT, RRS_ITEM_CD, HSP_TP_CD, PACT_ID, PT_NM, PT_SEX, PT_AGE, HD, POD  
                                 , DEPT_CD, DEPT_NM, DOC_NO, DOC_NM, DIAG_CD, DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO  
                                 , RRS_VALUE, ENT_DTM, RRS_STATE_CD  --, NEWS_SCORE  
                                 , REG_DTM, REG_ID, REG_IP, EQIP_KIND_CD )  
                            SELECT X.PT_NO  
                                 , SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8)
                                 , X.RRT_ITEM_CD  
                                 , X.HSP_TP_CD   
                                 , X.PACT_ID  
                                 , V.PT_NM    
                                 , V.SEX_TP_CD   
                                 , V.PT_AGE       
                                 , V.ENT_DUR_DT_CNT  
                                 , V.OP_DUR_DT_CNT  
                                 , V.MED_DEPT_CD  
                                 , V.MED_DEPT_NM  
                                 , V.ANDR_STF_NO  
                                 , V.ANDR_KOR_NM  
                                 , V.DIAG_CD  
                                 , V.DIAG_NM  
                                 , V.WD_DEPT_CD   
                                 , ''  
                                 , V.BED_NO  
                                 , X.RRT_RSLT_VAL  
                                 , TO_DATE(X.ITEM_REC_DTM, 'YYYY-MM-DD HH24:MI:SS')    --  X.ITEM_REC_DTM  
                                 , 'I'  
                                 --, V.SVRT_SCR_NO  
                                 , TO_DATE(X.LSH_DTM, 'YYYY-MM-DD HH24:MI')
                                 , 'EMNI004V VIEW'  
                                 , 'IP'  
                                 , V.EQIP_KIND_CD  
                              FROM EMNI004V V  
                             WHERE 1=1  
                               AND V.PACT_ID = X.PACT_ID  
                               AND V.HSP_CD = X.HSP_TP_CD  
                               AND ROWNUM < 2  
                    ;       
                    
                    
                    UPDATE HICU.RRS_VALUE A  
                       SET NEWS_SCORE = NVL( LPAD(( SELECT MAX(V.SVRT_SCR_NO)  
							                          FROM EMNI004V V  
							                         WHERE V.PACT_ID = X.PACT_ID  
							                           AND V.HSP_CD = X.HSP_TP_CD ), 2, '0') , '00') 
----                 , RRS_STATE_CD = CASE WHEN V_TOT_NEWS >= 5 THEN 'I'  
----                                       ELSE A.RRS_STATE_CD END  
--------------------------------------------------------------------------------------------------------------
--//20205 //NEWS_SCORE 중증도 > NEWS SCORE, DNR여부 추가 
-------------------------------------------------------------------------------------------------------------- 
                         , NEWS    = NVL( LPAD( (SELECT MAX(NEWS)
                                                   FROM NEWSCALCULATOR 
                                                  WHERE PT_NO        = X.PT_NO 
                                                    AND UITM_DT      = TO_DATE(X.ITEM_REC_DTE,'YYYY-MM-DD')
                                                    AND ITEM_REC_DTM = TO_DATE(X.ITEM_REC_DTM,'YYYY-MM-DD HH24:MI:SS')
                                                ), 2, '0') , '00')   
                         , DNR_YN  = 'Y' --(SELECT MAX(DNR_CSFM_YN) FROM DNRCSFMV WHERE PT_NO = X.PT_NO)      
--------------------------------------------------------------------------------------------------------------- 
		             WHERE PT_NO      = X.PT_NO  
		               AND ENT_DT     = SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8)
		               AND HSP_TP_CD  = X.HSP_TP_CD  
		               ----AND ENT_DTM >= X.FSR_DTM - 1/24/60 * 20  
		               ;  
		                         
		            -- 이력 생성   
		            DBMS_OUTPUT.PUT_LINE('2.DIFF...11.OUT...' ) ; 
		            XICU.PKG_NEORRS.PC_MAKE_HIST(X.PT_NO, SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8), X.RRT_ITEM_CD, X.HSP_TP_CD);
                    
              	EXCEPTION  --예외처리  
	            	WHEN OTHERS THEN  
	                	RAISE_APPLICATION_ERROR(-20553, 'PC_RRSDATA_INS_1' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;    
	            END;    
  
            ELSE  -- 수정 등록  
                SELECT WD_DEPT_CD, PRM_NO, BED_NO  
                  INTO V_WD_DEPT_CD, V_PRM_NO, V_BED_NO  
                  FROM ACPPRAAM A  
                 WHERE PACT_ID = ( SELECT MAX(PACT_ID) PACT_ID  
                                     FROM HICU.RRS_VALUE  
                                    WHERE HSP_TP_CD = IN_HSP_TP_CD  
                                      AND PT_NO = X.PT_NO  
                                 )  
                   AND ROWNUM = 1  
                   ;  
  
                UPDATE HICU.RRS_VALUE  
                   SET CUR_VALUE = X.RRT_RSLT_VAL  
                     , ENT_DTM   = TO_DATE(X.ITEM_REC_DTM, 'YYYY-MM-DD HH24:MI:SS') 
                     --, NEWS_SCORE = V.SVRT_SCR_NO  
                     , REG_DTM   = TO_DATE(X.LSH_DTM, 'YYYY-MM-DD HH24:MI')  -- V_SYSDATE  
                     , WARD_NO   = V_WD_DEPT_CD  
                     , ROOM_NO   = V_PRM_NO  
                     , BED_NO    = V_BED_NO  
                 WHERE PT_NO = X.PT_NO  
                   AND ENT_DT = TO_CHAR(V_SYSDATE, 'YYYYMMDD')  
                   AND RRS_ITEM_CD = X.RRT_ITEM_CD  
                   AND HSP_TP_CD = X.HSP_TP_CD  
                   ;    
                   
                 UPDATE HICU.RRS_VALUE A  
                    SET NEWS_SCORE = NVL( LPAD(( SELECT MAX(V.SVRT_SCR_NO)  
                                                   FROM EMNI004V V  
                                                  WHERE V.PACT_ID = X.PACT_ID  
                                                    AND V.HSP_CD = X.HSP_TP_CD ), 2, '0') , '00')  
	--                 , RRS_STATE_CD = CASE WHEN V_TOT_NEWS >= 5 THEN 'I'  
	--                                       ELSE A.RRS_STATE_CD END      
--------------------------------------------------------------------------------------------------------------
--//20205 //NEWS_SCORE 중증도 > NEWS SCORE, DNR여부 추가 
-------------------------------------------------------------------------------------------------------------- 
                     , NEWS    = NVL( LPAD( (SELECT MAX(NEWS)
                                               FROM NEWSCALCULATOR 
                                              WHERE PT_NO        = X.PT_NO 
                                                AND UITM_DT      = TO_DATE(X.ITEM_REC_DTE,'YYYY-MM-DD')
                                                AND ITEM_REC_DTM = TO_DATE(X.ITEM_REC_DTM,'YYYY-MM-DD HH24:MI:SS')
                                             ), 2, '0') , '00')   
                     , DNR_YN  = 'Y' -- (SELECT MAX(DNR_CSFM_YN) FROM DNRCSFMV WHERE PT_NO = X.PT_NO)      
-------------------------------------------------------------------------------------------------------------- 
	             WHERE PT_NO      = X.PT_NO  
	               AND ENT_DT     = SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8) 
	               AND HSP_TP_CD  = X.HSP_TP_CD  
	               --AND ENT_DTM >= X.FSR_DTM - 1/24/60 * 20  
	               ;  
	                         
	            -- 이력 생성 
--DBMS_OUTPUT.PUT_LINE('2.DIFF...22.OUT...' ) ; 
	            XICU.PKG_NEORRS.PC_MAKE_HIST(X.PT_NO, SUBSTR(REPLACE(X.ITEM_REC_DTM, '-' ,''), 1,8), X.RRT_ITEM_CD, X.HSP_TP_CD);
                 
            END IF;  
          
        EXCEPTION  
            WHEN OTHERS THEN  
                NULL;  
        END;  
--         DBMS_OUTPUT.PUT_LINE('2.DIFF...OUT...' ) ;
    END LOOP;  

-- DBMS_OUTPUT.PUT_LINE('2.DIFF...DONE....' ) ;  
--    COMMIT;  
END PC_RRSDATA_INS  
;  
  
  
/*===================================================================================  
* 서비스이름      : PC_MAKE_HIST  
* 최초 작성일     : 2020.03  
* 최초 작성자     : 하만석  
* DESCRIPTION     : RRS 이력 데이터 생성  
* 변경이력관리  
===================================================================================*/  
PROCEDURE PC_MAKE_HIST         ( IN_PT_NO            IN VARCHAR2     /* 환자번호 */  
                               , IN_ENT_DT           IN VARCHAR2     /* 등록일자 */  
                               , IN_ITEM_CD          IN VARCHAR2     /* 검사코드 */  
                               , IN_HSP_TP_CD        IN VARCHAR2  )  /* 병원구분코드 */  
IS  
  
BEGIN  
    begin  
        insert into HICU.RRS_VALUE_H (PT_NO, ENT_DT, RRS_ITEM_CD, HSP_TP_CD, HIST_SEQ, PACT_ID, PT_NM, PT_SEX, PT_AGE, HD, POD, DEPT_CD  
                                , DEPT_NM, DOC_NO, DOC_NM, DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO, CFRM_DTM, CFRM_ID, RRS_VALUE_H  
                                , CUR_VALUE, ENT_DTM, RRS_STATE_CD, NEWS_SCORE, ITEM_NEWS_SCORE, REG_DTM, REG_ID, REG_IP, EQIP_KIND_CD, DIAG_CD
                                , NEWS, DNR_YN) --//2025 추가  
  
        select PT_NO, ENT_DT, RRS_ITEM_CD, HSP_TP_CD  
             , nvl((select max(HIST_SEQ) + 1 from HICU.RRS_VALUE_H  
                     where PT_NO = IN_PT_NO  
                       and ENT_DT = IN_ENT_DT  
                       and RRS_ITEM_CD = IN_ITEM_CD  
                       and HSP_TP_CD = IN_HSP_TP_CD ), 0)  
             , PACT_ID, PT_NM, PT_SEX, PT_AGE, HD, POD, DEPT_CD  
             , DEPT_NM, DOC_NO, DOC_NM, DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO, CFRM_DTM, CFRM_ID, RRS_VALUE  
             , CUR_VALUE, ENT_DTM, RRS_STATE_CD, NEWS_SCORE, ITEM_NEWS_SCORE, REG_DTM, REG_ID, REG_IP  
             , EQIP_KIND_CD, DIAG_CD
             , NEWS, DNR_YN  
         from HICU.RRS_VALUE  
        where PT_NO = IN_PT_NO  
          and ENT_DT = IN_ENT_DT  
          and RRS_ITEM_CD = IN_ITEM_CD  
          and HSP_TP_CD = IN_HSP_TP_CD  
          ;  
  
        exception  --예외처리  
             when others then  
                    RAISE_APPLICATION_ERROR(-20553, 'PC_MAKE_HIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;  
  
    end;  
END PC_MAKE_HIST;  
  
  
END PKG_NEORRS;
