
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_EZOTC_EICU" 
IS 
     TYPE RETURNCURSOR IS REF CURSOR;    
    /**********************************************************************************************
    * Service Name : PC_EZOTC_INSERT_LOG
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    * 2021-03-18   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/
    PROCEDURE PC_EZOTC_INSERT_LOG (
        IN_INSERTSTAFFNUMBER          IN LOG_EZOTC_EICU.INSERTSTAFFNUMBER%TYPE,
        IN_ICU                        IN LOG_EZOTC_EICU.ICU%TYPE,
        IN_STATUS                     IN LOG_EZOTC_EICU.STATUS%TYPE,
        IN_PATIENTNUMBER              IN LOG_EZOTC_EICU.PATIENTNUMBER%TYPE,
        IN_ROOMNAME                   IN LOG_EZOTC_EICU.ROOMNAME%TYPE,
        IN_DEPSTAFFNUMBER             IN LOG_EZOTC_EICU.DEPSTAFFNUMBER%TYPE,      
        IN_DESSTAFFNUMBER             IN LOG_EZOTC_EICU.DESSTAFFNUMBER%TYPE,
        IN_CALLSTARTTIME              IN LOG_EZOTC_EICU.CALLSTARTTIME%TYPE,
        IN_CALLENDTIME                IN LOG_EZOTC_EICU.CALLENDTIME%TYPE,
        IN_MULTICALLYN                IN LOG_EZOTC_EICU.MULTICALLYN%TYPE,      
        IN_AUDIOFILEPATH              IN LOG_EZOTC_EICU.AUDIOFILEPATH%TYPE,
        IN_HOSPITALCODE               IN LOG_EZOTC_EICU.HOSPITALCODE%TYPE,
        IN_DESCRIPTION                IN LOG_EZOTC_EICU.DESCRIPTION%TYPE,
        IN_INSERTSTAFFDEPT            IN LOG_EZOTC_EICU.INSERTSTAFFDEPT%TYPE,
        IN_ACCS_IP_ADDR               IN LOG_EZOTC_EICU.ACCS_IP_ADDR%TYPE    
    )
    IS
    BEGIN
      INSERT INTO LOG_EZOTC_EICU
             (ID
             ,INSERTSTAFFNUMBER  
             ,ICU
             ,STATUS
             ,INSERTDATE
             ,PATIENTNUMBER  
             ,ROOMNAME
             ,DEPSTAFFNUMBER
             ,DESSTAFFNUMBER
             ,CALLSTARTTIME
             ,CALLENDTIME
             ,MULTICALLYN
             ,AUDIOFILEPATH
             ,HOSPITALCODE
             ,DESCRIPTION
             ,INSERTSTAFFDEPT
             ,ACCS_IP_ADDR
             )
      VALUES (SEQ_LOG_EZOTC_EICU_ID.NEXTVAL
             ,IN_INSERTSTAFFNUMBER  
             ,IN_ICU
             ,IN_STATUS
             ,SYSDATE
             ,IN_PATIENTNUMBER  
             ,IN_ROOMNAME
             ,IN_DEPSTAFFNUMBER
             ,IN_DESSTAFFNUMBER
             ,SYSDATE
             ,NULL
             ,IN_MULTICALLYN
             ,IN_AUDIOFILEPATH
             ,IN_HOSPITALCODE
             ,IN_DESCRIPTION
             ,IN_INSERTSTAFFDEPT
             ,IN_ACCS_IP_ADDR
             );
    END PC_EZOTC_INSERT_LOG; 

    /**********************************************************************************************
    * Service Name : PC_EZOTC_UPDATE_LOG
    * CREATED DATE : 
    * CREATED USER : LEE HYUNKYUNG
    * Description  : 
    * ---------------------------------------------------------------------------------------------
    * History      :           
    * 2021-03-18   : LEE HYUNKYUNG Created.
    ***********************************************************************************************/
    PROCEDURE PC_EZOTC_UPDATE_LOG (              
        IN_ROOMNAME                   IN LOG_EZOTC_EICU.ROOMNAME%TYPE,
        IN_AUDIOFILEPATH              IN LOG_EZOTC_EICU.AUDIOFILEPATH%TYPE,
        IN_MULTICALLYN                IN LOG_EZOTC_EICU.MULTICALLYN%TYPE,
        IN_DESCRIPTION                IN LOG_EZOTC_EICU.DESCRIPTION%TYPE
    )
    IS
    BEGIN
      UPDATE LOG_EZOTC_EICU
         SET CALLENDTIME   = SYSDATE
            ,AUDIOFILEPATH = IN_AUDIOFILEPATH   
            ,MULTICALLYN   = IN_MULTICALLYN
            ,DESCRIPTION   = IN_DESCRIPTION
       WHERE ID = (SELECT MAX(ID)
                     FROM LOG_EZOTC_EICU
                    WHERE ROOMNAME = IN_ROOMNAME)
         AND STATUS = 'CALL'
         AND CALLENDTIME IS NULL;
         
    END PC_EZOTC_UPDATE_LOG; 
    
    
    /**********************************************************************************************
    * Service Name : PC_EZOTC_SAVE_LOGIN_HISTORY
    * CREATED DATE : 
    * CREATED USER : 
    * Description  : EICU 로그인/로그아웃 이력 저장 Wrapper
    ***********************************************************************************************/
    PROCEDURE PC_EZOTC_SAVE_LOGIN_HISTORY (
          IN_HSP_TP_CD        IN VARCHAR2
        , IN_HIS_STF_NO       IN VARCHAR2
        , IN_USR_NM           IN VARCHAR2
        , IN_PRGM_LCLS_CD     IN VARCHAR2
        , IN_EPCN_YN          IN VARCHAR2
        , IN_WD_DEPT_CD       IN VARCHAR2
        , IN_HIS_PRGM_NM      IN VARCHAR2
        , IN_HIS_IP_ADDR      IN VARCHAR2
        , IN_LOGIN_YN         IN VARCHAR2   -- 'Y': 로그인, 'N': 로그아웃
        , IO_ERR_YN           OUT VARCHAR2
        , IO_ERR_MSG          OUT VARCHAR2
    )
    IS
        V_LGIN_DTM   DATE;
        V_LGOT_DTM   DATE;
    BEGIN
        IO_ERR_YN  := 'N';
        IO_ERR_MSG := NULL;

        IF IN_LOGIN_YN = 'Y' THEN
            V_LGIN_DTM := SYSDATE;
            V_LGOT_DTM := NULL;
        ELSE
            V_LGIN_DTM := NULL;
            V_LGOT_DTM := SYSDATE;
        END IF;

        PC_EICU_SAVE_LOGIN_HISTORY
        (
              IN_HSP_TP_CD     => IN_HSP_TP_CD
            , IN_HIS_STF_NO    => IN_HIS_STF_NO
            , IN_USR_NM        => IN_USR_NM
            , IN_PRGM_LCLS_CD  => IN_HSP_TP_CD
            , IN_EPCN_YN       => IN_EPCN_YN
            , IN_WD_DEPT_CD    => IN_WD_DEPT_CD
            , IN_LGIN_DTM      => V_LGIN_DTM
            , IN_LGOT_DTM      => V_LGOT_DTM
            , IN_HIS_PRGM_NM   => IN_HIS_PRGM_NM
            , IN_HIS_IP_ADDR   => IN_HIS_IP_ADDR
            , IO_ERR_YN        => IO_ERR_YN
            , IO_ERR_MSG       => IO_ERR_MSG
        );

    EXCEPTION
        WHEN OTHERS THEN
            IO_ERR_YN  := 'Y';
            IO_ERR_MSG := SQLERRM;
    END PC_EZOTC_SAVE_LOGIN_HISTORY;       
                                                
END Pkg_EZOTC_EICU;
