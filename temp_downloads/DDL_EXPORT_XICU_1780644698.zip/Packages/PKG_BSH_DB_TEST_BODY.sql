
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_BSH_DB_TEST" AS

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_ADS_PT_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : ICU 입원환자 조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_ADS_PT_LIST         ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_WD_NO         IN    VARCHAR2      /* 병동번호 */
                                         , IN_RM_NO         IN    VARCHAR2      /* 실번호 */
                                         , OUT_CURSOR       OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN    
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_WD_NO  || '''' ||
                       ',''' || IN_RM_NO  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
--            XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST(
--                  IN_HSP_TP_CD
--                , IN_WD_NO
--                , IN_RM_NO
--                , OUT_CURSOR
--            );   
OPEN OUT_CURSOR FOR
        SELECT /*+ XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_PATIENTLIST */
               Z.PT_NO                                                        PatientID
             , Z.PACT_ID                                                      PactID
             , A.PT_NM                                                        PatientName
             , A.SEX_TP_CD                                                    PatientSex
             , XBIL.FT_PCT_AGE ( 'AUTO' , SYSDATE , A.PT_BRDY_DT )            PatientAge
             , A.ABOB_TP_CD || A.RHB_TP_CD || DECODE(A.BBNK_BLTYP_KND_CD, NULL, NULL, '/' || A.BBNK_BLTYP_KND_CD)  PatientAbo
             , XMED.FT_MRN_BODYMSMTINF('BODYHEIGHT', 'PT_L', 'N', Z.PT_NO, Z.HSP_TP_CD, NULL, NULL, NULL, NULL)         PatientHeight
             , XMED.FT_MRN_BODYMSMTINF('BODYWEIGHT', 'PT_L', 'N', Z.PT_NO, Z.HSP_TP_CD, NULL, NULL, NULL, NULL)         PatientWeight
             , Z.WD_DEPT_CD                                                                                        PatientWardNoInBil
             , ( SELECT DEPT_NM FROM PDEDBMSM WHERE DEPT_CD = Z.WD_DEPT_CD AND HSP_TP_CD = Z.HSP_TP_CD)            PatientWardNameInBil
             , Z.PRM_NO                                                                                            PatientRoomNoInBil
             , Z.BED_NO                                                                                            PatientBedNoInBil
             , Z.CLCTN_WD_DEPT_CD                                                                                  PatientWardNoInNurse
             , ( SELECT DEPT_NM FROM PDEDBMSM WHERE DEPT_CD = Z.CLCTN_WD_DEPT_CD AND HSP_TP_CD = Z.HSP_TP_CD )     PatientWardNameInNurse
             , Z.CLCTN_PRM_NO                                                                                      PatientRoomNoInNurse
             , Z.CLCTN_BED_NO                                                                                      PatientBedNoInNurse
             , Z.MED_DEPT_CD                                                                                       PatientMedDeptCode
             , ( SELECT DEPT_NM FROM PDEDBMSM WHERE DEPT_CD = Z.MED_DEPT_CD AND HSP_TP_CD = Z.HSP_TP_CD)           PatientMedDeptName
             , DECODE(Z.CHDR_STF_NO, NULL, Z.NCDR_STF_NO, Z.CHDR_STF_NO)                                           PatientMedDeptGubun
             , 'MEDDR_ID'                                                                                          PatientPrfDoctorId
             , XMED.FT_MOO_USERNM(DECODE(Z.CHDR_STF_NO, NULL, Z.NCDR_STF_NO, Z.CHDR_STF_NO))                            PatientPrfDoctorName
             , Z.ANDR_STF_NO                                                                                       PatientJucDoctorId
             , XMED.FT_MOO_USERNM(Z.ANDR_STF_NO)                                                                        PatientJucDoctorName
             , TO_CHAR(Z.ADS_DT, 'YYYY-MM-DD')                                                                     PatientEnterDate
             , TO_CHAR(Z.ADS_DTM, 'HH24:MI:SS')                                                                    PatientEnterTime
             , XBIL.FT_ACP_GET_STAYDAYS(Z.HSP_TP_CD, Z.PACT_ID, 'EMR', 'TOT')                                      PatientStayTime
             , 'PatientDiagnosis'                                                                                  PatientDiagnosis
             , 'PatientOperationName'                                                                              PatientOperationName
             , TO_CHAR(SYSDATE, 'HH24:MI:SS')	                                                                     PatientOperationDate
             , 'PatientOperationRoom'                                                                              PatientOperationRoom
             , 'PatientOperationPod'                                                                               PatientOperationPod
             , XMED.FT_MOP_APACHEIISCORE(Z.PT_NO, Z.PACT_ID, Z.CLCTN_WD_DEPT_CD, Z.HSP_TP_CD)                      PatientApacheValue
             , ( SELECT NVL(PT_SILLM_CTG_GRP_CD, 0)     /*환자중증도분류그룹코드*/
                   FROM MOPPCCFD A
                  WHERE A.PACT_ID = Z.PACT_ID
                    AND A.PT_NO      = Z.PT_NO
                    AND A.CTG_DTM    = TRUNC(SYSDATE) - 1
                    AND PT_SILLM_CTG_TP_CD     = '2'
                    AND A.WD_DEPT_CD      = Z.CLCTN_WD_DEPT_CD
                    AND USE_YN = 'Y'
                    AND LST_YN = 'Y')                                                                              PatientCareValue
        		 , 'PatientEquipVentUseYn'                                                                             PatientEquipVentUseYn
        		 , 'PatientEquipCrrtUseYn'                                                                             PatientEquipCrrtUseYn
        		 , 'PatientEquipEcmoUseYn'                                                                             PatientEquipEcmoUseYn
        		 , 'PatientEquipIabpUseYn'                                                                             PatientEquipIabpUseYn
        		 , 'PatientAlertBlood'                                                                                 PatientAlertBlood
        		 , 'PatientAlertTouch'                                                                                 PatientAlertTouch
        		 , 'PatientAlertAir'                                                                                   PatientAlertAir
        		 , 'PatientAlertSpray'                                                                                 PatientAlertSpray
        		 , 'PatientAlertAllergy'                                                                               PatientAlertAllergy
        		 , 'PatientAlertInfection'                                                                             PatientAlertInfection
        		 , 'PatientAlertTotal'                                                                                 PatientAlertTotal
        		 , 'PatientSection'                                                                                    PatientSection
        		 , 'Y'                                                                                                 PatientIcuYn
        		 , 'PatientLocation'                                                                                   PatientLocation
        		 , 'PatientDischargeYn'                                                                                PatientDischargeYn
        		 , 'PatientDischargeStat'                                                                              PatientDischargeStat
        		 , TO_CHAR(SYSDATE, 'HH24:MI:SS')	                                                                     PatientDischargeDate
        		 , 'PatientPartoYn'                                                                                    PatientPartoYn
        		 , 'PatientUterusStatus'                                                                               PatientUterusStatus
        		 , 'PatientChildBitrhStatus'                                                                           PatientChildBitrhStatus
        		 , 'PatientGestationalAge'                                                                             PatientGestationalAge
--             , DECODE(Z.DS_EXPT_DT, TRUNC(SYSDATE), 'Y', 'N')                                                      DS_EXPT_YN
--             , NVL(Z.DSIS_DTMN_YN, 'N')                                                                            DSIS_DTMN_YN
--             , TO_CHAR(Z.DS_EXPT_DT, 'YYYY-MM-DD HH24:MI:SS')                                                      DS_EXPT_DT
          FROM ( SELECT  *
                   FROM ACPPRAAM  Z
                  WHERE Z.SIHS_YN = 'Y'
                    AND Z.APCN_YN = 'N'
                    AND Z.APCN_DTM IS NULL
                    AND Z.HSP_TP_CD = IN_HSP_TP_CD
                    AND Z.CLCTN_WD_DEPT_CD = IN_WD_NO
                    AND Z.CLCTN_PRM_NO  = NVL(IN_RM_NO, Z.CLCTN_PRM_NO)
                    AND NVL(Z.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE) ) Z
             , PCTPCPAM_DAMO A
         WHERE Z.PT_NO = A.PT_NO
         ORDER BY Z.BED_NO; 

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_ADS_PT_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_ADS_PT_LIST;    
      
/*===================================================================================
* 서비스이름      : PC_BSH_SYSDATETIME
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : 현재 서버 시간 조회
* AS-IS 쿼리 정보 : 
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SYSDATETIME (
      IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
    , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
    , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
    , IN_HSP_TP_CD     IN    VARCHAR2      /* 병원구분코드 */
    , OUT_CURSOR       OUT   RETURNCURSOR
)
IS
    V_SRCH_CNTE   VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'SELECT SYSDATE FROM DUAL';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG(
              'D'
            , IN_STF_NO
            , IN_SQL_ID
            , NVL(IN_HSP_TP_CD, '08')
            , IN_IP_ADDR
            , NULL
            , V_SRCH_CNTE
        );
    END;

    BEGIN
        OPEN OUT_CURSOR FOR
            SELECT SYSDATE AS CURRENT_DATETIME
              FROM DUAL;

    EXCEPTION
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(
                -20553,
                'PC_BSH_SYSDATETIME ERRCODE = ' || SQLCODE || ' ' || SQLERRM
            );
    END;
END PC_BSH_SYSDATETIME;
    
/*===================================================================================
* 서비스이름      : PC_BSH_ICU_SIHM_STS
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : ICU 재원환자 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_STAY_STATUS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_SIHM_STS            ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    V_SRCH_CNTE := 'VAR C REFCURSOR;' || CHR(13) || CHR(10) ||
                   'EXEC XMOB.' || IN_SQL_ID || '(' ||
                   ''''',''' || IN_STF_NO  || '''' ||
                   ',''' || IN_IP_ADDR  || '''' ||
                   ',''' || IN_HSP_TP_CD  || '''' ||
                   ',''' || IN_ICU_TP  || '''' ||
                   ',:C);';

    XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);

    IF IN_ICU_TP = 'JICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'OS' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'OS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'OS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'OS'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                             )
                                         AND R.MED_DEPT_CD = 'OS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'OS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'MICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'IM' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND XCOM.FT_PDE_UPPERDEPT(A.HSP_TP_CD, R.MED_DEPT_CD) = 'IM'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'IM'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SUBSTR(SPCDR_DPCD, 1, 2) = 'IM'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                             )
                                         AND XCOM.FT_PDE_UPPERDEPT(A.HSP_TP_CD, R.MED_DEPT_CD) = 'IM'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'IM'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'SICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'CS' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'CS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'CS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'CS'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                             )
                                         AND R.MED_DEPT_CD = 'CS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'CS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'NICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'PED' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'PED'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'PED'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'PED'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                             )
                                         AND R.MED_DEPT_CD = 'PED'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'PED'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'MFICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'OB' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'OB'
                                         AND R.MED_DEPT_CD = A.MED_DEPT_CD
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'OB'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'OB'
               UNION ALL
              SELECT '2' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'GY' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'GY'
                                         AND R.MED_DEPT_CD = A.MED_DEPT_CD
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'GY'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'GY'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD IN ('OB', 'GY')
                                         AND R.MED_DEPT_CD = A.MED_DEPT_CD
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'OBGY'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'CICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'IM1' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'IM1'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'IM1'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'IM1'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                             )
                                         AND R.MED_DEPT_CD = 'IM1'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'IM1'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'EICU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'NS' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'NS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'NS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'NS'
               UNION ALL
              SELECT '2' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'IM3' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'IM3'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'IM3'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'IM3'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND (R.MED_DEPT_CD = 'NS' OR R.MED_DEPT_CD = 'IM3')
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'NSIM3'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSIF IN_ICU_TP = 'SU' THEN
        OPEN OUT_CURSOR FOR
              SELECT '1' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'NS' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'NS'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'NS'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'NS'
               UNION ALL
              SELECT '2' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'NR' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND R.MED_DEPT_CD = 'NR'
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'NR'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'NR'
               UNION ALL
              SELECT 'MED_DEPT_CD' AS MED_DEPT_CD, MEDDEPT AS MED_DEPT_NM, COUNT(*) AS CNT
                FROM (
                      SELECT 'ETC' AS MEDDEPT,
                             CASE
                                 WHEN EXISTS (
                                      SELECT 1
                                        FROM CNLMRUDD R
                                       WHERE R.USE_SID IN (
                                                 SELECT U.SID
                                                   FROM CNLRRUSD U
                                                  WHERE U.STF_NO = DECODE(A.CHDR_STF_NO, NULL, A.NCDR_STF_NO, A.CHDR_STF_NO)
                                                    AND U.HSP_TP_CD = A.HSP_TP_CD
                                             )
                                         AND (R.MED_DEPT_CD = 'NS' OR R.MED_DEPT_CD = 'NR')
                                         AND R.HSP_TP_CD = A.HSP_TP_CD
                                 ) THEN 'NSNR'
                                 ELSE 'N'
                             END AS SPCDR_DPCD
                        FROM ACPPRAAM A
                       WHERE A.SIHS_YN = 'Y'
                         AND A.CLCTN_WD_DEPT_CD = IN_ICU_TP
                         AND A.APCN_YN = 'N'
                         AND NVL(A.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE)
                         AND A.HSP_TP_CD = IN_HSP_TP_CD
                     )
               WHERE SPCDR_DPCD = 'N';

    ELSE
        OPEN OUT_CURSOR FOR
            SELECT 'ETC' AS MED_DEPT_CD
                 , 'ETC' AS MED_DEPT_NM
                 , 0 AS COUNT
              FROM DUAL;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_SIHM_STS ERRCODE = ' || SQLCODE || ' ' || SQLERRM);
END PC_BSH_ICU_SIHM_STS;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_INFC_MGMT
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : ICU 감염관리 현황
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_INFC_MGMT           ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN                
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_ICU_TP  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MOO_SMARTCARE_DASHBOARD.PC_SEL_ICU_INFECTION_MGR(IN_SQL_ID, IN_STF_NO, IN_IP_ADDR, IN_ICU_TP, OUT_CURSOR);    -- 20260316 YJR

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_INFC_MGMT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_INFC_MGMT;

/*===================================================================================
* 서비스이름      : PC_BSH_ICU_USE_EQUP_CNT
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : ICU 사용 장비 카운트
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_USE_EQUIP_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_USE_EQUP_CNT        ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
        BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_INTFEQUPUSECOUNT(IN_ICU_TP, IN_HSP_TP_CD, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_USE_EQUP_CNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_USE_EQUP_CNT;
                 
/*==================================================================================
* 서비스이름  : pc_sel_icu_mv_use_count
* 최초 작성일 : 
* 최초 작성자 : 
* description : ICU 별 MV(Management Ventilator) 사용현황
                (AC(VC,PC), SIMV(VC,PC), PSV,   CPAP, BIBAP) -> MICU만 해당
                (HFOV,      SIMV(VC,PC), NCPAP, HFS        ) -> NICU만 해당
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_MV_USE_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_MV_USE_STS          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
--         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUVTLRUSECRCCM(IN_ICU_TP, IN_HSP_TP_CD, OUT_CURSOR);

OPEN OUT_CURSOR FOR
SELECT /*+ XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUVTLRUSECRCCM */
                        DEPT.DEPT_CD
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'VC(AC)'     THEN 1 ELSE 0 END) "VC_AC"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'PC(AC)'     THEN 1 ELSE 0 END) "PC_AC"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'SIMV(VC)'   THEN 1 ELSE 0 END) "SIMV_VC"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'SIMV(PC)'   THEN 1 ELSE 0 END) "SIMV_PC"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'PSV'        THEN 1 ELSE 0 END) "PSV"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'CPAP'       THEN 1 ELSE 0 END) "CPAP"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'BIPAP'      THEN 1 ELSE 0 END) "BIPAP"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'HFOV'       THEN 1 ELSE 0 END) "HFOV"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'NCPAP'      THEN 1 ELSE 0 END) "NCPAP"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'HFS'        THEN 1 ELSE 0 END) "HFS"
                      , SUM(CASE WHEN LASTDATA.VENT_MODE = 'ETC'        THEN 1 ELSE 0 END) "ETC"
                      , (SELECT COUNT(*)
                           FROM (
                                 SELECT XMED.FT_MRN_BODYMSMTINF('VENT-NO','PRD_L','N', A.PT_NO,A.HSP_TP_CD,NULL,NULL,TRUNC(SYSDATE),TRUNC(SYSDATE)+0.99999)   VENT_NO
                                   FROM ACPPRAAM A
                                  WHERE A.SIHS_YN         = 'Y'
                                    AND A.HSP_TP_CD       = IN_HSP_TP_CD
                                    AND A.APCN_YN         = 'N'
                                    AND A.WD_DEPT_CD      = IN_ICU_TP 
                                    AND 'NICU'            = IN_ICU_TP /*NICU에만 해당*/
                                 ) Z
                         WHERE Z.VENT_NO IS NOT NULL
                        )                                                                       VENT_NO
                  FROM (
                        SELECT SDATA.ETRM_WD_DEPT_CD                                 ETRM_WD_DEPT_CD
                              , CASE WHEN SDATA.ETRM_WD_DEPT_CD = 'MICU'
                                      THEN DECODE(SDATA.VENT_MODE, 'VC(AC)','VC(AC)','PC(AC)','PC(AC)','SIMV(VC)','SIMV(VC)','SIMV(PC)','SIMV(PC)','PSV','PSV','CPAP','CPAP','BIPAP','BIPAP','ETC')
                                      ELSE CASE WHEN SDATA.ETRM_WD_DEPT_CD = 'NICU'
                                                 THEN DECODE(SDATA.VENT_MODE, 'HFOV','HFOV','SIMV(VC)','SIMV(VC)','SIMV(PC)','SIMV(PC)','NCPAP','NCPAP','HFS','HFS','ETC')
                                                 ELSE 'ETC'
                                            END
                                 END                                                  VENT_MODE
                          FROM (
                                SELECT M.ETRM_WD_DEPT_CD                                                                                                                       ETRM_WD_DEPT_CD
                                      , UPPER(TRIM(XMED.FT_MRN_BODYMSMTINF('VENT-MODE','PRD_L','N', A.PT_NO,A.HSP_TP_CD,NULL,NULL,TRUNC(SYSDATE),TRUNC(SYSDATE)+0.99999)))   VENT_MODE
                                  FROM ACPPRAAM      A
                                     , MOMNMIOD      M
                                     , PCTPCPAM_DAMO B
                                     , MRNNRVCD      C
                                 WHERE A.PACT_ID         = M.PACT_ID
                                   AND A.HSP_TP_CD       = M.HSP_TP_CD
                                   AND A.PT_NO           = B.PT_NO
                                   AND A.PT_NO           = C.PT_NO
                                   AND A.PACT_ID         = C.PACT_ID
                                   AND A.HSP_TP_CD       = C.HSP_TP_CD --2018-12-21 서선미, 병원구분 추가
                                   AND A.SIHS_YN         = 'Y'
                                   AND A.APCN_YN         = 'N'
                                   AND M.CHOT_DTM        IS NULL
                                   AND M.ETRM_WD_DEPT_CD = IN_ICU_TP
                                   AND M.ETRM_WD_DEPT_CD IN (SELECT WD_DEPT_CD  FROM XBIL.ACPICUWV WHERE HSP_TP_CD = A.HSP_TP_CD) /*ICU 병동만*/
                                   AND M.USE_YN          = 'Y'
                                   AND M.LST_YN          = 'Y'
                                   AND M.HSP_TP_CD       = IN_HSP_TP_CD
                                   AND B.IMGN_PT_YN      = 'N'
                                   AND C.INTF_EQUP_TP_CD = '01' /*Ventilator*/
                                   AND C.USE_YN          = 'Y'
                                   AND C.LST_YN          = 'Y'
                                   AND NVL(C.EQUP_END_DTM,SYSDATE) <= SYSDATE
                                 ) SDATA
                         WHERE SDATA.VENT_MODE IS NOT NULL
                        ) LASTDATA
                      , PDEDBMSM DEPT
               WHERE DEPT.DEPT_CD = LASTDATA.ETRM_WD_DEPT_CD(+)
                 AND DEPT.DEPT_CD = IN_ICU_TP                       
               GROUP BY DEPT.DEPT_CD
                 ;
                 
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_MV_USE_STS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_MV_USE_STS;

/*==================================================================================
* 서비스이름  : pc_sel_icu_mv_use_count
* 최초 작성일 : 
* 최초 작성자 : 
* description : ICU 별 MV(Management Ventilator) 사용현황
                (AC(VC,PC), SIMV(VC,PC), PSV,   CPAP, BIBAP) -> MICU만 해당
                (HFOV,      SIMV(VC,PC), NCPAP, HFS        ) -> NICU만 해당
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_MV_USE_COUNT
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_USE_MV_CNT          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_ICU_TP            IN    VARCHAR2      /* ICU 구분 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
BEGIN
    OPEN OUT_CURSOR FOR
--        WITH MV_PATIENT AS
--        (
--            SELECT A.PT_NO,
--                   A.PACT_ID,
--                   A.HSP_TP_CD,
--                   UPPER(TRIM(
--                       XMED.FT_MRN_BODYMSMTINF(
--                           'VENT-MODE',
--                           'PRD_L',
--                           'N',
--                           A.PT_NO,
--                           A.HSP_TP_CD,
--                           NULL,
--                           NULL,
--                           TRUNC(SYSDATE),
--                           TRUNC(SYSDATE) + 0.99999
--                       )
--                   )) AS VENT_MODE
--              FROM ACPPRAAM A
--                 , MOMNMIOD M
--                 , PCTPCPAM_DAMO B
--                 , MRNNRVCD C
--             WHERE A.PACT_ID         = M.PACT_ID
--               AND A.HSP_TP_CD       = M.HSP_TP_CD
--               AND A.PT_NO           = B.PT_NO
--               AND A.PT_NO           = C.PT_NO
--               AND A.PACT_ID         = C.PACT_ID
--               AND A.HSP_TP_CD       = C.HSP_TP_CD
--               AND A.SIHS_YN         = 'Y'
--               AND A.APCN_YN         = 'N'
--               AND M.CHOT_DTM        IS NULL
--               AND M.ETRM_WD_DEPT_CD = IN_ICU_TP
--               AND M.USE_YN          = 'Y'
--               AND M.LST_YN          = 'Y'
--               AND M.HSP_TP_CD       = IN_HSP_TP_CD
--               AND B.IMGN_PT_YN      = 'N'
--               AND C.INTF_EQUP_TP_CD = '01' -- Ventilator
--               AND C.USE_YN          = 'Y'
--               AND C.LST_YN          = 'Y'
--               AND NVL(C.EQUP_END_DTM, DATE '9999-12-31') >= SYSDATE
--        )
--        SELECT VENT_MODE AS ITEM_ID,
--               VENT_MODE AS ITEM_NM,
--               COUNT(*) AS CNT,
--               'Y' AS USE_YN
--          FROM MV_PATIENT
--         WHERE VENT_MODE IS NOT NULL
--         GROUP BY VENT_MODE
--         ORDER BY VENT_MODE;            

        WITH MV_PATIENT AS
        (
            SELECT A.PT_NO,
                   A.PACT_ID,
                   A.HSP_TP_CD,
                   UPPER(TRIM(
                       XMED.FT_MRN_BODYMSMTINF(
                           'VENT-MODE',
                           'PRD_L',
                           'N',
                           A.PT_NO,
                           A.HSP_TP_CD,
                           NULL,
                           NULL,
                           TRUNC(SYSDATE),
                           TRUNC(SYSDATE) + 0.99999
                       )
                   )) AS VENT_MODE
              FROM ACPPRAAM A
                 , MOMNMIOD M
                 , PCTPCPAM_DAMO B
                 , MRNNRVCD C
             WHERE A.PACT_ID         = M.PACT_ID
               AND A.HSP_TP_CD       = M.HSP_TP_CD
               AND A.PT_NO           = B.PT_NO
               AND A.PT_NO           = C.PT_NO
               AND A.PACT_ID         = C.PACT_ID
               AND A.HSP_TP_CD       = C.HSP_TP_CD
               AND A.SIHS_YN         = 'Y'
               AND A.APCN_YN         = 'N'
               AND M.CHOT_DTM        IS NULL
               AND M.ETRM_WD_DEPT_CD = IN_ICU_TP
               AND M.ETRM_WD_DEPT_CD IN (
                       SELECT WD_DEPT_CD
                         FROM XBIL.ACPICUWV
                        WHERE HSP_TP_CD = A.HSP_TP_CD
                   )
               AND M.USE_YN          = 'Y'
               AND M.LST_YN          = 'Y'
               AND M.HSP_TP_CD       = IN_HSP_TP_CD
               AND B.IMGN_PT_YN      = 'N'
               AND C.INTF_EQUP_TP_CD = '01'
               AND C.USE_YN          = 'Y'
               AND C.LST_YN          = 'Y'
               AND NVL(C.EQUP_END_DTM, DATE '9999-12-31') >= SYSDATE
        ),
				        MV_COUNT AS
				(
				    SELECT ITEM_ID,
				           COUNT(*) AS CNT
				      FROM (
				            SELECT CASE
				                       WHEN IN_ICU_TP IN ('MICU', 'SICU')
				                            AND VENT_MODE IN ('VC(AC)', 'PC(AC)')
				                           THEN 'AC'
				
				                       WHEN VENT_MODE IN ('SIMV(VC)', 'SIMV(PC)')
				                           THEN 'SIMV'
				
				                       WHEN IN_ICU_TP IN ('MICU', 'SICU')
				                            AND VENT_MODE IN ('PSV', 'CPAP', 'BIPAP')
				                           THEN VENT_MODE
				
				                       WHEN IN_ICU_TP IN ('NICU', 'SICU')
				                            AND VENT_MODE IN ('HFOV', 'NCPAP')
				                           THEN VENT_MODE
				
				                       WHEN IN_ICU_TP = 'NICU'
				                            AND VENT_MODE = 'HFS'
				                           THEN VENT_MODE
				
				                       ELSE 'ETC'
				                   END AS ITEM_ID
				              FROM MV_PATIENT
				             WHERE VENT_MODE IS NOT NULL
				           )
				     GROUP BY ITEM_ID
				),
				MV_ITEM AS
				(
				    SELECT 'AC' ITEM_ID, 'AC' ITEM_NM, 1 SORT_SEQ, 'Y' USE_YN
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('MICU', 'SICU')
				
				    UNION ALL
				    SELECT 'SIMV', 'SIMV', 2, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('MICU', 'NICU', 'SICU')
				
				    UNION ALL
				    SELECT 'PSV', 'PSV', 3, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('MICU', 'SICU')
				
				    UNION ALL
				    SELECT 'CPAP', 'CPAP', 4, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('MICU', 'SICU')
				
				    UNION ALL
				    SELECT 'BIPAP', 'BiPAP', 5, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('MICU', 'SICU')
				
				    UNION ALL
				    SELECT 'HFOV', 'HFOV', 6, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('NICU', 'SICU')
				
				    UNION ALL
				    SELECT 'NCPAP', 'NCPAP', 7, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP IN ('NICU', 'SICU')
				
				    UNION ALL
				    SELECT 'HFS', 'HFS', 8, 'Y'
				      FROM DUAL
				     WHERE IN_ICU_TP = 'NICU'
				                            
						UNION ALL
						SELECT 'NO', 'NO', 9, 'Y'
						  FROM DUAL
						 WHERE IN_ICU_TP = 'NICU'
						 
				    UNION ALL
				    SELECT 'ETC', 'ETC', 99, 'Y'
				      FROM DUAL
				)
        SELECT I.ITEM_ID,
               I.ITEM_NM,
               NVL(C.CNT, 0) AS CNT,
               I.USE_YN
          FROM MV_ITEM I
             , MV_COUNT C
         WHERE I.ITEM_ID = C.ITEM_ID(+)
         ORDER BY I.SORT_SEQ;
         
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(
            -20553,
            'PC_BSH_ICU_USE_MV_CNT ERRCODE = ' || SQLCODE || SQLERRM
        );
END PC_BSH_ICU_USE_MV_CNT;

/*===================================================================================
* 서비스이름      : PC_BSH_CHRM_CRCCM
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : 분만장 대기 현황조회 - 고위험 산모실만
                    분만장 수술 현황조회 
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_WAIT_EBBDVLMT
                    PKG_SMARTCARE_DASHBOARD.PC_SEL_PATIENT_NICU_OPINFO
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_CHRM_CRCCM              ( IN_SQL_ID        IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO        IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR       IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD     IN    VARCHAR2      /* 병동구분코드 */
                                         , OUT_WAIT_CURSOR  OUT   RETURNCURSOR 
                                         , OUT_OP_CURSOR    OUT   RETURNCURSOR )IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHRMWAITCRCCM(IN_HSP_TP_CD, OUT_WAIT_CURSOR);

            EXCEPTION  --예외처리
                WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHRM_CRCCM - WAIT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;

    BEGIN
        XMED.PKG_MRN_NURSENSCREEN.PC_MRN_CHBROPCRCCM(IN_HSP_TP_CD, OUT_OP_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_CHRM_CRCCM - OP' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;    
END PC_BSH_CHRM_CRCCM;


/*===================================================================================
* 서비스이름      : PC_BSH_ICU_PT_DTL_ASK
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : ICU환자상세조회
* AS-IS 쿼리 정보 : PKG_SMARTCARE_DASHBOARD.PC_SEL_ICU_PAT_RECENT_VITAL
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_ICU_PT_DTL_ASK          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병동구분코드 */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_PACT_ID           IN    VARCHAR2      /* 원무접수ID */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);
    END;

    BEGIN
         XMED.PKG_MRN_NURSENSCREEN.PC_MRN_ICUPTDTLASK(IN_PT_NO, IN_PACT_ID, OUT_CURSOR);

        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_ICU_PT_DTL_ASK' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_ICU_PT_DTL_ASK;

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : MFICU(고위험산모치료실) 대기 환자 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LIST          ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT A.PT_NO                                                                              PT_NO
               , B.PT_NM                                                                              PT_NM
               , XBIL.FT_PCT_AGE ( 'AUTO' , SYSDATE , B.PT_BRDY_DT )                                  PT_AGE
               , A.WD_DEPT_CD                                                                         WD_DEPT_CD
               , A.CLCTN_WD_DEPT_CD                                                                   CLCTN_WD_DEPT_CD
               , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNPRD',A.PT_NO,A.HSP_TP_CD)              CHBR_AGE
               , XMED.FT_MOO_DIAGNOSIS(A.PT_NO , NULL, A.MED_DEPT_CD, A.PACT_ID, A.HSP_TP_CD, 'L')    PT_DIAGNOSIS
               , A.PACT_ID                                                                            PACT_ID
               , A.MED_DEPT_CD                                                                        MED_DEPT_CD
               , A.HSP_TP_CD                                                                          HSP_TP_CD
               , 'Y'                                                                                  USE_YN
            FROM ACPPRAAM A             --입원접수기본
               , PCTPCPAM_DAMO B
           WHERE A.PT_NO = B.PT_NO
             AND ( A.CLCTN_WD_DEPT_CD IN('42MF') --42MF (고위험산모태아집중치료실 전체 OR 041 병동 이면서  산부인과 진료과에 ALERT(임신) 정보 )
                 OR ( A.CLCTN_WD_DEPT_CD IN('041') ) --20260424 YJR Test Data 추가로 뒷 부분 주석  --AND A.MED_DEPT_CD = 'OG' AND XMED.FT_MOO_INFECT_CLS( A.PT_NO , NULL , A.HSP_TP_CD, '7') = 'A9998' )
                 )
             AND A.SIHS_YN = 'Y'
             AND NVL(A.DS_EXPT_DT,TO_DATE('2999-12-31','YYYY-MM-DD')) >= TRUNC(SYSDATE)  --퇴원예정일자 체크
             AND A.APCN_YN = 'N'
             AND A.HSP_TP_CD = IN_HSP_TP_CD
           ORDER BY DECODE(A.CLCTN_WD_DEPT_CD,'42MF',1,'041',2,A.CLCTN_WD_DEPT_CD) , A.PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_MFICU_LIST;        

/*===================================================================================
* 서비스이름      : PC_BSH_SEL_MFICU_LOG_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION     : MFICU(고위험산모치료실) 저장 로그 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_SEL_MFICU_LOG_LIST      ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
          SELECT A.PT_NO                                                                              PT_NO
               , B.PT_NM                                                                              PT_NM
               , XBIL.FT_PCT_AGE ( 'AUTO' , SYSDATE , B.PT_BRDY_DT )                                  PT_AGE
               , A.WD_DEPT_CD                                                                         WD_DEPT_CD
               , A.CLCTN_WD_DEPT_CD                                                                   CLCTN_WD_DEPT_CD
               , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CHBRINF('PRGNPRD',A.PT_NO,A.HSP_TP_CD)              CHBR_AGE
               , XMED.FT_MOO_DIAGNOSIS(A.PT_NO , NULL, A.MED_DEPT_CD, A.PACT_ID, A.HSP_TP_CD, 'L')    PT_DIAGNOSIS
               , A.PACT_ID                                                                            PACT_ID
               , A.MED_DEPT_CD                                                                        MED_DEPT_CD
               , A.HSP_TP_CD                                                                          HSP_TP_CD
               , A.USE_YN                                                                             USE_YN
            FROM BSHMFLOG A
               , PCTPCPAM_DAMO B
           WHERE A.PT_NO = B.PT_NO
             AND A.USE_YN = 'Y'
             AND A.PACT_ID IN ( SELECT PACT_ID
                                  FROM ACPPRAAM
                                 WHERE PACT_ID = A.PACT_ID
                                   AND SIHS_YN = 'Y'
                                   AND NVL(DS_EXPT_DT,TO_DATE('2999-12-31','YYYY-MM-DD')) >= TRUNC(SYSDATE)   --퇴원예정일자 체크
                                   AND APCN_YN = 'N' )
             AND ( A.CLCTN_WD_DEPT_CD IN('42MF') --42MF (고위험산모태아집중치료실 전체 OR 041 병동 이면서  산부인과 진료과에 ALERT(임신) 정보 )
                 OR ( A.CLCTN_WD_DEPT_CD IN('041'))-- 20260424 YJR Test Data 추가로 뒷 부분 주석		--AND A.MED_DEPT_CD = 'OG' AND XMED.FT_MOO_INFECT_CLS( A.PT_NO , NULL , A.HSP_TP_CD, '7') = 'A9998' )
                 )
             AND A.HSP_TP_CD = IN_HSP_TP_CD
           ORDER BY DECODE(A.CLCTN_WD_DEPT_CD,'42MF',1,'041',2,A.CLCTN_WD_DEPT_CD) , A.PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_BSH_SEL_MFICU_LOG_LIST;

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 당일 입실/퇴실 예정 환자 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_LIST      ( IN_SQL_ID           IN    VARCHAR2      /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
           SELECT PT_IO
         	    , PT_LOC
          		, PT_NO
          		, PT_NM
          		, PT_SEX
          		, PT_AGE
          		, PT_DEPT_CD
          		, WD_DEPT_CD
          		, HSP_CD
             FROM EMNI007V
            WHERE WD_DEPT_CD = IN_WD_DEPT_CD
              AND HSP_CD = IN_HSP_TP_CD 
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_IO_LIST;

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_IO_COUNT
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_IO_COUNT    ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT WD_DEPT_CD       --01. 환자실병동부서코드' 
            	 , TOL_WD_CNT		--02. 전체 병상 
			     , USE_WD_CNT       --03. 사용 병상 수
			     , EMPT_WD_CNT      --04. 공 병상 수
			     , ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)
			     , ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
			     , ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
			     , IN_WD_CNT        --08. 입실예정 환자 수
			     , OUT_WD_CNT       --09. 퇴실예정 환자 수
			     , OP_CNT           --10. 수술 수
			 fROM EMEI001V   			
            WHERE WD_DEPT_CD = IN_WD_DEPT_CD
              -- AND HSP_CD = IN_HSP_TP_CD
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_IO_COUNT;

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_PT_OP_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 당일 수술 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_PT_OP_LIST    ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT HSP_CD
				 , PT_NO
				 , OP_TITL
				 , OP_RSV_NO
              FROM EMNI008V
             WHERE HSP_CD = IN_HSP_TP_CD
               AND PT_NO  = IN_PT_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_SEL_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_PT_OP_LIST;  

/*==================================================================================
* 서비스이름  : PC_EICU_INS_TEST_OP_INFO
* 최초 작성일 : 
* 최초 작성자 : 
* description : 대시보드에서 검사 시술 내역 저장
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_INS_TEST_OP_INFO           ( IN_SQL_ID           IN     VARCHAR2      /* SQL ID */
										                      	 , IN_STF_NO           IN     VARCHAR2      /* 직원번호 */
                                        		 , IN_IP_ADDR          IN     VARCHAR2      /* IP ADDRESS */
                                             , IN_ICU_TP_CD        IN     VARCHAR2
											                       , IN_PT_NO            IN     VARCHAR2 
											                       , IN_INPUT_DT         IN     VARCHAR2  	/* 'hh24:mi'  */
											                       , IN_HIST_SEQ         IN     VARCHAR2 
											                       , IN_HSP_TP_CD        IN     VARCHAR2   
											                       , IN_ITEM_TP_CD       IN     VARCHAR2
											                       , IN_ITEM_CD          IN     VARCHAR2
											                       , IN_ITEM_SUB_CD      IN     VARCHAR2 
											                       , IN_MEMO             IN     VARCHAR2
                                             , IO_ERRYN            IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG           IN OUT VARCHAR2 ) /* MESSAGE */
IS
BEGIN   
	BEGIN  
--		 V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
--                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
--                       ;
----                       ''''',''' || IN_STF_NO  || '''' ||
----                       ',''' || IN_IP_ADDR  || '''' ||
----                       ',''' || IN_PT_NO  || '''' || 
----                       ',''' || IN_HSP_TP_CD  || '''' ||
----                       ',:C);';                  
--                       
--        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
--        
      INSERT INTO HICU.BSHDBLST ( ICU_TP_CD
							, PT_NO
							, INPUT_DT
							, HIST_SEQ
							, HSP_TP_CD
							, ITEM_TP_CD
							, ITEM_CD
							, ITEM_SUB_CD
							, MEMO    							
							, REG_DTM
							, REG_ID 
                           )
                      VALUES
                           ( IN_ICU_TP_CD
							, IN_PT_NO
							, IN_INPUT_DT
							, nvl((select max(HIST_SEQ)+ 1 from HICU.BSHDBLST
                                    where ICU_TP_CD = IN_ICU_TP_CD
                                    and PT_NO       = IN_PT_NO ), 1)
							, IN_HSP_TP_CD
							, IN_ITEM_TP_CD
							, IN_ITEM_CD
							, IN_ITEM_SUB_CD
							, IN_MEMO   
							, sysdate
							, IN_STF_NO
                           )
                           ;
      EXCEPTION  --예외처리
            WHEN OTHERS THEN
                IO_ERRYN := 'Y';
                IO_ERRMSG := 'PC_EICU_INS_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM;
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_INS_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
      END;
END PC_EICU_INS_TEST_OP_INFO;

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_OP_INFO
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 환자 검사 시술 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_OP_INFO       ( IN_SQL_ID             IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||    
                       ',''' || IN_PT_NO  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);

       OPEN OUT_CURSOR FOR
           SELECT ICU_TP_CD
				, PT_NO
				, INPUT_DT
				, HIST_SEQ
				, HSP_TP_CD
				, ITEM_TP_CD
				, ITEM_CD
				, ITEM_SUB_CD
				, MEMO    							
				, REG_DTM
				, REG_ID
				, 'N'	IS_READ
             FROM HICU.BSHDBLST
            WHERE HSP_TP_CD = IN_HSP_TP_CD
              AND PT_NO     = IN_PT_NO 
              and reg_dtm >= trunc(sysdate)
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_TEST_OP_INFO;    

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_LIST
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : 병원별 ICU 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_LIST    ( IN_SQL_ID            IN    VARCHAR2      /* SQL ID */       
                                  , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                  , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
																	, IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )    
IS                                  
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR             
			SELECT HSP_TP_CD
			     , DEPT_CD
			     , DEPT_NM
			     , RMK_CNTE
			  FROM HICU.UCCOCDPM
			 WHERE HSP_TP_CD = IN_HSP_TP_CD
			   AND USE_YN = 'Y'
			 ORDER BY SORT_SEQ
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_ICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_LIST; 
        
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_COUNT
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 환자 검사, 시술 카운트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_COUNT         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */
                                         , IN_ICU_TP_CD         IN    VARCHAR2      /* 중환자실코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_ICU_TP_CD  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_ICU_TP_CD, V_SRCH_CNTE);

       OPEN OUT_CURSOR FOR
           SELECT COUNT(DISTINCT PT_NO) TST_COUNT
             FROM HICU.BSHDBLST
            WHERE HSP_TP_CD = IN_HSP_TP_CD
              AND ICU_TP_CD = IN_ICU_TP_CD
              AND REG_DTM >= trunc(sysdate)
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_OP_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_TEST_COUNT;    

/*===================================================================================
* 서비스이름      : PC_EICU_SEL_TEST_ITEM
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 환자 검사, 시술 하위 항목 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_TEST_ITEM         ( IN_SQL_ID            IN    VARCHAR2       /* SQL ID */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                         , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
--                       ''''',''' || IN_STF_NO  || '''' ||
--                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_ITEM_TP_CD  || '''' || 
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', '', IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), '', IN_ITEM_TP_CD, V_SRCH_CNTE);

			IF IN_ITEM_TP_CD = 'A' THEN
	       OPEN OUT_CURSOR FOR
				-- 검사
				select DETL_CD			ITEM_CD
	     			 , DETL_CD_NM		ITEM_NM
	  		   	  from HICU.RRS_DETAIL
			 	 where HSP_TP_CD = IN_HSP_TP_CD
			       and MSTR_CD = 'DB_TEST'
			       and USE_YN = 'Y'
		      ORDER BY DISP_SEQ 
	        ;
     ELSIF IN_ITEM_TP_CD = 'B' THEN
	        OPEN OUT_CURSOR FOR
				-- 시술
				select DETL_CD     ITEM_CD
				     , DETL_CD_NM  ITEM_NM
				  from HICU.RRS_DETAIL
				 where HSP_TP_CD = IN_HSP_TP_CD
				   and MSTR_CD = 'DB_OP'
				   and USE_YN = 'Y'
		      ORDER BY DISP_SEQ      
          ;                     
     	ELSE 
     		OPEN OUT_CURSOR FOR
     	SELECT '01'	ITEM_CD    				
     	     , '기타' ITEM_NM      
     	 FROM DUAL;
    END IF;
    
              
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_TEST_ITEM' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;

    END;
END PC_EICU_SEL_TEST_ITEM;   

/*===================================================================================
* 서비스이름      : PC_EICU_TST_OP_LIST_DELETE
* 최초 작성일     : 
* 최초 작성자     : 
* DESCRIPTION    : ICU 환자 검사, 시술, 수술 삭제
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TST_OP_LIST_DELETE      ( IN_SQL_ID           IN    VARCHAR2       /* SQL ID */
                                         , IN_STF_NO            IN    VARCHAR2      /* 직원번호 */
                                         , IN_IP_ADDR           IN    VARCHAR2      /* IP ADDRESS */ 
                                         , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */
                                         , IN_ITEM_TP_CD        IN    VARCHAR2      /* 검사,시술구분코드 */
                                         , IN_HIST_SEQ          IN    VARCHAR2      /* 순번 */
                                         , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */                                                 
                                         , OUT_CURSOR           OUT   RETURNCURSOR 
                                         )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||    
                       ',''' || IN_ITEM_TP_CD  || '''' ||
                       ',''' || IN_HIST_SEQ  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',:C);';                  
                       
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, IN_PT_NO, V_SRCH_CNTE);

--       OPEN OUT_CURSOR FOR
           DELETE FROM HICU.BSHDBLST
            WHERE HSP_TP_CD  = IN_HSP_TP_CD
              AND PT_NO      = IN_PT_NO
              AND ITEM_TP_CD = IN_ITEM_TP_CD 
              AND HIST_SEQ   = IN_HIST_SEQ
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TST_OP_LIST_DELETE' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_TST_OP_LIST_DELETE;   

/*==================================================================================
* 서비스이름  : PC_BSH_UPD_MFICU_LOG_LIST
* 최초 작성일 : 
* 최초 작성자 : 
* DESCRIPTION : MFICU(고위험산모치료실) 환자 로그 수정
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_UPD_MFICU_LOG_LIST  ( IN_SQL_ID            IN     VARCHAR2      /* SQL ID */
                                     , IN_STF_NO            IN     VARCHAR2      /* 직원번호 */
                                     , IN_IP_ADDR           IN     VARCHAR2      /* IP ADDRESS */
                                     , IN_HSP_TP_CD         IN     VARCHAR2      /* 병원구분코드 */
                                     , IN_PACT_ID           IN     VARCHAR2     /* 원무접수아이디 */
                                     , IN_PT_NO             IN     VARCHAR2     /* 환자번호 */
                                     , IN_MED_DEPT_CD       IN     VARCHAR2     /* 진료부서코드 */
                                     , IN_WD_DEPT_CD        IN     VARCHAR2     /* 병동부서코드 */
                                     , IN_CLCTN_WD_DEPT_CD  IN     VARCHAR2     /* 현위치병동부서코드 */
                                     , IN_USE_YN            IN     VARCHAR2     /* 사용여부 */  
                                     , IO_ERRYN             IN OUT VARCHAR2     /* ERROR Y/N */
									 , IO_ERRMSG            IN OUT VARCHAR2 )   /* MESSAGE */
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
        V_SRCH_CNTE := 'VAR C REFCURSOR;' ||  CHR(13) || CHR(10) ||
                       'EXEC XMOB.' || IN_SQL_ID || '(' ||
                       ''''',''' || IN_STF_NO  || '''' ||
                       ',''' || IN_IP_ADDR  || '''' ||
                       ',''' || IN_HSP_TP_CD  || '''' ||
                       ',''' || IN_PACT_ID  || '''' ||
                       ',''' || IN_PT_NO  || '''' ||
                       ',''' || IN_MED_DEPT_CD  || '''' ||
                       ',''' || IN_WD_DEPT_CD  || '''' ||
                       ',''' || IN_CLCTN_WD_DEPT_CD  || '''' ||
                       ',''' || IN_USE_YN  || '''' ||  
                       ',:C);';
    END;

    BEGIN
        XMOB.PC_BSH_SV_LOG('D', IN_STF_NO, IN_SQL_ID, NVL(IN_HSP_TP_CD, '08'), IN_IP_ADDR, NULL, V_SRCH_CNTE);
    END;

    BEGIN
        
        INSERT INTO BSHMFLOG ( PACT_ID
                             , HSP_TP_CD
                             , PT_NO
                             , MED_DEPT_CD
                             , WD_DEPT_CD
                             , CLCTN_WD_DEPT_CD
                             , USE_YN
                             , FSR_DTM
                             , FSR_STF_NO
                             , FSR_PRGM_NM
                             , FSR_IP_ADDR
                             , LSH_DTM
                             , LSH_STF_NO
                             , LSH_PRGM_NM
                             , LSH_IP_ADDR
                             )
                      VALUES ( IN_PACT_ID
                             , IN_HSP_TP_CD
                             , IN_PT_NO
                             , IN_MED_DEPT_CD
                             , IN_WD_DEPT_CD
                             , IN_CLCTN_WD_DEPT_CD
                             , IN_USE_YN
                             , SYSDATE
                             , NVL(IN_STF_NO,'C0EMR')
                             , 'BESTBoard'
                             , IN_IP_ADDR
                             , SYSDATE
                             , NVL(IN_STF_NO,'C0EMR')
                             , 'BESTBoard'
                             , IN_IP_ADDR
                             ) ;

       EXCEPTION
           WHEN DUP_VAL_ON_INDEX THEN
               BEGIN
                   UPDATE BSHMFLOG
 		              SET USE_YN = IN_USE_YN
                        , LSH_STF_NO = NVL(IN_STF_NO,'C0EMR')
                        , LSH_DTM = SYSDATE
                        , LSH_PRGM_NM = 'BESTBoard'
                        , LSH_IP_ADDR = IN_IP_ADDR
                    WHERE PACT_ID = IN_PACT_ID
                      AND HSP_TP_CD = NVL(IN_HSP_TP_CD, '08') ;
       
                   EXCEPTION
                       WHEN OTHERS THEN
                           IO_ERRYN  := 'Y';
                           IO_ERRMSG := 'PC_BSH_UPD_MFICU_LOG_LIST : 사용여부 변경중 에러 발생  : ' || TO_CHAR(SQLCODE);
                           RETURN;
               END;
           WHEN OTHERS THEN
             IO_ERRYN  := 'Y';
             IO_ERRMSG := 'PC_BSH_UPD_MFICU_LOG_LIST : 신규등록중 에러 발생  : ' || TO_CHAR(SQLCODE);
             RETURN;                 
    END;
     EXCEPTION  --예외처리
        WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_UPD_MFICU_LOG_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
END PC_BSH_UPD_MFICU_LOG_LIST; 

/*==================================================================================
* 서비스이름  : PC_BSH_INS_BESTBOARD_LOG
* 최초 작성일 : 
* 최초 작성자 : 
* description : Lob Table에 삽입
* 변경이력관리
===================================================================================*/
PROCEDURE PC_BSH_INS_BESTBOARD_LOG           ( IN_SYS_NM                       IN     VARCHAR2   /* 시스템 명 */
                                             , IN_CLIENT_IP_ADDR               IN     VARCHAR2   /* 클라이언트 IP */
                                             , IN_CLIENT_DEPT_CD               IN     VARCHAR2   /* 부서 코드 */
                                             , IN_CLIENT_PC_MEMORY             IN     VARCHAR2   /* 메모리 사용량 */
                                             , IN_LOGIN_STF_NO                 IN     VARCHAR2   /* 로그인 직원 사번 */
                                             , IN_ACCESS_SERVER                IN     VARCHAR2   /* 접근 서버 IP */
                                             , IN_PROC_TYPE                    IN     VARCHAR2   /* 프로시저 타입  */
                                             , IN_PROC_NM                      IN     VARCHAR2   /* 프로시저 명 */
                                             , IN_PROC_COMMENT                 IN     VARCHAR2   /* 프로시저 설명 */
                                             , IN_PROC_PARAM_INFO              IN     VARCHAR2   /* 파라미터 정보 */
                                             , IN_DB_CALL_START_DTM            IN     VARCHAR2   /* 데이터베이스 호출 시작시간 */
                                             , IN_DB_CALL_END_DTM              IN     VARCHAR2   /* 데이터베이스 호출 종료시간 */
                                             , IN_CLIENT_BINDING_END_DTM       IN     VARCHAR2   /* 클라이언트 바인딩 완료시간 */
                                             , IN_DB_CALL_PROGRESS_TM          IN     VARCHAR2   /* 데이터베이스 호출 경과시간(초) */
                                             , IN_CLIENT_BINDING_PROGRESS_TM   IN     VARCHAR2   /* 클라이언트 바인딩 경과시간(초) */
                                             , IN_ALL_PROCESS_PROGRESS_TM      IN     VARCHAR2   /* 데이터베이스 호출 + 클라이언트 바인딩 경과시간(초) */
                                             , IN_DATA_SIZE                    IN     VARCHAR2   /* 조회한 데이터 사이즈(Byte) */
                                             , IN_CLIENT_LOGIC_PATH            IN     VARCHAR2   /* 클라이언트 바인딩 로직 구간 경로 */
                                             , IO_ERRYN                        IN OUT VARCHAR2   /* ERROR Y/N */
                                             , IO_ERRMSG                       IN OUT VARCHAR2 ) /* MESSAGE */
IS
BEGIN     
   BEGIN
      INSERT INTO BSHPMLOG ( SYS_NM
                           , CLIENT_IP_ADDR
                           , CLIENT_DEPT_CD
                           , CLIENT_PC_MEMORY
                           , LOGIN_STF_NO
                           , ACCESS_SERVER
                           , PROC_TYPE
                           , PROC_NM
                           , PROC_COMMENT
                           , PROC_PARAM_INFO
                           , DB_CALL_START_DTM
                           , DB_CALL_END_DTM
                           , CLIENT_BINDING_END_DTM
                           , DB_CALL_PROGRESS_TM
                           , CLIENT_BINDING_PROGRESS_TM
                           , ALL_PROCESS_PROGRESS_TM
                           , DATA_SIZE
                           , CLIENT_LOGIC_PATH
                           )
                      VALUES
                           ( IN_SYS_NM
                           , IN_CLIENT_IP_ADDR
                           , IN_CLIENT_DEPT_CD
                           , TO_NUMBER(IN_CLIENT_PC_MEMORY)
                           , IN_LOGIN_STF_NO
                           , IN_ACCESS_SERVER
                           , IN_PROC_TYPE
                           , IN_PROC_NM
                           , IN_PROC_COMMENT
                           , IN_PROC_PARAM_INFO
                           , TO_DATE(IN_DB_CALL_START_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_DATE(IN_DB_CALL_END_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_DATE(IN_CLIENT_BINDING_END_DTM, 'yyyy-mm-dd hh24:mi:ss')
                           , TO_NUMBER(IN_DB_CALL_PROGRESS_TM)
                           , TO_NUMBER(IN_CLIENT_BINDING_PROGRESS_TM)
                           , TO_NUMBER(IN_ALL_PROCESS_PROGRESS_TM)
                           , TO_NUMBER(IN_DATA_SIZE)
                           , IN_CLIENT_LOGIC_PATH
                           )
                           ;
      EXCEPTION  --예외처리
            WHEN OTHERS THEN
                IO_ERRYN := 'Y';
                IO_ERRMSG := 'PC_BSH_INS_BESTBOARD_LOG' || ' ERRCODE = ' || SQLCODE || SQLERRM;
                RAISE_APPLICATION_ERROR(-20553, 'PC_BSH_INS_BESTBOARD_LOG' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
      END;
END PC_BSH_INS_BESTBOARD_LOG;


END PKG_BSH_DB_TEST;
