
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_COM_TALK" AS

/*====================================================================
 * 1) PC_COM_TALK_SEND
 *   - SPEC 에 있으므로 BODY에 반드시 필요
 *   - 지금은 사용 안 할 거면, 이런 식으로 "미구현" 스텁 처리 가능
 *====================================================================*/
PROCEDURE PC_COM_TALK_SEND (
       IN_DATE_CLIENT_REQ  IN    VARCHAR2
     , IN_CALLBACK         IN    VARCHAR2
     , IN_TEMPLATE_CODE    IN    VARCHAR2
     , IN_CONTENT          IN    VARCHAR2
     , IN_RECIPIENT_NUM    IN    VARCHAR2
     , IN_RETRY_CONTENT    IN    VARCHAR2
     , IN_KKO_BTN_TYPE     IN    VARCHAR2
     , IN_KKO_BTN_INFO     IN    VARCHAR2
     , IO_SEQ              OUT   NUMBER
     , IO_ERRYN            OUT   VARCHAR2
     , IO_ERRMSG           OUT   VARCHAR2
) IS
BEGIN
    IO_SEQ   := NULL;
    IO_ERRYN := 'Y';
    IO_ERRMSG := 'PC_COM_TALK_SEND is not implemented.';
END PC_COM_TALK_SEND;



/*====================================================================
 * 2) PC_COM_DFTALK_SEND
 *   - 이것도 SPEC에 있으므로 BODY에 스텁 구현
 *====================================================================*/
PROCEDURE PC_COM_DFTALK_SEND (
       IN_MT_REFKEY        IN    VARCHAR2
     , IN_DATE_CLIENT_REQ  IN    VARCHAR2
     , IN_SUBJECT          IN    VARCHAR2
     , IN_CALLBACK         IN    VARCHAR2
     , IN_TEMPLATE_CODE    IN    VARCHAR2
     , IN_CONTENT          IN    VARCHAR2
     , IN_RECIPIENT_NUM    IN    VARCHAR2
     , IN_RETRY_CONTENT    IN    VARCHAR2
     , IN_KKO_BTN_TYPE     IN    VARCHAR2
     , IN_KKO_BTN_INFO     IN    VARCHAR2
     , IO_SEQ              OUT   NUMBER
     , IO_ERRYN            OUT   VARCHAR2
     , IO_ERRMSG           OUT   VARCHAR2
) IS
BEGIN
    IO_SEQ   := NULL;
    IO_ERRYN := 'Y';
    IO_ERRMSG := 'PC_COM_DFTALK_SEND is not implemented.';
END PC_COM_DFTALK_SEND;



/*====================================================================
 * 3) PC_COM_DTALK_SEND
 *   - 실제로 XCOM.ATA_MMT_TRAN 에 INSERT 하는 프로시저
 *   - 지금 작성하신 버전 그대로 유지
 *====================================================================*/
PROCEDURE PC_COM_DTALK_SEND (
       IN_MT_REFKEY        IN    VARCHAR2
     , IN_DATE_CLIENT_REQ  IN    VARCHAR2
     , IN_SUBJECT          IN    VARCHAR2
     , IN_CALLBACK         IN    VARCHAR2
     , IN_TEMPLATE_CODE    IN    VARCHAR2
     , IN_CONTENT          IN    VARCHAR2
     , IN_RECIPIENT_NUM    IN    VARCHAR2
     , IN_RETRY_CONTENT    IN    VARCHAR2
     , IN_KKO_BTN_TYPE     IN    VARCHAR2
     , IN_KKO_BTN_INFO     IN    VARCHAR2
     , IN_USER_ID          IN    VARCHAR2
     , IN_ORD_ID           IN    VARCHAR2
     , IN_PT_NM            IN    VARCHAR2
     , IN_ETC_TEXT_1       IN    VARCHAR2
     , IN_ETC_TEXT_2       IN    VARCHAR2
     , IN_ETC_TEXT_3       IN    VARCHAR2
     , IN_ETC_NUM_1        IN    NUMBER
     , IN_ETC_NUM_2        IN    NUMBER
     , IN_ETC_NUM_3        IN    NUMBER
     , IO_SEQ              OUT   NUMBER
     , IO_ERRYN            OUT   VARCHAR2
     , IO_ERRMSG           OUT   VARCHAR2
) IS
    v_date_client_req  DATE;
    v_kko_btn_type     VARCHAR2(40);
BEGIN
    IO_ERRYN  := 'N';
    IO_ERRMSG := NULL;
    IO_SEQ    := NULL;  -- KO_SEQ 에도 NULL 들어가게 함

    -- 전송 예약 시간 변환 (NULL이면 SYSDATE)
    IF IN_DATE_CLIENT_REQ IS NOT NULL THEN
        v_date_client_req := TO_DATE(IN_DATE_CLIENT_REQ, 'YYYY-MM-DD HH24:MI:SS');
    ELSE
        v_date_client_req := SYSDATE;
    END IF;

    -- 버튼 타입 기본값 '2'
    v_kko_btn_type := NVL(IN_KKO_BTN_TYPE, '2');

    INSERT INTO XCOM.ATA_MMT_TRAN (
          KO_MT_REFKEY
        , KO_DATE_CLIENT_REQ
        , KO_SUBJECT
        , KO_CALLBACK
        , KO_TEMPLATE_CODE
        , KO_CONTENT
        , KO_RECIPIENT_NUM
        , KO_SMCONTENT
        , KO_KKO_BTN_TYPE
        , KO_KKO_BTN_INFO
        , KO_USER_ID
        , KO_ORD_ID
        , KO_PT_NM
        , KO_ETC_TEXT_1
        , KO_ETC_TEXT_2
        , KO_ETC_TEXT_3
        , KO_ETC_NUM_1
        , KO_ETC_NUM_2
        , KO_ETC_NUM_3
        , KO_SEQ
    ) VALUES (
          IN_MT_REFKEY
        , v_date_client_req
        , IN_SUBJECT
        , IN_CALLBACK
        , IN_TEMPLATE_CODE
        , IN_CONTENT
        , IN_RECIPIENT_NUM
        , IN_RETRY_CONTENT
        , v_kko_btn_type
        , IN_KKO_BTN_INFO
        , IN_USER_ID
        , IN_ORD_ID
        , IN_PT_NM
        , IN_ETC_TEXT_1
        , IN_ETC_TEXT_2
        , IN_ETC_TEXT_3
        , IN_ETC_NUM_1
        , IN_ETC_NUM_2
        , IN_ETC_NUM_3
        , IO_SEQ  -- 지금은 NULL, 나중에 시퀀스 쓰고 싶으면 여기 채우면 됨
    );

EXCEPTION
    WHEN OTHERS THEN
        IO_ERRYN  := 'Y';
        IO_ERRMSG := SQLERRM;
END PC_COM_DTALK_SEND;


END PKG_COM_TALK;
