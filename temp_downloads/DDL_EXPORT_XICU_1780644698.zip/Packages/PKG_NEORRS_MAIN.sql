
  CREATE OR REPLACE EDITIONABLE PACKAGE "XICU"."PKG_NEORRS_MAIN" 
IS 
TYPE RETURNCURSOR IS REF CURSOR; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHART_DTL_DATA 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 차트 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHART_DTL_DATA   ( IN_PT_NO                 IN    VARCHAR2      /* 환자번호 */ 
                                   , IN_HSP_TP_CD             IN    VARCHAR2      /* 병동구분코드 */ 
                                   , IN_RRS_ITEM_CD                IN    VARCHAR2 
                                   , IN_FROMDATE              IN    VARCHAR2 
                                   , IN_TODATE              IN    VARCHAR2 
                                   , OUT_CURSOR               OUT   RETURNCURSOR  
                                   ) 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHART_NEWS_DATA 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 차트 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHART_NEWS_DATA   ( IN_PT_NO                 IN    VARCHAR2      /* 환자번호 */ 
                                   , IN_HSP_TP_CD             IN    VARCHAR2      /* 병동구분코드 */ 
                                   , IN_FROMDATE              IN    VARCHAR2 
                                   , IN_TODATE                IN    VARCHAR2 
                                   , OUT_CURSOR               OUT   RETURNCURSOR  
                                   ) 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LOGIN_CHECK 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 로그인 정보 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LOGIN_CHECK  ( IN_STF_NO             IN    VARCHAR2      /* 환자번호 */ 
                              , IN_HSP_TP_CD          IN    VARCHAR2      /* 병동구분코드 */ 
                              , IN_PWD                IN    VARCHAR2 
                              , IN_ADLOGIN_YN         IN    VARCHAR2 
                              , OUT_CURSOR            OUT  RETURNCURSOR) 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LOGIN_CHECK 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 병원 부서 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SELECT_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2 /* 병동구분코드 */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR  
                                , OUT_CURSOR2           OUT  RETURNCURSOR)   
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_USER_DEPTCD 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 사용자 등록 시 병원 부서 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_USER_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR )  
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SELECT_USER_INFO 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 사용자 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SELECT_USER_INFO  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                   , IN_STF_NO             IN   VARCHAR2 
                                   , OUT_CURSOR            OUT  RETURNCURSOR  
                                   , OUT_SMS_CURSOR        OUT  RETURNCURSOR )   
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_IU_USER 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 사용자 등록 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_IU_USER  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                          , IN_USR_ID             IN   VARCHAR2 
                          , IN_USR_NM             IN   VARCHAR2 
                          , IN_AUTH_STATE         IN   VARCHAR2 
                          , IN_PH_NO              IN   VARCHAR2  
                          , IN_SMS_YN             IN   VARCHAR2  
                          , IN_REG_ID             IN   VARCHAR2 
                          , IO_ERRYN              OUT  VARCHAR2 
                          , IO_MESSAGE            OUT  VARCHAR2 
                          )   
;         
                        
                        
/*=================================================================================== 
* 서비스이름      : PC_RRS_DELETE_USER 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 사용자 등록 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DELETE_USER  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                              , IN_STF_NO             IN   VARCHAR2 
                              , IN_LoginID            IN   VARCHAR2 
                              , IO_ERRYN              OUT  VARCHAR2 
                              , IO_MESSAGE            OUT  VARCHAR2 
                              )  
;                                                      
                        
/*=================================================================================== 
* 서비스이름      : PC_RRS_PATIENT_SEARCH 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 직접입력 시 환자번호 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_PATIENT_SEARCH     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                    , OUT_CURSOR          OUT   RETURNCURSOR ) 
;   
 
/*=================================================================================== 
* 서비스이름      : PC_RRSDATA_USER_INSERT 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 데이터 직접입력 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRSDATA_USER_INSERT    ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , IN_PACT_ID          IN VARCHAR2   /* 원무접수ID */ 
                                    , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                    , IN_STF_NO           IN VARCHAR2   /* 입력 직원번호 */ 
                                    ) 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_INS_UDT_DEPTCD 
* 최초 작성일     : 2019.03.0 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 에서 사용하는 부서 등록 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_INS_UDT_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                 , IN_DEPT_CD            IN   VARCHAR2   
                                 , IN_IU_GUBN            IN   VARCHAR2          /* 등록 삭제 구분(I : 등록,   U : 삭제 ) */ 
                                 , IN_ENT_USER           IN   VARCHAR2  
                                 , IO_ERRYN              OUT  VARCHAR2 )   
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_NEW_LABCODE_EDIT 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : LAB 검사 추가 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_NEW_LABCODE_EDIT     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                  , IN_MSTR_CD          IN VARCHAR2   /* 항목구분코드  VITAL, LAB */ 
                                  , IN_ITEM_CD          IN VARCHAR2   /* 검사코드 */ 
                                  , IN_ITEM_NM          IN VARCHAR2   /* 검사명칭  */ 
                                  , IN_ENT_STF          IN VARCHAR2   /* 입력 직원번호 */ 
                                  , IN_ITEM_A_MIN       IN VARCHAR2   /* 성인 기준치 하한치 */ 
                                  , IN_ITEM_A_MAX        IN VARCHAR2   /* 성인 기준치 상한치 */ 
                                  , IN_ITEM_C_MIN        IN VARCHAR2   /* 소아 기준치 하한치 */ 
                                  , IN_ITEM_C_MAX        IN VARCHAR2   /* 소아 기준치 상한치 */ 
                                  , IN_ITEM_P_MIN       IN VARCHAR2   /* 임산부 기준치 하한치 */ 
                                  , IN_ITEM_P_MAX       IN VARCHAR2   /* 임산부 기준치 상한치 */ 
                                  , IN_REG_IP           IN VARCHAR2   /* 등록자 ip */   
                                  , IO_ERRYN            OUT  VARCHAR2 ) 
; 
    
/*=================================================================================== 
* 서비스이름      : PC_NEW_LABCODE_EDIT_ICU 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : LAB 검사 추가 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_NEW_LABCODE_EDIT_ICU ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                  , IN_MSTR_CD          IN VARCHAR2   /* 항목구분코드  VITAL, LAB */ 
                                  , IN_ITEM_CD          IN VARCHAR2   /* 검사코드 */ 
                                  , IN_ITEM_NM          IN VARCHAR2   /* 검사명칭  */ 
                                  , IN_ENT_STF          IN VARCHAR2   /* 입력 직원번호 */ 
                                  , IN_ITEM_A_MIN       IN VARCHAR2   /* 성인 기준치 하한치 */ 
                                  , IN_ITEM_A_MAX        IN VARCHAR2   /* 성인 기준치 상한치 */ 
                                  , IN_ITEM_C_MIN        IN VARCHAR2   /* 소아 기준치 하한치 */ 
                                  , IN_ITEM_C_MAX        IN VARCHAR2   /* 소아 기준치 상한치 */ 
                                  , IN_ITEM_P_MIN       IN VARCHAR2   /* 임산부 기준치 하한치 */ 
                                  , IN_ITEM_P_MAX       IN VARCHAR2   /* 임산부 기준치 상한치 */ 
                                  , IN_REG_IP           IN VARCHAR2   /* 등록자 ip */
                                  , IN_ICU_CD           IN VARCHAR2   /* ICU CD */      
                                  , IO_ERRYN            OUT  VARCHAR2 ) 
                                  ; 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_SETTING_ITEMS 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_SETTING_ITEMS  ( IN_HSP_TP_CD    IN   VARCHAR2       /* 병동구분코드 */ 
                                    , IN_MSTR_CD      IN   VARCHAR2       /* Vital, Lab 고정 및 추가 항목  */ 
                                    , OUT_CURSOR      OUT  RETURNCURSOR )  
;                                     
             
 /*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_SETTING_ICU_ITEMS 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_SETTING_ICU_ITEMS  ( IN_HSP_TP_CD     IN   VARCHAR2       /* 병동구분코드 */ 
                                        , IN_ICUcd         IN   VARCHAR2       /* 고정 / 추가 항목  */ 
                                        , IN_MSTR_CD       IN   VARCHAR2       /* 고정 / 추가 항목  */ 
                                        , OUT_CURSOR       OUT  RETURNCURSOR )  
                                        ;
                                        
/*=================================================================================== 
* 서비스이름      : PC_RRS_UDT_ENV_SETTING 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 환경설정 저장 ( sms전송 및 sound ) 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_UDT_ENV_SETTING  ( IN_HSP_TP_CD    IN   VARCHAR2  /* 병동구분코드 */ 
                                  , IN_WHAT         IN   VARCHAR2  /* 저장할 값 구분  */ 
                                  , IN_VALUE        IN   VARCHAR2  /* 설정 값 Trud, False */ 
                                  , IN_USER_ID      IN   VARCHAR2  /* 로그인 사용자 */ 
                                  , IO_ERRYN        OUT  VARCHAR2 
                                    )   
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_UDT_ENV_SETTING 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DEL_SETTING_ITEMS  ( IN_HSP_TP_CD    IN   VARCHAR2       /* 병동구분코드 */ 
                                    , IN_MSTR_CD      IN   VARCHAR2  /* 고정 / 추가 항목  */ 
                                    , IN_ITEM_CD      IN   VARCHAR2  /* 항목 코드 */ 
                                    , IO_ERRYN        OUT  VARCHAR2 )   
;                                     
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHANGE_STATE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 환자 상태 변경 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHANGE_STATE  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                               , IN_HSP_TP_CD     IN   VARCHAR2  /* 병원구분코드 */ 
                               , IN_RRS_STATE_CD  IN   VARCHAR2 
                               , IN_PACT_ID       IN   VARCHAR2 
                               , IN_REG_ID        IN   VARCHAR2 
                               , IN_REG_IP        IN   VARCHAR2 
                                 )   
;           

/*=================================================================================== 
* 서비스이름      : PC_RRS_CHANGE_STATE_2 
* 최초 작성일     : 2026.04.04
* 최초 작성자     : 장인수 
* DESCRIPTION    : 지역의료원 환자 상태 변경 지역의료원에서 사용하는 프로시저 본사 개발 테스트를 위해 생성  
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHANGE_STATE_2  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                               , IN_HSP_TP_CD     IN   VARCHAR2  /* 병원구분코드 */ 
                               , IN_RRS_STATE_CD  IN   VARCHAR2 
                               , IN_PACT_ID       IN   VARCHAR2 
                               , IN_ITEM_CD       IN   VARCHAR2 
                               , IN_ENT_DTM       IN   VARCHAR2  
                               , IN_REG_ID        IN   VARCHAR2 
                               , IN_REG_IP        IN   VARCHAR2 
                                 )                          
;

 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 리스트 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                       , IN_RRS_STATE_CD       IN   VARCHAR2  /* 상태  */  
                       , IN_WARD_INFO          IN   VARCHAR2  /* 병동  */  
                       , IN_PT_NO              IN   VARCHAR2  /* 환자번호  */  
                       , OUT_CURSOR            OUT  RETURNCURSOR )   
;                        
           
/*=================================================================================== 
* 서비스이름      : PC_RRS_PAT_EACH_LIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 환자별 RRS 리스트 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_PAT_EACH_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                , IN_PT_NO              IN   VARCHAR2  /* 환자번호  */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR )  
;                                 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_FIXED_ITEM_LIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 고정항목 리스트 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_FIXED_ITEM_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                  , OUT_CURSOR            OUT  RETURNCURSOR )  
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_RRS_TEST_HIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 환자별 RRS 검사 이력 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_RRS_TEST_HIST  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                 , IN_PT_NO             IN   VARCHAR2          /* 환자번호 */ 
                                 , IN_TEST_GUBN         IN   VARCHAR2          /* 임상관찰:4,  LAB검사:5  */   
                                 , OUT_CURSOR          OUT  sys_refcursor  
                                 )  
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_ALL_STATISTICS 
* 최초 작성일     : 2019.03.18 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 전체 통계조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_ALL_STATISTICS  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
--                                 , IN_WORK_DT            IN   VARCHAR2          /* 적용 일자 */ 
--                                  
--                                 , OUT_CURSOR_1          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_2          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_3          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_4          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_5          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_6          OUT  RETURNCURSOR    
--                                 , OUT_CURSOR_7          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_8          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_9          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_10         OUT  RETURNCURSOR                               
--                                  )   
--;                                   
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LIST_COUNT 
* 최초 작성일     : 2019.03.19 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 리스트 건수 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LIST_COUNT  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */          
																											  , IN_SEARCH_CHECK_TM    IN   VARCHAR2  /* 20260407 장인수 지역병원과 동일하게 권역병원에서도 인파라미터 형식 맞쳐줌 */
                             , OUT_CURSOR            OUT  RETURNCURSOR ) 
;                                                         
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CUR_PAT_STATE 
* 최초 작성일     : 2019.03.19 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 현재환자 상태 조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_CUR_PAT_STATE  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
--                                , IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
--                                , IN_RRS_ITEM_CD        IN   VARCHAR2  /* 검사항목 */ 
--                                , OUT_CURSOR            OUT  RETURNCURSOR )  
--;                                                                            
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_LIST_SEARCH 
* 최초 작성일     : 2019.03.20 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모내역 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_LIST_SEARCH  ( IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                   , IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                   , IN_REG_ID             IN   VARCHAR2  /* 등록자 ID */ 
                                   , IN_MEMO_KIND          IN   VARCHAR2  /* 중요 여부 */ 
                                   , OUT_CURSOR            OUT  RETURNCURSOR )  
;                                 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_INSERT 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모 등록 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_INSERT  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                              , IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
                              , IN_MEMO          IN   VARCHAR2 
                              , IN_MEMO_KIND     IN   VARCHAR2 
                              , IN_REG_ID        IN   VARCHAR2                               
                              , IN_REG_IP        IN   VARCHAR2 
                             ) 
;                              
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_DELETE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_DELETE  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                              , IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */                               
                              , IN_SEQ           IN   VARCHAR2 
                              , IN_REG_ID        IN   VARCHAR2 
                              , IN_REG_IP        IN   VARCHAR2 
                             ) 
;                              
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_ADD_PTNO_LIST 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 추가환자리스트 조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_ADD_PTNO_LIST  ( IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
--                                , OUT_CURSOR            OUT  RETURNCURSOR 
--                   ) 
--; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO  ( IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR 
                   ) 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_USING_DEPT_LIST 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS CRF 데이터 조회 - 진료과  코드 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_USING_DEPT_LIST         ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , OUT_CURSOR           OUT  RETURNCURSOR) 
 
;  
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_TEST_ITEM_LIST 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS CRF 데이터 조회 - 검사항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_TEST_ITEM_LIST     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , OUT_CURSOR           OUT  RETURNCURSOR) 
 
;  
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_DIAGNOSIS_LIST 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS CRF 데이터 조회 - 검사항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DIAGNOSIS_LIST     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , OUT_CURSOR           OUT  RETURNCURSOR) 
 
; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_VITALIZE_DATA 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 활성화정보 저장 내역 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_VITALIZE_DATA ( IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                   , IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                   , OUT_CURSOR           OUT  RETURNCURSOR) 
 
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO_SAVE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO_SAVE  (IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                    , IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                    , IN_METHOD_CD          IN   VARCHAR2  /* 방법 */ 
                                    , IN_METHOD_TXT         IN   VARCHAR2  /* 방법 기타 */ 
                                    , IN_SUBJECT_CD         IN   VARCHAR2  /* 주체 */ 
                                    , IN_SUBJECT_TXT        IN   VARCHAR2  /* 주체 기타 */ 
                                    , IN_VITALIZE_TM        IN   VARCHAR2  /* 활성화 시간 */ 
                                    , IN_VITALIZE_ARRI_TM   IN   VARCHAR2  /* 현장도착시간 */ 
                                    , IN_VIT_JUDT_CNTS      IN   VARCHAR2  /* 활성화중재내용 */ 
                                    , IN_VIT_JUDT_CNTS_TXT  IN   VARCHAR2  /* 활성화중재내용 기타 */ 
                                    , IN_VIT_TEAM_DIAG      IN   VARCHAR2  /* 신속대응팀 진단  */ 
                                    , IN_VIT_TEAM_DIAG_TXT  IN   VARCHAR2  /* 신속대응팀 진단 기타 */ 
                                    , IN_VIT_END_RSLT       IN   VARCHAR2  /* 활성화 종료 결과  */ 
                                    , IN_VIT_END_RSLT_TXT   IN   VARCHAR2  /* 활성화 종료 결과 기타 */ 
                                    , IN_REG_ID             IN   VARCHAR2  /* 등록자ID */ 
                                    , IN_REG_IP             IN   VARCHAR2  /* 등록자IP */ 
                                    , IO_ERRYN              OUT  VARCHAR2 
                                    , IO_MESSAGE            OUT  VARCHAR2 ) 
; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CRF_SERARCH 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS CRF 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CRF_SERARCH    ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                , IN_ST_DT            IN VARCHAR2   /* 조회 시작일 */ 
                                , IN_DT_DT            IN VARCHAR2   /* 조회 종료일 */                                     
                                , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                , IN_PT_SEX           IN VARCHAR2   /* 성별 */  
                                , IN_SC_CHK           IN VARCHAR2   /* 스크리닝 20260407 장인수 지역병원과 동일하게 권역병원에서도 인파라미터 형식 맞쳐줌 */  
                                , IN_PT_AGE_S         IN VARCHAR2   /* 나이 구간 시작 */ 
                                , IN_PT_AGE_E         IN VARCHAR2   /* 나이 구간 종료 */ 
                                , IN_DEPT_CD          IN VARCHAR2   /* 부서코드 */ 
                                , IN_PT_LOC           IN VARCHAR2   /* 병동위치 */ 
                                , IN_RRS_ITEM_CD      IN VARCHAR2   /* 검사코드 */ 
                                , IN_NEWS_SCORE       IN VARCHAR2   /* NEWS 계산 스코어 */ 
                                , IN_RRS_STATE_CD     IN VARCHAR2   /* RRS 상태값 */ 
                                , IN_DIAGNOSIS        IN VARCHAR2   /* 진단명 */                                   
                                , OUT_CURSOR          OUT  RETURNCURSOR 
                                , OUT_CUR_STATISTIC   OUT  RETURNCURSOR  /* 20260407 장인수 지역병원과 동일하게 권역병원에서도 인파라미터 형식 맞쳐줌 */
                                ) 
; 
    
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITAL_INFO_LIST 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS CRF 바이탈 입력 정보 리스트 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITAL_INFO_LIST ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                 , IN_ST_DT            IN VARCHAR2   /* 조회 시작일 */ 
                                 , IN_DT_DT            IN VARCHAR2   /* 조회 종료일 */                                     
                                 , IN_PT_NO            IN VARCHAR2   /* 환자번호 */                              
                                 , IN_VITALMETHOD      IN VARCHAR2   /* 활성화 방법 */ 
                                 , IN_VITALSUBJECT     IN VARCHAR2   /* 활성화 주체 */ 
                                 , IN_VITJUDGCNTS      IN VARCHAR2    
                                 , IN_VITTEAMDIAG      IN VARCHAR2    
                                 , IN_VITENDRSLT       IN VARCHAR2    
                                 , OUT_CURSOR          OUT  RETURNCURSOR 
                                 ) 
;   
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SMS_MSG_SEND 
* 최초 작성일     : 2020.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     :  RRS 주치의, 전문의 문자 전송 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SMS_MSG_SEND ( IN_HSP_TP_CD            IN VARCHAR2   /* 병원구분코드 */ 
                              , IN_MSG               IN VARCHAR2   /* 메시지 */                                  
                              , IN_PT_NO             IN VARCHAR2   /* 환자번호 */   
                              , IN_PACT_ID           IN VARCHAR2   /* PACT_ID */     
                              ) 
;  
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO_EDIT 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO_EDIT ( 
              IN_ROWNUM             IN   VARCHAR2 
            , IN_PT_NO              IN   VARCHAR2     
            , IN_ENT_DT             IN   VARCHAR2     
            , IN_HSP_TP_CD          IN   VARCHAR2     
            , IN_METHOD_CD          IN   VARCHAR2     
            , IN_METHOD_TXT         IN   VARCHAR2     
            , IN_SUBJECT_CD         IN   VARCHAR2     
            , IN_SUBJECT_TXT        IN   VARCHAR2     
            , IN_VITALIZE_TM        IN   VARCHAR2     
            , IN_VITALIZE_ARRI_TM   IN   VARCHAR2     
            , IN_VIT_JUDT_CNTS      IN   VARCHAR2     
            , IN_VIT_JUDT_CNTS_TXT  IN   VARCHAR2     
            , IN_VIT_TEAM_DIAG      IN   VARCHAR2     
            , IN_VIT_TEAM_DIAG_TXT  IN   VARCHAR2     
            , IN_VIT_END_RSLT       IN   VARCHAR2     
            , IN_VIT_END_RSLT_TXT   IN   VARCHAR2     
            , IN_REG_ID             IN   VARCHAR2     
            , IN_REG_IP             IN   VARCHAR2     
            , IO_ERRYN              OUT   VARCHAR2     
            , IO_MESSAGE            OUT   VARCHAR2    ) 
;                    

/*=================================================================================== 
* 서비스이름      : IF_PHONE_NUMBER_SEL 
* 최초 작성일     : 2025.12 
* 최초 작성자     : 윤재림 
* DESCRIPTION    : 이송시스템 휴대번호 조회 
* 변경이력관리 
===================================================================================*/         
PROCEDURE IF_PHONE_NUMBER_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
	 												, IN_HSP_TP_CD				IN VARCHAR2
	                        , OUT_CURSOR 		  		OUT SYS_REFCURSOR
          );

/*=================================================================================== 
* 서비스이름      : IF_PHONE_NUMBER_SEL 
* 최초 작성일     : 2025.12 
* 최초 작성자     : 윤재림 
* DESCRIPTION    : 이송시스템 휴대번호 등록 
* 변경이력관리 
===================================================================================*/                 
PROCEDURE IF_PHONE_NUMBER_UPD (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
                          , IN_COMN_CD          IN  VARCHAR2
                          , IN_HSP_TP_CD      	IN  VARCHAR2
                          , IN_COMN_CD_NM       IN  VARCHAR2  
                          , OUT_CURSOR          OUT SYS_REFCURSOR 
        );                              
        


 
END PKG_NEORRS_MAIN;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_NEORRS_MAIN" 
IS 
   
/*=================================================================================== 
* 서비스이름      :                   
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 5RRS 차트 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHART_DTL_DATA   ( IN_PT_NO                 IN    VARCHAR2      /* 환자번호 */ 
                                   , IN_HSP_TP_CD             IN    VARCHAR2      /* 병동구분코드 */ 
                                   , IN_RRS_ITEM_CD                IN    VARCHAR2 
                                   , IN_FROMDATE              IN    VARCHAR2 
                                   , IN_TODATE              IN    VARCHAR2 
                                   , OUT_CURSOR               OUT   RETURNCURSOR  
                                   ) 
IS 
 
BEGIN 
    OPEN OUT_CURSOR FOR 
        SELECT tm.ENT_DTM, tm.CALC_ENT_DTM, h.RRS_VALUE, h.NEWS, h.NEWS_SCORE  --//―2025/ez고도화로 인한 작업―YJR
          FROM ( select DISTINCT ENT_DTM, TO_CHAR(rv.ENT_DTM, 'HH24:MI') as CALC_ENT_DTM 
          from HICU.RRS_VALUE_H rv        
         where rv.PT_NO =IN_PT_NO 
           and rv.HSP_TP_CD = IN_HSP_TP_CD 
           and rv.ENT_DT >= IN_FROMDATE 
           and rv.ENT_DT <= IN_TODATE 
          ) tm 
         LEFT OUTER JOIN ( select DISTINCT rvh.ENT_DT, rvh.ENT_DTM, rvh.NEWS, rvh.NEWS_SCORE   --//―2025/ez고도화로 인한 작업―YJR  
                                     , NVL(rvh.CUR_VALUE, rvh.RRS_VALUE_H ) as RRS_VALUE 
                                  from HICU.RRS_VALUE_H rvh    
                                 where PT_NO = IN_PT_NO 
                                   and HSP_TP_CD = IN_HSP_TP_CD 
                                   AND RRS_ITEM_CD  = IN_RRS_ITEM_CD 
                                   and ENT_DT >= IN_FROMDATE 
                                   and ENT_DT <= IN_TODATE 
                                   AND REG_DTM = (select max(REG_DTM) from HICU.RRS_VALUE_H rvh2  
                                                   where PT_NO = IN_PT_NO 
                                                   and HSP_TP_CD = IN_HSP_TP_CD 
                                                   AND RRS_ITEM_CD  = IN_RRS_ITEM_CD 
                                                   and ENT_DT = rvh.ENT_DT 
                                                   and ENT_DTM = rvh.ENT_DTM  
                                                  ) 
                              ) h ON (h.ENT_DTM = tm.ENT_DTM  ) 
        ORDER BY ENT_DTM 
        ; 
END PC_RRS_CHART_DTL_DATA;      
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHART_NEWS_DATA 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 차트 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHART_NEWS_DATA   ( IN_PT_NO                 IN    VARCHAR2      /* 환자번호 */ 
                                   , IN_HSP_TP_CD             IN    VARCHAR2      /* 병동구분코드 */ 
                                   , IN_FROMDATE              IN    VARCHAR2 
                                   , IN_TODATE                IN    VARCHAR2 
                                   , OUT_CURSOR               OUT   RETURNCURSOR  
                                   ) 
IS 
 
BEGIN 
    OPEN OUT_CURSOR FOR 
        SELECT DISTINCT tm.ENT_DTM,  CALC_ENT_DTM 
             , (SELECT MAX(NEWS_SCORE) FROM HICU.RRS_VALUE_H in_c
                 WHERE in_c.HSP_TP_CD = tm.HSP_TP_CD 
                   AND in_c.PT_NO = tm.PT_NO 
                   AND in_c.ENT_DTM = tm.ENT_DTM 
                   AND in_c.HIST_SEQ = (SELECT MAX(HIST_SEQ)  
                                          FROM HICU.RRS_VALUE_H rvh  
                                         WHERE HSP_TP_CD = in_c.HSP_TP_CD 
                                           AND PT_NO = in_c.PT_NO 
                                           AND ENT_DTM = in_c.ENT_DTM)) NEWS_SCORE_VALUE   --//―2025/ez고도화로 인한 작업―YJR   RRS_VALUE -> NEWS_SCORE_VALUE
             , (SELECT MAX(NEWS) FROM HICU.RRS_VALUE_H in_c   --//―2025/ez고도화로 인한 작업―YJR  
                 WHERE in_c.HSP_TP_CD = tm.HSP_TP_CD 
                   AND in_c.PT_NO = tm.PT_NO 
                   AND in_c.ENT_DTM = tm.ENT_DTM 
                   AND in_c.HIST_SEQ = (SELECT MAX(HIST_SEQ)  
                                          FROM HICU.RRS_VALUE_H rvh  
                                         WHERE HSP_TP_CD = in_c.HSP_TP_CD 
                                           AND PT_NO = in_c.PT_NO 
                                           AND ENT_DTM = in_c.ENT_DTM)) RRS_VALUE 
          FROM ( 
            SELECT DISTINCT HSP_TP_CD, PT_NO, ENT_DTM, TO_CHAR(rv.ENT_DTM, 'HH24:MI') as CALC_ENT_DTM 
              FROM HICU.RRS_VALUE_H rv        
             where rv.PT_NO = IN_PT_NO 
               AND rv.HSP_TP_CD = IN_HSP_TP_CD 
               AND rv.ENT_DT >= IN_FROMDATE 
               AND rv.ENT_DT <= IN_TODATE 
               AND rv.RRS_ITEM_CD NOT IN ( 
                    SELECT DETL_CD_1 FROM HICU.RRS_DETAIL rd  
                     WHERE HSP_TP_CD = IN_HSP_TP_CD 
                       AND MSTR_CD IN ('LAB', 'LAB_ADD') 
                       AND USE_YN = 'Y' 
                   ) 
           ) tm  
         ORDER BY tm.ENT_DTM 
        ; 
END PC_RRS_CHART_NEWS_DATA;  
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LOGIN_CHECK 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 로그인 정보 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LOGIN_CHECK  ( IN_STF_NO             IN    VARCHAR2      /* 환자번호 */ 
                              , IN_HSP_TP_CD          IN    VARCHAR2      /* 병동구분코드 */ 
                              , IN_PWD                IN    VARCHAR2 
                              , IN_ADLOGIN_YN         IN    VARCHAR2 
                       , OUT_CURSOR            OUT  RETURNCURSOR) 
 
 
IS    
    V_RESULT VARCHAR2(2) := '';    
    V_AUTH VARCHAR2(2) := '';       
    V_STF_NM VARCHAR2(20) := '';         
BEGIN 
    OPEN OUT_CURSOR FOR 
   SELECT 'Y' -- CASE WHEN decode(IN_ADLOGIN_YN, 'Y', SEC_LGIN_PWD, XCOM.FT_COM_ONEWAYCRYPTO(IN_PWD)) = SEC_LGIN_PWD THEN 'Y' ELSE 'N' END 
         , NVL(B.USR_AUTH,'N')   AUTH_STATE  
         , b.USR_NM  
         , nvl(b.DEPT_CD, '-') DEPT_CD 
         , B.HSP_TP_CD                
      FROM HICU.RRS_USER B 
     WHERE B.HSP_TP_CD = decode(IN_HSP_TP_CD, '*', B.HSP_TP_CD, IN_HSP_TP_CD) 
       AND B.USR_ID = IN_STF_NO 
       AND B.HIST_SEQ = 0 
       ;         
END PC_RRS_LOGIN_CHECK; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SELECT_DEPTCD 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     : 병원 부서 조회 - 병동, 응급실, 중환자실 만 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SELECT_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR  
                                , OUT_CURSOR2           OUT  RETURNCURSOR)   
IS 
BEGIN 
   OPEN OUT_CURSOR FOR 
        SELECT DEPT_CD 
           , RMK_CNTE DEPT_NM 
           , 'Y' 
        FROM HICU.UCCOCDPM 
       WHERE HSP_TP_CD = IN_HSP_TP_CD 
         AND USE_YN = 'Y' 
       ORDER BY SORT_SEQ 
       ;    
        
    OPEN OUT_CURSOR2 FOR 
           SELECT HSP_TP_CD, HSP_NM 
          FROM HICU.UCCOCHPM 
         where USE_YN = 'Y' 
           ;  
             
END PC_RRS_SELECT_DEPTCD; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_USER_DEPTCD 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION   : 사용자 등록 시 병원 부서 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_USER_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                              , OUT_CURSOR            OUT  RETURNCURSOR )   
IS 
BEGIN 
    OPEN OUT_CURSOR FOR 
        select distinct 
             A.DEPT_CD 
           , A.DEPT_NM 
        from PDEDBMSM A --권역 테스트 20260210 VIEW_DEPT A
           , HICU.RRS_VALUE B   
		where A.HSP_TP_CD  = '08' -- 권역 테스트 20260210 '1'           -- 권역병원 20251219  where A.HSP_TP_CD  = '1'     
         and A.HSP_TP_CD  = B.HSP_TP_CD
         and B.DEPT_CD = A.DEPT_CD
         and ENT_DT between TO_CHAR((SYSDATE-30), 'YYYYMMDD') AND TO_CHAR(SYSDATE, 'YYYYMMDD')
       order by DEPT_CD
            ; 
END PC_RRS_USER_DEPTCD; 
 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SELECT_USER_INFO 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 사용자 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SELECT_USER_INFO  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                   , IN_STF_NO             IN   VARCHAR2 
                                   , OUT_CURSOR            OUT  RETURNCURSOR 
                                   , OUT_SMS_CURSOR        OUT  RETURNCURSOR)   
IS  
BEGIN 
    -- 사용자 조회 
    OPEN OUT_CURSOR FOR 
       select USR_ID 
            , USR_NM 
            , USR_AUTH   USR_AUTH 
            , USR_PHONE  PH_NO 
            , SMS_YN 
            , DEPT_CD    DEPT_CD 
            , DISP_SEQ    
            , ROWNUM     INDEX_NO 
         from HICU.RRS_USER 
        where HSP_TP_CD = IN_HSP_TP_CD 
          and USR_ID = decode(IN_STF_NO, NULL, USR_ID, IN_STF_NO) 
          and HIST_SEQ = 0 
        order by DISP_SEQ 
         ; 
          
    -- SMS 전송여부 
    OPEN OUT_SMS_CURSOR FOR 
       SELECT ( SELECT DETL_CD FROM HICU.RRS_DETAIL rd 
                 WHERE HSP_TP_CD = IN_HSP_TP_CD 
                   AND MSTR_CD = 'SMS_SEND' 
                   AND USE_YN = 'Y'  
                   AND ROWNUM = 1) SMS_SEND, 
                (SELECT DETL_CD 
                   FROM HICU.RRS_DETAIL rd 
                  WHERE HSP_TP_CD = IN_HSP_TP_CD                
                    AND MSTR_CD = 'OVER_VAL_SMS' 
                    AND USE_YN = 'Y' 
                    AND ROWNUM = 1)  SMS_VAL, 
                (SELECT DETL_CD FROM HICU.RRS_DETAIL rd 
                  WHERE HSP_TP_CD = IN_HSP_TP_CD 
                    AND MSTR_CD = 'SCREENING' 
                    AND USE_YN = 'Y' 
                    AND ROWNUM = 1) SCREENING_VAL 
                   FROM DUAL 
         ;          
        
          
END PC_RRS_SELECT_USER_INFO; 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_IU_USER 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION   : 사용자 등록 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_IU_USER  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                          , IN_USR_ID             IN   VARCHAR2 
                          , IN_USR_NM             IN   VARCHAR2 
                          , IN_AUTH_STATE         IN   VARCHAR2 
                          , IN_PH_NO              IN   VARCHAR2  
                          , IN_SMS_YN             IN   VARCHAR2  
                          , IN_REG_ID             IN   VARCHAR2 
                          , IO_ERRYN              OUT  VARCHAR2 
                          , IO_MESSAGE            OUT  VARCHAR2 
                          )   
IS 
 
BEGIN   
      IO_ERRYN  := 'N'; 
           
    update HICU.RRS_USER set HIST_SEQ = ( select max(HIST_SEQ) + 1 from HICU.RRS_USER 
                                      where HSP_TP_CD = IN_HSP_TP_CD 
                                        and USR_ID    = IN_USR_ID  ) 
     where HSP_TP_CD = IN_HSP_TP_CD 
       and USR_ID    = IN_USR_ID  
       and HIST_SEQ  = 0 
       ; 
     
    insert  
      into HICU.RRS_USER(HSP_TP_CD, USR_ID, HIST_SEQ, USR_NM, USR_AUTH, USR_PHONE, SMS_YN, DISP_SEQ, REG_DTM, REG_ID) 
             values(IN_HSP_TP_CD, IN_USR_ID, 0, IN_USR_NM, IN_AUTH_STATE, IN_PH_NO, IN_SMS_YN, 1, sysdate, IN_REG_ID) 
    ;                   
 
    EXCEPTION 
        WHEN OTHERS THEN 
            IO_ERRYN  := 'Y'; 
            IO_MESSAGE := '1.사용자 입력 및 변경중 에러발생  ERRCODE = ' || TO_CHAR(SQLCODE); 
 
END PC_RRS_IU_USER; 
                           
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_DELETE_USER 
* 최초 작성일     : 2019.03.05 
* 최초 작성자     : 하만석 
* DESCRIPTION   : 사용자 등록 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DELETE_USER  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                             , IN_STF_NO             IN   VARCHAR2 
                              , IN_LoginID            IN   VARCHAR2 
                             , IO_ERRYN              OUT  VARCHAR2 
                             , IO_MESSAGE            OUT  VARCHAR2 
                             )   
IS   
BEGIN   
   IO_ERRYN  := 'N'; 
    
    update HICU.RRS_USER  
       set HIST_SEQ = nvl((select max(HIST_SEQ)+1 from HICU.RRS_USER  
                          where HSP_TP_CD  = IN_HSP_TP_CD 
                              and USR_ID     = IN_STF_NO 
                               ), 1) 
         , REG_ID    = IN_LoginID 
         , REG_DTM   = SYSDATE 
     where HSP_TP_CD = IN_HSP_TP_CD 
       and USR_ID    = IN_STF_NO 
       and HIST_SEQ  =  0 
          ; 
    
    
    EXCEPTION 
        WHEN OTHERS THEN 
            IO_ERRYN  := 'Y'; 
            IO_MESSAGE := '사용자 입력 및 삭제중 에러발생  ERRCODE = ' || TO_CHAR(SQLCODE); 
 
END PC_RRS_DELETE_USER; 
 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_PATIENT_SEARCH 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 직접입력 시 환자번호 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_PATIENT_SEARCH ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                , OUT_CURSOR          OUT   RETURNCURSOR ) 
 
 
IS 
 
BEGIN 
    OPEN OUT_CURSOR FOR 
    SELECT A.PACT_ID 
         , A.PT_NO 
         , B.PT_NM 
         , B.SEX_TP_CD 
         , '' AS PT_AGE -- XBIL.FT_PCT_AGE('AUTO',SYSDATE, (SELECT PT_BRDY_DT FROM PCTPCPAM_DAMO WHERE PT_NO = A.PT_NO)) AS PT_AGE 
         , (SELECT DISTINCT DEPT_NM 
                   FROM PDEDBMSM 
                   WHERE DEPT_CD = (SELECT MED_DEPT_CD FROM ACPPRAAM WHERE PT_NO = A.PT_NO AND PACT_ID = A.PACT_ID)) 
         , ''  -- XCOM.FT_CNL_SELSTFINFO('4', NVL(A.CHDR_STF_NO, A.NCDR_STF_NO), A.HSP_TP_CD, NULL)    AS DEPT_NM 
       , (SELECT CLCTN_WD_DEPT_CD || '/' || CLCTN_PRM_NO || '/' || CLCTN_BED_NO FROM ACPPRAAM WHERE PT_NO = A.PT_NO AND PACT_ID = A.PACT_ID)       AS PT_LOC 
      FROM ACPPRAAM A, PCTPCPAM_DAMO B 
     WHERE A.PT_NO = IN_PT_NO 
       and B.PT_NO = A.PT_NO  
       and A.HSP_TP_CD = IN_HSP_TP_CD 
       and a.ADS_DT = (select max(ADS_DT) From ACPPRAAM where HSP_TP_CD = A.HSP_TP_CD and PT_NO = a.PT_NO) 
       and ROWNUM < 2 
     ; 
 
END PC_RRS_PATIENT_SEARCH; 
 
 
     
/*=================================================================================== 
* 서비스이름      : PC_RRSDATA_USER_INSERT 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 데이터 직접입력 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRSDATA_USER_INSERT    ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , IN_PACT_ID          IN VARCHAR2   /* 원무접수ID */ 
                                    , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                    , IN_STF_NO           IN VARCHAR2   /* 입력 직원번호 */ 
                                    ) 
 
IS 
   V_SYSDATE DATE := SYSDATE; 
    V_HIST_SEQ NUMBER := 0; 
    V_SEL_CNT  NUMBER := 0; 
BEGIN 
   ---------------------------------------------------------------------------------------------------------------------------------------------  
   -- 데이터 이력번호 생성 
   select count(*) 
       into V_HIST_SEQ 
     from HICU.RRS_MOBRRSMT 
    where PACT_ID = IN_PACT_ID 
    ; 
     
   ---------------------------------------------------------------------------------------------------------------------------------------------  
   -- 데이터 등록 
    INSERT INTO HICU.RRS_MOBRRSMT ( PACT_ID 
                         , HIST_SEQ 
                         , HSP_TP_CD 
                         , PT_NO 
                         , RRT_ITEM_TP  
                         , RRT_ITEM_CD 
                         , RRT_ITEM_NM 
                         , UITM_DTM 
                         , ENT_DT 
                         , RRT_RSLT_VAL 
                         , REC_CFMT_YN 
                          
                         , FSR_DTM 
                         , FSR_STF_NO 
                         , FSR_PRGM_NM 
                         , FSR_IP_ADDR 
                         , LSH_DTM 
                         , LSH_STF_NO 
                         , LSH_PRGM_NM 
                         , LSH_IP_ADDR 
                         ) 
                  VALUES ( IN_PACT_ID 
                         , V_HIST_SEQ 
                         , IN_HSP_TP_CD 
                         , IN_PT_NO 
                         , 'V' 
                         , 'UI' 
                         , '직접등록' 
                         , V_SYSDATE 
                         , to_char(V_SYSDATE, 'yyyymmdd') 
                         , '-' 
                         , 'Y'                              
                         , V_SYSDATE 
                         , IN_STF_NO 
                         , 'RRS' 
                         , '1.1.1.1' 
                         , TO_DATE('29991231', 'YYYYMMDD') 
                         , IN_STF_NO 
                         , 'RRS' 
                         , '1.1.1.1' 
                         )  
                         ;    
                          
   --------------------------------------------------------------------------------------------------------------------------------------------- 
   -- 등록된 값 확인          
    select count(pt_no) 
      into V_SEL_CNT 
      from HICU.RRS_VALUE 
     where PT_NO = IN_PT_NO 
       and ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
       and RRS_ITEM_CD = 'UI' 
       and HSP_TP_CD = IN_HSP_TP_CD 
       ; 
      
--   if V_SEL_CNT = 0 THEN -- 신규 입력 
--      -- 해당 값 등록 
--       insert  
--         into RRS_VALUE ( PT_NO, ENT_DT, RRS_ITEM_CD, HSP_TP_CD, PACT_ID, PT_NM, PT_SEX, PT_AGE, HD, POD 
--                        , DEPT_CD, DEPT_NM, DOC_NO, DOC_NM, DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO 
--                        , RRS_VALUE, ENT_DTM, RRS_STATE_CD, NEWS_SCORE, ITEM_NEWS_SCORE 
--                        , REG_DTM, REG_ID, REG_IP ) 
--                   select A.PT_NO    --"환자번호" 
--                        , to_char(V_SYSDATE, 'yyyymmdd') 
--                        , 'UI' 
--                        , IN_HSP_TP_CD 
--                        , A.PACT_ID 
--                        , B.PT_NM    --"환자성명" 
--                        , B.SEX_TP_CD    --"환자성별" 
--                        , '' -- XBIL.FT_PCT_AGE ( 'AUTO' , V_SYSDATE , B.PT_BRDY_DT )   --"현재일자 기준 만나이" 
--                        , TRUNC(V_SYSDATE) - A.ADS_DT + 1  --" 재원일수" 
--                         , 0  --"재원 후 최종 수술 후 경과일" 
----                        , (select trunc(max(K.OP_EXPT_DT)) 
----                             from MOOOPPAM K 
----                            where K.PT_NO = A.PT_NO 
----                              and K.HSP_TP_CD = A.HSP_TP_CD 
----                              and K.OP_EXPT_DT >= A.ADS_DT 
----                              and K.OP_DTMN_YN = 'Y' 
----                              and K.OP_CNCL_DTMN_YN = 'N' 
----                              and K.OP_DEL_YN = 'N' 
----                              and K.DEL_EXPT_YN = 'N' ) - A.ADS_DT - 1 --"재원 후 최종 수술 후 경과일" 
--                        , A.MED_DEPT_CD  --"주진료과 코드" 
--                        , C.DEPT_NM      --"주진료과 명칭" 
--                        , A.ANDR_STF_NO  --"주치의 사번" 
--                        , E.LGL_KOR_NM   --"주치의 성명"           
--                        , ''  -- , XMED.FT_MOO_DIAGNOSIS(A.PT_NO , NULL, A.MED_DEPT_CD, A.PACT_ID, A.HSP_TP_CD, 'L')  --"주진료과 진단명" 
--                        , A.WD_DEPT_CD   --"병동 코드" 
--                        , a.PRM_NO  --"병실 코드" 
--                        , a.BED_NO  --"병상 코드" 
--                        , '+' -- 결과 
--                        , V_SYSDATE      -- 등록시간 
--                        , 'M'            -- 상태    
--                        , '00' 
--                        , '00' 
--                        , V_SYSDATE 
--                        , IN_STF_NO 
--                        , '1.1.1.1' 
--                     from ACPPRAAM A 
--                        , PCTPCPAM_DAMO B 
--                        , PDEDBMSM C 
--                        , CNLRRUSD E 
--                    where 1=1 
--                      and A.PACT_ID   = IN_PACT_ID 
--                      and A.HSP_TP_CD = IN_HSP_TP_CD 
--                      and A.APCN_YN = 'N' 
--                      and A.APCN_DTM IS NULL 
--                      and A.PT_NO = B.PT_NO 
--                      and A.MED_DEPT_CD = C.DEPT_CD 
--                      and A.HSP_TP_CD = C.HSP_TP_CD 
--                      and A.ANDR_STF_NO = E.STF_NO(+) 
--                      and A.HSP_TP_CD = E.HSP_TP_CD(+) 
--                      and rownum < 2 
--           ; 
--   else  -- 수정 등록 
--       update RRS_VALUE  
--          set CUR_VALUE = CUR_VALUE || '+'  
--            , ENT_DTM   = V_SYSDATE 
--            , REG_DTM   = V_SYSDATE 
--            , REG_ID    = IN_STF_NO 
--            , REG_IP    = '1.1.1.1' 
--        where PT_NO = IN_PT_NO 
--          and ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
--          and RRS_ITEM_CD = 'UI' 
--          and HSP_TP_CD = IN_HSP_TP_CD 
--          ; 
--   end if; 
 
   --------------------------------------------------------------------------------------------------------------------------------------------- 
   -- 상태 변경 값 등록 
   PKG_NEORRS_MAIN.PC_RRS_CHANGE_STATE  ( IN_PT_NO 
                         , IN_HSP_TP_CD 
                         , 'M' 
                         , IN_PACT_ID 
                         , IN_STF_NO 
                         , '1.1.1.1' 
                   );             
    
   --------------------------------------------------------------------------------------------------------------------------------------------- 
   -- 이력 생성     
--   PKG_NEORRS.PC_MAKE_HIST(IN_PT_NO, to_char(V_SYSDATE, 'yyyymmdd'), 'UI', IN_HSP_TP_CD); 
                         
   EXCEPTION  
      WHEN OTHERS THEN 
          RAISE_APPLICATION_ERROR(-20501,'Insert Error 발생 : PC_RRSDATA_USER_INSERT'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm);        
 
END  PC_RRSDATA_USER_INSERT; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_INS_UDT_DEPTCD 
* 최초 작성일     : 2019.03.0 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 에서 사용하는 부서 등록 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_INS_UDT_DEPTCD  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                 , IN_DEPT_CD            IN   VARCHAR2   
                                 , IN_IU_GUBN            IN   VARCHAR2          /* 등록 삭제 구분(I : 등록,   U : 삭제 ) */ 
                                 , IN_ENT_USER           IN   VARCHAR2  
                                 , IO_ERRYN              OUT  VARCHAR2 )   
IS 
    V_SEQ_NO NUMBER := 0;    
BEGIN 
   IO_ERRYN := 'N';    
    
--      select nvl(max(WRT_SEQ), 0)  
--      into V_SEQ_NO 
--      from UDTRRSDEPT 
--     where HSP_TP_CD = IN_HSP_TP_CD 
--       and DEPT_CD   = IN_DEPT_CD 
--        ;    
--      
--    BEGIN 
--        if V_SEQ_NO > 0 then          
--            update UDTRRSDEPT 
--               set USE_YN = 'N' 
--             where HSP_TP_CD = IN_HSP_TP_CD 
--               and DEPT_CD = IN_DEPT_CD 
--               and WRT_SEQ = V_SEQ_NO 
--               ; 
--        END IF; 
--         
--        if IN_IU_GUBN = 'I' then 
--           INSERT INTO UDTRRSDEPT (HSP_TP_CD, DEPT_CD, WRT_SEQ, USE_YN, ENT_DTM, ENT_USER)  
--                VALUES (IN_HSP_TP_CD, IN_DEPT_CD, V_SEQ_NO+1, 'Y', SYSDATE, IN_ENT_USER) 
--           ; 
--        END IF; 
--         
--        exception 
--             when others then 
--                 IO_ERRYN := 'Y';       
--                 return;                    
--    END;        
END PC_RRS_INS_UDT_DEPTCD; 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_NEW_LABCODE_EDIT 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : LAB 검사 추가 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_NEW_LABCODE_EDIT     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                  , IN_MSTR_CD          IN VARCHAR2   /* 항목구분코드  VITAL, LAB */ 
                                  , IN_ITEM_CD          IN VARCHAR2   /* 검사코드 */ 
                                  , IN_ITEM_NM          IN VARCHAR2   /* 검사명칭  */ 
                                  , IN_ENT_STF          IN VARCHAR2   /* 입력 직원번호 */ 
                          , IN_ITEM_A_MIN      IN VARCHAR2   /* 성인 기준치 하한치 */ 
                                  , IN_ITEM_A_MAX       IN VARCHAR2   /* 성인 기준치 상한치 */ 
                                  , IN_ITEM_C_MIN       IN VARCHAR2   /* 소아 기준치 하한치 */ 
                                  , IN_ITEM_C_MAX       IN VARCHAR2   /* 소아 기준치 상한치 */ 
                                  , IN_ITEM_P_MIN       IN VARCHAR2   /* 임산부 기준치 하한치 */ 
                                  , IN_ITEM_P_MAX       IN VARCHAR2   /* 임산부 기준치 상한치 */ 
                                  , IN_REG_IP           IN VARCHAR2   /* 등록자 ip */   
                          , IO_ERRYN            OUT  VARCHAR2 ) 
 
IS 
   V_CNT   NUMBER := 0; 
   V_CNT_M NUMBER := 0; 
     
    V_SYSDATE DATE; 
    
BEGIN 
    
    V_SYSDATE := sysdate; 
   IO_ERRYN := 'N'; 
    
    select count(*) 
      into V_CNT  
      from HICU.RRS_DETAIL 
     where HSP_TP_CD = IN_HSP_TP_CD 
       and MSTR_CD   = IN_MSTR_CD 
       and ( DETL_CD_1 = IN_ITEM_CD or DETL_CD_2 = IN_ITEM_CD or DETL_CD_3 = IN_ITEM_CD or DETL_CD_4 = IN_ITEM_CD ) 
    ; 
     
     
    if V_CNT = 0 then  
        begin 
            insert into HICU.RRS_DETAIL (HSP_TP_CD, MSTR_CD, DETL_CD, DETL_CD_NM, DETL_CD_1, DISP_SEQ, USE_YN, REG_DTM, REG_ID) 
                             values(IN_HSP_TP_CD 
                                  , IN_MSTR_CD 
                                  , IN_ITEM_CD 
                                  , IN_ITEM_NM 
                                  , IN_ITEM_CD 
                                  , (select max(DISP_SEQ) from HICU.RRS_DETAIL where HSP_TP_CD = IN_HSP_TP_CD and MSTR_CD = IN_MSTR_CD) + 1 
                                  , 'Y' 
                                  , V_SYSDATE 
                                  , IN_ENT_STF ); 
                                   
            insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'A' 
                                    , 0 
                                    , IN_ITEM_A_MAX 
                                    , IN_ITEM_A_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP); 
              
             insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'C' 
                                    , 0 
                                    , IN_ITEM_C_MAX 
                                    , IN_ITEM_C_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP); 
                                     
             insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'P' 
                                    , 0 
                                    , IN_ITEM_P_MAX 
                                    , IN_ITEM_P_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP);                                 
             
            EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Update Error 발생 : PC_NEW_LABCODE_EDIT'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y'; 
         
        end; 
    else 
        begin 
            insert into HICU.RRS_ITEM_STD ( HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP ) 
             select HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP 
                  , (select max(HIST_SEQ) from HICU.RRS_ITEM_STD  
                      where HSP_TP_CD = a.HSP_TP_CD 
                        and MSTR_CD = a.MSTR_CD 
                        and ITEM_CD = a.ITEM_CD 
                        and AGE_GRP = a.AGE_GRP) + 1 
                  , MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP 
               from HICU.RRS_ITEM_STD a 
              where HSP_TP_CD = IN_HSP_TP_CD 
                and MSTR_CD = IN_MSTR_CD 
                and ITEM_CD = IN_ITEM_CD 
                and HIST_SEQ = 0; 
                 
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='A' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_A_MAX 
                            , MIN_VAL = IN_ITEM_A_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP 
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'A', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 1, V_SYSDATE, IN_ENT_STF, IN_REG_IP) 
             ; 
                   
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='C' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_C_MAX 
                            , MIN_VAL = IN_ITEM_C_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP  
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'C', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 2, V_SYSDATE, IN_ENT_STF, IN_REG_IP) 
             ; 
              
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='P' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_P_MAX 
                            , MIN_VAL = IN_ITEM_P_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP 
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'P', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 3, V_SYSDATE, IN_ENT_STF, IN_REG_IP) 
             ; 
              
        EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Update Error 발생 : PC_NEW_LABCODE_EDIT'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y'; 
 
        end;     
    end if; 
          
END PC_NEW_LABCODE_EDIT; 
 
       

 
/*=================================================================================== 
* 서비스이름      : PC_NEW_LABCODE_EDIT_ICU 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : LAB 검사 추가 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_NEW_LABCODE_EDIT_ICU ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                  , IN_MSTR_CD          IN VARCHAR2   /* 항목구분코드  VITAL, LAB */ 
                                  , IN_ITEM_CD          IN VARCHAR2   /* 검사코드 */ 
                                  , IN_ITEM_NM          IN VARCHAR2   /* 검사명칭  */ 
                                  , IN_ENT_STF          IN VARCHAR2   /* 입력 직원번호 */ 
                          , IN_ITEM_A_MIN      IN VARCHAR2   /* 성인 기준치 하한치 */ 
                                  , IN_ITEM_A_MAX       IN VARCHAR2   /* 성인 기준치 상한치 */ 
                                  , IN_ITEM_C_MIN       IN VARCHAR2   /* 소아 기준치 하한치 */ 
                                  , IN_ITEM_C_MAX       IN VARCHAR2   /* 소아 기준치 상한치 */ 
                                  , IN_ITEM_P_MIN       IN VARCHAR2   /* 임산부 기준치 하한치 */ 
                                  , IN_ITEM_P_MAX       IN VARCHAR2   /* 임산부 기준치 상한치 */ 
                                  , IN_REG_IP           IN VARCHAR2   /* 등록자 ip */
                                  , IN_ICU_CD           IN VARCHAR2   /* ICU CD */      
                          , IO_ERRYN            OUT  VARCHAR2 ) 
 
IS 
   V_CNT   NUMBER := 0; 
   V_CNT_M NUMBER := 0; 
     
    V_SYSDATE DATE; 
    
BEGIN 
    
    V_SYSDATE := sysdate; 
   IO_ERRYN := 'N'; 
    
    select count(*) 
      into V_CNT  
      from HICU.RRS_DETAIL 
     where HSP_TP_CD = IN_HSP_TP_CD 
       and MSTR_CD   = IN_MSTR_CD 
       and ( DETL_CD_1 = IN_ITEM_CD or DETL_CD_2 = IN_ITEM_CD or DETL_CD_3 = IN_ITEM_CD or DETL_CD_4 = IN_ITEM_CD ) 
    ; 
     
     
    if V_CNT = 0 then  
        begin 
            insert into HICU.RRS_DETAIL (HSP_TP_CD, MSTR_CD, DETL_CD, DETL_CD_NM, DETL_CD_1, DISP_SEQ, USE_YN, REG_DTM, REG_ID) 
                             values(IN_HSP_TP_CD 
                                  , IN_MSTR_CD 
                                  , IN_ITEM_CD 
                                  , IN_ITEM_NM 
                                  , IN_ITEM_CD 
                                  , (select max(DISP_SEQ) from HICU.RRS_DETAIL where HSP_TP_CD = IN_HSP_TP_CD and MSTR_CD = IN_MSTR_CD) + 1 
                                  , 'Y' 
                                  , V_SYSDATE 
                                  , IN_ENT_STF ); 
                                   
            insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'A' 
                                    , 0 
                                    , IN_ITEM_A_MAX 
                                    , IN_ITEM_A_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP
                                    , IN_ICU_CD ); 
              
             insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'C' 
                                    , 0 
                                    , IN_ITEM_C_MAX 
                                    , IN_ITEM_C_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP
                                    , IN_ICU_CD ); 
                                     
             insert into HICU.RRS_ITEM_STD (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                              values (IN_HSP_TP_CD 
                                    , IN_MSTR_CD 
                                    , IN_ITEM_CD 
                                    , 'P' 
                                    , 0 
                                    , IN_ITEM_P_MAX 
                                    , IN_ITEM_P_MIN 
                                    , 1 
                                    , V_SYSDATE 
                                    , IN_ENT_STF 
                                    , IN_REG_IP
                                    , IN_ICU_CD );                                 
             
            EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Update Error 발생 : PC_NEW_LABCODE_EDIT'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y'; 
         
        end; 
    else 
        begin 
            insert into HICU.RRS_ITEM_STD ( HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD ) 
             select HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP 
                  , (select max(HIST_SEQ) from HICU.RRS_ITEM_STD  
                      where HSP_TP_CD = a.HSP_TP_CD 
                        and MSTR_CD = a.MSTR_CD 
                        and ITEM_CD = a.ITEM_CD 
                        and AGE_GRP = a.AGE_GRP) + 1 
                  , MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD 
               from HICU.RRS_ITEM_STD a 
              where HSP_TP_CD = IN_HSP_TP_CD 
                and MSTR_CD = IN_MSTR_CD     
                and DEPT_CD = IN_ICU_CD
                and ITEM_CD = IN_ITEM_CD 
                and HIST_SEQ = 0; 
                 
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD     
                       and DEPT_CD = IN_ICU_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='A' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_A_MAX 
                            , MIN_VAL = IN_ITEM_A_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP 
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'A', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 1, V_SYSDATE, IN_ENT_STF, IN_REG_IP, IN_ICU_CD) 
             ; 
                   
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD    
                       and DEPT_CD = IN_ICU_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='C' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_C_MAX 
                            , MIN_VAL = IN_ITEM_C_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP  
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'C', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 2, V_SYSDATE, IN_ENT_STF, IN_REG_IP, IN_ICU_CD) 
             ; 
              
            merge into HICU.RRS_ITEM_STD 
                 using dual on (HSP_TP_CD  = IN_HSP_TP_CD 
                       and MSTR_CD = IN_MSTR_CD     
                       and DEPT_CD = IN_ICU_CD 
                       and ITEM_CD = IN_ITEM_CD 
                       and AGE_GRP ='P' 
                       and HIST_SEQ = 0) 
                when matched then 
                   update set MAX_VAL = IN_ITEM_P_MAX 
                            , MIN_VAL = IN_ITEM_P_MIN 
                            , REG_DTM = V_SYSDATE 
                            , REG_ID  = IN_ENT_STF  
                            , REG_IP  = IN_REG_IP 
                when not matched then 
                   insert (HSP_TP_CD, MSTR_CD, ITEM_CD, AGE_GRP, HIST_SEQ, MAX_VAL, MIN_VAL, DISP_SEQ, REG_DTM, REG_ID, REG_IP, DEPT_CD) 
                   values (IN_HSP_TP_CD, IN_MSTR_CD, IN_ITEM_CD, 'P', 0, IN_ITEM_A_MAX, IN_ITEM_A_MIN, 3, V_SYSDATE, IN_ENT_STF, IN_REG_IP, IN_ICU_CD) 
             ; 
              
        EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Update Error 발생 : PC_NEW_LABCODE_EDIT'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y'; 
 
        end;     
    end if; 
          
END PC_NEW_LABCODE_EDIT_ICU; 
 
  
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_SETTING_ITEMS 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_SETTING_ITEMS  ( IN_HSP_TP_CD     IN   VARCHAR2       /* 병동구분코드 */ 
                                    , IN_MSTR_CD       IN   VARCHAR2       /* 고정 / 추가 항목  */ 
                                    , OUT_CURSOR       OUT  RETURNCURSOR )   
IS 
BEGIN 
   OPEN OUT_CURSOR FOR 
     select MSTR_CD,ITEM_NM,ITEM_CD,A_VAL,C_VAL,P_VAL,INDEX_NO 
       from ( 
            select d.MSTR_CD 
                 , d.DETL_CD_NM ITEM_NM   
                 , d.DETL_CD_1 ITEM_CD  
                 , decode(d.detl_cd, 'OXYGEN', 'STOP', 'GCS', 'A', 
                                     case when ita.AGE_GRP = 'A' THEN ita.MIN_VAL || '/' || ita.MAX_VAL END ) A_VAL 
                 , case when itc.AGE_GRP = 'C' THEN itc.MIN_VAL || '/' || itc.MAX_VAL END C_VAL 
                 , case when itp.AGE_GRP = 'P' THEN itp.MIN_VAL || '/' || itp.MAX_VAL END P_VAL 
                 , nvl(d.disp_seq, rownum) AS INDEX_NO 
            from HICU.RRS_DETAIL d 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'A' 
                     and it.HIST_SEQ = 0) ita 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'C' 
                     and it.HIST_SEQ = 0) itc 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'P' 
                     and it.HIST_SEQ = 0) itp    
            where d.HSP_TP_CD = IN_HSP_TP_CD 
            and d.MSTR_CD = IN_MSTR_CD 
            and d.USE_YN = 'Y' 
            and d.DETL_CD_1 = ita.ITEM_CD(+) 
            and d.DETL_CD_1 = itc.ITEM_CD(+) 
            and d.DETL_CD_1 = itp.ITEM_CD(+) 
        union  
            select d.MSTR_CD 
                 , d.DETL_CD_NM ITEM_NM   
                 , d.DETL_CD_2 ITEM_CD  
                 , decode(d.detl_cd, 'OXYGEN', 'STOP', 'GCS', 'A', 
                                     case when ita.AGE_GRP = 'A' THEN ita.MIN_VAL || '/' || ita.MAX_VAL END ) A_VAL 
                 , case when itc.AGE_GRP = 'C' THEN itc.MIN_VAL || '/' || itc.MAX_VAL END C_VAL 
                 , case when itp.AGE_GRP = 'P' THEN itp.MIN_VAL || '/' || itp.MAX_VAL END P_VAL 
                 , nvl(d.disp_seq, rownum) AS INDEX_NO 
            from HICU.RRS_DETAIL d 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'A' 
                     and it.HIST_SEQ = 0) ita 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'C' 
                     and it.HIST_SEQ = 0) itc 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'P' 
                     and it.HIST_SEQ = 0) itp    
            where d.HSP_TP_CD = IN_HSP_TP_CD 
            and d.MSTR_CD = IN_MSTR_CD 
            and d.USE_YN = 'Y' 
            and d.DETL_CD_2 = ita.ITEM_CD(+) 
            and d.DETL_CD_2 = itc.ITEM_CD(+) 
            and d.DETL_CD_2 = itp.ITEM_CD(+) 
         union 
             select d.MSTR_CD 
                 , d.DETL_CD_NM ITEM_NM   
                 , d.DETL_CD_3 ITEM_CD  
                 , decode(d.detl_cd, 'OXYGEN', 'STOP', 'GCS', 'A', 
                                     case when ita.AGE_GRP = 'A' THEN ita.MIN_VAL || '/' || ita.MAX_VAL END ) A_VAL 
                 , case when itc.AGE_GRP = 'C' THEN itc.MIN_VAL || '/' || itc.MAX_VAL END C_VAL 
                 , case when itp.AGE_GRP = 'P' THEN itp.MIN_VAL || '/' || itp.MAX_VAL END P_VAL 
                 , nvl(d.disp_seq, rownum) AS INDEX_NO 
            from HICU.RRS_DETAIL d 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'A' 
                     and it.HIST_SEQ = 0) ita 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'C' 
                     and it.HIST_SEQ = 0) itc 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'P' 
                     and it.HIST_SEQ = 0) itp    
            where d.HSP_TP_CD = IN_HSP_TP_CD 
            and d.MSTR_CD = IN_MSTR_CD 
            and d.USE_YN = 'Y' 
            and d.DETL_CD_3 = ita.ITEM_CD(+) 
            and d.DETL_CD_3 = itc.ITEM_CD(+) 
            and d.DETL_CD_3 = itp.ITEM_CD(+) 
        union 
            select d.MSTR_CD 
                 , d.DETL_CD_NM ITEM_NM   
                 , d.DETL_CD_4 ITEM_CD  
                 , decode(d.detl_cd, 'OXYGEN', 'STOP', 'GCS', 'A', 
                                     case when ita.AGE_GRP = 'A' THEN ita.MIN_VAL || '/' || ita.MAX_VAL END ) A_VAL 
                 , case when itc.AGE_GRP = 'C' THEN itc.MIN_VAL || '/' || itc.MAX_VAL END C_VAL 
                 , case when itp.AGE_GRP = 'P' THEN itp.MIN_VAL || '/' || itp.MAX_VAL END P_VAL 
                 , nvl(d.disp_seq, rownum) AS INDEX_NO 
            from HICU.RRS_DETAIL d 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'A' 
                     and it.HIST_SEQ = 0) ita 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'C' 
                     and it.HIST_SEQ = 0) itc 
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL 
                    from HICU.RRS_ITEM_STD it 
                   where it.HSP_TP_CD = IN_HSP_TP_CD 
                     and it.MSTR_CD = IN_MSTR_CD 
                     and it.AGE_GRP = 'P' 
                     and it.HIST_SEQ = 0) itp    
            where d.HSP_TP_CD = IN_HSP_TP_CD 
            and d.MSTR_CD = IN_MSTR_CD 
            and d.USE_YN = 'Y' 
            and d.DETL_CD_4 = ita.ITEM_CD(+) 
            and d.DETL_CD_4 = itc.ITEM_CD(+) 
            and d.DETL_CD_4 = itp.ITEM_CD(+) 
      ) 
     where ITEM_CD is not null 
     order by INDEX_NO, ITEM_CD 
    ;         
    
END PC_RRS_SEL_SETTING_ITEMS; 

 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_SETTING_ICU_ITEMS 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_SETTING_ICU_ITEMS  ( IN_HSP_TP_CD     IN   VARCHAR2       /* 병동구분코드 */ 
                                        , IN_ICUcd         IN   VARCHAR2       /* 고정 / 추가 항목  */ 
                                        , IN_MSTR_CD       IN   VARCHAR2       /* 고정 / 추가 항목  */ 
                                        , OUT_CURSOR       OUT  RETURNCURSOR )   
IS 
BEGIN 
   OPEN OUT_CURSOR FOR 
     select MSTR_CD,ITEM_NM,ITEM_CD,A_VAL,C_VAL,P_VAL,INDEX_NO, ICU_CD 
       from (   
             select d.MSTR_CD
                 , d.DETL_CD_NM ITEM_NM
                 , d.DETL_CD_1 ITEM_CD
                 , decode(d.detl_cd, 'OXYGEN', 'STOP', 'GCS', 'A',
                                     case when ita.AGE_GRP = 'A' THEN ita.MIN_VAL || '/' || ita.MAX_VAL END ) A_VAL
                 , case when itc.AGE_GRP = 'C' THEN itc.MIN_VAL || '/' || itc.MAX_VAL END C_VAL
                 , case when itp.AGE_GRP = 'P' THEN itp.MIN_VAL || '/' || itp.MAX_VAL END P_VAL
                 , nvl(d.disp_seq, rownum) AS INDEX_NO    
                 , IN_ICUcd AS ICU_CD
            from HICU.RRS_DETAIL d
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL , IT.dept_cd
                    from HICU.RRS_ITEM_STD it
                   where it.HSP_TP_CD = IN_HSP_TP_CD
                     AND it.dept_cd = IN_ICUcd
                     and it.MSTR_CD = IN_MSTR_CD
                     and it.AGE_GRP = 'A'
                     and it.HIST_SEQ = 0) ita
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL
                    from HICU.RRS_ITEM_STD it
                   where it.HSP_TP_CD = IN_HSP_TP_CD
                     AND it.dept_cd = IN_ICUcd
                     and it.MSTR_CD = IN_MSTR_CD
                     and it.AGE_GRP = 'C'
                     and it.HIST_SEQ = 0) itc
               , (select it.ITEM_CD, It.AGE_GRP, it.MAX_VAL, it.MIN_VAL
                    from HICU.RRS_ITEM_STD it
                   where it.HSP_TP_CD = IN_HSP_TP_CD
                     AND it.dept_cd = IN_ICUcd
                     and it.MSTR_CD = IN_MSTR_CD
                     and it.AGE_GRP = 'P'
                     and it.HIST_SEQ = 0) itp
            where d.HSP_TP_CD = IN_HSP_TP_CD
            and d.MSTR_CD = IN_MSTR_CD
            and d.USE_YN = 'Y'
            and d.DETL_CD_1 = ita.ITEM_CD(+)
            and d.DETL_CD_1 = itc.ITEM_CD(+)
            and d.DETL_CD_1 = itp.ITEM_CD(+)
            and d.detl_Cd in ('HR','SBP','SPO2','BT','RR') --20260407 장인수 RRS 세팅값 vital 항목 전체 설정할 수 있도록 주석 처리         
      ) 
     where ITEM_CD is not null 
     order by INDEX_NO, ITEM_CD 
    ;         
    
END PC_RRS_SEL_SETTING_ICU_ITEMS; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_DEL_SETTING_ITEMS 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 등록된 검사 항목 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DEL_SETTING_ITEMS  ( IN_HSP_TP_CD    IN   VARCHAR2       /* 병동구분코드 */ 
                                    , IN_MSTR_CD      IN   VARCHAR2  /* 고정 / 추가 항목  */ 
                                    , IN_ITEM_CD      IN   VARCHAR2  /* 항목 코드 */ 
                                    , IO_ERRYN        OUT  VARCHAR2 )   
IS 
BEGIN    
    IO_ERRYN := 'N'; 
     
   BEGIN        
        delete HICU.RRS_DETAIL  
         where HSP_TP_CD = IN_HSP_TP_CD 
           and MSTR_CD   = IN_MSTR_CD 
           and DETL_CD_1 = IN_ITEM_CD 
           ;            
            
        update HICU.RRS_ITEM_STD set HIST_SEQ = (select max(HIST_SEQ) from HICU.RRS_ITEM_STD 
                                             where HSP_TP_CD = IN_HSP_TP_CD 
                                               and MSTR_CD = IN_MSTR_CD 
                                               and ITEM_CD = IN_ITEM_CD ) + 1 
         where HSP_TP_CD = IN_HSP_TP_CD 
           and MSTR_CD = IN_MSTR_CD 
           and ITEM_CD = IN_ITEM_CD 
           and HIST_SEQ = 0 
           ; 
       
      EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Delete Error 발생 : PC_RRS_DEL_SETTING_ITEMS'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y';      
   END; 
END PC_RRS_DEL_SETTING_ITEMS; 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_UDT_ENV_SETTING 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 환경설정 저장 ( sms전송 및 sound ) 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_UDT_ENV_SETTING  ( IN_HSP_TP_CD    IN   VARCHAR2  /* 병동구분코드 */ 
                                  , IN_WHAT         IN   VARCHAR2  /* 저장할 값 구분  */ 
                                  , IN_VALUE        IN   VARCHAR2  /* 설정 값 Trud, False */ 
                                  , IN_USER_ID      IN   VARCHAR2  /* 로그인 사용자 */ 
                                  , IO_ERRYN        OUT  VARCHAR2 
                                    )   
IS 
BEGIN 
    IO_ERRYN := 'N'; 
     
    BEGIN 
        update HICU.RRS_DETAIL  
           set DETL_CD = decode(IN_VALUE, 'True', 'Y', 'N') 
             , REG_DTM = sysdate 
             , REG_ID  = IN_USER_ID 
         where HSP_TP_CD = IN_HSP_TP_CD 
           and MSTR_CD   = IN_WHAT 
           ; 
     
    EXCEPTION  
         WHEN OTHERS THEN 
            RAISE_APPLICATION_ERROR(-20501,'Delete Error 발생 : PC_RRS_DEL_SETTING_ITEMS'  || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm); 
            IO_ERRYN := 'Y : ' || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm;      
   END; 
 
END PC_RRS_UDT_ENV_SETTING; 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHANGE_STATE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 환자 상태 변경 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHANGE_STATE  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                               , IN_HSP_TP_CD     IN   VARCHAR2  /* 병원구분코드 */ 
                               , IN_RRS_STATE_CD  IN   VARCHAR2 
                               , IN_PACT_ID       IN   VARCHAR2 
                               , IN_REG_ID        IN   VARCHAR2 
                               , IN_REG_IP        IN   VARCHAR2 
                         )   
IS 
   V_NEWS NUMBER := 0; 
    V_SYSDATE DATE := sysdate; 
BEGIN 
    update HICU.RRS_VALUE a 
       set RRS_STATE_CD = IN_RRS_STATE_CD 
         , CFRM_DTM = V_SYSDATE 
         , CFRM_ID  = IN_REG_ID 
     where PT_NO  = IN_PT_NO 
       and ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
       and HSP_TP_CD = IN_HSP_TP_CD 
       and PACT_ID = IN_PACT_ID 
       ; 
 
 
    merge into HICU.RRS_STATE s 
    using DUAL t 
       on (s.PT_NO = IN_PT_NO and s.PACT_ID = IN_PACT_ID and s.HSP_TP_CD = IN_HSP_TP_CD ) 
    when MATCHED then 
        update set s.HIST_SEQ = (select max(HIST_SEQ) + 1 from HICU.RRS_STATE  
                                 where PT_NO = IN_PT_NO and PACT_ID = IN_PACT_ID and HSP_TP_CD = IN_HSP_TP_CD ) 
         where s.HIST_SEQ = 0 
    ; 
     
    insert into HICU.RRS_STATE (PT_NO, PACT_ID, HSP_TP_CD, HIST_SEQ, RRS_STATE_CD, REG_DT, REG_DTM, REG_ID, REG_IP ) 
                   values (IN_PT_NO,IN_PACT_ID, IN_HSP_TP_CD, 0, IN_RRS_STATE_CD, to_char(V_SYSDATE, 'yyyymmdd'), V_SYSDATE, IN_REG_ID, IN_REG_IP) 
    ; 
 
   EXCEPTION  
      WHEN OTHERS THEN 
         ROLLBACK; 
         RAISE_APPLICATION_ERROR(-20501,'update Error 발생 : PC_RRS_CHANGE_STATE ' || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm ); 
END PC_RRS_CHANGE_STATE; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CHANGE_STATE_2 
* 최초 작성일     : 2026.04.04
* 최초 작성자     : 장인수 
* DESCRIPTION    : 지역의료원 환자 상태 변경 지역의료원에서 사용하는 프로시저 본사 개발 테스트를 위해 생성  
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CHANGE_STATE_2  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                               , IN_HSP_TP_CD     IN   VARCHAR2  /* 병원구분코드 */ 
                               , IN_RRS_STATE_CD  IN   VARCHAR2 
                               , IN_PACT_ID       IN   VARCHAR2 
                               , IN_ITEM_CD       IN   VARCHAR2 
                               , IN_ENT_DTM       IN   VARCHAR2  
                               , IN_REG_ID        IN   VARCHAR2 
                               , IN_REG_IP        IN   VARCHAR2 
                         )   
IS 
   V_NEWS NUMBER := 0; 
    V_SYSDATE DATE := sysdate; 
BEGIN 
    update HICU.RRS_VALUE a 
       set RRS_STATE_CD = IN_RRS_STATE_CD 
         , CFRM_DTM = V_SYSDATE 
         , CFRM_ID  = IN_REG_ID 
     where PT_NO  = IN_PT_NO 
       and ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
       and HSP_TP_CD = IN_HSP_TP_CD 
       and PACT_ID = IN_PACT_ID 
       ; 
 
 
    merge into HICU.RRS_STATE s 
    using DUAL t 
       on (s.PT_NO = IN_PT_NO and s.PACT_ID = IN_PACT_ID and s.HSP_TP_CD = IN_HSP_TP_CD ) 
    when MATCHED then 
        update set s.HIST_SEQ = (select max(HIST_SEQ) + 1 from HICU.RRS_STATE  
                                 where PT_NO = IN_PT_NO and PACT_ID = IN_PACT_ID and HSP_TP_CD = IN_HSP_TP_CD ) 
         where s.HIST_SEQ = 0 
    ; 
     
    insert into HICU.RRS_STATE (PT_NO, PACT_ID, HSP_TP_CD, HIST_SEQ, RRS_STATE_CD, REG_DT, REG_DTM, REG_ID, REG_IP ) 
                   values (IN_PT_NO,IN_PACT_ID, IN_HSP_TP_CD, 0, IN_RRS_STATE_CD, to_char(V_SYSDATE, 'yyyymmdd'), V_SYSDATE, IN_REG_ID, IN_REG_IP) 
    ; 
 
   EXCEPTION  
      WHEN OTHERS THEN 
         ROLLBACK; 
         RAISE_APPLICATION_ERROR(-20501,'update Error 발생 : PC_RRS_CHANGE_STATE ' || chr(10) || 'code=' || sqlcode || ' : ' || sqlerrm ); 
END PC_RRS_CHANGE_STATE_2; 
 




/*=================================================================================== 
* 서비스이름      : PC_RRS_LIST_COUNT 
* 최초 작성일     : 2019.03.19 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 리스트 건수 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LIST_COUNT  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */
																													, IN_SEARCH_CHECK_TM    IN   VARCHAR2  /* 20260407 장인수 지역병원에서 IN 파라미터로 받고 있어서 권역에서도 받기만 하도록 변경 */    
                             , OUT_CURSOR            OUT  RETURNCURSOR )   
IS 
BEGIN 
    OPEN OUT_CURSOR FOR 
    select sum(TOT_CNT) TOT_CNT 
         , sum(NEWS7_CNT) NEWS7_CNT 
         , sum(I_CNT) I_CNT 
         , sum(P_CNT) P_CNT 
         , sum(M_CNT) M_CNT 
         , sum(R_CNT) R_CNT 
         , sum(X_CNT) X_CNT 
    from ( 
        select ( select sum(PT_NO) CNT 
                   from ( select 1 PT_NO 
                            from HICU.RRS_VALUE 
                           WHERE ENT_DT = to_char(sysdate, 'yyyymmdd') 
                             AND HSP_TP_CD = IN_HSP_TP_CD 
                           GROUP BY PT_NO 
                ) 
                ) TOT_CNT 
             , ( select sum(PT_NO) CNT 
                   from ( select 1 PT_NO 
                            from HICU.RRS_VALUE 
                           WHERE ENT_DT = to_char(sysdate, 'yyyymmdd') 
                             AND HSP_TP_CD = IN_HSP_TP_CD 
                )) NEWS7_CNT 
              , 0 I_CNT 
              , 0 P_CNT 
              , 0 M_CNT 
              , 0 R_CNT 
              , 0 X_CNT 
          from DUAL 
         union ALL 
        select 0 
             , 0 
             , sum(I_CNT) I_CNT 
             , sum(P_CNT) P_CNT 
             , sum(M_CNT) M_CNT 
             , sum(R_CNT) R_CNT 
             , sum(X_CNT) X_CNT 
        from ( 
            select case when RRS_STATE_CD = 'I' THEN 1 else 0 end I_CNT 
                 , case when RRS_STATE_CD = 'P' THEN 1 else 0 end P_CNT 
                 , case when RRS_STATE_CD = 'M' THEN 1 else 0 end M_CNT 
                 , case when RRS_STATE_CD = 'R' THEN 1 else 0 end R_CNT 
                 , case when RRS_STATE_CD = 'X' THEN 1 else 0 end X_CNT 
              from HICU.RRS_VALUE r 
             where r.ENT_DT = to_char(sysdate, 'yyyymmdd') 
               and r.HSP_TP_CD = IN_HSP_TP_CD 
--               and (r.PT_NO, r.ENT_DT, r.RRS_ITEM_CD, r.HSP_TP_CD) in ( 
--                    select PT_NO,ENT_DT,RRS_ITEM_CD,HSP_TP_CD 
--                      from HICU.RRS_VALUE_H 
--                     where PT_NO = r.PT_NO 
--                       and ENT_DT = r.ENT_DT 
--                       and RRS_ITEM_CD = r.RRS_ITEM_CD 
--                       and HSP_TP_CD = r.HSP_TP_CD 
--                       and (ITEM_NEWS_SCORE >= '03' or NEWS_SCORE >= LPAD((SELECT DETL_CD  
--                                                                         FROM HICU.RRS_dETAIL 
--                                                                        WHERE HSP_TP_CD = IN_HSP_TP_CD 
--                                                                          AND MSTR_CD   = 'SCREENING' 
--                                                                          AND USE_YN    = 'Y'), 2, '0'))  
--                       ) 
             group by r.PT_NO, r.RRS_STATE_CD 
         ) 
     ); 
END PC_RRS_LIST_COUNT; 
             
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_LIST  
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 리스트 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                       , IN_RRS_STATE_CD       IN   VARCHAR2  /* 상태  */  
                       , IN_WARD_INFO          IN   VARCHAR2  /* 병동  */  
                       , IN_PT_NO              IN   VARCHAR2  /* 환자번호  */  
                       , OUT_CURSOR            OUT  RETURNCURSOR )   
IS 
BEGIN 
    --PKG_NEORRS.PC_RRSDATA_INS(IN_HSP_TP_CD); 
 
 
   IF IN_RRS_STATE_CD = 'P' or IN_RRS_STATE_CD = 'M' or IN_RRS_STATE_CD = 'R' or IN_RRS_STATE_CD = 'X' THEN 
      OPEN OUT_CURSOR FOR 
          select distinct r.HSP_TP_CD 
             , r.PT_NO 
             , r.ENT_DT 
             , '-' RRS_ITEM_CD --  r.RRS_ITEM_CD      
             , '-' RRS_ITEM    --  i.DETL_CD_NM RRS_ITEM 
             , r.PACT_ID 
             , r.PT_NM 
             , r.PT_SEX
             , (SELECT TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') 
                  FROM PCTPCPAM_DAMO
                  WHERE PT_NO =r.PT_NO) AS PT_BIRTH     -- 20251103 장인수 협진등록을 위해 생년월일 정보 추가  //―2025/ez고도화로 인한 작업―JIS
             , r.PT_AGE 
             , nvl(r.HD, 0) HD 
             , nvl(r.POD, 0) POD 
             , r.DEPT_CD 
             , r.DEPT_NM 
             , r.DOC_NO 
             , r.DOC_NM 
             , r.DIAGNOSIS 
             , r.WARD_NO || '/' || r.BED_NO PT_LOC 
             --, r.WARD_NO || '/' || r.ROOM_NO || '/' || r.BED_NO PT_LOC 
             --, a.WD_DEPT_CD || '/' || a.PRM_NO || '/' || a.BED_NO PT_LOC 
             , XICU.FT_RRT_CALC_TIME(r.CFRM_DTM) CFRM_DTM 
             , r.CFRM_DTM REAL_CFRM_DTM 
             , r.CFRM_ID 
             , u.USR_NM CFRM_NM 
             , '-' RRS_VALUE   -- r.RRS_VALUE 
             , '-' CUR_VALUE   -- r.CUR_VALUE 
             , '-'  ENT_DTM  --  XICU.FT_RRT_CALC_TIME(r.ENT_DTM) ENT_DTM 
--             , '-' REAL_ENT_DTM  --  r.ENT_DTM REAL_ENT_DTM 
             , CAST(NULL AS DATE) AS REAL_ENT_DTM   --//―2026/ez고도화로 인한 작업―YJR
             , r.RRS_STATE_CD 
             , d.DETL_CD_NM RRS_STATE 
             , lpad(r.NEWS, 2, '0') NEWS   --//―2025/ez고도화로 인한 작업―YJR 
             , lpad(r.NEWS_SCORE, 2, '0') NEWS_SCORE 
             , '-' ITEM_NEWS_SCORE  --  r.ITEM_NEWS_SCORE 
             , (select RRS_STATE_CD from HICU.RRS_STATE  
                 where PT_NO = r.PT_NO 
                   and PACT_ID = r.PACT_ID 
                   and HSP_TP_CD = r.HSP_TP_CD 
                   and HIST_SEQ = 0 )  BF_RRS_STATE_CD 
             , r.REG_ID 
             , decode(( select count(*) 
                          from HICU.RRS_MEMO 
                         where PT_NO = r.PT_NO 
                           and HSP_TP_CD = r.HSP_TP_CD 
                          ), 0, '', 'Y') MEMO_YN 
              , (select max(NEWS_SCORE) 
                  from HICU.RRS_VALUE_H 
                  where PT_NO = r.PT_NO 
                   and ENT_DT = r.ENT_DT 
                   and HSP_TP_CD = r.HSP_TP_CD  
                     )            MAX_NEWS_SCORE --//―2025/ez고도화로 인한 작업―YJR    MAX_NEWS -> MAX_NEWS_SCORE
              , (select max(NEWS) --//―2025/ez고도화로 인한 작업―YJR
                  from HICU.RRS_VALUE_H 
                  where PT_NO = r.PT_NO 
                   and ENT_DT = r.ENT_DT 
                   and HSP_TP_CD = r.HSP_TP_CD  
                     )            MAX_NEWS 
--              , XMED.FT_MOO_GET_USERNM(a.NCDR_STF_NO, a.hsp_tp_cd) DOC_NM_1 
              , r.DNR_YN DNR_YN   --, '' DNR -- XMED.PKG_MOO_RRS_INFO.FT_SEL_DNR_CSFM_YN(r.HSP_TP_CD, r.PACT_ID) DNR   //―2025/ez고도화로 인한 작업―YJR 
              , '' INFECT -- XMED.PKG_MOO_RRS_INFO.FT_SEL_INFC_YN(r.HSP_TP_CD, r.PACT_ID) INFECT   
              , '' EQIP_KIND_CD     
              , '' LH_VALUE    
              , '' SEARCH_CHECK_TM
           from HICU.RRS_VALUE r 
              , HICU.RRS_USER u 
              , HICU.RRS_DETAIL d 
              , HICU.RRS_DETAIL i 
--              , ACPPRAAM a 
          where r.ENT_DT = TO_CHAR(SYSDATE, 'YYYYMMDD') 
            and r.RRS_STATE_CD = decode(IN_RRS_STATE_CD, 'A', r.RRS_STATE_CD, IN_RRS_STATE_CD) 
            and r.HSP_TP_CD = IN_HSP_TP_CD 
            and r.WARD_NO = decode(nvl(IN_WARD_INFO, '*'), '*', r.WARD_NO, IN_WARD_INFO) 
            and r.PT_NO = decode(nvl(IN_PT_NO, '*'), '*', r.PT_NO, IN_PT_NO) 
             
            and r.ENT_DTM >= ( select max(ENT_DTM) - 1/24/60*180  --  1/24/60*20  
                                 from HICU.RRS_VALUE av 
                                where av.HSP_TP_CD = r.HSP_TP_CD 
                                  and av.PT_NO     = r.PT_NO 
                                  and av.ENT_DT = r.ENT_DT  ) 
             
            and u.HSP_TP_CD(+) = r.HSP_TP_CD 
            and r.CFRM_ID = u.USR_ID(+) 
            and u.HIST_SEQ(+) = 0 
 
            and d.HSP_TP_CD = r.HSP_TP_CD 
            and d.MSTR_CD = 'STAT_CD' 
            and r.RRS_STATE_CD = d.DETL_CD 
 
            and i.HSP_TP_CD = r.HSP_TP_CD 
            and i.MSTR_CD IN ('VITAL','VITAL_ADD', 'LAB', 'LAB_ADD', 'DIRECT') 
            and i.USE_YN = 'Y' 
            and ( r.RRS_ITEM_CD = i.DETL_CD_1 or r.RRS_ITEM_CD = i.DETL_CD_2 or r.RRS_ITEM_CD = i.DETL_CD_3 or r.RRS_ITEM_CD = i.DETL_CD_4 ) 
             
--            and r.PACT_ID = a.PACT_ID 
        order by PT_NM 
        ;          
    
   ELSIF IN_RRS_STATE_CD = 'A' or IN_RRS_STATE_CD = 'I' then 
      OPEN OUT_CURSOR FOR 
        select r.HSP_TP_CD 
             , r.PT_NO 
             , r.ENT_DT 
             , r.RRS_ITEM_CD      
             , i.DETL_CD_NM RRS_ITEM 
             , r.PACT_ID 
             , r.PT_NM 
             , r.PT_SEX 
             , (SELECT TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')   -- 20251103 장인수 협진등록을 위해 생년월일 정보 추가   //―2025/ez고도화로 인한 작업―JIS 
                  FROM PCTPCPAM_DAMO
                  WHERE PT_NO =r.PT_NO) AS PT_BIRTH
             , r.PT_AGE 
             , nvl(r.HD, 0) HD 
             , nvl(r.POD, 0) POD 
             , r.DEPT_CD 
             , r.DEPT_NM 
             , r.DOC_NO 
             , r.DOC_NM 
             , r.DIAGNOSIS      
             , r.WARD_NO || '/' || r.BED_NO PT_LOC 
             --, r.WARD_NO || '/' || r.ROOM_NO || '/' || r.BED_NO PT_LOC 
--             , a.WD_DEPT_CD || '/' || a.PRM_NO || '/' || a.BED_NO PT_LOC 
             , XICU.FT_RRT_CALC_TIME(r.CFRM_DTM) CFRM_DTM 
             , r.CFRM_DTM REAL_CFRM_DTM 
             , r.CFRM_ID 
             , u.USR_NM CFRM_NM 
             , r.RRS_VALUE 
             , r.CUR_VALUE 
             , XICU.FT_RRT_CALC_TIME(r.ENT_DTM) ENT_DTM 
             , r.ENT_DTM REAL_ENT_DTM 
             , r.RRS_STATE_CD 
             , d.DETL_CD_NM RRS_STATE 
             , lpad(r.NEWS, 2, '0') NEWS --//―2025/ez고도화로 인한 작업―YJR
             , lpad(r.NEWS_SCORE, 2, '0') NEWS_SCORE 
             , r.ITEM_NEWS_SCORE 
             , (select RRS_STATE_CD from HICU.RRS_STATE  
                 where PT_NO = r.PT_NO 
                   and PACT_ID = r.PACT_ID 
                   and HSP_TP_CD = r.HSP_TP_CD 
                   and HIST_SEQ = 0 )  BF_RRS_STATE_CD 
             , r.REG_ID 
             , decode(( select count(*) 
                          from HICU.RRS_MEMO 
                         where PT_NO = r.PT_NO 
                           and HSP_TP_CD = r.HSP_TP_CD 
                          ), 0, '', 'Y') MEMO_YN
             , (select max(NEWS_SCORE)
                  from HICU.RRS_VALUE_H 
                  where PT_NO = r.PT_NO 
                   and ENT_DT = r.ENT_DT 
                   and HSP_TP_CD = r.HSP_TP_CD  
                     )            MAX_NEWS_SCORE  --//―2025/ez고도화로 인한 작업―YJR  MAX_NEWS -> MAX_NEWS_SCORE
             , (select max(NEWS)   --//―2025/ez고도화로 인한 작업―YJR 
                  from HICU.RRS_VALUE_H 
                  where PT_NO = r.PT_NO 
                   and ENT_DT = r.ENT_DT 
                   and HSP_TP_CD = r.HSP_TP_CD  
                     )            MAX_NEWS 
--              , XMED.FT_MOO_GET_USERNM(a.NCDR_STF_NO, a.hsp_tp_cd) DOC_NM_1 
              , r.DNR_YN DNR_YN   --, '' DNR -- XMED.PKG_MOO_RRS_INFO.FT_SEL_DNR_CSFM_YN(r.HSP_TP_CD, r.PACT_ID) DNR   //―2025/ez고도화로 인한 작업―YJR 
              , '' INFECT -- XMED.PKG_MOO_RRS_INFO.FT_SEL_INFC_YN(r.HSP_TP_CD, r.PACT_ID) INFECT 
              , EQIP_KIND_CD    
              , case when to_number(nvl(cd.MAX_VAL, '9999')) < to_number(NVL(r.CUR_VALUE, r.RRS_VALUE))   then 'H'
                     when to_number(nvl(cd.MIN_VAL, '-9999')) > to_number( NVL(r.CUR_VALUE, r.RRS_VALUE)) then 'L'
                     else 'N' end LH_VALUE
              , to_char(r.ENT_DTM, 'yyyymmddhh24mi') SEARCH_CHECK_TM
           from HICU.RRS_VALUE r 
              , HICU.RRS_USER u 
              , HICU.RRS_DETAIL d 
              , HICU.RRS_DETAIL i
              , (select MAX_VAL, MIN_VAL, DEPT_CD, ITEM_CD
                   from HICU.RRS_ITEM_STD
                  where mstr_Cd = 'VITAL'
                  and HSP_TP_CD = '08' --권역병원 20251219 and HSP_TP_CD = '08'
                    and AGE_GRP = 'A'
                    and HIST_SEQ = 0) cd
          where r.ENT_DT = TO_CHAR(SYSDATE, 'YYYYMMDD') 
            and r.RRS_STATE_CD = decode(IN_RRS_STATE_CD, 'A', r.RRS_STATE_CD, IN_RRS_STATE_CD) 
            and r.HSP_TP_CD = IN_HSP_TP_CD 
            and r.WARD_NO = decode(nvl(IN_WARD_INFO, '*'), '*', r.WARD_NO, IN_WARD_INFO) 
            and r.PT_NO = decode(nvl(IN_PT_NO, '*'), '*', r.PT_NO, IN_PT_NO) 
            and r.RRS_STATE_CD <> 'X' 
 
            and u.HSP_TP_CD(+) = r.HSP_TP_CD 
            and r.CFRM_ID = u.USR_ID(+) 
            and u.HIST_SEQ(+) = 0 
 
            and d.HSP_TP_CD = r.HSP_TP_CD 
            and d.MSTR_CD = 'STAT_CD' 
            and r.RRS_STATE_CD = d.DETL_CD 
 
            and i.HSP_TP_CD = r.HSP_TP_CD 
            and i.MSTR_CD IN ('VITAL','VITAL_ADD', 'LAB', 'LAB_ADD', 'DIRECT') 
            and i.USE_YN = 'Y' 
            and ( r.RRS_ITEM_CD = i.DETL_CD_1 or r.RRS_ITEM_CD = i.DETL_CD_2 or r.RRS_ITEM_CD = i.DETL_CD_3 or r.RRS_ITEM_CD = i.DETL_CD_4 ) 
             
            and r.WARD_NO = cd.DEPT_CD
            and r.RRS_ITEM_CD = cd.ITEM_CD
              
            order by r.ENT_DTM desc 
            ; 
        
   END IF; 
END PC_RRS_LIST; 
 
/*===================================================================================
* 서비스이름      : PC_RRS_PAT_EACH_LIST
* 최초 작성일     : 2019.03.08
* 최초 작성자     : 하만석
* DESCRIPTION    : 환자별 RRS 리스트 조회
* 변경이력관리    : 2026-01-08, [ARPA-H프로젝트] eICU 화면 고도화 지원 부탁드립니다. (SR:202503-00980)
                  2026-03-10, 원격중환자실 e-ICU프로그램 RRS화면 수정 요청드립니다.(SR:202603-00119)
                  2026-04-02 원격중환자실 e-ICU프로그램 RRS화면 수정 요청드립니다.(SR:202603-00119) 
===================================================================================*/
PROCEDURE PC_RRS_PAT_EACH_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */
                                , IN_PT_NO              IN   VARCHAR2  /* 환자번호  */
                                , OUT_CURSOR            OUT  RETURNCURSOR )  
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT A.PT_NO
         , IT.MSTR_CD
         , IT.DETL_CD
         , IT.DETL_CD_1 RRS_ITEM_CD
--         , TO_CHAR(A.ENT_DTM, 'MM-DD HH24:MI') ENT_DTM
         , TO_CHAR(CASE WHEN IT.DETL_CD_1= 'L1' THEN XSUP.FT_MSE_GET_SPC_RECENT_BRFG_DTM(A.HSP_TP_CD, A.PT_NO, 'TCO2')
                        WHEN IT.DETL_CD_1= 'L2' THEN XSUP.FT_MSE_GET_SPC_RECENT_BRFG_DTM(A.HSP_TP_CD, A.PT_NO, 'PH')
                        WHEN IT.DETL_CD_1= 'L3' THEN XSUP.FT_MSE_GET_SPC_RECENT_BRFG_DTM(A.HSP_TP_CD, A.PT_NO, 'PAO2')
                        WHEN IT.DETL_CD_1= 'L4' THEN XSUP.FT_MSE_GET_SPC_RECENT_BRFG_DTM(A.HSP_TP_CD, A.PT_NO, 'PCO2')
                        WHEN IT.DETL_CD_1= 'L6' THEN XSUP.FT_MSE_GET_SPC_RECENT_BRFG_DTM(A.HSP_TP_CD, A.PT_NO, 'LACTATE') --2026-04-22 김종범 (SR : 202603-00119) 각 검사 실제 보고시간 추가.
                    END, 'MM-DD HH24:MI') ENT_DTM
         , CASE WHEN IT.DETL_CD_1= '30250' THEN A.EQIP_KIND_CD
                WHEN IT.DETL_CD_1= 'L1' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'TCO2')
                WHEN IT.DETL_CD_1= 'L2' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'PH')
                WHEN IT.DETL_CD_1= 'L3' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'PAO2')
                WHEN IT.DETL_CD_1= 'L4' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'PCO2')
--                WHEN IT.DETL_CD_1= 'L5' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'HCO3')
                WHEN IT.DETL_CD_1= 'L6' THEN XSUP.FT_MSE_GET_SPC_RECENT_RESULT(A.HSP_TP_CD, A.PT_NO, 'LACTATE') --2026-04-02 김종범 (SR : 202603-00119) HCO3 삭제, LACTATE 추가.
                END RRS_VALUE
         , A.RRS_STATE_CD
         , S.DETL_CD_NM      RRS_STATE
         , A.NEWS --//―2025/EZ고도화로 인한 작업―YJR
         , A.NEWS_SCORE
         , '' ITEM_NEWS_SCORE
         , A.REG_ID
         , U.USR_NM || ' (' || A.CFRM_ID || ')' CFRM_NM
      FROM HICU.RRS_VALUE A
         , HICU.RRS_DETAIL S
         , (SELECT MSTR_CD, DETL_CD, DETL_CD_1 FROM HICU.RRS_DETAIL
             WHERE HSP_TP_CD = IN_HSP_TP_CD
              AND MSTR_CD = 'LAB'
              AND USE_YN = 'Y' ) IT
         , HICU.RRS_USER U
     WHERE A.HSP_TP_CD = IN_HSP_TP_CD
       AND A.PT_NO     = IN_PT_NO
       AND A.ENT_DT    = TO_CHAR(SYSDATE, 'YYYYMMDD')
       AND A.RRS_STATE_CD <> 'R'
       AND A.RRS_STATE_CD <> 'X'
       AND A.RRS_ITEM_CD <> 'UI'
       AND A.HSP_TP_CD = S.HSP_TP_CD
       AND S.MSTR_CD = 'STAT_CD'
       AND S.DETL_CD = A.RRS_STATE_CD
       AND A.HSP_TP_CD = U.HSP_TP_CD(+)
       AND U.USR_ID(+) = A.CFRM_ID
       AND U.HIST_SEQ(+) = 0
     UNION
    SELECT PT_NO
         , MSTR_CD
         , DETL_CD
         , RRS_ITEM_CD
         , ENT_DTM
         , RRS_VALUE
         , RRS_STATE_CD
         , RRS_STATE
         , NEWS
         , NEWS_SCORE
         , FN_ITEM_NEWS_SCORE(IN_HSP_TP_CD, UPPER(DETL_CD), RRS_VALUE) ITEM_NEWS_SCORE
         , REG_ID
         , CFRM_NM
     FROM (
            SELECT PT_NO
                 , MSTR_CD
                 , DETL_CD
                 , RRS_ITEM_CD
                 , CASE WHEN DETL_NM = 'OXYGEN' THEN
                        CASE WHEN VENTMODE IS NOT NULL OR VENTFIO2 IS NOT NULL THEN
                                  TO_CHAR(TO_DATE(NVL(SUBSTR(VENTMODE, INSTR(VENTMODE, '@', 1, 2 ) + 1, LENGTH(VENTMODE) - INSTR(VENTMODE, '@', 1, 2)), SUBSTR(VENTFIO2, INSTR(VENTFIO2, '@', 1, 2 ) + 1, LENGTH(VENTFIO2) - INSTR(VENTFIO2, '@', 1, 2))), 'YYYY-MM-DD HH24:MI'), 'MM-DD HH24:MI')
                             WHEN DETL_VALUE IS NOT NULL OR FLOWRATE IS NOT NULL OR METHOD IS NOT NULL THEN
                                  TO_CHAR(TO_DATE(NVL(SUBSTR(DETL_VALUE, INSTR(DETL_VALUE, '@', 1, 2 ) + 1, LENGTH(DETL_VALUE) - INSTR(DETL_VALUE, '@', 1, 2)), SUBSTR(METHOD, INSTR(METHOD, '@', 1, 2 ) + 1, LENGTH(METHOD) - INSTR(METHOD, '@', 1, 2))), 'YYYY-MM-DD HH24:MI'), 'MM-DD HH24:MI')
                        END
                   ELSE TO_CHAR(TO_DATE(SUBSTR(DETL_VALUE, INSTR(DETL_VALUE, '@', 1, 2 ) + 1, LENGTH(DETL_VALUE) - INSTR(DETL_VALUE, '@', 1, 2)), 'YYYY-MM-DD HH24:MI'), 'MM-DD HH24:MI')
                   END AS ENT_DTM
                 , CASE WHEN DETL_CD = 'OXYGEN' THEN
                        CASE WHEN VENTMODE IS NOT NULL OR VENTFIO2 IS NOT NULL THEN 'Y'
                             WHEN DETL_VALUE IS NOT NULL OR METHOD IS NOT NULL THEN 'Y'
                             ELSE NULL
                        END
                   ELSE
                        CASE WHEN DETL_CD = 'LOC' AND DETL_VALUE IS NOT NULL THEN SUBSTR(DETL_VALUE, 1, 1)
                             WHEN DETL_CD = 'LOC' AND DETL_VALUE IS NULL THEN  '-'
                             ELSE SUBSTR(DETL_VALUE, 1, INSTR(DETL_VALUE, '@', 1, 1) - 1)
                        END
                   END AS RRS_VALUE
                 , RRS_STATE_CD
                 , RRS_STATE
                 , NEWS --//―2025/EZ고도화로 인한 작업―YJR
                 , NEWS_SCORE
                 , REG_ID
                 , CFRM_NM
             FROM (
                    SELECT A.PT_NO
                         , IT.MSTR_CD
                         , IT.DETL_CD
                         , IT.DETL_CD_NM        AS DETL_NM
                         , IT.DETL_CD_1         AS RRS_ITEM_CD
--                         , IT.DETL_CD           AS ITEM_NAME
                         , TO_CHAR(A.ENT_DTM, 'MM-DD HH24:MI') ENT_DTM
                         , CASE WHEN IT.DETL_CD = 'LOC' THEN XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('AVPU', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)
                                WHEN IT.DETL_CD = 'OXYGEN'THEN XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('FIO2', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)
                                ELSE XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL(IT.DETL_CD, 'ACPT_L_DATE', 'N', A.PT_NO, '08', A.PACT_ID, 'I', NULL, NULL)
                           END AS DETL_VALUE
                         , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('VENT-MODE', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)      AS VENTMODE
                         , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('VENT-FIO2', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)      AS VENTFIO2
                         , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('METHOD', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)         AS METHOD
                         , XMED.PKG_MRN_NURSENSCREEN.FT_MRN_CLCORECITEMVAL('FLOWRATE', 'PRD_L_DATE', 'N', A.PT_NO, '08', NULL, NULL, A.ENT_DTM - 3, A.ENT_DTM)       AS FLOWRATE
                         , A.RRS_STATE_CD
                         , S.DETL_CD_NM  RRS_STATE
                         , A.NEWS
                         , A.NEWS_SCORE
                         , A.REG_ID
                         , U.USR_NM || ' (' || A.CFRM_ID || ')' CFRM_NM
                      FROM HICU.RRS_VALUE A
                         , HICU.RRS_DETAIL S
                         , (SELECT MSTR_CD, DETL_CD, DETL_CD_1, DETL_CD_NM FROM HICU.RRS_DETAIL
                             WHERE HSP_TP_CD = IN_HSP_TP_CD
                              AND MSTR_CD = 'VITAL'
                              AND USE_YN = 'Y' ) IT
                         , HICU.RRS_USER U
                     WHERE A.HSP_TP_CD = IN_HSP_TP_CD
                       AND A.PT_NO     = IN_PT_NO
                       AND A.ENT_DT    = TO_CHAR(SYSDATE, 'YYYYMMDD')
                       AND A.RRS_STATE_CD <> 'R'
                       AND A.RRS_STATE_CD <> 'X'
                       AND A.RRS_ITEM_CD <> 'UI'
                       AND A.HSP_TP_CD = S.HSP_TP_CD
                       AND S.MSTR_CD = 'STAT_CD'
                       AND S.DETL_CD = A.RRS_STATE_CD
                       AND A.HSP_TP_CD = U.HSP_TP_CD(+)
                       AND U.USR_ID(+) = A.CFRM_ID
                       AND U.HIST_SEQ(+) = 0
                    )          
          )  

;
END PC_RRS_PAT_EACH_LIST; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_FIXED_ITEM_LIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 고정항목 리스트 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_FIXED_ITEM_LIST  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                  , OUT_CURSOR            OUT  RETURNCURSOR )   
IS 
BEGIN 
    OPEN OUT_CURSOR FOR 
    select MSTR_CD, DETL_CD, DETL_CD_NM, DETL_CD_1, DETL_CD_2, DETL_CD_3, DETL_CD_4, DISP_SEQ 
      from HICU.RRS_DETAIL 
     where HSP_TP_CD = IN_HSP_TP_CD 
       and MSTR_CD in('VITAL', 'LAB') 
       and USE_YN = 'Y' 
       and DETL_CD <> 'UI' 
     order by MSTR_CD, DISP_SEQ 
        ;    
END PC_RRS_FIXED_ITEM_LIST; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_RRS_TEST_HIST 
* 최초 작성일     : 2019.03.08 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 환자별 RRS 검사 이력 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_RRS_TEST_HIST  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
                                 , IN_PT_NO             IN   VARCHAR2          /* 환자번호 */ 
                                 , IN_TEST_GUBN         IN   VARCHAR2          /* 임상관찰:V,  LAB검사:L  */                                  
                                 , OUT_CURSOR          OUT  sys_refcursor  
                                 )   
IS     
    V_SQL_STMT VARCHAR2(30000); 
BEGIN 
   V_SQL_STMT := 'SELECT to_char(m.ENT_DTM, ''mm-dd hh24:mi:ss'') AS "등록일시" '; 
                             
   for X in ( 
        select '1', DETL_CD_1 as ITEM_CD, DETL_CD_NM as ITEM_NM, DISP_SEQ 
          from HICU.RRS_DETAIL 
         where MSTR_CD  = decode(IN_TEST_GUBN, 'V', 'VITAL', 'L', 'LAB') 
           and HSP_TP_CD = IN_HSP_TP_CD  
           and DETL_CD_1 <> 'UI' 
           and USE_YN = 'Y' 
         union all 
        select '2', DETL_CD_2 as ITEM_CD, DETL_CD_NM as ITEM_NM, DISP_SEQ 
          from HICU.RRS_DETAIL 
         where MSTR_CD  = decode(IN_TEST_GUBN, 'V', 'VITAL', 'L', 'LAB') 
           and HSP_TP_CD = IN_HSP_TP_CD  
           and DETL_CD_1 <> 'UI' 
           AND length(trim(DETL_CD_2)) > 0  
           and USE_YN = 'Y' 
         union all 
        select '3', DETL_CD_3 as ITEM_CD, DETL_CD_NM as ITEM_NM, DISP_SEQ 
          from HICU.RRS_DETAIL 
         where MSTR_CD  = decode(IN_TEST_GUBN, 'V', 'VITAL', 'L', 'LAB') 
           and HSP_TP_CD = IN_HSP_TP_CD  
           and DETL_CD_1 <> 'UI' 
           AND length(trim(DETL_CD_3)) > 0  
           and USE_YN = 'Y' 
         union all 
        select '4', DETL_CD_4 as ITEM_CD, DETL_CD_NM as ITEM_NM, DISP_SEQ 
          from HICU.RRS_DETAIL 
         where MSTR_CD  = decode(IN_TEST_GUBN, 'V', 'VITAL', 'L', 'LAB') 
           and HSP_TP_CD = IN_HSP_TP_CD  
           AND length(trim(DETL_CD_4)) > 0  
           and DETL_CD_1 <> 'UI' 
           and USE_YN = 'Y' 
         union all 
        select '5', DETL_CD_1 as ITEM_CD, DETL_CD_NM as ITEM_NM, DISP_SEQ 
          from HICU.RRS_DETAIL 
         where MSTR_CD  = decode(IN_TEST_GUBN, 'V', 'VITAL_ADD', 'L', 'LAB_ADD') 
           and HSP_TP_CD = IN_HSP_TP_CD  
           and DETL_CD_1 <> 'UI' 
           and USE_YN = 'Y' 
         order by DISP_SEQ, 1  
   )     
   LOOP 
        V_SQL_STMT := V_SQL_STMT || ', (select NVL(CUR_VALUE, RRS_VALUE_H) from HICU.RRS_VALUE_H WHERE HSP_TP_CD = ''' || IN_HSP_TP_CD || '''  and PT_NO = ''' || IN_PT_NO ; 
        V_SQL_STMT := V_SQL_STMT || '''  and RRS_ITEM_CD = '''|| X.item_cd ||''' and ENT_DT = m.ENT_DT and ENT_DTM = m.ENT_DTM and rownum = 1) AS "' || X.ITEM_NM || '"' || chr(10) || chr(13); 
   END LOOP; 
    
   V_SQL_STMT := V_SQL_STMT || ' FROM HICU.RRS_VALUE_H m, HICU.RRS_DETAIL d WHERE m.HSP_TP_CD = ''' || IN_HSP_TP_CD || ''' and m.PT_NO = ''' || IN_PT_NO || ''''; 
     
     
    V_SQL_STMT := V_SQL_STMT || ' and ((''' || IN_TEST_GUBN || ''' = ''V'') and d.MSTR_CD in (''VITAL'',''VITAL_ADD'')  '; 
   V_SQL_STMT := V_SQL_STMT || '   or (''' || IN_TEST_GUBN || ''' = ''L'') and d.MSTR_CD in (''LAB'',''LAB_ADD'') )    '; 
    
     
    V_SQL_STMT := V_SQL_STMT || ' and m.RRS_ITEM_CD = d.DETL_CD_1 or m.RRS_ITEM_CD = d.DETL_CD_2 or m.RRS_ITEM_CD = d.DETL_CD_3 or m.RRS_ITEM_CD = d.DETL_CD_4  '; 
    V_SQL_STMT := V_SQL_STMT || ' and m.HSP_TP_CD = d.HSP_TP_CD and m.ENT_DTM > SYSDATE - 7 and m.RRS_ITEM_CD <> ''UI'' '; 
    V_SQL_STMT := V_SQL_STMT || ' group by m.ENT_DT, m.ENT_DTM '; 
    V_SQL_STMT := V_SQL_STMT || ' order by 1 desc ' ;    
 
dbms_output.put_line('V_SQL_STMT...' || V_SQL_STMT); 
    
    OPEN OUT_CURSOR FOR(V_SQL_STMT);  
     
END PC_RRS_RRS_TEST_HIST; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_ALL_STATISTICS 
* 최초 작성일     : 2019.03.18 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 전체 통계조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_ALL_STATISTICS  ( IN_HSP_TP_CD          IN   VARCHAR2          /* 병동구분코드 */ 
--                                 , IN_WORK_DT            IN   VARCHAR2          /* 적용 일자 */ 
--                                  
--                                 , OUT_CURSOR_1          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_2          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_3          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_4          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_5          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_6          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_7          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_8          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_9          OUT  RETURNCURSOR 
--                                 , OUT_CURSOR_10         OUT  RETURNCURSOR                               
--                                  )   
--IS 
--BEGIN 
--   BEGIN 
--       OPEN OUT_CURSOR_1 FOR 
--       with All_tm as ( 
--          select '00' TM_W from DUAL UNION 
--         select '01' TM_W from DUAL UNION 
--         select '02' TM_W from DUAL UNION 
--         select '03' TM_W from DUAL UNION 
--         select '04' TM_W from DUAL UNION 
--         select '05' TM_W from DUAL UNION 
--         select '06' TM_W from DUAL UNION 
--         select '07' TM_W from DUAL UNION 
--         select '08' TM_W from DUAL UNION 
--         select '09' TM_W from DUAL UNION 
--         select '10' TM_W from DUAL UNION 
--         select '11' TM_W from DUAL UNION 
--         select '12' TM_W from DUAL UNION 
--         select '13' TM_W from DUAL UNION 
--         select '14' TM_W from DUAL UNION 
--         select '15' TM_W from DUAL UNION 
--         select '16' TM_W from DUAL UNION 
--         select '17' TM_W from DUAL UNION 
--         select '18' TM_W from DUAL UNION 
--         select '19' TM_W from DUAL UNION 
--         select '20' TM_W from DUAL UNION 
--         select '21' TM_W from DUAL UNION 
--         select '22' TM_W from DUAL UNION 
--         select '23' TM_W from DUAL ) 
--         select a.tm_W, c.cnt 
--            from ( 
--            select to_char(ent_Dtm, 'hh24') entdtm, count(pt_no) cnt 
--                from ( 
--               select min(ent_Dtm) ent_Dtm, a.pt_no 
--                 from ( 
--                  select HSP_TP_CD, PT_NO 
--                    from UDTRRS a 
--                   where a.HSP_TP_CD = IN_HSP_TP_CD 
--                     and a.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                     and a.ent_Dtm < TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                     and A.RRS_STATE_CD <> 'R'  
--                     and A.RRS_STATE_CD <> 'X' 
--                   group by HSP_TP_CD, PT_NO 
--                  ) a, 
--                  UDTRRS b 
--                where a.HSP_TP_CD = b.HSP_TP_CD 
--                  and a.pt_no = b.PT_NO 
--                  and b.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                  and b.ent_Dtm < TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                  and B.RRS_STATE_CD <> 'R'    
--                  and B.RRS_STATE_CD <> 'X'  
--                group by a.pt_no 
--            ) 
--            group by to_char(ent_Dtm, 'hh24') 
--             ) c, All_tm a 
--         where a.tm_w = c.entdtm(+) 
--         order by 1 
--         ; 
--   END; 
--    
--   BEGIN 
--       OPEN OUT_CURSOR_2 FOR 
--          with All_tm as ( 
--            select '00' TM_W from DUAL UNION 
--            select '01' TM_W from DUAL UNION 
--            select '02' TM_W from DUAL UNION 
--            select '03' TM_W from DUAL UNION 
--            select '04' TM_W from DUAL UNION 
--            select '05' TM_W from DUAL UNION 
--            select '06' TM_W from DUAL UNION 
--            select '07' TM_W from DUAL UNION 
--            select '08' TM_W from DUAL UNION 
--            select '09' TM_W from DUAL UNION 
--            select '10' TM_W from DUAL UNION 
--            select '11' TM_W from DUAL UNION 
--            select '12' TM_W from DUAL UNION 
--            select '13' TM_W from DUAL UNION 
--            select '14' TM_W from DUAL UNION 
--            select '15' TM_W from DUAL UNION 
--            select '16' TM_W from DUAL UNION 
--            select '17' TM_W from DUAL UNION 
--            select '18' TM_W from DUAL UNION 
--            select '19' TM_W from DUAL UNION 
--            select '20' TM_W from DUAL UNION 
--            select '21' TM_W from DUAL UNION 
--            select '22' TM_W from DUAL UNION 
--            select '23' TM_W from DUAL ) 
--            select nvl(a.tm_w, 0) tm, c.cnt 
--              from All_tm a, 
--              ( 
--               select to_char(ent_Dtm, 'hh24') entdtm, count(pt_no) cnt 
--                 from ( 
--                  select min(ent_Dtm) ent_Dtm, a.pt_no 
--                    from ( 
--                        select HSP_TP_CD, PT_NO 
--                        from UDTRRShist a 
--                        where a.HSP_TP_CD = IN_HSP_TP_CD 
--                        and a.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                          and a.ent_Dtm < TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                        and news_score = '7' 
--                        and A.RRS_STATE_CD <> 'R' 
--                        and A.RRS_STATE_CD <> 'X'                         
--                        group by HSP_TP_CD, PT_NO 
--                        ) a, 
--                      UDTRRShist b 
--                  where a.HSP_TP_CD = b.HSP_TP_CD 
--                    and a.pt_no = b.PT_NO 
--                          and b.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                    and b.ent_Dtm < TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                    and news_score = '7' 
--                    and B.RRS_STATE_CD <> 'R' 
--                      and B.RRS_STATE_CD <> 'X' 
--                  group by a.pt_no 
--               ) 
--               group by to_char(ent_Dtm, 'hh24') 
--               order by 1 
--              ) c 
--            where a.tm_w = c.entdtm(+) 
--            order by 1 
--            ; 
--   END; 
--    
--   BEGIN  -- 당일 전체 환자 수 
--       OPEN OUT_CURSOR_3 FOR 
--       select (select count(*) A_CNT from ( 
--               select PT_NO, count(PT_NO) cnt 
--                 from UDTRRS 
--                 where HSP_TP_CD = IN_HSP_TP_CD 
--                   and RRS_STATE_CD <> 'R' 
--                   and RRS_STATE_CD <> 'X' 
--                       and ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                  and ent_Dtm <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                 group by PT_NO) ) A_CNT 
--            , (select count(*) R_CNT from ( 
--               select /*+ INDEX(A2 UDTRRS_SI02) */  
--                           PT_NO, count(PT_NO) cnt 
--                 from UDTRRS A2 
--                 where HSP_TP_CD = IN_HSP_TP_CD 
--                   and RRS_STATE_CD = 'R' 
--                       and CONFIRM_DTM >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                  and CONFIRM_DTM <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                 group by PT_NO) ) R_CNT 
--        from dual 
--            ; 
--             
--   END; 
--             
--   BEGIN 
--        -- 관리상태별 환자수 
--       OPEN OUT_CURSOR_4 FOR 
--        select decode(state, 'I', 1, 'P', 2, 'M', 3, 'R', 4, 'X', 5, 6) SEQ 
--             , (select KEY_DESC from UDTITEMMASTER 
--                 where hsp_tp_cd = '01' 
--                   and index_no = 2 
--                   and key_kind = st.state ) state 
--             , cnt1, cnt2 
--          from ( 
--            select 'I' state,  sum(pt_no) cnt1, sum(cnt) cnt2 
--            from ( 
--                select '1' pt_no 
--                     , count(pt_no) cnt 
--                  from ( 
--                    select distinct pt_no, rrs_item_cd 
--                      from udtrrs 
--                     where hsp_tp_Cd = IN_HSP_TP_CD 
--                       and rrs_state_cd = 'I' 
--                       and ent_dtm >= to_Date(IN_WORK_DT,'yyyymmdd') 
--                       and ent_dtm < to_Date(IN_WORK_DT,'yyyymmdd') + 1 
--                       and (news_Score >= 5 or item_news_score >= 3) 
--                ) 
--            group by pt_no  
--            )  
-- 
--            union all 
-- 
--             select rrs_state_Cd, sum(pt_no) cnt1, sum(cnt) cnt2 
--              from ( 
--                select '1' pt_no, count(rrs_item_cd) cnt, rrs_State_Cd 
--                 from ( 
--                    select distinct pt_no, rrs_item_cd, RRS_STATE_cD  
--                      from UDTRRS 
--                     where hsp_tp_cd = IN_HSP_TP_CD 
--                       and confirm_dtm >= to_Date(IN_WORK_DT,'yyyymmdd') 
--                       and confirm_dtm < to_Date(IN_WORK_DT,'yyyymmdd') + 1 
--                       AND RRS_STATE_cD IN ('P','M','R','X') 
--                    ) 
--                 group by pt_no, rrs_state_cd 
--                ) 
--            group by RRS_STATE_cD 
--        ) st 
--        order by 1 
--         ; 
--   END; 
-- 
--   BEGIN  -- top 진료과 
--       OPEN OUT_CURSOR_5 FOR 
--       select DEPT_NM, CNT 
--         from ( SELECT DEPT_NM, count(DEPT_NM) cnt 
--                   from ( SELECT PT_NO || TRUNC(ENT_DTM) as PT_NO, max(DEPT_NM) DEPT_NM 
--                      fROM UDTRRS 
--                      where HSP_TP_CD = IN_HSP_TP_CD 
--                        and ENT_DTM >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                              and ENT_DTM <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                      group by PT_NO || TRUNC(ENT_DTM) 
--                  ) 
--              group by DEPT_NM 
--               order by 2 desc 
--               ) 
--        where rownum < 6 
--      ; 
--   END; 
-- 
--   BEGIN  -- top 부서 
--       OPEN OUT_CURSOR_6 FOR 
--       select PT_LOC, CNT  
--         from ( SELECT PT_LOC, count(PT_LOC) cnt 
--               from ( SELECT PT_NO || TRUNC(ENT_DTM) AS PT_NO, max(substr(PT_LOC, 1, instr(PT_LOC, '/', 1, 1)-1)) PT_LOC 
--                            fROM UDTRRS 
--                           where HSP_TP_CD = IN_HSP_TP_CD 
--                             and ENT_DTM >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                             and ENT_DTM <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                           group by PT_NO || TRUNC(ENT_DTM) 
--                        ) 
--                  group by PT_LOC 
--              order by 2 desc 
--            ) 
--         where rownum < 6 
--            ; 
--   END;       
-- 
-- 
--   BEGIN   --- tat 
--       OPEN OUT_CURSOR_7 FOR 
--        select max_IP_TIME 
--             , max_IM_TIME 
--             , max_IR_TIME 
--             , max_IX_TIME 
--             , CEIL(P_SUM_TIME/decode(P_CNT, 0, 1, P_CNT)) MEAN_IP_TIME 
--             , CEIL(M_SUM_TIME/decode(M_CNT, 0, 1, M_CNT)) MEAN_IM_TIME 
--             , CEIL(R_SUM_TIME/decode(R_CNT, 0, 1, R_CNT)) MEAN_IR_TIME 
--             , CEIL(X_SUM_TIME/decode(X_CNT, 0, 1, X_CNT)) MEAN_IX_TIME 
--             , CEIL((P_SUM_TIME + M_SUM_TIME + R_SUM_TIME + X_SUM_TIME)  
--                   / decode((P_CNT + M_CNT + R_CNT + X_CNT), 0, 1, (P_CNT + M_CNT + R_CNT + X_CNT))) MEAN_TOT 
--        from ( 
--            select nvl(max(IP_TIME),0) max_IP_TIME 
--                 , nvl(max(IM_TIME),0) max_IM_TIME 
--                 , nvl(max(IR_TIME),0) max_IR_TIME 
--                 , nvl(max(IX_TIME),0) max_IX_TIME 
--                 , SUM(IP_TIME)  P_SUM_TIME 
--                 , SUM(P_CNT)  P_CNT 
--                 , SUM(IM_TIME)  M_SUM_TIME 
--                 , SUM(M_CNT)  M_CNT 
--                 , SUM(IR_TIME)  R_SUM_TIME 
--                 , SUM(R_CNT)  R_CNT 
--                 , SUM(IX_TIME)  X_SUM_TIME 
--                 , SUM(X_CNT)  X_CNT 
--            from ( 
--                select I_ENT_DTM 
--                     , decode(RRS_STATE_CD, 'P', STATE_ENT_DTM, '') P_ENT_DTM 
--                     , decode(RRS_STATE_CD, 'P', CEIL(((STATE_ENT_DTM - I_ENT_DTM) * 24) * 60) , 0) IP_TIME 
--                     , decode(RRS_STATE_CD, 'P', 1, 0) P_CNT 
--                     , decode(RRS_STATE_CD, 'M', STATE_ENT_DTM, '') M_ENT_DTM 
--                     , decode(RRS_STATE_CD, 'M', CEIL(((STATE_ENT_DTM - I_ENT_DTM) * 24) * 60) , 0) IM_TIME 
--                     , decode(RRS_STATE_CD, 'M', 1, 0) M_CNT 
--                     , decode(RRS_STATE_CD, 'R', STATE_ENT_DTM, '') R_ENT_DTM 
--                     , decode(RRS_STATE_CD, 'R', CEIL(((STATE_ENT_DTM - I_ENT_DTM) * 24) * 60) , 0) IR_TIME 
--                     , decode(RRS_STATE_CD, 'R', 1, 0) R_CNT 
--                     , decode(RRS_STATE_CD, 'X', STATE_ENT_DTM, '') X_ENT_DTM 
--                     , decode(RRS_STATE_CD, 'X', CEIL(((STATE_ENT_DTM - I_ENT_DTM) * 24) * 60) , 0) IX_TIME 
--                     , decode(RRS_STATE_CD, 'X', 1, 0) X_CNT 
--                from ( 
--                select hist.HSP_TP_CD, I_ent_dtm 
--                    , (select min(FIRST_DTM) from UDTRRSSTATE  
--                        where HSP_TP_CD = hist.HSP_TP_CD  
--                          and PT_NO = hist.PT_NO  
--                          and PACT_ID = hist.PACT_ID) STATE_ENT_DTM 
--                    , (select rrs_State_cd from UDTRRSSTATE  
--                        where HSP_TP_CD = hist.HSP_TP_CD  
--                          and PT_NO = hist.PT_NO  
--                          and PACT_ID = hist.PACT_ID 
--                          and FIRST_DTM = (select min(FIRST_DTM) from UDTRRSSTATE  
--                                            where HSP_TP_CD = hist.HSP_TP_CD  
--                                              and PT_NO = hist.PT_NO  
--                                              and PACT_ID = hist.PACT_ID) 
--                          and rownum = 1) RRS_STATE_CD 
--                from (select u.HSP_TP_CD, u.PT_NO, u.PACT_ID  
--                           , min(u.ent_dtm) I_ent_dtm 
--                        from udtrrsHIST u 
--                       where u.hsp_tp_cd = IN_HSP_TP_CD 
--                         and u.ent_dtm >= to_Date(IN_WORK_DT,'yyyymmdd') 
--                         and u.ent_dtm <  to_Date(IN_WORK_DT,'yyyymmdd') + 1 
--                         and u.rrs_state_cd = 'I' 
--                         and u.rrs_ITEM_cd <> 'UI' 
--                       group by u.HSP_TP_CD, u.pt_no, u.PACT_ID  
--                       ) hist 
--                ) 
--                WHERE RRS_STATE_CD IS NOT NULL 
--            ) 
--        ) 
--        ;                                    
--   END; 
--    
--   BEGIN  -- news 별 환자수 
--       OPEN OUT_CURSOR_8 FOR 
--        select sum(NEWS1) NEWS1 
--              , sum(NEWS2) NEWS2 
--              , sum(NEWS3) NEWS3 
--           from ( 
--                select CASE WHEN MAX(NEWS_SCORE) >= 1 AND MAX(NEWS_SCORE) <= 2 THEN 1 
--                            ELSE 0 END NEWS1 
--                     , CASE WHEN MAX(NEWS_SCORE) >= 3 AND MAX(NEWS_SCORE) <= 6 THEN 1 
--                            ELSE 0 END NEWS2 
--                     , CASE WHEN MAX(NEWS_SCORE) = 7 THEN 1 
--                            ELSE 0 END NEWS3 
--                  from UDTRRSHIST 
--                 where HSP_TP_CD = IN_HSP_TP_CD 
--                   and ENT_DTM >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                   and ENT_DTM <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                 group by pt_no 
--             ) 
--            ; 
--   END; 
--    
--   BEGIN  -- vital 검사 통계 
--       OPEN OUT_CURSOR_9 FOR 
--       select RRS_ITEM, SUM(CNT) CNT 
--           from ( 
--                select RRS_ITEM, 1 CNT 
--                  from UDTRRSHIST u 
--                     , UDTITEMMASTER i 
--                 where u.HSP_TP_CD = i.HSP_TP_CD 
--                   and u.HSP_TP_CD = IN_HSP_TP_CD 
--                   and i.INDEX_NO = '4' 
--                   AND U.RRS_STATE_CD = 'I' 
--                   and u.RRS_ITEM_CD = i.KEY_KIND 
--                   and u.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                   and u.ent_Dtm <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                 group by PT_NO, RRS_ITEM 
--                 ) 
--           group by RRS_ITEM 
--            ; 
--   END; 
--    
--   BEGIN  -- lab 검사 통계 
--       OPEN OUT_CURSOR_10 FOR 
--       select RRS_ITEM, SUM(CNT) CNT 
--           from ( 
--                select RRS_ITEM, 1 CNT 
--                  from UDTRRSHIST u 
--                     , UDTITEMMASTER i 
--                 where u.HSP_TP_CD = i.HSP_TP_CD 
--                   and u.HSP_TP_CD = IN_HSP_TP_CD 
--                   and i.INDEX_NO = '5' 
--                   AND U.RRS_STATE_CD = 'I' 
--                   and u.RRS_ITEM_CD = i.KEY_KIND 
--                   and u.ent_Dtm >= TO_dATE(IN_WORK_DT, 'yyyymmdd') 
--                   and u.ent_Dtm <  TO_dATE(IN_WORK_DT, 'yyyymmdd')+1 
--                 group by PT_NO, RRS_ITEM 
--                 ) 
--           group by RRS_ITEM 
--            ; 
--   END; 
 
--END PC_RRS_ALL_STATISTICS; 
              
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CUR_PAT_STATE 
* 최초 작성일     : 2019.03.19 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 현재환자 상태 조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_CUR_PAT_STATE  ( IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
--                                , IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
--                                , IN_RRS_ITEM_CD        IN   VARCHAR2  /* 검사항목 */ 
--                                , OUT_CURSOR            OUT  RETURNCURSOR )   
--IS 
--BEGIN 
--    OPEN OUT_CURSOR FOR 
--       select u.RRS_STATE 
--             --, u.ENT_STF 
--             , c.KOR_SRNM_NM ||'(' || u.ENT_STF || ')' 
--             , u.CONFIRM_NM 
--        from UDTRRS u 
--             --, HCOM.CNLRRUSD c 
--             , ( select '01' as HSP_TP_CD, 'aa' as STF_NO, '---' KOR_SRNM_NM  from dual) c  
--       where u.hsp_tp_cd = IN_HSP_TP_CD 
--            and u.pt_no = IN_PT_NO 
--         and u.rrs_item_cd = decode(IN_RRS_ITEM_CD, '*', u.rrs_item_cd, IN_RRS_ITEM_CD) 
--            
--           and u.HSP_TP_CD = c.HSP_TP_CD(+) 
--           and u.ENT_STF = c.STF_NO(+) 
--           and rownum = 1 
--      ; 
 
--END PC_RRS_CUR_PAT_STATE; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_LIST_SEARCH 
* 최초 작성일     : 2019.03.20 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모내역 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_LIST_SEARCH  ( IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                   , IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                   , IN_REG_ID            IN   VARCHAR2  /* 등록자 ID */ 
                                   , IN_MEMO_KIND          IN   VARCHAR2  /* 중요 여부 */ 
                                   , OUT_CURSOR            OUT  RETURNCURSOR )   
IS 
BEGIN 
    OPEN OUT_CURSOR FOR 
       select m.PT_NO 
            , m.HSP_TP_CD 
            , m.HIST_SEQ 
            , to_char(m.REG_DTM, 'yyyy-mm-dd hh24:mi') REG_DTM 
            , m.REG_ID  
            , ( select USR_NM from HICU.RRS_USER u 
                 where HSP_TP_CD = m.HSP_TP_CD 
                   and USR_ID = m.REG_ID 
                   and HIST_SEQ = 0) REG_NM 
            , m.MEMO 
            , decode(m.MEMO_KIND, 'I', '중요', 'G', '일반', '-') MEMO_KIND           
         from HICU.RRS_MEMO m 
        where m.PT_NO = IN_PT_NO 
          and m.HSP_TP_CD = IN_HSP_TP_CD 
          and m.USE_YN = 'Y' 
          AND nvl(m.REG_ID,'^') = decode(nvl(IN_REG_ID, '-'), '-', nvl(m.REG_ID,'^'), IN_REG_ID) 
          AND nvl(m.MEMO_KIND,'^') = decode(nvl(IN_MEMO_KIND, '-'), '-', nvl(m.MEMO_KIND,'^'), IN_MEMO_KIND) 
        order by m.HIST_SEQ 
      ; 
 
END PC_RRS_MEMO_LIST_SEARCH; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_INSERT 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모 등록 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_INSERT  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                              , IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
                              , IN_MEMO          IN   VARCHAR2 
                              , IN_MEMO_KIND     IN   VARCHAR2 
                              , IN_REG_ID        IN   VARCHAR2                               
                              , IN_REG_IP        IN   VARCHAR2 
                      )   
IS 
   v_ENT_NO VARCHAR2(5) := '0'; 
BEGIN    
    insert into  
       HICU.RRS_MEMO (PT_NO, HSP_TP_CD, HIST_SEQ, MEMO, MEMO_KIND, USE_YN, REG_DTM, REG_ID, REG_IP) 
          values(IN_PT_NO, IN_HSP_TP_CD 
               , nvl((select max(HIST_SEQ) + 1 from HICU.RRS_MEMO 
                       where PT_NO = IN_PT_NO 
                         and HSP_TP_CD = IN_HSP_TP_CD ), 1) 
               , IN_MEMO, IN_MEMO_KIND, 'Y', sysdate, IN_REG_ID, IN_REG_IP) ; 
    
   EXCEPTION  
      WHEN OTHERS THEN 
         ROLLBACK; 
         RAISE_APPLICATION_ERROR(-20501,'RRS MEMO insert Error 발생 : PC_RRS_MEMO_INSERT'); 
END PC_RRS_MEMO_INSERT; 
         
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_MEMO_DELETE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS 메모 삭제 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_MEMO_DELETE  ( IN_PT_NO         IN   VARCHAR2  /* 환자번호  */ 
                              , IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */                               
                              , IN_SEQ           IN   VARCHAR2 
                              , IN_REG_ID        IN   VARCHAR2 
                              , IN_REG_IP        IN   VARCHAR2 
                      )   
IS 
   v_ENT_NO VARCHAR2(5) := '0'; 
BEGIN         
   update HICU.RRS_MEMO 
      set USE_YN = 'N' 
        , MEMO = to_char(SYSDATE, 'yyyy-mm-dd hh24:mi') || ' ' || IN_REG_ID || '(' || IN_REG_IP ||' )' || ' delete!'  || chr(13) || chr(10) || MEMO 
    where PT_NO     = IN_PT_NO 
       and HSP_TP_CD = IN_HSP_TP_CD 
       and HIST_SEQ  = IN_SEQ 
      ; 
    
   EXCEPTION  
      WHEN OTHERS THEN 
         ROLLBACK; 
         RAISE_APPLICATION_ERROR(-20501,'RRS MEMO Delete Error 발생 : PC_RRS_MEMO_DELETE'); 
             
END PC_RRS_MEMO_DELETE; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_ADD_PTNO_LIST 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 추가환자리스트 조회 
* 변경이력관리 
===================================================================================*/ 
--PROCEDURE PC_RRS_ADD_PTNO_LIST  ( IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
--                             , OUT_CURSOR            OUT  RETURNCURSOR 
--                              ) 
--IS 
-- 
--BEGIN 
--   OPEN OUT_CURSOR FOR 
--      select hsp_tp_Cd 
--           , pt_no 
--             , rrs_item_cd 
--           , a.pt_nm 
--           , a.rrs_item 
--           , nvl(a.normal_value, a.rrs_value) rrs_value 
--        from udtrrs a 
--       where hsp_tp_Cd = IN_HSP_TP_CD 
--         and cfmt_yn = 'N' 
--      ;                
--    
--   for X in ( 
--      select hsp_tp_Cd, pt_no, rrs_item_cd 
--           , a.pt_nm, a.rrs_item 
--           , nvl(a.normal_value, a.rrs_value) rrs_value 
--        from udtrrs a 
--       where hsp_tp_Cd = IN_HSP_TP_CD 
--         and cfmt_yn = 'N' 
--   ) 
--   LOOP 
--      update udtrrs set cfmt_yn = 'Y'  
--       where hsp_tp_Cd = x.hsp_tp_Cd 
--         and pt_no = x.pt_no 
--         and rrs_item_cd  = x.rrs_item_cd 
--         ; 
--   END LOOP; 
       
       
--END PC_RRS_ADD_PTNO_LIST; 
 
 
 
/*=================================================================================== 
* 서비스이름      : PC_USING_DEPT_LIST 
* 최초 작성일     : 2019.02 
* 최초 작성자     : 하만석 
* DESCRIPTION     : RRS 에 등록된 진료과  코드 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_USING_DEPT_LIST  ( IN_HSP_TP_CD          IN    VARCHAR2      /* 병원구분코드 */ 
                       , OUT_CURSOR            OUT  RETURNCURSOR) 
 
 
IS    
         
BEGIN 
    OPEN OUT_CURSOR FOR 
   select DISTINCT DEPT_NM || ' [' || DEPT_CD || ']' DEPT_NM, DEPT_CD 
     from HICU.RRS_VALUE 
    WHERE HSP_TP_CD = IN_HSP_TP_CD 
      AND RRS_STATE_CD <> 'R' 
    ORDER BY 1 
       ;         
END PC_USING_DEPT_LIST; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_TEST_ITEM_LIST 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS CRF 데이터 조회 - 검사항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_TEST_ITEM_LIST     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , OUT_CURSOR           OUT  RETURNCURSOR) 
IS    
         
BEGIN 
    OPEN OUT_CURSOR FOR 
    select DETL_CD_NM || ' [' || DETL_CD_1 || ']' ITEM_NM 
          , DETL_CD_1 ITEM_CD 
       from HICU.RRS_DETAIL 
      where HSP_TP_CD = IN_HSP_TP_CD 
         and MSTR_CD IN ( 'LAB','LAB_ADD','VITAL','VITAL_ADD') 
         and USE_YN = 'Y' 
     order by 2, 1 
       ;         
END PC_RRS_TEST_ITEM_LIST; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_DIAGNOSIS_LIST 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS CRF 데이터 조회 - 검사항목 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_DIAGNOSIS_LIST     ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                    , OUT_CURSOR           OUT  RETURNCURSOR) 
IS    
         
BEGIN 
    OPEN OUT_CURSOR FOR 
   select DISTINCT DIAGNOSIS 
     from HICU.RRS_VALUE 
    WHERE HSP_TP_CD = IN_HSP_TP_CD 
      AND RRS_STATE_CD <> 'R' 
    ORDER BY 1 
       ;         
END PC_RRS_DIAGNOSIS_LIST; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO  ( IN_HSP_TP_CD     IN   VARCHAR2  /* 병동구분코드 */ 
                                , OUT_CURSOR            OUT  RETURNCURSOR 
                   ) 
IS 
 
BEGIN             
    OPEN OUT_CURSOR FOR 
    select MSTR_CD, to_char(DETL_CD) DETL_CD, DETL_CD_NM, DISP_SEQ 
      from HICU.RRS_DETAIL 
     where HSP_TP_CD = IN_HSP_TP_CD 
       --and MSTR_CD in('VT_METHOD', 'VT_SUBJECT', 'VT_YN', 'VT_EVAL') 
       and MSTR_CD in('VT_METHOD', 'VT_SUBJECT', 'VT_VTZ_JUDT_CNTS', 'VT_TEAM_DIAG', 'VT_VTZ_END')  
       and USE_YN = 'Y' 
     order by MSTR_CD, DISP_SEQ 
     ; 
                    
END PC_RRS_VITALIZE_INFO; 
 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SEL_VITALIZE_DATA 
* 최초 작성일     : 2019.03 
* 최초 작성자     : 하만석 
* DESCRIPTION   : RRS 활성화정보 저장 내역 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SEL_VITALIZE_DATA     ( IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                   , IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                   , OUT_CURSOR           OUT  RETURNCURSOR) 
 
IS 
 
BEGIN             
    OPEN OUT_CURSOR FOR 
    select v.PT_NO 
         , v.ENT_DT 
         , v.SEQ 
         , v.HSP_TP_CD 
         , to_char(v.ENT_DTM, 'yyyy-mm-dd hh24:mi:ss') ENT_DTM 
         , v.USE_YN 
         , v.METHOD_CD 
         , v.METHOD_TXT 
         , v.SUBJECT_CD 
         , v.SUBJECT_TXT 
         , v.VITALIZE_TM 
         , v.VITALIZE_ARRI_TM 
--         , v.VITALIZE_YN 
--         , v.VITALIZE_TXT 
--         , v.EVAL_CD 
--         , v.EVAL_TXT          
         , VTZ_JUDT_CNTS_CD 
         , VTZ_JUDT_CNTS_TXT 
         , TEAM_DIAG_CD 
         , TEAM_DIAG_TXT 
         , VTZ_END_CD 
         , VTZ_END_TXT 
         , v.REG_DTM 
         , u.USR_NM 
         , v.REG_ID 
      from HICU.RRS_VTZ_INF v 
         , HICU.RRS_USER u 
     where v.PT_NO = IN_PT_NO 
       and v.HSP_TP_CD = IN_HSP_TP_CD 
       and v.USE_YN = 'Y' 
 
       and u.HSP_TP_CD = v.HSP_TP_CD  
       and u.USR_ID = v.REG_ID 
       and u.HIST_SEQ = 0 
     order by v.ENT_DTM desc 
     ; 
                    
END PC_RRS_SEL_VITALIZE_DATA; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO_SAVE 
* 최초 작성일     : 2019.03.13 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO_SAVE  (IN_PT_NO              IN   VARCHAR2  /* 환자번호 */ 
                                    , IN_HSP_TP_CD          IN   VARCHAR2  /* 병동구분코드 */ 
                                    , IN_METHOD_CD          IN   VARCHAR2  /* 방법 */ 
                                    , IN_METHOD_TXT         IN   VARCHAR2  /* 방법 기타 */ 
                                    , IN_SUBJECT_CD         IN   VARCHAR2  /* 주체 */ 
                                    , IN_SUBJECT_TXT        IN   VARCHAR2  /* 주체 기타 */ 
                                    , IN_VITALIZE_TM        IN   VARCHAR2  /* 활성화 시간 */ 
                                    , IN_VITALIZE_ARRI_TM   IN   VARCHAR2  /* 현장도착시간 */ 
                                    , IN_VIT_JUDT_CNTS      IN   VARCHAR2  /* 활성화중재내용 */ 
                                    , IN_VIT_JUDT_CNTS_TXT  IN   VARCHAR2  /* 활성화중재내용 기타 */ 
                                    , IN_VIT_TEAM_DIAG      IN   VARCHAR2  /* 신속대응팀 진단  */ 
                                    , IN_VIT_TEAM_DIAG_TXT  IN   VARCHAR2  /* 신속대응팀 진단 기타 */ 
                                    , IN_VIT_END_RSLT       IN   VARCHAR2  /* 활성화 종료 결과  */ 
                                    , IN_VIT_END_RSLT_TXT   IN   VARCHAR2  /* 활성화 종료 결과 기타 */ 
                                    , IN_REG_ID             IN   VARCHAR2  /* 등록자ID */ 
                                    , IN_REG_IP             IN   VARCHAR2  /* 등록자IP */ 
                                    , IO_ERRYN              OUT  VARCHAR2 
                                    , IO_MESSAGE            OUT  VARCHAR2 ) 
IS 
    V_SYSDATE DATE := SYSDATE; 
     
    V_TXT VARCHAR2(300) := ''; 
BEGIN 
    IO_ERRYN  := 'N'; 
    IO_MESSAGE := '-'; 
 
    select SUBSTR(XMLAGG(XMLELEMENT(rslt, '|'||rslt) ORDER BY 1).EXTRACT('//text()').GETSTRINGVAL(), 2) AS rslt 
      into V_TXT 
      from ( 
            select d.DETL_CD || ':' || nvl(r.CUR_VALUE, r.rrs_value) rslt 
            From HICU.RRS_VALUE r 
               , HICU.RRS_DETAIL d  
            where r.HSP_TP_CD = IN_HSP_TP_CD 
            and r.PT_NO = IN_PT_NO 
            and r.ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
            and r.HSP_TP_CD = d.HSP_TP_CD 
            and r.RRS_ITEM_CD <> 'UI' 
            and (r.RRS_ITEM_CD = d.DETL_CD_1  
              or r.RRS_ITEM_CD = d.DETL_CD_2  
              or r.RRS_ITEM_CD = d.DETL_CD_3  
              or r.RRS_ITEM_CD = d.DETL_CD_4) 
        ); 
 
    insert  
      into HICU.RRS_VTZ_INF ( PT_NO 
                       , ENT_DT 
                       , SEQ 
                       , HSP_TP_CD 
                       , ENT_DTM 
                       , USE_YN 
                       , METHOD_CD 
                       , METHOD_TXT 
                       , SUBJECT_CD 
                       , SUBJECT_TXT 
                       , VITALIZE_TM 
                       , VITALIZE_ARRI_TM 
                       , VTZ_JUDT_CNTS_CD 
                       , VTZ_JUDT_CNTS_TXT 
                       , TEAM_DIAG_CD 
                       , TEAM_DIAG_TXT 
                       , VTZ_END_CD 
                       , VTZ_END_TXT 
                       , REG_DTM 
                       , REG_ID 
                       , REG_IP 
                       , RRS_RESULT) 
     values ( IN_PT_NO 
            , to_char(V_SYSDATE, 'yyyymmdd') 
            , nvl((select max(SEQ)+1 from HICU.RRS_VTZ_INF 
                    where PT_NO     = IN_PT_NO 
                      and ENT_DT    = to_char(V_SYSDATE, 'yyyymmdd') 
                      and HSP_TP_CD = IN_HSP_TP_CD), 0) 
            , IN_HSP_TP_CD 
            , V_SYSDATE 
            , 'Y' 
            , IN_METHOD_CD 
            , IN_METHOD_TXT 
            , IN_SUBJECT_CD 
            , IN_SUBJECT_TXT 
            , IN_VITALIZE_TM 
            , IN_VITALIZE_ARRI_TM 
            , IN_VIT_JUDT_CNTS 
            , IN_VIT_JUDT_CNTS_TXT 
            , IN_VIT_TEAM_DIAG 
            , IN_VIT_TEAM_DIAG_TXT 
            , IN_VIT_END_RSLT 
            , IN_VIT_END_RSLT_TXT 
            , V_SYSDATE 
            , IN_REG_ID 
            , IN_REG_IP 
            , V_TXT) 
     ; 
      
     EXCEPTION 
        WHEN OTHERS THEN 
            IO_ERRYN  := 'Y'; 
            IO_MESSAGE := 'ERR : PC_RRS_VITALIZE_INFO_SAVE  ERRCODE = ' || '-' || TO_CHAR(SQLCODE); 
      
                    
END PC_RRS_VITALIZE_INFO_SAVE; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITALIZE_INFO_EDIT 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : 활성화정보 입력 항목 수정 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITALIZE_INFO_EDIT ( 
              IN_ROWNUM             IN   VARCHAR2 
            , IN_PT_NO              IN   VARCHAR2    
            , IN_ENT_DT             IN   VARCHAR2    
            , IN_HSP_TP_CD          IN   VARCHAR2    
            , IN_METHOD_CD          IN   VARCHAR2    
            , IN_METHOD_TXT         IN   VARCHAR2    
            , IN_SUBJECT_CD         IN   VARCHAR2    
            , IN_SUBJECT_TXT        IN   VARCHAR2    
            , IN_VITALIZE_TM        IN   VARCHAR2    
            , IN_VITALIZE_ARRI_TM   IN   VARCHAR2    
            , IN_VIT_JUDT_CNTS      IN   VARCHAR2    
            , IN_VIT_JUDT_CNTS_TXT  IN   VARCHAR2    
            , IN_VIT_TEAM_DIAG      IN   VARCHAR2    
            , IN_VIT_TEAM_DIAG_TXT  IN   VARCHAR2    
            , IN_VIT_END_RSLT       IN   VARCHAR2    
            , IN_VIT_END_RSLT_TXT   IN   VARCHAR2    
--           , IN_VITALIZE_YN        IN   VARCHAR2    
--           , IN_VITALIZE_TXT       IN   VARCHAR2    
--           , IN_EVAL_CD            IN   VARCHAR2    
--           , IN_EVAL_TXT           IN   VARCHAR2    
            , IN_REG_ID             IN   VARCHAR2    
            , IN_REG_IP             IN   VARCHAR2    
            , IO_ERRYN              OUT   VARCHAR2    
            , IO_MESSAGE            OUT   VARCHAR2   ) 
IS 
    V_SYSDATE DATE := SYSDATE; 
     
    V_RRS_RESULT VARCHAR2(300) := ''; 
BEGIN 
    IO_ERRYN  := 'N'; 
    IO_MESSAGE := '-'; 
 
    select SUBSTR(XMLAGG(XMLELEMENT(rslt, '|'||rslt) ORDER BY 1).EXTRACT('//text()').GETSTRINGVAL(), 2) AS rslt 
      into V_RRS_RESULT 
      from ( 
            select d.DETL_CD || ':' || nvl(r.CUR_VALUE, r.rrs_value) rslt 
            From HICU.RRS_VALUE r 
               , HICU.RRS_DETAIL d  
            where r.HSP_TP_CD = IN_HSP_TP_CD 
            and r.PT_NO = IN_PT_NO 
            and r.ENT_DT = to_char(V_SYSDATE, 'yyyymmdd') 
            and r.HSP_TP_CD = d.HSP_TP_CD 
            and r.RRS_ITEM_CD <> 'UI' 
            and (r.RRS_ITEM_CD = d.DETL_CD_1  
              or r.RRS_ITEM_CD = d.DETL_CD_2  
              or r.RRS_ITEM_CD = d.DETL_CD_3  
              or r.RRS_ITEM_CD = d.DETL_CD_4) 
        ); 
     
 
        UPDATE HICU.RRS_VTZ_INF  
          SET ENT_DTM          = V_SYSDATE 
            , METHOD_CD        = IN_METHOD_CD 
            , METHOD_TXT       = IN_METHOD_TXT 
            , SUBJECT_CD       = IN_SUBJECT_CD  
            , SUBJECT_TXT      = IN_SUBJECT_TXT 
            , VITALIZE_TM      = IN_VITALIZE_TM 
            , VITALIZE_ARRI_TM = IN_VITALIZE_ARRI_TM             
            , VTZ_JUDT_CNTS_CD = IN_VIT_JUDT_CNTS 
            , VTZ_JUDT_CNTS_TXT = IN_VIT_JUDT_CNTS_TXT 
            , TEAM_DIAG_CD     = IN_VIT_TEAM_DIAG 
            , TEAM_DIAG_TXT    = IN_VIT_TEAM_DIAG_TXT 
            , VTZ_END_CD       = IN_VIT_END_RSLT 
            , VTZ_END_TXT      = IN_VIT_END_RSLT_TXT 
             
    --       , VITALIZE_YN      = IN_VITALIZE_YN 
    --       , VITALIZE_TXT     = IN_VITALIZE_TXT 
    --       , EVAL_CD          = IN_EVAL_CD 
    --       , EVAL_TXT         = IN_EVAL_TXT        
            , RRS_RESULT       = V_RRS_RESULT 
            , REG_DTM          = V_SYSDATE 
            , REG_ID           = IN_REG_ID 
            , REG_IP           = IN_REG_IP 
        WHERE PT_NO     = IN_PT_NO 
          AND ENT_DT    = IN_ENT_DT 
          AND SEQ       = IN_ROWNUM 
          AND HSP_TP_CD = IN_HSP_TP_CD 
    ; 
 
      
     EXCEPTION 
        WHEN OTHERS THEN 
            IO_ERRYN  := 'Y'; 
            IO_MESSAGE := 'ERR : PC_RRS_VITALIZE_INFO_EDIT  ERRCODE = ' || '-' || TO_CHAR(SQLCODE); 
      
                    
END PC_RRS_VITALIZE_INFO_EDIT; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_CRF_SERARCH 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS CRF 데이터 조회 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_CRF_SERARCH    ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                , IN_ST_DT            IN VARCHAR2   /* 조회 시작일 */ 
                                , IN_DT_DT            IN VARCHAR2   /* 조회 종료일 */                                     
                                , IN_PT_NO            IN VARCHAR2   /* 환자번호 */ 
                                , IN_PT_SEX           IN VARCHAR2   /* 성별 */  
                                , IN_SC_CHK           IN VARCHAR2   /* 스크리닝 20260407 장인수 지역병원과 동일하게 권역병원에서도 인파라미터 형식 맞쳐줌 */
                                , IN_PT_AGE_S         IN VARCHAR2   /* 나이 구간 시작 */ 
                                , IN_PT_AGE_E         IN VARCHAR2   /* 나이 구간 종료 */ 
                                , IN_DEPT_CD          IN VARCHAR2   /* 부서코드 */ 
                                , IN_PT_LOC           IN VARCHAR2   /* 병동위치 */ 
                                , IN_RRS_ITEM_CD      IN VARCHAR2   /* 검사코드 */ 
                                , IN_NEWS_SCORE       IN VARCHAR2   /* NEWS 계산 스코어 */ 
                                , IN_RRS_STATE_CD     IN VARCHAR2   /* RRS 상태값 */ 
                                , IN_DIAGNOSIS        IN VARCHAR2   /* 진단명 */                                   
                                , OUT_CURSOR          OUT  RETURNCURSOR 
                                , OUT_CUR_STATISTIC   OUT  RETURNCURSOR  /* 20260407 장인수 지역병원과 동일하게 권역병원에서도 인파라미터 형식 맞쳐줌 */
                                ) 
IS    
   V_S_CNT   VARCHAR2(10) := 0; 
   V_H_CNT   VARCHAR2(10) := 0; 
   V_D_S_CNT VARCHAR2(10) := 0; 
   V_D_H_CNT VARCHAR2(10) := 0;    
BEGIN    
    OPEN OUT_CURSOR FOR 
    select u.PT_NO 
         , u.PT_NM, PT_SEX 
         , u.PT_AGE, DEPT_NM 
         , u.WARD_NO   PT_LOC 
         , u.ROOM_NO|| '/'|| u.BED_NO  PT_ROOM 
         , u.DIAGNOSIS as DIGNOSIS 
         , u.RRS_ITEM_CD  
         , di.DETL_CD_NM RRT_ITEM 
         , NVL(u.CUR_VALUE, u.RRS_VALUE) as RRT_VALUE  
         , nvl(u.ITEM_NEWS_SCORE, 0) AS ITEM_NEWS 
         , nvl(u.NEWS_SCORE, 0) AS NEWS_SCORE --//―2025/ez고도화로 인한 작업―YJR  NEWS -> NEWS_SCORE 
         , nvl(u.NEWS, 0) AS NEWS   --, nvl(u.NEWS_SCORE, 0) AS NEWS //―2025/ez고도화로 인한 작업―YJR
         , u.RRS_STATE_CD 
         , ds.DETL_CD_NM  as RRT_STATE 
         , decode( (select '1' 
                      from HICU.RRS_MEMO m 
                     where m.HSP_TP_CD = u.HSP_TP_CD 
                       and m.PT_NO = u.PT_NO 
                       and m.USE_YN = 'Y' 
                     group by PT_NO ), '1', 'Y', 'N' ) MEMO 
         , to_char(ENT_DTM, 'yyyy-mm-dd hh24:mi') ENT_DTM 
         , to_char(ac.ADS_DTM, 'yyyy-mm-dd hh24:mi') ADS_DTM 
         , to_char(ac.DS_DTM, 'yyyy-mm-dd hh24:mi') DS_DTM 
         , (select SUBSTR(XMLAGG(XMLELEMENT(MEMO, chr(13)||chr(10) || MEMO) ORDER BY HIST_SEQ).EXTRACT('//text()').GETSTRINGVAL(), 2) AS NAME  
              from HICU.RRS_MEMO 
             where PT_NO = u.PT_NO 
               and HSP_TP_CD  = u.HSP_TP_CD 
               and REG_DTM >= trunc(u.ENT_DTM) 
               and REG_DTM < trunc(u.ENT_DTM)+1 
             ) MEMO_TXT 
         , u.DOC_NM 
      from HICU.RRS_VALUE u 
         , HICU.RRS_DETAIL ds 
         , HICU.RRS_DETAIL di    
         , ACPPRAAM ac         
      where u.HSP_TP_CD = IN_HSP_TP_CD 
      and u.ENT_DT >= replace(IN_ST_DT, '-' , '') 
      and u.ENT_DT <= replace(IN_DT_DT, '-' , '') 
                          
        and ds.HSP_TP_CD = u.HSP_TP_CD 
        and ds.MSTR_CD = 'STAT_CD' 
        and ds.DETL_CD = u.RRS_STATE_cd 
         
        and di.HSP_TP_CD = u.HSP_TP_CD 
        and di.MSTR_CD in ('VITAL','VITAL_ADD','LAB','LAB_ADD') 
        and di.USE_YN = 'Y' 
        and ( di.DETL_CD_1 = u.RRS_ITEM_CD or di.DETL_CD_2 = u.RRS_ITEM_CD or di.DETL_CD_3 = u.RRS_ITEM_CD or di.DETL_CD_4 = u.RRS_ITEM_CD ) 
         
        and u.PACT_ID = ac.PACT_ID(+) 
         
        and u.PT_NO = decode(IN_PT_NO, 'ALL', u.PT_NO, IN_PT_NO) 
        and ( IN_PT_SEX = 'ALL' 
          or  
             U.PT_SEX in ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                             from ( selecT IN_PT_SEX as multidata from DUAL) a 
                          connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) 
            )                                                   
        -- 나이 
        AND ( CASE WHEN instr(PT_AGE, '일') > 0  then ( round( (to_number(REPLACE(PT_AGE, '일'))/ 30) / 12) )
                   WHEN instr(PT_AGE, '개월') > 0 then ( round(to_number(REPLACE(PT_AGE, '개월')) / 12) ) 
                else to_number(REPLACE(PT_AGE, '세')) end >= DECODE(IN_PT_AGE_S, 'ALL', 0, TO_NUMBER(IN_PT_AGE_S)) 
            and  
             CASE WHEN instr(PT_AGE, '일') > 0  then ( round( (to_number(REPLACE(PT_AGE, '일'))/ 30) / 12) )
                  WHEN instr(PT_AGE, '개월') > 0 then ( round(to_number(REPLACE(PT_AGE, '개월')) / 12) ) 
                else to_number(REPLACE(PT_AGE, '세')) end <= DECODE(IN_PT_AGE_E,'ALL', 999, TO_NUMBER(IN_PT_AGE_E)) 
           ) 
        -- 진료과 
        and ( IN_DEPT_CD = 'ALL' 
          or ( U.DEPT_CD IN ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                from ( selecT IN_DEPT_CD as multidata from DUAL) a 
                             connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        ) 
        -- 위치 
        and ( IN_PT_LOC = 'ALL' 
          or ( U.WARD_NO IN ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                from ( selecT IN_PT_LOC as multidata from DUAL) a 
                             connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        )  
        -- 검사코드 
        and ( IN_RRS_ITEM_CD = 'ALL' 
          or ( RRS_ITEM_CD IN ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                  from ( selecT IN_RRS_ITEM_CD as multidata from DUAL) a 
                               connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        ) 
        -- NEWS 
        and ( IN_NEWS_SCORE = 'ALL' 
          or ( NVL(NEWS, 0) IN ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata   --or ( NVL(NEWS_SCORE, 0) IN ( select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata   //―2025/ez고도화로 인한 작업―YJR IN_NEWS_SCORE 값이 NEWS_SCORE -> NEWS로 변경
                                         from ( selecT IN_NEWS_SCORE as multidata from DUAL) a 
                                      connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        ) 
        -- 관리상태 
        and ( IN_RRS_STATE_CD = 'ALL' 
          or ( RRS_STATE_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                    from ( selecT IN_RRS_STATE_CD as multidata from DUAL) a 
                                 connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        )   
        -- 진단명 
        and ( IN_DIAGNOSIS = 'ALL' 
          or ( DIAGNOSIS IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                 from ( selecT IN_DIAGNOSIS as multidata from DUAL) a 
                              connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
        ) 
        ;   
 
--    select to_char(count(*) + 0) S_CNT     -- Screening 환자 : 
--      into V_S_CNT 
--     from (  select R.PT_NO || R.ENT_DT 
--             from HICU.RRS_VALUE r 
--                , HICU.RRS_VALUE_H h 
--              where r.HSP_TP_CD = IN_HSP_TP_CD 
--                and h.PT_NO  = r.PT_NO 
--                 and h.ENT_DT = r.ENT_DT 
--            and h.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--            and h.ENT_DT <= replace(IN_DT_DT, '-' , '') 
--            and h.RRS_ITEM_CD = r.RRS_ITEM_CD 
--            and h.HSP_TP_CD   = r.HSP_TP_CD 
--            and ( TO_NUMBER(h.NEWS_SCORE) >= 5 or TO_NUMBER(h.ITEM_NEWS_SCORE) >= 3 ) 
--           group by R.PT_NO || R.ENT_DT 
--            )  
--   ;                
     
--   select to_char(count(*) + 0) H_CNT       -- 고위험 환자 : 
--     into V_H_CNT 
--      from ( select R.PT_NO || R.ENT_DT 
--             from HICU.RRS_VALUE r 
--                , HICU.RRS_VALUE_H h 
--                , (select pt_no, hsp_tp_cd, reg_dt, PACT_ID 
--                     from HICU.RRS_STATE S 
--                    where hsp_tp_cd = IN_HSP_TP_CD                     
--                      and reg_dt >= replace(IN_ST_DT, '-' , '') 
--                      and reg_dt <= replace(IN_DT_DT, '-' , '') ) s 
--           where r.HSP_TP_CD = IN_HSP_TP_CD 
--             and h.PT_NO  = r.PT_NO 
--             and h.ENT_DT = r.ENT_DT 
--             and r.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--             and r.ENT_DT <= replace(IN_DT_DT, '-' , '') 
--             and h.RRS_ITEM_CD = r.RRS_ITEM_CD 
--             and h.HSP_TP_CD   = r.HSP_TP_CD 
--             and ( TO_NUMBER(h.NEWS_SCORE) >= 7 or h.RRS_STATE_CD = 'M' ) 
--             and r.PT_NO = s.PT_NO 
--             and r.PACT_ID = s.PACT_ID 
--            and r.HSP_TP_CD = s.HSP_TP_CD 
--            and s.reg_dt = r.ENT_DT 
--            group by R.PT_NO || R.ENT_DT 
--          
--           union 
--          
--          select R.PT_NO || R.ENT_DT 
--            from HICU.RRS_VALUE r 
--            where r.HSP_TP_CD = IN_HSP_TP_CD 
--             and r.RRS_sTATE_CD = 'M' 
--            and r.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--            and r.ENT_DT <= replace(IN_DT_DT, '-' , '') 
--           group by R.PT_NO || R.ENT_DT          
--          ) 
--       ; 
--            
--   select to_char(count(*) + 0) D_S_CNT     -- Screening 건수:    
--     into V_D_S_CNT 
--      from ( select m.pt_no, m.pact_id, m.ent_dt, to_char(m.uitm_dtm, 'yyyymmddhh24miss') 
--               from HICU.RRS_VALUE r 
--                  , HICU.RRS_VALUE_H h 
--                  , HICU.RRS_MOBRRSMT m 
--              where r.HSP_TP_CD = IN_HSP_TP_CD 
--                and r.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--                and r.ENT_DT <= replace(IN_DT_DT, '-' , '') 
--                and h.HSP_TP_CD   = r.HSP_TP_CD 
--                and h.PT_NO  = r.PT_NO 
--                and h.ENT_DT = r.ENT_DT 
--                and h.RRS_ITEM_CD = r.RRS_ITEM_CD 
--                and ( TO_NUMBER(h.NEWS_SCORE) >= 5 or TO_NUMBER(h.ITEM_NEWS_SCORE) >= 3 ) 
--                and m.ent_dt = r.ent_dt 
--              and m.pt_no = r.pt_no 
--              and m.rrt_item_cd = r.rrs_item_cd 
--             and m.pact_id = r.pact_id 
--             and m.FSR_DTM = h.ent_dtm 
--           group by m.pt_no, m.pact_id, m.ent_dt, to_char(m.uitm_dtm, 'yyyymmddhh24miss') 
--          )         
--      ;   
--         
--   select to_char(count(PT_INFO) + 0) D_H_CNT       -- 고위험 환자 건수     
--     into V_D_H_CNT 
--      from (select (m.pt_no || m.pact_id || m.ent_dt || to_char(m.uitm_dtm, 'yyyymmddhh24miss')) PT_INFO 
--           from HICU.RRS_VALUE r 
--               , HICU.RRS_VALUE_H h 
--                , HICU.RRS_MOBRRSMT m 
--                 , (select pt_no, hsp_tp_cd, reg_dt, PACT_ID 
--                      from HICU.RRS_STATE S 
--                     where hsp_tp_cd = IN_HSP_TP_CD 
--                       and reg_dt >= replace(IN_ST_DT, '-' , '') 
--                      and reg_dt <= replace(IN_DT_DT, '-' , '') ) s 
--          where r.HSP_TP_CD = IN_HSP_TP_CD 
--            and h.PT_NO  = r.PT_NO 
--             and h.ENT_DT = r.ENT_DT 
--             and r.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--             and r.ENT_DT <= replace(IN_DT_DT, '-' , '') 
--             and h.RRS_ITEM_CD = r.RRS_ITEM_CD 
--             and h.HSP_TP_CD   = r.HSP_TP_CD 
--             and ( TO_NUMBER(h.NEWS_SCORE) >= 7 or h.RRS_STATE_CD = 'M' ) 
-- 
--             and r.PT_NO = s.PT_NO 
--            and r.PACT_ID = s.PACT_ID 
--            and r.HSP_TP_CD = s.HSP_TP_CD 
--            and s.reg_dt = r.ENT_DT 
-- 
--            and m.hsp_tp_cd = r.hsp_tp_cd 
--            and m.ent_dt = r.ent_dt 
--            and m.pt_no = r.pt_no 
--               and m.rrt_item_cd = r.rrs_item_cd 
--               and m.pact_id = r.pact_id 
--               and m.FSR_DTM = h.ent_dtm 
--          group by (m.pt_no || m.pact_id || m.ent_dt || to_char(m.uitm_dtm, 'yyyymmddhh24miss')) 
--           union 
--          select (m.pt_no || m.pact_id || m.ent_dt || to_char(m.uitm_dtm, 'yyyymmddhh24miss')) 
--            from HICU.RRS_VALUE r 
--                , HICU.RRS_MOBRRSMT m 
--           where r.HSP_TP_CD = IN_HSP_TP_CD 
--             and r.RRS_sTATE_CD = 'M' 
--             and r.ENT_DT >= replace(IN_ST_DT, '-' , '') 
--             and r.ENT_DT <= replace(IN_DT_DT, '-' , '') 
-- 
--             and m.hsp_tp_cd = r.hsp_tp_cd 
--            and m.ent_dt = r.ent_dt 
--            and m.pt_no = r.pt_no 
--            and m.rrt_item_cd = r.rrs_item_cd 
--            and m.pact_id = r.pact_id 
--            and m.FSR_DTM = r.ent_dtm 
--           group by (m.pt_no || m.pact_id || m.ent_dt || to_char(m.uitm_dtm, 'yyyymmddhh24miss'))       
--         )         
--        ; 
--    
--   OPEN OUT_CUR_STATISTIC FOR  
--   select V_S_CNT   as S_CNT 
--        , V_H_CNT   as H_CNT 
--        , V_D_S_CNT as D_S_CNT 
--        , V_D_H_CNT as D_H_CNT   
--     from dual 
--   ;                                           
    
END PC_RRS_CRF_SERARCH; 
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_VITAL_INFO_LIST 
* 최초 작성일     : 2019.07 
* 최초 작성자     : 하만석 
* DESCRIPTION    : RRS CRF 바이탈 입력 정보 리스트 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_VITAL_INFO_LIST ( IN_HSP_TP_CD        IN VARCHAR2   /* 병원구분코드 */ 
                                 , IN_ST_DT            IN VARCHAR2   /* 조회 시작일 */ 
                                 , IN_DT_DT            IN VARCHAR2   /* 조회 종료일 */                                     
                                 , IN_PT_NO            IN VARCHAR2   /* 환자번호 */                              
                                 , IN_VITALMETHOD      IN VARCHAR2   /* 활성화 방법 */ 
                                 , IN_VITALSUBJECT     IN VARCHAR2   /* 활성화 주체 */ 
                                 , IN_VITJUDGCNTS      IN VARCHAR2    
                                 , IN_VITTEAMDIAG      IN VARCHAR2    
                                 , IN_VITENDRSLT       IN VARCHAR2    
                                 , OUT_CURSOR          OUT  RETURNCURSOR 
                                 ) 
IS    
BEGIN    
    --활성화정보 상세 
   OPEN OUT_CURSOR FOR 
    select r.PT_NO 
         , r.ENT_DT 
         , r.HSP_TP_CD 
         , r.PT_NM 
         , r.PT_SEX 
         , r.PT_AGE 
         , to_char( (to_date(r.ENT_DT, 'yyyymmdd') - to_number(r.HD) + 1), 'yyyy-mm-dd') ADMI_DT 
         , r.HD 
         , r.DEPT_NM 
         , r.DOC_NM 
         , r.DIAGNOSIS 
         , r.WARD_NO  PT_LOC 
         , (r.ROOM_NO || '/' || r.BED_NO) PT_ROOM 
         , v.SEQ 
         , to_char(v.ENT_DTM, 'yyyy-mm-dd hh24:mi:ss') ENT_DTM 
         , v.USE_YN 
         , v.METHOD_CD 
         , d_m.DETL_CD_NM           METHOD_TXT 
         , TRIM(v.METHOD_TXT)   METHOD_TXT_OTH 
         , v.SUBJECT_CD          
         , d_s.DETL_CD_NM           SUBJECT_TXT 
         , TRIM(v.SUBJECT_TXT)  SUBJECT_TXT_OTH 
         , v.VITALIZE_TM 
         , v.VITALIZE_ARRI_TM 
         , v.VTZ_JUDT_CNTS_CD 
         , d_j.DETL_CD_NM               JUDT_CNTS_TXT 
         , TRIM(v.VTZ_JUDT_CNTS_TXT)  JUDT_CNTS_TXT_OTH          
         , v.TEAM_DIAG_CD 
         , d_d.DETL_CD_NM               DIAG_TXT 
         , TRIM(v.TEAM_DIAG_TXT)      DIAGL_TXT_OTH          
         , v.VTZ_END_CD 
         , d_e.DETL_CD_NM               END_TXT 
         , TRIM(v.VTZ_END_TXT)        END_TXT_OTH 
         , u.USR_NM 
         , v.REG_ID 
         , v.RRS_RESULT 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'SBP')    V_SBP 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'DBP')    V_DBP 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'HR')     V_HR 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'RR')     V_RR 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'BT')     V_BT 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'SPO2')   V_SPO2 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'GCS')    V_GCS 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'OXYGEN') V_METHOD 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'PH')     V_PH 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'PACO2')  V_PACO2 
         , XICU.FT_GET_VITAL_RSLT (v.RRS_RESULT, 'PAO2')   V_PAO2 
      from HICU.RRS_VTZ_INF v 
         , HICU.RRS_USER u 
         , (select PT_NO, ENT_DT, HSP_TP_CD, PT_NM 
                 , PT_SEX, PT_AGE, HD, DEPT_NM, DOC_NM 
                 , DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO 
              from HICU.rrs_value 
             where hsp_tp_cd = IN_HSP_TP_CD 
               and pt_no = decode(IN_PT_NO, 'ALL', PT_NO, IN_PT_NO) 
               and ENT_DT >= IN_ST_DT 
               and ENT_DT <= IN_DT_DT 
             group by PT_NO, ENT_DT, HSP_TP_CD, PT_NM 
                    , PT_SEX, PT_AGE, HD, DEPT_NM, DOC_NM 
                    , DIAGNOSIS, WARD_NO, ROOM_NO, BED_NO ) r 
         , (select DETL_CD, DETL_CD_NM 
              from HICU.RRS_DETAIL 
             where HSP_TP_CD = '01' 
               and MSTR_CD = 'VT_METHOD') d_m   -- 활성화방법 
         , (select DETL_CD, DETL_CD_NM 
              from HICU.RRS_DETAIL 
             where HSP_TP_CD = '01' 
               and MSTR_CD = 'VT_SUBJECT') d_s   -- 활성화주체 
         , (select DETL_CD, DETL_CD_NM 
              from HICU.RRS_DETAIL 
             where HSP_TP_CD = '01' 
               and MSTR_CD = 'VT_VTZ_JUDT_CNTS') d_j   -- 활성화 중재내용 
         , (select DETL_CD, DETL_CD_NM 
              from HICU.RRS_DETAIL 
             where HSP_TP_CD = '01' 
               and MSTR_CD = 'VT_TEAM_DIAG') d_d  -- 신속대응팀 진단  
         , (select DETL_CD, DETL_CD_NM 
              from HICU.RRS_DETAIL 
             where HSP_TP_CD = '01' 
               and MSTR_CD = 'VT_VTZ_END') d_e  -- 활성화종료 결과 
     where v.HSP_TP_CD = IN_HSP_TP_CD 
       and v.PT_NO = decode(IN_PT_NO, 'ALL', v.PT_NO, IN_PT_NO) 
       and v.ENT_DT >= IN_ST_DT 
       and v.ENT_DT <= IN_DT_DT        
       and v.USE_YN = 'Y' 
       and u.HSP_TP_CD = v.HSP_TP_CD  
       and u.USR_ID = v.REG_ID 
       and u.HIST_SEQ = 0        
       and r.HSP_TP_CD = v.HSP_TP_CD  
       and v.PT_NO = r.PT_NO 
       and v.ENT_DT = r.ENT_DT        
       and v.METHOD_CD = d_m.DETL_CD(+) 
       and v.SUBJECT_CD = d_s.DETL_CD(+) 
       and v.VTZ_JUDT_CNTS_CD = d_j.DETL_CD(+) 
       and v.TEAM_DIAG_CD = d_d.DETL_CD(+) 
       and v.VTZ_END_CD = d_e.DETL_CD(+) 
        
       and ( IN_VITALMETHOD = 'ALL' 
              or ( METHOD_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                     from ( selecT IN_VITALMETHOD as multidata from DUAL) a 
                                  connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
            ) 
       and ( IN_VITALSUBJECT = 'ALL' 
              or ( SUBJECT_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                     from ( selecT IN_VITALSUBJECT as multidata from DUAL) a 
                                  connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
            ) 
       and ( IN_VITJUDGCNTS = 'ALL' 
              or ( VTZ_JUDT_CNTS_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                     from ( selecT IN_VITJUDGCNTS as multidata from DUAL) a 
                                  connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
            ) 
       and ( IN_VITTEAMDIAG = 'ALL' 
              or ( TEAM_DIAG_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                     from ( selecT IN_VITTEAMDIAG as multidata from DUAL) a 
                                  connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
            ) 
       and ( IN_VITENDRSLT = 'ALL' 
              or ( EVAL_CD IN (  select trim(regexp_substr(multidata, '[^,]+', 1, rownum)) as showdata 
                                     from ( selecT IN_VITENDRSLT as multidata from DUAL) a 
                                  connect by rownum <= length(regexp_replace(multidata, '[^,]+')) + 1) ) 
            ) 
     order by v.ENT_DTM, v.PT_NO, v.SEQ 
     ; 
 
END PC_RRS_VITAL_INFO_LIST;     
     
 
/*=================================================================================== 
* 서비스이름      : PC_RRS_SMS_MSG_SEND 
* 최초 작성일     : 2020.05 
* 최초 작성자     : 하만석 
* DESCRIPTION     :  RRS 주치의, 전문의 문자 전송 
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_RRS_SMS_MSG_SEND ( IN_HSP_TP_CD            IN VARCHAR2   /* 병원구분코드 */ 
                              , IN_MSG               IN VARCHAR2   /* 메시지 */                                  
                              , IN_PT_NO             IN VARCHAR2   /* 환자번호 */   
                              , IN_PACT_ID           IN VARCHAR2   /* PACT_ID */     
                                 ) 
IS    
    OUT_CURSOR sys_Refcursor; 
 
    O_ID_1 VARCHAR2(50); 
    O_NM_1 VARCHAR2(200);  
    O_PH_1 VARCHAR2(50);  
    O_ID_2 VARCHAR2(50);  
    O_NM_2 VARCHAR2(200);  
    O_PH_2 VARCHAR2(50); 
     
    V_CALLBACK_PHONE VARCHAR2(50) := '01000000000'; 
BEGIN     
                   
   select '1'  into O_ID_1 
     from dual 
   ;           
--    XMED.PKG_MOO_RRS_INFO.PC_SEL_PATIENT_MEDDR_INFO(IN_HSP_TP_CD, IN_PT_NO, IN_PACT_ID, OUT_CURSOR); 
-- 
--    loop 
--        FETCH OUT_CURSOR INTO O_ID_1, O_NM_1, O_PH_1, O_ID_2, O_NM_2, O_PH_2; 
--        EXIT WHEN OUT_CURSOR%NOTFOUND;  
--         
--        if length(trim(O_PH_1)) > 8 then 
--            XCOM.PC_COM_DEFAULT_SMS_SEND('RRS' 
--                                        , SYSDATE 
--                                        , 'RRS 조기경고' 
--                                        , IN_MSG 
--                                        , V_CALLBACK_PHONE 
--                                        , O_PH_1 
--                                        , '' 
--                                        , 'RRS' 
--                                        , 'RRS' 
--                                        , IN_HSP_TP_CD 
--                                        ); 
--       end if; 
-- 
--        if length(trim(O_PH_2)) > 8 then 
--            XCOM.PC_COM_DEFAULT_SMS_SEND('RRS' 
--                                        , SYSDATE 
--                                        , 'RRS 조기경고' 
--                                        , IN_MSG 
--                                        , V_CALLBACK_PHONE 
--                                        , O_PH_2 
--                                        , '' 
--                                        , 'RRS' 
--                                        , 'RRS' 
--                                        , IN_HSP_TP_CD 
--                                        ); 
--       end if; 
--    end loop; 
 
 
END PC_RRS_SMS_MSG_SEND;       

/**********************************************************************************************
*    SERVICENAME    : IF_PHONE_NUMBER_SEL
*    CREATEDATE     : 2025.12.01
*    Author         : 윤재림
*    Description    : 휴대번호 조회 
*    Change History :
**********************************************************************************************/
PROCEDURE IF_PHONE_NUMBER_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
	                        , IN_HSP_TP_CD		  	IN VARCHAR2
													, OUT_CURSOR					OUT SYS_REFCURSOR
	)
	IS
	BEGIN
		OPEN OUT_CURSOR FOR
	  SELECT
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_1' THEN COMN_CD_NM END) AS PHONE_NUMBER_1,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_2' THEN COMN_CD_NM END) AS PHONE_NUMBER_2,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_3' THEN COMN_CD_NM END) AS PHONE_NUMBER_3,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_4' THEN COMN_CD_NM END) AS PHONE_NUMBER_4,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_5' THEN COMN_CD_NM END) AS PHONE_NUMBER_5
		FROM HICU.UCCOCSTE
		WHERE COMN_GRP_CD = 'ICTEL'
		  AND COMN_CD IN (
		        'PHONE_NUMBER_1',
		        'PHONE_NUMBER_2',
		        'PHONE_NUMBER_3',
		        'PHONE_NUMBER_4',
		        'PHONE_NUMBER_5'
	  );
END IF_PHONE_NUMBER_SEL;

  
/**********************************************************************************************
*    SERVICENAME    : IF_PHONE_NUMBER_UPD
*    CREATEDATE     : 2025.12.01
*    Author         : 윤재림
*    Description    : 휴대번호 수정 
*    Change History :
**********************************************************************************************/
PROCEDURE IF_PHONE_NUMBER_UPD (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
											    , IN_COMN_CD          IN  VARCHAR2
											    , IN_HSP_TP_CD        IN  VARCHAR2
											    , IN_COMN_CD_NM       IN  VARCHAR2
											    , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);

BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE HICU.UCCOCSTE
       SET COMN_CD_NM	 = IN_COMN_CD_NM
     WHERE COMN_CD 	   = IN_COMN_CD
       AND HSP_TP_CD   = IN_HSP_TP_CD
       AND COMN_GRP_CD = 'ICTEL';

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END IF_PHONE_NUMBER_UPD;

     
END PKG_NEORRS_MAIN;
