
  CREATE OR REPLACE EDITIONABLE PACKAGE "XICU"."PKG_EICU_ODS" 
AS
   /*===================================================================================
   * 서비스이름        : PC_PATIENT_BASIC_INFO
   * 최초 작성일       : 2021.03.29
   * 최초 작성자       : 이창우
   * DESCRIPTION : 중환자기본 정보
   * 변경이력관리
   ===================================================================================*/
   PROCEDURE PC_PATIENT_BASIC_INFO
             ( IN_SCHD_EXCT_ID IN VARCHAR2
             , IN_HSP_TP_CD IN VARCHAR2
             , IN_BEGIN_DT  IN DATE 
             , IN_END_DT    IN DATE 
             );
   /*===================================================================================
   * 서비스이름        : PC_PATIENT_ETRM_CHOT_DTM_INF
   * 최초 작성일       : 2021.03.29
   * 최초 작성자       : 이창우
   * DESCRIPTION : 중환자실 입실 퇴실 시간 정보
   * 변경이력관리
   ===================================================================================*/
   PROCEDURE PC_PATIENT_ETRM_CHOT_DTM_INF
             ( IN_SCHD_EXCT_ID IN VARCHAR2
             , IN_HSP_TP_CD IN VARCHAR2
             , IN_BEGIN_DT  IN DATE 
             , IN_END_DT    IN DATE 
             );
END PKG_EICU_ODS;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_EICU_ODS" 
IS
   /*===================================================================================
   * 서비스이름        : PC_PATIENT_BASIC_INFO
   * 최초 작성일       : 2021.03.29
   * 최초 작성자       : 이창우
   * DESCRIPTION : 중환자기본 정보
   * 변경이력관리
   ===================================================================================*/
   PROCEDURE PC_PATIENT_BASIC_INFO
             ( IN_SCHD_EXCT_ID IN VARCHAR2
             , IN_HSP_TP_CD IN VARCHAR2
             , IN_BEGIN_DT  IN DATE 
             , IN_END_DT    IN DATE 
             )
   IS
   BEGIN
      BEGIN
         XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_BASIC', 'BEGIN');
         MERGE INTO HICU.UICICRPM CRPM
              USING (
                     SELECT EV.PT_NO 
                          , EV.PT_NM 
                          , EV.SEX_TP_CD 
                          , EV.AGE 
                          , EV.PACT_ID 
                          , EV.ADS_DT 
                          , EV.MED_DEPT_CD
                          , EV.MED_DEPT_CD_NM
                          , EV.PT_CUR_PSTN_CD
                          , EV.PT_CUR_PSTN_NM
                          , EV.SPCT_NM
                          , EV.ANDR_NM
                          , EV.NRS_NM
                          , EV.MAIN_DGNS_DT
                          , EV.MAIN_DGNS_CD
                          , EV.MAIN_DGNS_NM
                          , EV.FSR_DTM
                          , EV.LSH_DTM
                       FROM XICU.EMEI012V EV
                      WHERE ( EV.LSH_DTM BETWEEN IN_BEGIN_DT AND IN_END_DT ) -- 최초 입력시간은 마지막 저장시간과 동일하기 때문에 마지막 저장 시간만 확인하다
                    ) SRC
                 ON (
                          CRPM.PT_NO = SRC.PT_NO 
                      AND CRPM.PACT_ID = SRC.PACT_ID 
                    )
               WHEN MATCHED THEN 
                    UPDATE SET CRPM.PT_NM = SRC.PT_NM 
                             , CRPM.ADS_DT = SRC.ADS_DT 
                             , CRPM.SEX_TP_CD = SRC.SEX_TP_CD
                             , CRPM.AGE = SRC.AGE 
                             , CRPM.LST_LOD_DTM = SYSDATE
               WHEN NOT MATCHED THEN 
                    INSERT ( PACT_ID
                           , HSP_TP_CD
                           , PT_NO
                           , PT_NM
                           , ADS_DT
                           , SEX_TP_CD
                           , AGE
                           , FST_WRT_DTM
                           , LST_CHG_DTM
                           , FST_LOD_DTM
                           , LST_LOD_DTM
                           )
                     VALUES( SRC.PACT_ID 
                           , IN_HSP_TP_CD
                           , SRC.PT_NO 
                           , SRC.PT_NM 
                           , SRC.ADS_DT 
                           , SRC.SEX_TP_CD 
                           , SRC.AGE 
                           , SRC.FSR_DTM 
                           , SRC.LSH_DTM 
                           , SYSDATE 
                           , SYSDATE
                           )
         ;
         XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_BASIC', 'END');
      END;
   END PC_PATIENT_BASIC_INFO;

   /*===================================================================================
   * 서비스이름        : PC_PATIENT_ETRM_CHOT_DTM_INF
   * 최초 작성일       : 2021.03.29
   * 최초 작성자       : 이창우
   * DESCRIPTION : 중환자실 입실 퇴실 시간 정보
   * 변경이력관리
   ===================================================================================*/
   PROCEDURE PC_PATIENT_ETRM_CHOT_DTM_INF
             ( IN_SCHD_EXCT_ID IN VARCHAR2
             , IN_HSP_TP_CD IN VARCHAR2
             , IN_BEGIN_DT  IN DATE 
             , IN_END_DT    IN DATE 
             )
   IS
   BEGIN
      BEGIN
         XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_ETRM_CHOT_DTM_INF', 'BEGIN');
         MERGE INTO HICU.UICICRID CRID
              USING (
                     SELECT CIPT_ETRM_CHOT_ID,     HST_SEQ,              USE_YN,                  LST_YN,         PACT_ID
                          , PACT_TP_CD,            PT_NO,                MED_DEPT_CD,             MED_DEPT_CD_NM, ETRM_DTM
                          , ETRM_WD_DEPT_CD,       ETRM_WD_DEPT_CD_NM,   ETRM_PRM_NO,             ETRM_BED_NO,    EMRG_BED_YN
                          , ISLT_BED_YN,           ICU_ETRM_PATH_CLS_CD, ICU_ETRM_PATH_CLS_CD_NM, CHOT_DTM,       ICU_CHOT_PLC_TP_CD
                          , ICU_CHOT_PLC_TP_CD_NM, CHOT_WD_MTD_CD,       CHOT_WD_MTD_CD_NM,       FST_WRT_DTM,    LST_CHG_DTM
                          , PT_NM,                 ADS_DT,               DS_EXPT_DT, DS_DT,       SEX_TP_CD,      AGE
                          , AGE_MRK_NM,            ADS_PATH_CD,          ADS_PATH_CD_NM,          FST_ACP_DTM,    LST_ACP_DTM
                          , APCN_YN,               RPRN_MED_DEPT_CD,     RPRN_MED_DEPT_CD_NM
                       FROM XICU.EMEI003V EV
                      WHERE ( EV.LST_CHG_DTM BETWEEN IN_BEGIN_DT AND IN_END_DT ) -- 최초 입력시간은 마지막 저장시간과 동일하기 때문에 마지막 저장 시간만 확인하다
                    ) SRC
                 ON (
                     CRID.CIPT_ETRM_CHOT_ID = SRC.CIPT_ETRM_CHOT_ID
                    )
               WHEN MATCHED THEN 
                    UPDATE SET CRID.USE_YN = SRC.USE_YN
                             , CRID.LST_YN = SRC.LST_YN
                             , CRID.MED_DEPT_CD = SRC.MED_DEPT_CD
                             , CRID.MED_DEPT_CD_NM = SRC.MED_DEPT_CD_NM
--                             , RPRN_MED_DEPT_CD
--                             , RPRN_MED_DEPT_CD_NM
                             , CRID.ETRM_DTM = SRC.ETRM_DTM
                             , CRID.ETRM_WD_DEPT_CD = SRC.ETRM_WD_DEPT_CD
                             , CRID.ETRM_WD_DEPT_CD_NM = SRC.ETRM_WD_DEPT_CD_NM
                             , CRID.ETRM_PRM_NO = SRC.ETRM_PRM_NO
                             , CRID.ETRM_BED_NO = SRC.ETRM_BED_NO
                             , CRID.EMRG_BED_YN = SRC.EMRG_BED_YN
                             , CRID.ISLT_BED_YN = SRC.ISLT_BED_YN
                             , CRID.ICU_ETRM_PATH_CLS_CD = SRC.ICU_ETRM_PATH_CLS_CD
                             , CRID.ICU_ETRM_PATH_CLS_CD_NM = SRC.ICU_ETRM_PATH_CLS_CD_NM
                             , CRID.CHOT_DTM = SRC.CHOT_DTM
                             , CRID.ICU_CHOT_PLC_TP_CD = SRC.ICU_CHOT_PLC_TP_CD
                             , CRID.ICU_CHOT_PLC_TP_CD_NM = SRC.ICU_CHOT_PLC_TP_CD_NM
                             , CRID.CHOT_WD_MTD_CD = SRC.CHOT_WD_MTD_CD
                             , CRID.CHOT_WD_MTD_CD_NM = SRC.CHOT_WD_MTD_CD_NM
                             , CRID.FST_WRT_DTM = SRC.FST_WRT_DTM
                             , CRID.LST_CHG_DTM = SRC.LST_CHG_DTM
                             , CRID.LST_LOD_DTM = SYSDATE
               WHEN NOT MATCHED THEN 
                    INSERT ( CIPT_ETRM_CHOT_ID
                           , HSP_TP_CD
                           , HST_SEQ
                           , USE_YN
                           , LST_YN
                           , PACT_ID
                           , PACT_TP_CD
                           , PT_NO
                           , MED_DEPT_CD
                           , MED_DEPT_CD_NM
                           , RPRN_MED_DEPT_CD
                           , RPRN_MED_DEPT_CD_NM
                           , ETRM_DTM
                           , ETRM_WD_DEPT_CD
                           , ETRM_WD_DEPT_CD_NM
                           , ETRM_PRM_NO
                           , ETRM_BED_NO
                           , EMRG_BED_YN
                           , ISLT_BED_YN
                           , ICU_ETRM_PATH_CLS_CD
                           , ICU_ETRM_PATH_CLS_CD_NM
                           , CHOT_DTM
                           , ICU_CHOT_PLC_TP_CD
                           , ICU_CHOT_PLC_TP_CD_NM
                           , CHOT_WD_MTD_CD
                           , CHOT_WD_MTD_CD_NM
                           , FST_WRT_DTM
                           , LST_CHG_DTM
                           , FST_LOD_DTM
                           , LST_LOD_DTM
                           )
                    VALUES ( SRC.CIPT_ETRM_CHOT_ID
                           , IN_HSP_TP_CD
                           , SRC.HST_SEQ
                           , SRC.USE_YN
                           , SRC.LST_YN
                           , SRC.PACT_ID
                           , SRC.PACT_TP_CD
                           , SRC.PT_NO
                           , SRC.MED_DEPT_CD
                           , SRC.MED_DEPT_CD_NM
                           , SRC.RPRN_MED_DEPT_CD
                           , SRC.RPRN_MED_DEPT_CD_NM
                           , SRC.ETRM_DTM
                           , SRC.ETRM_WD_DEPT_CD
                           , SRC.ETRM_WD_DEPT_CD_NM
                           , SRC.ETRM_PRM_NO
                           , SRC.ETRM_BED_NO
                           , SRC.EMRG_BED_YN
                           , SRC.ISLT_BED_YN
                           , SRC.ICU_ETRM_PATH_CLS_CD
                           , SRC.ICU_ETRM_PATH_CLS_CD_NM
                           , SRC.CHOT_DTM
                           , SRC.ICU_CHOT_PLC_TP_CD
                           , SRC.ICU_CHOT_PLC_TP_CD_NM
                           , SRC.CHOT_WD_MTD_CD
                           , SRC.CHOT_WD_MTD_CD_NM
                           , SRC.FST_WRT_DTM
                           , SRC.LST_CHG_DTM
                           , SYSDATE
                           , SYSDATE
                           )
         ;
         BEGIN
            XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_ETRM_CHOT_DETAIL', 'BEGIN');
            FOR LIST_CUR IN (
               SELECT PACT_ID
                    , PT_NO
                    , PT_NM
                    , ADS_DT
                    , DS_EXPT_DT
                    , DS_DT
                    , SEX_TP_CD
                    , AGE
                    , AGE_MRK_NM
                    , ADS_PATH_CD
                    , ADS_PATH_CD_NM
                    , FST_ACP_DTM
                    , LST_ACP_DTM
                    , APCN_YN
                    , RPRN_MED_DEPT_CD
                    , RPRN_MED_DEPT_CD_NM
                 FROM XICU.EMEI003V EV
                WHERE EV.LST_CHG_DTM BETWEEN IN_BEGIN_DT AND IN_END_DT -- 최초 입력시간은 마지막 저장시간과 동일하기 때문에 마지막 저장 시간만 확인하다
            ) LOOP
               UPDATE HICU.UICICRPM CRPM
                  SET CRPM.ADS_PATH_CD = LIST_CUR.ADS_PATH_CD
                    , CRPM.ADS_PATH_CD_NM = LIST_CUR.ADS_PATH_CD_NM
                    , CRPM.ADS_DT = LIST_CUR.ADS_DT
                    , CRPM.DS_EXPT_DT = LIST_CUR.DS_EXPT_DT
                WHERE CRPM.PT_NO = LIST_CUR.PT_NO
                  AND CRPM.PACT_ID = LIST_CUR.PACT_ID;
            END LOOP;
            XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_ETRM_CHOT_DETAIL', 'END');
         END;
      
         XICU.PC_EICU_PCLOG(IN_SCHD_EXCT_ID, 'ODS_PATIENT_ETRM_CHOT_DTM_INF', 'END');
      END;
   END;
END PKG_EICU_ODS;
