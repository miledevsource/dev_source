
  CREATE OR REPLACE EDITIONABLE PACKAGE "XICU"."PKG_EICU_TOT_MANAGE" 
IS 
TYPE RETURNCURSOR IS REF CURSOR;  
      
/*===================================================================================
* 서비스이름      : PC_TOT_HOSP_LST
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION     : 전체 병원 리스트
* 변경이력관리
===================================================================================*/
PROCEDURE PC_TOT_HOSP_LST (     
   OUT_CURSOR                    OUT RETURNCURSOR)
   ;
          
/*===================================================================================
* 서비스이름      : PC_TOT_MANAGE_SYS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION     : 통합관제 시스템
* 변경이력관리
===================================================================================*/
PROCEDURE PC_TOT_MANAGE_SYS (
   IN_HSP_CD                     IN VARCHAR2,     
   OUT_CURSOR                    OUT RETURNCURSOR)
   ;
  
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : 병원별 ICU 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_LIST    ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
                                  ;  
      
/*===================================================================================
* 서비스이름      : PC_EICU_ICU_PT_IO_COUNT
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_PT_IO_COUNT    ( IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                     , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                     , OUT_CURSOR           OUT   RETURNCURSOR )
                                     ;

/*===================================================================================
* 서비스이름      : PC_EICU_TOT_MANSGE_SYS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : 통합관체 시스템 1번 화면
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TOT_MANAGE_SYS    ( OUT_CURSOR_1          OUT   RETURNCURSOR 
                                    , OUT_CURSOR_2          OUT   RETURNCURSOR )
                                    ;               

/*===================================================================================
* 서비스이름      : PC_EICU_TOT_MANSGE_SYS_RRS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : 통합관체 시스템 1번 화면
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TOT_MANAGE_SYS_RRS    ( IN_TM                 IN    VARCHAR2      /* RRS 조회 시간  */
                                        , OUT_CURSOR_1          OUT   RETURNCURSOR 
                                        , OUT_CURSOR_2          OUT   RETURNCURSOR )
                                        ;  
                                        
/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_INFO
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : ICU 중환자실통합현황
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_INFO    ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
                                  ;   

/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_RRS_INFO
* 최초 작성일     : 2021.03
* 최초 작성자     : 이성우
* DESCRIPTION    : ICU 중환자실통합현황 RRS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_RRS_INFO    ( IN_HSP_TP_CD          IN    VARCHAR2      /* 병원구분코드 */ 
                                      , IN_TM               IN    VARCHAR2      /* RRS 조회 시간  */
                                      , OUT_CURSOR          OUT   RETURNCURSOR )
                                      ;                                  
                                      
/*===================================================================================
* 서비스이름      : PC_EICU_ICU_WAVEFORM_PT_LIST
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : ICU 웨이브폼에 표출되는 환자리스트
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_WAVEFORM_PT_LIST ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
                                       , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */ 
                                       , OUT_CURSOR           OUT   RETURNCURSOR )
                                       ;      
                                       
/*=================================================================================== 
* 서비스이름      : PC_EICU_CCTV_PT_STATUS 
* 최초 작성일     : 2021.04 
* 최초 작성자     : 이원희 
* DESCRIPTION    : CCTV 실행여부 및 비대면 협진 상태 확인  
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_EICU_CCTV_PT_STATUS ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */  
							     , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */  
                                 , OUT_CURSOR           OUT   RETURNCURSOR ) 
                                 ;       

/*===================================================================================
* 서비스이름      : PC_EICU_AGENT_LOGIN_HISTORY
* 최초 작성일     : 2021.04
* 최초 작성자     : 이성우
* DESCRIPTION    : Agent 로그인 정보를 이지케어텍 프로시저로 호출
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_AGENT_LOGIN_HISTORY ( IN_HSP_TP_CD          IN  VARCHAR2 -- 병원구분코드
                                     , IN_HIS_STF_NO         IN  VARCHAR2 -- HIS직원번호
                                     , IN_USR_NM             IN  VARCHAR2 -- HIS사용자명
                                     , IN_PRGM_LCLS_CD       IN  VARCHAR2 -- 프로그램대분류코드
                                     , IN_EPCN_YN            IN  VARCHAR2 -- 관제센터여부
                                     , IN_WD_DEPT_CD         IN  VARCHAR2 -- 병동부서코드
                                     , IN_LGIN_DTM           IN  VARCHAR2 -- 로그인 일시
                                     , IN_LGOT_DTM           IN  VARCHAR2 -- 로그아웃 일시
                                     , IN_HIS_PRGM_NM        IN  VARCHAR2 -- 사용프로그램 명
                                     , IN_HIS_IP_ADDR        IN  VARCHAR2 -- 사용자 PC IP 
                                     , IO_ERR_YN             IN OUT VARCHAR2
                                     , IO_ERR_MSG            IN OUT VARCHAR2 )
                                     ;    
                                     
/*=================================================================================== 
* 서비스이름      : IF_PHONE_NUMBER_SEL 
* 최초 작성일     : 2025.12 
* 최초 작성자     : 윤재림 
* DESCRIPTION    : 이송시스템 휴대번호 조회 
* 변경이력관리 
===================================================================================*/         
PROCEDURE IF_PHONE_NUMBER_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
	 												, IN_HSP_TP_CD				IN VARCHAR2
	                        , OUT_CURSOR 		  		OUT SYS_REFCURSOR
          );                 


/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_RRS_COUNT
* 최초 작성일     : 2026.04.14
* 최초 작성자     : 장인수
* DESCRIPTION    : 통합관체 시스템 1번 화면 - 지역의료원에서 사용하는 프로시저로 본사 개발테스트 시 지역병원 프로시저 호출 하도록 임시 적용  
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_RRS_COUNT	( IN_HSP_CD IN VARCHAR2
																																		  , IN_DEPT_CD IN VARCHAR2
																																		  , OUT_CURSOR OUT SYS_REFCURSOR
       																												  ); 


/*===================================================================================
* 서비스이름      : PC_ICU_DEPT_INFO
* 최초 작성일     : 2026.05.28
* 최초 작성자     : KGD
* DESCRIPTION  : ICU 부서리스트 가져오기
* 변경이력관리
===================================================================================*/
PROCEDURE PC_ICU_DEPT_INFO (IN_HSP_TP_CD	IN VARCHAR2
						  , OUT_CURSOR      OUT RETURNCURSOR
);
                                                                              
END PKG_EICU_TOT_MANAGE;
/
CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."PKG_EICU_TOT_MANAGE" 
IS 
  
/*===================================================================================
* 서비스이름      : PC_TOT_HOSP_LST
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION     : 전체 병원 리스트
* 변경이력관리
===================================================================================*/
PROCEDURE PC_TOT_HOSP_LST ( OUT_CURSOR OUT RETURNCURSOR )
IS

BEGIN
    BEGIN
	    OPEN OUT_CURSOR FOR
	        SELECT HSP_TP_CD, HSP_NM, RMK_CNTE AS HSP_RG_NM
			 FROM HICU.UCCOCHPM
			where USE_YN = 'Y'
	        ;  
            
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_TOT_HOSP_LST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_TOT_HOSP_LST;


/*===================================================================================
* 서비스이름      : PC_TOT_MANAGE_SYS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION     : 통합관제 시스템
* 변경이력관리
===================================================================================*/ 
PROCEDURE PC_TOT_MANAGE_SYS   ( IN_HSP_CD                 IN    VARCHAR2      /* 병원코드 */
                              , OUT_CURSOR                OUT   RETURNCURSOR 
                               )    	
IS

BEGIN
    BEGIN
	    OPEN OUT_CURSOR FOR
	        SELECT HSP_CD
				 , HSP_NM
				 , ICU_CNT
				 , TOT_WD_CNT
				 , IN_CNT
				 , EMPT_WD_DNT
				 , ISLT_EMPT_WD_CNT
				 , NGPSSR_EMPT_WD_CNT
				 , TOT_VENT_PT_CNT
		      FROM XICU.EMNI001V
	         WHERE HSP_CD = IN_HSP_CD
	        ;  
            
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_ICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_TOT_MANAGE_SYS; 
            
    
/*===================================================================================
* 서비스이름      : PC_EICU_SEL_ICU_LIST
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : 병원별 ICU 리스트 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_SEL_ICU_LIST    ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )    
IS                                  
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR             
			SELECT HSP_TP_CD
			     , DEPT_CD
			     , DEPT_NM
			     , RMK_CNTE
			  FROM HICU.UCCOCDPM
			 WHERE HSP_TP_CD = IN_HSP_TP_CD
			   AND USE_YN = 'Y'
			 ORDER BY SORT_SEQ
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_SEL_ICU_LIST' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_SEL_ICU_LIST; 
         

/*===================================================================================
* 서비스이름      : PC_EICU_ICU_INFO
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 하만석
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_INFO    (IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                             , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT WD_DEPT_CD       --01. 환자실병동부서코드'
			     , USE_WD_CNT       --03. 사용 병상 수
			     , EMPT_WD_CNT      --04. 공 병상 수
			     , ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)
			     , ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
			     , ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
			     , IN_WD_CNT        --08. 입실예정 환자 수
			     , OUT_WD_CNT       --09. 퇴실예정 환자 수
			     , OP_CNT           --10. 수술 수
			 fROM XICU.EMEI001V   			
           -- WHERE HSP_CD = IN_HSP_TP_CD
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_ICU_PT_IO_COUNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_ICU_INFO;         
   

/*===================================================================================
* 서비스이름      : PC_EICU_ICU_PT_IO_COUNT
* 최초 작성일     : 2021.03.16
* 최초 작성자     : 이원희
* DESCRIPTION    : ICU 당일 병상 현황 및 입실/퇴실 예정 환자 현황 조회
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_PT_IO_COUNT    ( IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */
                                     , IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                     , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT WD_DEPT_CD       --01. 환자실병동부서코드'
			     , USE_WD_CNT       --03. 사용 병상 수
			     , EMPT_WD_CNT      --04. 공 병상 수
			     , ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)
			     , ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
			     , ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
			     , IN_WD_CNT        --08. 입실예정 환자 수
			     , OUT_WD_CNT       --09. 퇴실예정 환자 수
			     , OP_CNT           --10. 수술 수
			 fROM XICU.EMEI001V   			
            WHERE WD_DEPT_CD = IN_WD_DEPT_CD
              -- AND HSP_CD = IN_HSP_TP_CD
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_ICU_PT_IO_COUNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_ICU_PT_IO_COUNT;


/*===================================================================================
* 서비스이름      : PC_EICU_TOT_MANSGE_SYS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : 통합관체 시스템 1번 화면
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TOT_MANAGE_SYS    ( OUT_CURSOR_1          OUT   RETURNCURSOR 
                                    , OUT_CURSOR_2          OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR_1 FOR
            select a.HSP_CD_CMT
			     , a.TOT_WD_CNT
			     , a.EMPT_WD_DNT
			     , a.ISLT_EMPT_WD_CNT
			     , a.TOT_VENT_PT_CNT
			     , (SELECT COUNT(HSP_TP_CD) HSP_TP_CD_CNT
  					  FROM ( SELECT CGPM.EPCN_GRP_NM --권역코드
						          , CGPM.EPCN_GRP_CD
						          , CHRD.HSP_TP_CD
						       FROM HICU.UCCOCGPM CGPM
						          , HICU.UCCOCHRD CHRD
						      WHERE CGPM.EPCN_GRP_CD = 'CTN01'
						        AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD ))  CONN_HSP_CNT
			     , a.ISLT_PT_CNT  ISOL_PT_CNT  
			     ,  nvl((SELECT COUNT(*)
																  FROM LOG_EZOTC_EICU
																 WHERE 1=1
																   AND CALLSTARTTIME BETWEEN TRUNC(SYSDATE) -1  AND TRUNC(SYSDATE) + 0.99999
																   AND CALLENDTIME   BETWEEN TRUNC(SYSDATE) -1 AND TRUNC(SYSDATE) + 0.99999
																   AND CALLENDTIME   IS NOT NULL ), 0)        NON_VIEW_CLINIC     -- 20260519 JIS 이지온더콜 당일 건수 조회 수정 
--			     , nvl((select sum(WHL_CSLT_CNT) WHL_CSLT_CNT
--						 From hicu.ucoscnsd
--						where untc_rec_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')), 0) NON_VIEW_CLINIC
			     , (select count(pt_no)
							  from (select distinct pt_no
							  		  from HICU.RRS_VALUE r
                                         , HICU.UCCOCDPM d
								     WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
									   and d.HSP_TP_CD = r.HSP_TP_CD
									   and d.DEPT_CD = r.WARD_NO
						   		       and d.USE_YN = 'Y'  ) )     RRS_PT_CNT
				   , NVL((select sum(cnt)
						        from (select count(rrs_item_cd) cnt
						                from HICU.RRS_VALUE r
                                           , HICU.UCCOCDPM d
						               WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
										 and d.HSP_TP_CD = r.HSP_TP_CD
										 and d.DEPT_CD = r.WARD_NO
							   		     and d.USE_YN = 'Y'
						               group by r.pt_no)), 0)                           RRS_ITEM_CNT
			from (
			select count(ai.HSP_CD)      HSP_CD_CMT -- 전체병원 수
			     , SUM(ai.TOT_WD_CNT)    TOT_WD_CNT -- 전체 병상 수
			     , SUM(ai.EMPT_WD_DNT)   EMPT_WD_DNT -- 전체 공병상 수
			     , SUM(ai.ISLT_EMPT_WD_CNT) ISLT_EMPT_WD_CNT -- 격리 공병상 수
			     , sum(ai.TOT_VENT_PT_CNT)  TOT_VENT_PT_CNT  -- 인공호흡기 적용 환자 수
                 , sum(ai.ISLT_PT_CNT)    ISLT_PT_CNT
			from (
				select HSP_CD
				     , TOT_WD_CNT          --04. 중환자실 전체 병상 수
				     , EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
				     , ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
				     , TOT_VENT_PT_CNT     --09. 중환자실 내 인공호흡기 적용 환자 수  
                     , ISLT_PT_CNT
				from xicu.EMNI001V
			) ai
			) a
			;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_1' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
    END;
    
    BEGIN            
    	OPEN OUT_CURSOR_2 FOR  
    		select v.HSP_CD              
    		     , h.HSP_NM
			     , v.ICU_CNT             --03. 중환자실 수
			     , v.TOT_WD_CNT          --04. 중환자실 전체 병상 수
			     , v.IN_CNT              --05. 중환자실 전체 입원환자 수
			     , v.EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
			     , v.ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
			     , v.NGPSSR_EMPT_WD_CNT  --08. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
			     , ROUND( ((v.IN_CNT / v.TOT_WD_CNT ) * 100), 2)  WORKING_PER  -- 병상가동률
			from xicu.EMNI001V v
			  , (select hsp_tp_cd
					  , hsp_nm
			       from HICU.UCCOCHPM
			      where USE_YN = 'Y'  ) h
			where v.HSP_CD = h.hsp_tp_cd  
			;  
		EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_2' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;      
    END;
END PC_EICU_TOT_MANAGE_SYS;



/*===================================================================================
* 서비스이름      : PC_EICU_TOT_MANSGE_SYS_RRS
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : 통합관체 시스템 1번 화면
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_TOT_MANAGE_SYS_RRS    ( IN_TM                 IN    VARCHAR2      /* RRS 조회 시간  */
                                        , OUT_CURSOR_1          OUT   RETURNCURSOR 
                                        , OUT_CURSOR_2          OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR_1 FOR
            select SUBSTR(XMLAGG(XMLELEMENT(TITLE, '|'||TITLE) ORDER BY 1).EXTRACT('//text()').GETSTRINGVAL(), 2) AS TITLE  FROM (
--				select '미확인(확인)' || '^' || sum(I_CNT)|| '(' ||sum(C_CNT) ||')' TITLE
--				 from (
--				select DECODE(RRS_STATE_CD, 'I', 1, 0) I_CNT
--				     , DECODE(RRS_STATE_CD, 'I', 0, 1) C_CNT
--				from HICU.rrs_value r
--                   , HICU.UCCOCDPM d
--				where ent_dt = to_char(sysdate, 'yyyymmdd')  
--  				  and d.USE_YN = 'Y'
--			      and r.HSP_TP_CD = d.HSP_TP_CD
--			      and r.WARD_NO = D.dept_cd
--				)
--				UNION
				select H.hsp_nm || '^' || COUNT(R.RRS_ITEM_CD) TITLE
				from hicu.rrs_value  R
				   , HICU.UCCOCHPM H
                   , HICU.UCCOCDPM d
				where R.HSP_TP_CD = H.hsp_tp_cd
				  and R.ent_dt = to_char(sysdate, 'yyyymmdd')  
				  and h.USE_YN = 'Y' 
				  and d.USE_YN = 'Y'
			      and r.HSP_TP_CD = d.HSP_TP_CD  
			      and r.WARD_NO = D.dept_cd
				GROUP BY H.hsp_nm
				  )
				;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_RRS_1' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
    END;
    
    BEGIN            
    	OPEN OUT_CURSOR_2 FOR  
    		SELECT IN_DTM, hsp_nm, LOC, DETL_CD_NM
    	         , RRS_VALUE || case when LH_VALUE = 'H' THEN ' ↑'
                                     when LH_VALUE = 'L' THEN ' ↓'
                                     ELSE '' END  RRS_VALUE
                 , LH_VALUE 
              FROM (
		    		SELECT to_char(ENT_DTM, 'mm-dd hh24:mi') IN_DTM
					     , h.hsp_nm
					     , a.WARD_NO || ' / ' || A.BED_NO LOC
					     , c.DETL_CD_NM
					     , nvl(a.CUR_VALUE, a.RRS_VALUE) RRS_VALUE
					     , case when to_number(nvl(cd.MAX_VAL, '9999'))  < to_number(NVL(a.CUR_VALUE, a.RRS_VALUE))  then 'H'
		                        when to_number(nvl(cd.MIN_VAL, '-9999')) > to_number( NVL(a.CUR_VALUE, a.RRS_VALUE)) then 'L'
		                        else 'N' end LH_VALUE
					FROM HICU.RRS_VALUE a
					   , (select HSP_TP_CD
					           , DETL_CD_NM
								     , DETL_CD_1
									from HICU.RRS_DETAIL
									WHERE MSTR_CD = 'VITAL' ) C
					   , (select hsp_tp_cd
								     , hsp_nm
								from HICU.UCCOCHPM
					           where USE_YN = 'Y'  ) h    
					   , HICU.UCCOCDPM d        
					   , (select MAX_VAL, MIN_VAL, DEPT_CD, ITEM_CD, HSP_TP_CD
		                   from HICU.RRS_ITEM_STD
		                  where mstr_Cd = 'VITAL'
		                    and AGE_GRP = 'A'
		                    and HIST_SEQ = 0) cd
					where a.ent_dt = to_char(sysdate, 'yyyymmdd')
					  AND a.ENT_DTM >= SYSDATE  - (1 / 24) * TO_NUMBER(NVL(IN_TM, '1'))
					  and a.rrs_item_cd = c.detl_cd_1
					  and a.HSP_TP_CD = c.HSP_TP_CD
					  and a.HSP_TP_CD = h.HSP_TP_CD    
					  and d.HSP_TP_CD = h.HSP_TP_CD
					  and d.DEPT_CD = a.WARD_NO
		   		      and d.USE_YN = 'Y'        
		   		      and a.HSP_TP_CD = cd.HSP_TP_CD
		   		      and a.WARD_NO = cd.DEPT_CD
                      and a.RRS_ITEM_CD = cd.ITEM_CD
		   		      ) tot
		   		where tot.LH_VALUE <> 'N'
			order by 1 desc   			  
			;   
			
		EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_RRS_2' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;      
    END;
END PC_EICU_TOT_MANAGE_SYS_RRS;
              

/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_INFO
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : ICU 중환자실통합현황
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_INFO    ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */
                                  , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR            
			WITH MAIN AS (
				select a.*
				  FROM HICU.UICICSPM A --중환자실환자지표기본
				WHERE A.HSP_TP_CD = IN_HSP_TP_CD --병원구분코드
			),
			--입실환자
			NEW_IN_DATA AS (
				SELECT NVL(SUM(DECODE(A.ICU_ETRM_PATH_CLS_CD, '02', 1)), 0) CNT_NEWIN /* 신입(입원)환자수 */ --중환자실입실경로유형
				     , NVL(SUM(DECODE(A.ICU_ETRM_PATH_CLS_CD, '01', 1)), 0) CNT_MOVEIN /* 전입환자수 */
				     , A.ETRM_WD_DEPT_CD
				  FROM MAIN A --중환자실환자지표기본
				 WHERE TRUNC(A.ETRM_DTM) = TRUNC(sysdate)
				 GROUP BY A.ETRM_WD_DEPT_CD
			),
			--퇴실환자
			CHOT_DATA AS(
				SELECT NVL(SUM(1), 0) CNT_OUT /* 퇴실환자수*/
			         , A.ETRM_WD_DEPT_CD
				  FROM MAIN A
				 WHERE TRUNC(A.CHOT_DTM) = TRUNC(sysdate)
				 GROUP BY A.ETRM_WD_DEPT_CD
			)
			select a.HSP_TP_CD
			     , a.DEPT_CD
			     , a.RMK_CNTE
			     , nvl((i.CNT_NEWIN + i.CNT_MOVEIN), 0) in_cnt
			     , nvl(o.CNT_OUT, 0) o_cnt
			     , USE_WD_CNT
			     , EMPT_WD_CNT
			     , ISLT_EMPT_WD_CNT
			     , nvl(r.cnt, 0) RRS_CNT
			from hicu.UCCOCDPM a
			   , NEW_IN_DATA i
			   , CHOT_DATA o
			   , (select WD_DEPT_CD, USE_WD_CNT, EMPT_WD_CNT, ISLT_EMPT_WD_CNT
			        from XICU.EMEI001V) v
			   , (select count(pt_no) cnt, ward_no
							from (
							select distinct pt_no, ward_no
							from hicu.rrs_value
							where hsp_tp_cd = IN_HSP_TP_CD
							and ent_Dt = TO_CHAR(sysdate,'yyyymmdd')
							)
							group by ward_no) r
			where a.hsp_tp_cd = IN_HSP_TP_CD
			and a.use_yn = 'Y'
			and a.DEPT_CD = i.ETRM_WD_DEPT_CD(+)
			and a.DEPT_CD = o.ETRM_WD_DEPT_CD(+)
			and a.DEPT_CD = v.WD_DEPT_CD(+)
			and a.DEPT_CD = r.ward_no(+)
			order by a.sort_seq
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_ICU_TOT_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_ICU_TOT_INFO;
        
/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_RRS_INFO
* 최초 작성일     : 2021.03
* 최초 작성자     : 이성우
* DESCRIPTION    : ICU 중환자실통합현황 RRS
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_RRS_INFO    ( IN_HSP_TP_CD          IN    VARCHAR2      /* 병원구분코드 */ 
										, IN_TM               IN    VARCHAR2      /* RRS 조회 시간  */
                                        , OUT_CURSOR          OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN            
    	OPEN OUT_CURSOR FOR  
    	    SELECT IN_DTM, hsp_nm, LOC, DETL_CD_NM
    	         , RRS_VALUE || case when LH_VALUE = 'H' THEN ' ↑'
                                     when LH_VALUE = 'L' THEN ' ↓'
                                     ELSE '' END  RRS_VALUE
                 , LH_VALUE 
              FROM (
		    		SELECT to_char(ENT_DTM, 'mm-dd hh24:mi') IN_DTM
					     , h.hsp_nm
					     , a.WARD_NO || ' / ' || A.BED_NO LOC
					     , c.DETL_CD_NM
					     , nvl(a.CUR_VALUE, a.RRS_VALUE) RRS_VALUE 
					     , case when to_number(nvl(cd.MAX_VAL, '9999'))  < to_number(NVL(a.CUR_VALUE, a.RRS_VALUE))  then 'H'
		                        when to_number(nvl(cd.MIN_VAL, '-9999')) > to_number( NVL(a.CUR_VALUE, a.RRS_VALUE)) then 'L'
		                        else 'N' end LH_VALUE
					FROM HICU.RRS_VALUE a
					   , (select HSP_TP_CD
					           , DETL_CD_NM
								     , DETL_CD_1
									from HICU.RRS_DETAIL
									WHERE MSTR_CD = 'VITAL' ) C
					   , (select hsp_tp_cd
								     , hsp_nm
								from HICU.UCCOCHPM
					           where USE_YN = 'Y'  ) h
					   , HICU.UCCOCDPM d     
					   , (select MAX_VAL, MIN_VAL, DEPT_CD, ITEM_CD
		                   from HICU.RRS_ITEM_STD
		                  where mstr_Cd = 'VITAL'
		                    and HSP_TP_CD = IN_HSP_TP_CD
		                    and AGE_GRP = 'A'
		                    and HIST_SEQ = 0) cd
					where a.ent_dt = to_char(sysdate, 'yyyymmdd')
					  AND a.ENT_DTM >= SYSDATE  - (1 / 24) * TO_NUMBER(NVL(IN_TM, '1'))   
					  and a.rrs_item_cd = c.detl_cd_1
					  and a.HSP_TP_CD = IN_HSP_TP_CD
					  and a.HSP_TP_CD = c.HSP_TP_CD
					  and a.HSP_TP_CD = h.HSP_TP_CD    
					  and d.HSP_TP_CD = h.HSP_TP_CD
					  and d.DEPT_CD = a.WARD_NO
		   		      and d.USE_YN = 'Y'
		   		      and a.WARD_NO = cd.DEPT_CD
                      and a.RRS_ITEM_CD = cd.ITEM_CD
		   		      ) tot
		   		where tot.LH_VALUE <> 'N'
			order by 1 desc
			;   
			
		EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_ICU_TOT_RRS_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;      
    END;
END PC_EICU_ICU_TOT_RRS_INFO;

/*===================================================================================
* 서비스이름      : PC_EICU_ICU_WAVEFORM_PT_LIST
* 최초 작성일     : 2021.03
* 최초 작성자     : 하만석
* DESCRIPTION    : ICU 웨이브폼에 표출되는 환자리스트
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_WAVEFORM_PT_LIST ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
                                       , IN_WD_DEPT_CD        IN    VARCHAR2      /* 중환자실코드 */ 
                                       , OUT_CURSOR           OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR FOR
            SELECT DISTINCT
			       Z.PT_NO               PT_NO
			     -- , Z.PACT_ID
			     , A.PT_NM               PT_NM
			     , Z.CLCTN_WD_DEPT_CD    WD_DEPT_CD
			     -- , ( SELECT DEPT_NM FROM PDEDBMSM WHERE DEPT_CD = Z.CLCTN_WD_DEPT_CD )  WD_DEPT_NM
			     , Z.CLCTN_BED_NO              BED_NO
			    FROM ( SELECT  *
			           FROM ACPPRAAM  Z
--			              , HICU.UCCOCDPM E
			          WHERE Z.SIHS_YN = 'Y'
			            AND Z.APCN_YN = 'N'     --접수취소여부
			            AND Z.APCN_DTM IS NULL
--			            AND Z.CLCTN_WD_DEPT_CD = E.DEPT_CD
			            AND Z.CLCTN_WD_DEPT_CD = IN_WD_DEPT_CD
			            AND Z.HSP_TP_cD = IN_HSP_TP_CD
			            AND NVL(Z.DS_EXPT_DT, SYSDATE) >= TRUNC(SYSDATE) ) Z
			     , PCTPCPAM_DAMO A
			 WHERE Z.PT_NO = A.PT_NO
			 ORDER BY BED_NO
          ;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_ICU_PT_IO_COUNT' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_EICU_ICU_WAVEFORM_PT_LIST;

/*=================================================================================== 
* 서비스이름      : PC_EICU_CCTV_PT_STATUS 
* 최초 작성일     : 2021.04 
* 최초 작성자     : 이원희 
* DESCRIPTION    : CCTV 실행여부 및 비대면 협진 상태 확인  
* 변경이력관리 
===================================================================================*/ 
PROCEDURE PC_EICU_CCTV_PT_STATUS ( IN_HSP_TP_CD         IN    VARCHAR2      /* 병원구분코드 */ 
							     , IN_PT_NO             IN    VARCHAR2      /* 환자번호 */  
                                 , OUT_CURSOR           OUT   RETURNCURSOR ) 
IS 
    V_SRCH_CNTE          VARCHAR2(4000); 
BEGIN 
    BEGIN    
		select COUNT(*) TOTALCOUNT
  			  INTO V_SRCH_CNTE
		  from LOG_EZOTC_EICU a
		 where 1=1
		   and a.CALLSTARTTIME IS NOT NULL
		   and a.CALLENDTIME IS NULL
		   and a.PATIENTNUMBER IS NOT NULL
		   and a.HOSPITALCODE = IN_HSP_TP_CD
		   and a.PATIENTNUMBER = NVL(IN_PT_NO, a.PATIENTNUMBER)
         	;
			
			BEGIN
			IF V_SRCH_CNTE > 1 AND IN_PT_NO IS NULL THEN
			    RETURN;
			ELSE
				BEGIN
				    OPEN OUT_CURSOR FOR  
				    select * from
					(
						select
						       a.CALLSTARTTIME
						     , a.CALLENDTIME
						     , a.PATIENTNUMBER
						     , a.ICU
						     , decode(a.CALLENDTIME, null, 'Y', 'N') checkcall
				             , p.PT_NM
				             , C.CLCTN_BED_NO
						     --, (select PT_NM from PCTPCPAM_DAMO where 1=1 and pt_no = a.PATIENTNUMBER) PT_NM
						     --, (select BED_NO from ACPPRAAM where 1=1 and pt_no = a.PATIENTNUMBER AND WD_DEPT_CD = a.ICU AND DS_DTM IS NULL) BED_NO
	                         , p.SEX_TP_CD                                                                              --성별구분코드
                       	     , MONTHS_BETWEEN(TRUNC(SYSDATE,'YEAR'),TRUNC(p.PT_BRDY_DT,'YEAR')) /12 +1 AS age           --환자만나이
						  from LOG_EZOTC_EICU a
						     , PCTPCPAM_DAMO p
						     , ACPPRAAM c
						 where a.CALLSTARTTIME IS NOT NULL
--						   and a.CALLENDTIME IS NULL
						   and a.PATIENTNUMBER IS NOT NULL 
						   and a.HOSPITALCODE = IN_HSP_TP_CD
						   and a.PATIENTNUMBER = NVL(IN_PT_NO, a.PATIENTNUMBER)
						   and p.pt_no = a.PATIENTNUMBER
						   and c.pt_no = a.PATIENTNUMBER
						   and c.WD_DEPT_CD = a.ICU
						   and c.DS_DTM IS NULL
						   and c.SIHS_YN = 'Y'
				           and c.APCN_YN = 'N'
						 order by a.CALLSTARTTIME DESC
					) b
					where rownum <= 1
					;
			    END;
			END IF;
			END;

        EXCEPTION  --예외처리 
            WHEN OTHERS THEN 
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_CCTV_PT_STATUS' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
    END; 
END PC_EICU_CCTV_PT_STATUS;  
      
/*===================================================================================
* 서비스이름      : PC_EICU_AGENT_LOGIN_HISTORY
* 최초 작성일     : 2021.04
* 최초 작성자     : 이성우
* DESCRIPTION    : Agent 로그인 정보를 이지케어텍 프로시저로 오출
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_AGENT_LOGIN_HISTORY ( IN_HSP_TP_CD          IN  VARCHAR2 -- 병원구분코드
                                     , IN_HIS_STF_NO         IN  VARCHAR2 -- HIS직원번호
                                     , IN_USR_NM             IN  VARCHAR2 -- HIS사용자명
                                     , IN_PRGM_LCLS_CD       IN  VARCHAR2 -- 프로그램대분류코드
                                     , IN_EPCN_YN            IN  VARCHAR2 -- 관제센터여부
                                     , IN_WD_DEPT_CD         IN  VARCHAR2 -- 병동부서코드
                                     , IN_LGIN_DTM           IN  VARCHAR2 -- 로그인 일시
                                     , IN_LGOT_DTM           IN  VARCHAR2 -- 로그아웃 일시
                                     , IN_HIS_PRGM_NM        IN  VARCHAR2 -- 사용프로그램 명
                                     , IN_HIS_IP_ADDR        IN  VARCHAR2 -- 사용자 PC IP 
                                     , IO_ERR_YN             IN OUT VARCHAR2
                                     , IO_ERR_MSG            IN OUT VARCHAR2 )
IS
BEGIN
    BEGIN 
	    XICU.PC_EICU_SAVE_LOGIN_HISTORY( IN_HSP_TP_CD
	                                        , IN_HIS_STF_NO
	                                        , IN_USR_NM
	                                        , IN_PRGM_LCLS_CD
	                                        , IN_EPCN_YN
	                                        , IN_WD_DEPT_CD
	                                        , TO_DATE(IN_LGIN_DTM, 'yyyy-mm-dd hh24:mi:ss')
	                                        , TO_DATE(IN_LGOT_DTM, 'yyyy-mm-dd hh24:mi:ss')
	                                        , IN_HIS_PRGM_NM
	                                        , IN_HIS_IP_ADDR
	                                        , IO_ERR_YN
	                                        , IO_ERR_MSG)
	                                        ;
            
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_AGENT_LOGIN_HISTORY' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END; 
               
END PC_EICU_AGENT_LOGIN_HISTORY;  


/**********************************************************************************************
*    SERVICENAME    : IF_PHONE_NUMBER_SEL
*    CREATEDATE     : 2025.12.01
*    Author         : 윤재림
*    Description    : 휴대번호 조회 
*    Change History :
**********************************************************************************************/
PROCEDURE IF_PHONE_NUMBER_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
	                        , IN_HSP_TP_CD		  	IN VARCHAR2
													, OUT_CURSOR					OUT SYS_REFCURSOR
	)
	IS
	BEGIN
		OPEN OUT_CURSOR FOR
	  SELECT
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_1' THEN COMN_CD_NM END) AS PHONE_NUMBER_1,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_2' THEN COMN_CD_NM END) AS PHONE_NUMBER_2,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_3' THEN COMN_CD_NM END) AS PHONE_NUMBER_3,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_4' THEN COMN_CD_NM END) AS PHONE_NUMBER_4,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_5' THEN COMN_CD_NM END) AS PHONE_NUMBER_5
		FROM HICU.UCCOCSTE
		WHERE COMN_GRP_CD = 'ICTEL'
		  AND COMN_CD IN (
		        'PHONE_NUMBER_1',
		        'PHONE_NUMBER_2',
		        'PHONE_NUMBER_3',
		        'PHONE_NUMBER_4',
		        'PHONE_NUMBER_5'
	  );
END IF_PHONE_NUMBER_SEL;

        
/*===================================================================================
* 서비스이름      : PC_EICU_TOT_MANSGE_SYS_NUH
* 최초 작성일     : 2025.12
* 최초 작성자     : 
* DESCRIPTION    : 통합관체 시스템 1번 화면
* 변경이력관리
===================================================================================*/

PROCEDURE PC_EICU_TOT_MANAGE_SYS_NUH    ( OUT_CURSOR_1          OUT   RETURNCURSOR 
                                    , OUT_CURSOR_2          OUT   RETURNCURSOR )
IS
    V_SRCH_CNTE          VARCHAR2(4000);
BEGIN
    BEGIN
       OPEN OUT_CURSOR_1 FOR
            select a.HSP_CD_CMT
			     , a.TOT_WD_CNT
			     , a.EMPT_WD_DNT
			     , a.ISLT_EMPT_WD_CNT
			     , a.TOT_VENT_PT_CNT
			     , (SELECT COUNT(HSP_TP_CD) HSP_TP_CD_CNT
  					  FROM ( SELECT CGPM.EPCN_GRP_NM --권역코드
						          , CGPM.EPCN_GRP_CD
						          , CHRD.HSP_TP_CD
						       FROM HICU.UCCOCGPM CGPM
						          , HICU.UCCOCHRD CHRD
						      WHERE CGPM.EPCN_GRP_CD = 'CTN01'
						        AND CGPM.EPCN_GRP_CD = CHRD.EPCN_GRP_CD ))  CONN_HSP_CNT
			     , a.ISLT_PT_CNT  ISOL_PT_CNT
			     , nvl((select sum(WHL_CSLT_CNT) WHL_CSLT_CNT
						 From hicu.ucoscnsd
						where untc_rec_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')), 0) NON_VIEW_CLINIC
			     , (select count(pt_no)
							  from (select distinct pt_no
							  		  from HICU.RRS_VALUE r
                                         , HICU.UCCOCDPM d
								     WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
									   and d.HSP_TP_CD = r.HSP_TP_CD
									   and d.DEPT_CD = r.WARD_NO
						   		       and d.USE_YN = 'Y'  ) )     RRS_PT_CNT
				   , NVL((select sum(cnt)
						        from (select count(rrs_item_cd) cnt
						                from HICU.RRS_VALUE r
                                           , HICU.UCCOCDPM d
						               WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
										 and d.HSP_TP_CD = r.HSP_TP_CD
										 and d.DEPT_CD = r.WARD_NO
							   		     and d.USE_YN = 'Y'
						               group by r.pt_no)), 0)                           RRS_ITEM_CNT
			from (
			select count(ai.HSP_CD)      HSP_CD_CMT -- 전체병원 수
			     , SUM(ai.TOT_WD_CNT)    TOT_WD_CNT -- 전체 병상 수
			     , SUM(ai.EMPT_WD_DNT)   EMPT_WD_DNT -- 전체 공병상 수
			     , SUM(ai.ISLT_EMPT_WD_CNT) ISLT_EMPT_WD_CNT -- 격리 공병상 수
			     , sum(ai.TOT_VENT_PT_CNT)  TOT_VENT_PT_CNT  -- 인공호흡기 적용 환자 수
                 , sum(ai.ISLT_PT_CNT)    ISLT_PT_CNT
			from (
				select HSP_CD
				     , TOT_WD_CNT          --04. 중환자실 전체 병상 수
				     , EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
				     , ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
				     , TOT_VENT_PT_CNT     --09. 중환자실 내 인공호흡기 적용 환자 수  
                     , ISLT_PT_CNT
				from xicu.TEST001V
			) ai
			) a
			;
        
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_1' || ' ERRCODE = ' || SQLCODE || SQLERRM) ; 
    END;
    
    BEGIN            
    	OPEN OUT_CURSOR_2 FOR  
    		select v.HSP_CD              
    		     , h.HSP_NM
			     , v.ICU_CNT             --03. 중환자실 수
			     , v.TOT_WD_CNT          --04. 중환자실 전체 병상 수
			     , v.IN_CNT              --05. 중환자실 전체 입원환자 수
			     , v.EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
			     , v.ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
			     , v.NGPSSR_EMPT_WD_CNT  --08. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
			     , ROUND( ((v.IN_CNT / v.TOT_WD_CNT ) * 100), 2)  WORKING_PER  -- 병상가동률
			from xicu.TEST001V v
			  , (select hsp_tp_cd
					  , hsp_nm
			       from HICU.UCCOCHPM
			      where USE_YN = 'Y'  ) h
			where v.HSP_CD = h.hsp_tp_cd  
			;  
		EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_EICU_TOT_MANSGE_SYS_2' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;      
    END;
END PC_EICU_TOT_MANAGE_SYS_NUH;   
                                   
         
/*===================================================================================
* 서비스이름      : PC_EICU_ICU_TOT_RRS_COUNT
* 최초 작성일     : 2026.04.14
* 최초 작성자     : 장인수
* DESCRIPTION    : 통합관체 시스템 1번 화면 - 지역의료원에서 사용하는 프로시저로 본사 개발테스트 시 지역병원 프로시저 호출 하도록 임시 적용  
* 변경이력관리
===================================================================================*/
PROCEDURE PC_EICU_ICU_TOT_RRS_COUNT
(
  IN_HSP_CD IN VARCHAR2
  , IN_DEPT_CD IN VARCHAR2
  , OUT_CURSOR OUT SYS_REFCURSOR
) 
IS
 BEGIN 
 OPEN OUT_CURSOR FOR
    SELECT COUNT(pt_no) RRS_CNT
    FROM (
        SELECT DISTINCT pt_no
        FROM HICU.RRS_VALUE r,
             HICU.UCCOCDPM d
        WHERE r.ent_dt = TO_CHAR(SYSDATE, 'YYYYMMDD')
          AND r.hsp_tp_cd = IN_HSP_CD
          AND r.ward_no = IN_DEPT_CD 
          AND d.HSP_TP_CD = r.HSP_TP_CD
          AND d.DEPT_CD = r.WARD_NO
          AND d.USE_YN = 'Y'
    );  		       
END PC_EICU_ICU_TOT_RRS_COUNT;

/*===================================================================================
* 서비스이름      : PC_ICU_DEPT_INFO
* 최초 작성일     : 2026.05.28
* 최초 작성자     : KGD
* DESCRIPTION  : ICU 부서리스트 가져오기
* 변경이력관리
===================================================================================*/
PROCEDURE PC_ICU_DEPT_INFO( IN_HSP_TP_CD              IN    VARCHAR2      /* 병원코드 */
                          , OUT_CURSOR                OUT   RETURNCURSOR 
)    	
IS

BEGIN
    BEGIN
	    OPEN OUT_CURSOR FOR
	    	SELECT B.COMN_CD		AS DEPT_CD
     			 , B.COMN_CD_NM		AS WARD_NM
			  FROM HICU.UCCOCLTC A
			 INNER JOIN HICU.UCCOCSTE B
			    ON A.COMN_GRP_CD = B.COMN_GRP_CD
			   AND A.HSP_TP_CD = B.HSP_TP_CD
			 WHERE A.COMN_GRP_CD ='002'
			   AND A.HSP_TP_CD ='01'
			   AND B.DTRL1_NM ='Y'		-- WaveForm, cctv용
			   ORDER BY B.SORT_SEQ
	           ;  
            
        EXCEPTION  --예외처리
            WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20553, 'PC_ICU_DEPT_INFO' || ' ERRCODE = ' || SQLCODE || SQLERRM) ;
    END;
END PC_ICU_DEPT_INFO;  

END PKG_EICU_TOT_MANAGE;
