
  CREATE OR REPLACE EDITIONABLE PACKAGE BODY "XICU"."IFARPA_PACK" IS

/***********************************************************************************
 *    서비스이름  : XICU.IFARPA_PACK
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION : EICU 협진 이송시스템  
 **********************************************************************************/
-- /* 로그 */
--  PROCEDURE LOGGING ( TBLOG IN OUT IF_ACESLOG%ROWTYPE    );

--  FUNCTION READ_DGNSNM(P_RECPNO IN NUMBER) RETURN VARCHAR2;
--    
--  FUNCTION READ_KTAS(P_RECPNO IN NUMBER) RETURN VARCHAR2;
--
--  FUNCTION READ_AVPU(P_RECPNO IN NUMBER) RETURN VARCHAR2;
--  FUNCTION READ_CMMNCD(P_COMKDCD IN VARCHAR2, P_CDNM IN VARCHAR2) RETURN VARCHAR2;
--  FUNCTION READ_CMMNNM(P_COMKDCD IN VARCHAR2, P_CD IN VARCHAR2) RETURN VARCHAR2;   




/**********************************************************************************************
*    SERVICENAME    : IF_PT_INFO_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 환자 조회
*    Change History : 2025.07.16, 장인수, 최초작성
**********************************************************************************************/    
PROCEDURE      IF_PT_INFO_SEL( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
                          , IN_SEARCH_INFO      IN  VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS

BEGIN
    OPEN OUT_CURSOR FOR
				   SELECT T.HSP_TP_CD
               , T.HSP_NM
               , T.PT_NM
               , T.PT_NO
               , T.PT_BIRTH
               , T.PT_AGE
               , T.SEX_TP_CD
               , T.DEPT_CD
               , T.DEPT_NM
               , T.PACT_ID
           FROM (SELECT DECODE(C.HSP_TP_CD,'01','ansung','02','icheon','03','pocheon')  HSP_TP_CD
--                  , C.HSP_TP_CD
                          , DECODE(C.HSP_TP_CD,'01','경기도의료원 안성병원','02','경기도의료원 이천병원','03','경기도의료원 포천병원') HSP_NM
                          , A.PT_NM
                          , C.PT_NO
                          , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
                          , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
                          , A.SEX_TP_CD
                          , C.MED_DEPT_CD DEPT_CD
                          , (SELECT DEPT_NM
                               FROM PDEDBMSM
                              WHERE DEPT_CD = C.MED_DEPT_CD
--                                AND HSP_TP_CD = C.HSP_TP_CD  icheon, ansung, pocheon eicu 사용적합성 평가로 인해 주석 20251022 장인수 
                                 ) DEPT_NM
                  , C.PACT_ID
                   FROM PCTPCPAM_DAMO A
                      , ACPPRETM C
                  WHERE A.PT_NO     = c.PT_NO
                    AND C.SIHS_YN   = 'Y'
                    AND C.APCN_YN   = 'N'
                    AND ( A.PT_NM like '%'||IN_SEARCH_INFO||'%'  OR IN_SEARCH_INFO = C.PT_NO ) ) T
            WHERE 1=1
              AND T.HSP_TP_CD = IN_HSP_TP_CD

       UNION

           SELECT T.HSP_TP_CD
                     , T.HSP_NM
                     , T.PT_NM
                     , T.PT_NO
                     , T.PT_BIRTH
                     , T.PT_AGE
                     , T.SEX_TP_CD
                     , T.DEPT_CD
                     , T.DEPT_NM
                     , T.PACT_ID
                 FROM (SELECT DECODE(C.HSP_TP_CD,'01','icheon','02','icheon','03','pocheon')  HSP_TP_CD
                            , DECODE(C.HSP_TP_CD,'01','경기도의료원 이천병원','02','경기도의료원 이천병원','03','경기도의료원 포천병원') HSP_NM
                            , A.PT_NM
                            , C.PT_NO
                            , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
                            , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
                            , A.SEX_TP_CD
                            , C.MED_DEPT_CD DEPT_CD
                            , (SELECT DEPT_NM
                                 FROM PDEDBMSM
                                WHERE DEPT_CD = C.MED_DEPT_CD 
--                                  AND HSP_TP_CD = C.HSP_TP_CD  icheon, ansung, pocheon eicu 사용적합성 평가로 인해 주석 20251022 장인수 
                                  ) DEPT_NM
                           , C.PACT_ID
                       FROM PCTPCPAM_DAMO A
                           , ACPPRAAM C
                      WHERE A.PT_NO     = c.PT_NO
                        AND C.SIHS_YN   = 'Y'
                        AND C.APCN_YN   = 'N'
                        AND C.TWRM_WD_DEPT_CD IN ('CICU','NICU','DICU','MICU','EICU','NCU','OICU','EICU2')
                        AND ( A.PT_NM like '%'||IN_SEARCH_INFO||'%' OR IN_SEARCH_INFO = C.PT_NO )) T
               WHERE 1=1
                 AND T.HSP_TP_CD = IN_HSP_TP_CD;


END IF_PT_INFO_SEL;


/**********************************************************************************************
*    SERVICENAME    : PC_PT_TRNF_INS
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송환자 등록
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/                        
PROCEDURE IF_PT_TRNF_INS (
                             IN_VNDR              IN  VARCHAR2
                           , IN_CLNTIP            IN  VARCHAR2
                           , IN_USERID            IN  VARCHAR2
                           -- IN_HSPTID           IN  VARCHAR2
																								   , IN_HSP_TP_CD         IN  VARCHAR2
																								   , IN_PT_NM             IN  VARCHAR2
																								   , IN_PT_NO             IN  number
																								   , IN_PACT_ID           IN  VARCHAR2
																								   , IN_TARGET_HSP_NM     IN  VARCHAR2
																								   , IN_TARGET_DEPT_NM    IN  VARCHAR2
																								   , IN_CO_TREAT_REASON   IN  VARCHAR2
																								   , IN_CO_TREAT_RMK      IN  VARCHAR2  
																								   , IN_TRNF_PRGR_STS_CD  IN  VARCHAR2  
																								   , IN_STATUS_STS_CD     IN  VARCHAR2
																								   , IN_CONSULT_REQ_DT    IN  VARCHAR2
																								   , IN_FSR_DTM           IN  VARCHAR2   
																								   , IN_FSR_IP_ADDR       IN  VARCHAR2
																								   , IN_FSR_STF_NO	       IN  VARCHAR2				
																								   , IN_FSR_STF_NM	       IN  VARCHAR2				
																								   , IN_FSR_PRGM_NM	      IN  VARCHAR2					
																								   , IN_LSH_DTM		         IN  VARCHAR2				
																								   , IN_LSH_IP_ADDR	      IN  VARCHAR2					
																								   , IN_LSH_STF_NO       	IN  VARCHAR2					
																								   , IN_LSH_STF_NM	       IN  VARCHAR2					
																								   , IN_LSH_PRGM_NM	      IN  VARCHAR2				
																								   , OUT_CURSOR           OUT SYS_REFCURSOR           
    

)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
    EXIST_CNT  NUMBER;

BEGIN

    SELECT COUNT(*)
      INTO EXIST_CNT
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID 
       AND STATUS_STS_CD = 'A';   -- ACTIVE 환자 (이송중) 
       
       
    IF EXIST_CNT > 0 THEN
        IS_SUCCESS := 'N';
        ERROR_MSG := '해당 환자는 이송요청 진행중인 환자입니다.';
    ELSE
        BEGIN
            INSERT INTO ARPA_PT_LIST (
                HSP_TP_CD
               , SEQ
               , PT_NM
               , PT_NO
               , PACT_ID
               , TARGET_HSP_NM
               , TARGET_DEPT_NM
               , CO_TREAT_REASON  
               , CO_TREAT_RMK
               , TRNF_PRGR_STS_CD
               , STATUS_STS_CD  
               , CONSULT_REQ_DT    
               , FSR_DTM
               , FSR_IP_ADDR
               , FSR_STF_NO
               , FSR_STF_NM
               , FSR_PRGM_NM 
               , LSH_DTM
               , LSH_IP_ADDR
               , LSH_STF_NO
               , LSH_STF_NM
               , LSH_PRGM_NM
            ) VALUES (
                 IN_HSP_TP_CD
               , (SELECT NVL(MAX(SEQ), 0) + 1
												       FROM ARPA_PT_LIST
												      WHERE HSP_TP_CD = IN_HSP_TP_CD
												     )
               , IN_PT_NM
               , IN_PT_NO
               , IN_PACT_ID
               , IN_TARGET_HSP_NM
               , IN_TARGET_DEPT_NM
               , IN_CO_TREAT_REASON
               , IN_CO_TREAT_RMK
               , IN_TRNF_PRGR_STS_CD      
               , IN_STATUS_STS_CD  
               , TO_DATE(IN_CONSULT_REQ_DT, 'YYYY-MM-DD HH24:MI:SS')   
               , TO_DATE(IN_FSR_DTM, 'YYYY-MM-DD HH24:MI:SS')
               , IN_FSR_IP_ADDR
               , IN_FSR_STF_NO
               , IN_FSR_STF_NM
               , IN_FSR_PRGM_NM
               , TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
               , IN_LSH_IP_ADDR
               , IN_LSH_STF_NO
               , IN_LSH_STF_NM
               , IN_LSH_PRGM_NM
            );
            IS_SUCCESS := 'Y';
            ERROR_MSG := '';
        EXCEPTION
            WHEN OTHERS THEN
                IS_SUCCESS := 'N';
                ERROR_MSG := SQLERRM;
        END;
    END IF;

    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;

/***********************************************************************************
 *    서비스이름  : IF_CSLT_HSP_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION : 협진병원 및 진료과 조회
 ***********************************************************************************/

PROCEDURE IF_CSLT_HSP_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2       -- 병원구분코드
																							   , OUT_CURSOR          OUT SYS_REFCURSOR   -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
          SELECT CDDES1 AS TARGET_HSP_CD
									     , IF_FN_CODE_SEL('TARGET_HSP_CD',CDDES1)  AS TARGET_HSP_NM
									     , CDBS   AS TARGET_DEPT_CD
									     , CDNM   AS TARGET_DEPT_NM
				      FROM ARPA_CD_LIST
								 WHERE COMKDCD = 'TARGET_DEPT_CD'
								   AND (CDDES1  = IF_FN_CODE_SEL('HSP_TP_CD',IN_HSP_TP_CD,'CDDES1') OR (CDDES1 = IF_FN_CODE_SEL('TARGET_HSP_CD',IN_HSP_TP_CD,'CDDES1')))
								   AND USE_YN  = 'Y'

								;

END IF_CSLT_HSP_SEL;

/**********************************************************************************************
*    SERVICENAME    : PC_CSLT_PT_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 협진의뢰 조회
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE IF_CSLT_PT_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2                   
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
																				      , IN_SEQ              IN  NUMBER
																				      , IN_PT_NO            IN  VARCHAR2
																				      , IN_PACT_ID          IN  VARCHAR2
                          , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS

BEGIN

   OPEN OUT_CURSOR FOR

									SELECT  A.HSP_TP_CD                    HSP_TP_CD               
									
									
				                , IF_FN_CODE_SEL('HSP_TP_CD',IN_HSP_TP_CD,'CDDES')  HSP_NM
									      , A.PT_NM                        PT_NM
									      , A.PT_NO                        PT_NO

									      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									      , B.SEX_TP_CD                    SEX_TP_CD
									      , (SELECT DEPT_NM
									           FROM PDEDBMSM
									          WHERE MED_DEPT_CD =  C.MED_DEPT_CD ) DEPT_NM
 								      , A.PACT_ID                              PACT_ID    -- 20250828 장인수 인터페이스명세서에 PACT_ID 추가되어있어서 컬럼 추가 
									      , A.TARGET_HSP_NM                  TARGET_HSP_NM
									      , A.TARGET_DEPT_NM                 TARGET_DEPT_NM
									      , A.CO_TREAT_REASON             CO_TREAT_REASON  
									      , A.CO_TREAT_RMK                CO_TREAT_RMK
									  FROM ARPA_PT_LIST A
									     , PCTPCPAM_DAMO B
									     , ACPPRAAM C
									WHERE A.HSP_TP_CD = IN_HSP_TP_CD
											AND A.SEQ = IN_SEQ
									  AND A.PT_NO = B.PT_NO
									  AND A.PT_NO = IN_PT_NO
									  AND A.PACT_ID = IN_PACT_ID
									  AND A.PACT_ID = C.PACT_ID
--									  AND A.PACT_ID = D.PACT_ID


									UNION ALL

															SELECT  A.HSP_TP_CD                    HSP_TP_CD
				           , IF_FN_CODE_SEL('HSP_TP_CD',IN_HSP_TP_CD,'CDDES')  HSP_NM
									      , A.PT_NM                        PT_NM
									      , A.PT_NO                        PT_NO

									      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD') PT_BIRTH
									      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
									      , B.SEX_TP_CD                    SEX_TP_CD
									      , NVL((SELECT DEPT_NM
									           FROM PDEDBMSM
									          WHERE MED_DEPT_CD =  C.MED_DEPT_CD ),C.MED_DEPT_CD) DEPT_NM
									      , A.PACT_ID                              PACT_ID   -- 20250828 장인수 인터페이스명세서에 PACT_ID 추가되어있어서 컬럼 추가 
									      , A.TARGET_HSP_NM                  TARGET_HSP_NM
									      , A.TARGET_DEPT_NM                 TARGET_DEPT_NM
									      , A.CO_TREAT_REASON             CO_TREAT_REASON
               , A.CO_TREAT_RMK                CO_TREAT_RMK 
									  FROM ARPA_PT_LIST A
									     , PCTPCPAM_DAMO B
									     , ACPPRETM C
									WHERE A.HSP_TP_CD = IN_HSP_TP_CD
									  AND A.SEQ       = IN_SEQ
									  AND A.PT_NO = IN_PT_NO
									  AND A.PACT_ID = IN_PACT_ID
									  AND A.PT_NO = B.PT_NO
									  AND A.PACT_ID = C.PACT_ID ;


END;
   


/**********************************************************************************************
*    SERVICENAME    : IF_CSLT_PT_UPD
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 협진의뢰 사유변경
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE IF_CSLT_PT_UPD (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , IN_CO_TREAT_REASON  IN VARCHAR2
																							   , IN_LSH_DTM		        IN VARCHAR2
																										,	IN_LSH_IP_ADDR	     IN VARCHAR2
																										,	IN_LSH_STF_NO	      IN VARCHAR2
																										,	IN_LSH_STF_NM	      IN VARCHAR2
																										,	IN_LSH_PRGM_NM	     IN VARCHAR2

                          , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000); 
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000);
  

BEGIN
  
    BEGIN 
    
    SELECT TRNF_PRGR_STS_CD 
         , STATUS_STS_CD  
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD 
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO; 
       
    IF V_STATUS_STS_CD = 'A' AND V_TRNF_PRGR_STS_CD = '10' THEN   
    
       UPDATE ARPA_PT_LIST
          SET CO_TREAT_REASON = IN_CO_TREAT_REASON
            , LSH_DTM = TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
            , LSH_IP_ADDR = IN_LSH_IP_ADDR
            , LSH_STF_NO  = IN_LSH_STF_NO
            , LSH_STF_NM  = IN_LSH_STF_NM
            , LSH_PRGM_NM = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       =  IN_SEQ
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID;

		   	    IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
				 
				 ELSIF V_STATUS_STS_CD = 'D' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 삭제된 환자입니다.'; 
								  
				 ELSIF V_STATUS_STS_CD = 'C' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진취소된 환자입니다. 사유 : ' || V_CANCEL_REASON ;   
								  
     ELSIF V_STATUS_STS_CD = 'E' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송종료된 환자입니다.';        
								  
 		  ELSIF V_STATUS_STS_CD = 'N' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송불가한 환자입니다.';     
								  
					ELSIF V_STATUS_STS_CD = 'Y' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진완료된 환자입니다.'; 	
								  
								  		  
     ELSE IS_SUCCESS := 'N';
          ERROR_MSG  := '이미 협진이 진행되었으며 협진등록사유 변경이 불가합니다 화면 재조회 해주세요.';
                    
							END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG  := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;



/**********************************************************************************************
*    SERVICENAME    : IF_CSLT_PT_CANCEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송환자 협진 취소
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE IF_CSLT_PT_CANCEL (  

                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2
																							   , IN_SEQ              IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2
																							   , IN_PACT_ID          IN VARCHAR2
																							   , IN_STATUS_STS_CD    IN VARCHAR2
																							   , IN_CANCEL_REASON    IN VARCHAR2 
																							   , IN_LSH_DTM		        IN VARCHAR2
																										,	IN_LSH_IP_ADDR	     IN VARCHAR2
																										,	IN_LSH_STF_NO	      IN VARCHAR2
																										,	IN_LSH_STF_NM	      IN VARCHAR2
																										,	IN_LSH_PRGM_NM	     IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);    
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000) ;  
    

BEGIN

    BEGIN    
       
     SELECT TRNF_PRGR_STS_CD 
         , STATUS_STS_CD 
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO; 
       
      IF V_STATUS_STS_CD = 'A'  THEN
    
       UPDATE ARPA_PT_LIST
          SET CANCEL_REASON  = IN_CANCEL_REASON
            , STATUS_STS_CD  = IN_STATUS_STS_CD 
            , LSH_DTM        = TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
            , LSH_IP_ADDR    = IN_LSH_IP_ADDR
            , LSH_STF_NO     = IN_LSH_STF_NO
            , LSH_STF_NM     = IN_LSH_STF_NM
            , LSH_PRGM_NM    = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ =  IN_SEQ
       AND PT_NO = IN_PT_NO
       AND PACT_ID = IN_PACT_ID;     
       
  				   	IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
								  
								  		  
     ELSE IS_SUCCESS := 'N';
          ERROR_MSG  := '이미 처리된 환자입니다.';
                    
							END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;
 

/**********************************************************************************************
*    SERVICENAME    : IF_CSLT_PRGR_UPD
*    CREATEDATE     : 2025.07.16
*    AUTHOR         : 장인수
*    DESCRIPTION    : EICU 이송환자 EZONTHECALL 실행 및 상태값 변경
*    CHANGE HISTORY : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE IF_CSLT_PRGR_UPD (  

                            IN_VNDR              IN  VARCHAR2
                          , IN_CLNTIP            IN  VARCHAR2
                          , IN_USERID            IN  VARCHAR2
                          -- IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD         IN  VARCHAR2
																							   , IN_SEQ               IN  NUMBER
																							   , IN_PT_NO             IN  VARCHAR2
																							   , IN_PACT_ID           IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD  IN  VARCHAR2
																							   , IN_CO_TREAT_PROGRESS_DT  IN  VARCHAR2
																							   , IN_LSH_DTM		             IN VARCHAR2
																										,	IN_LSH_IP_ADDR	          IN VARCHAR2
																										,	IN_LSH_STF_NO	           IN VARCHAR2
																										,	IN_LSH_STF_NM	           IN VARCHAR2
																										,	IN_LSH_PRGM_NM	          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000); 
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000);
  

BEGIN
    
    BEGIN 
    
     SELECT TRNF_PRGR_STS_CD 
         , STATUS_STS_CD 
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO; 
       
    IF V_STATUS_STS_CD = 'A' AND V_TRNF_PRGR_STS_CD IN('10') THEN   
    
						    UPDATE ARPA_PT_LIST
						       SET CO_TREAT_PROGRESS_DT = TO_DATE(IN_CO_TREAT_PROGRESS_DT,'YYYY-MM-DD HH24:MI:SS')
						           , TRNF_PRGR_STS_CD     = IN_TRNF_PRGR_STS_CD
						           , LSH_DTM              = TO_DATE(IN_LSH_DTM,'YYYY-MM-DD HH24:MI:SS')
						           , LSH_IP_ADDR          = IN_LSH_IP_ADDR
						           , LSH_STF_NO           = IN_LSH_STF_NO
						           , LSH_STF_NM           = IN_LSH_STF_NM
						           , LSH_PRGM_NM          = IN_LSH_PRGM_NM
						     WHERE HSP_TP_CD = IN_HSP_TP_CD
						       AND SEQ       = IN_SEQ
						       AND PT_NO     = IN_PT_NO
						       AND PACT_ID   = IN_PACT_ID;

				  	    IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
				 
				 ELSIF V_STATUS_STS_CD = 'D' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 삭제된 환자입니다.'; 
								  
				 ELSIF V_STATUS_STS_CD = 'C' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진취소된 환자입니다. 사유 : ' || V_CANCEL_REASON ;   
								  
     ELSIF V_STATUS_STS_CD = 'E' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송종료된 환자입니다.';        
								  
 		  ELSIF V_STATUS_STS_CD = 'N' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송불가한 환자입니다.';     
								  
					ELSIF V_STATUS_STS_CD = 'Y' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진완료된 환자입니다.'; 	
								  
								  		  
--     ELSIF V_TRNF_PRGR_STS_CD IS_SUCCESS := 'N';
--          ERROR_MSG  := '이미 협진이 진행되었으며 화면 재조회 바랍니다.';
--                    
							END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG  := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;
 

/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_MAIN_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송요청 환자리스트  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
PROCEDURE      IF_TRNF_MAIN_SEL
                          ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID          IN  VARCHAR2
                          , IN_STATUS_STS_CD    IN  VARCHAR2
                          , OUT_CURSOR          OUT SYS_REFCURSOR
                          )
IS

BEGIN
    OPEN OUT_CURSOR FOR
  SELECT  A.TRNF_PRGR_STS_CD                                    TRNF_PRGR_STS_CD
        , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD) TRNF_PRGR_STS_NM
        , A.CONSULT_REQ_DT                                CONSULT_REQ_DT
        , A.PACT_ID                                       PACT_ID
        , A.PT_NO						                                   PT_NO
        , A.PT_NM                                         PT_NM
        , B.SEX_TP_CD                                     SEX_TP_CD
        , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH
        , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
--        , (SELECT DEPT_NM
--             FROM PDEDBMSM
--            WHERE MED_DEPT_CD =  C.MED_DEPT_CD )          DEPT_NM
        ,'신경과3'     DEPT_NM
        ,  '박정현'                                            ANDR_NM
        , A.TARGET_HSP_NM                                 TARGET_HSP_NM    
        , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD )        HSP_NM
        , DECODE(A.PT_NO ,'88888885' ,'Duodenal perforation', '88888886' ,'Gastric ulcar' ,'INTRACEREBRAL HEMORRHAGE')  AS DGNS_NM 
  --      , DECODE(TRNF_PRGR_STS_CD, '7','Y','N')           ARVL_YN
        , 'NEWS-' || DECODE(A.PT_NO , '88888885' ,'5'
                                    , '88888886' ,'5' 
                                    , '88888887' ,'1' 
                                    , '88888888' ,'4' 
                                    , '88888889' ,'5' 
                                    , '88888810' ,'7' 
                                    , '88888811' ,'8' 
                                    ,'3' )                         PT_SCORE
        , A.HSP_TP_CD									                    HSP_TP_CD
        , A.CO_TREAT_PROGRESS_DT					                CO_TREAT_PROGRESS_DT
        , A.XFER_DECISION_DT					                    XFER_DECISION_DT
        , A.REFERRAL_DOC_REG_DT					                  REFERRAL_DOC_REG_DT
        , A.XFER_INFO_REG_DT					                    XFER_INFO_REG_DT
        , A.XFER_START_DT					                        XFER_START_DT
        , A.XFER_ARVL_PLAN_DT					                    XFER_ARVL_PLAN_DT
        , A.XFER_ARVL_DT					                        XFER_ARVL_DT
        , A.XFER_END_DT					                          XFER_END_DT
        , A.SEQ                 													SEQ    
      	, '010-1234-5678 홍길동'                                 PHONE_NUMBER  
      	
    FROM ARPA_PT_LIST A
       , PCTPCPAM_DAMO B
       , ACPPRAAM C
      
--       , (
--          SELECT *
--          FROM (
--              SELECT D.*
--                   , ROW_NUMBER() OVER (
--                        PARTITION BY D.PACT_ID
--                        ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
--                     ) AS RN
--                FROM MOPPCCFD D
--          )
--          WHERE RN = 1
--       ) D
  WHERE 1=1
    AND A.STATUS_STS_CD = IN_STATUS_STS_CD
    AND A.HSP_TP_CD = IN_HSPTID 
    AND A.PT_NO = B.PT_NO
    AND A.PACT_ID = C.PACT_ID




UNION ALL

      SELECT  A.TRNF_PRGR_STS_CD                                    TRNF_PRGR_STS_CD
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD) TRNF_PRGR_STS_NM
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT
      , A.PACT_ID                                       PACT_ID
      , A.PT_NO						                                   PT_NO
      , A.PT_NM                                         PT_NM
      , B.SEX_TP_CD                                     SEX_TP_CD
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE
      , '응급실'                       DEPT_NM
      ,  '홍길동'                                            ANDR_NM
--      , C.MEDR_SID                                      ANDR_NM
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM 
      , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD )        HSP_NM
      , 'Acute myocardial infaraction'               AS DGNS_NM
--      , DECODE(TRNF_PRGR_STS_CD, '7','Y','N')           ARVL_YN
      , 'KTAS-' || DECODE(A.PT_NO ,'88888885' ,'5'
                                  ,'88888886' ,'5'
                                  ,'88888881' ,'1'
                                  ,'88888882' ,'2'
                                  ,'88888883' ,'3'
                                  ,  '8' )                          PT_SCORE
      , A.HSP_TP_CD									                    HSP_TP_CD
      , A.CO_TREAT_PROGRESS_DT					                CO_TREAT_PROGRESS_DT
      , A.XFER_DECISION_DT					                    XFER_DECISION_DT
      , A.REFERRAL_DOC_REG_DT					                  REFERRAL_DOC_REG_DT
      , A.XFER_INFO_REG_DT					                    XFER_INFO_REG_DT
      , A.XFER_START_DT					                        XFER_START_DT
      , A.XFER_ARVL_PLAN_DT					                    XFER_ARVL_PLAN_DT
      , A.XFER_ARVL_DT					                        XFER_ARVL_DT
      , A.XFER_END_DT					                          XFER_END_DT
      , A.SEQ									                          SEQ
      , '010-1234-5678 홍길동'                                 PHONE_NUMBER   
      
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C
WHERE 1=1
  AND A.STATUS_STS_CD = IN_STATUS_STS_CD
   AND A.HSP_TP_CD = IN_HSPTID 
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID


ORDER BY CONSULT_REQ_DT DESC , SEQ ;


END IF_TRNF_MAIN_SEL;



/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_MAIN_DEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 협진삭제
*    Change History : 2025.08.06, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE IF_TRNF_MAIN_DEL ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																						    , IN_HSP_TP_CD        IN  VARCHAR2
																						    , IN_SEQ              IN VARCHAR2
																						    , IN_PT_NO            IN  VARCHAR2
																						    , IN_PACT_ID          IN  VARCHAR2
																						    , IN_STATUS_STS_CD    IN VARCHAR2
																						    , IN_LSH_DTM		        IN VARCHAR2
																										, IN_LSH_IP_ADDR	     IN VARCHAR2
																										, IN_LSH_STF_NO	      IN VARCHAR2
																										, IN_LSH_STF_NM	      IN VARCHAR2
																										, IN_LSH_PRGM_NM	     IN VARCHAR2
																						
																						    , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000);
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000) ;

 BEGIN    
    BEGIN   
    
       SELECT TRNF_PRGR_STS_CD 
         , STATUS_STS_CD 
         , NVL(CANCEL_REASON,'')
      INTO V_TRNF_PRGR_STS_CD
         , V_STATUS_STS_CD
         , V_CANCEL_REASON
      FROM ARPA_PT_LIST
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO; 
       
   IF V_STATUS_STS_CD = 'A'  THEN 
   
       UPDATE ARPA_PT_LIST
          SET STATUS_STS_CD  = IN_STATUS_STS_CD 
            , LSH_DTM        =  TO_DATE(IN_LSH_DTM, 'YYYY-MM-DD HH24:MI:SS')
            , LSH_IP_ADDR    = IN_LSH_IP_ADDR
            , LSH_STF_NO     = IN_LSH_STF_NO
            , LSH_STF_NM     = IN_LSH_STF_NM
            , LSH_PRGM_NM    = IN_LSH_PRGM_NM
		     WHERE HSP_TP_CD = IN_HSP_TP_CD
		       AND SEQ       =  IN_SEQ
		       AND PT_NO     = IN_PT_NO
		       AND PACT_ID   = IN_PACT_ID;       
       
   				  	IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
								  
								  		  
     ELSE IS_SUCCESS := 'N';
          ERROR_MSG  := '이미 처리된 환자입니다.';
                    
			END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG  := SQLERRM;
                      
 END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;
  

/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_DETAIL_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송요청 환자 리스트 상세 조회
*    Change History : 2025.07.16, 장인수, 최초작성
**********************************************************************************************/
PROCEDURE      IF_TRNF_DETAIL_SEL
                          ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
                          , IN_SEQ              IN  NUMBER
                          , IN_PT_NO            IN  VARCHAR2
                          , IN_PACT_ID          IN  VARCHAR2
                          , OUT_CURSOR       OUT SYS_REFCURSOR
                          )
IS

BEGIN
    OPEN OUT_CURSOR FOR
									SELECT HSP_TP_CD
									     , TRNF_PRGR_STS_CD
									     , STATUS_STS_CD
									     , CONSULT_REQ_DT
									     , CO_TREAT_PROGRESS_DT
									     , XFER_DECISION_DT
									     , REFERRAL_DOC_REG_DT
									     , XFER_INFO_REG_DT 
									     , XFER_START_DT
									     , XFER_ARVL_PLAN_DT
									     , XFER_ARVL_DT
									     , XFER_END_DT
									     , PACT_ID
									     , PT_NO
									     , PT_NM 
									     , CO_TREAT_REASON
									     , SEQ
									     
									  FROM ARPA_PT_LIST
									 WHERE HSP_TP_CD = IN_HSP_TP_CD
									   AND PT_NO = IN_PT_NO
									   AND PACT_ID = IN_PACT_ID
									   AND SEQ = IN_SEQ

									;

END IF_TRNF_DETAIL_SEL;


/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_DETAIL_END_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송종료현황  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
PROCEDURE      IF_TRNF_DETAIL_END_SEL
                          ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID          IN  VARCHAR2
--                          , IN_HSP_TP_CD        IN  VARCHAR2
                          , IN_START_DT         IN  VARCHAR2
                          , IN_END_DT           IN  VARCHAR2          
           
                          , OUT_CURSOR          OUT SYS_REFCURSOR
                          )
IS

BEGIN
    OPEN OUT_CURSOR FOR
SELECT  A.TRNF_PRGR_STS_CD                                     TRNF_PRGR_STS_CD     -- 이송진행상태코드 
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD)  TRNF_PRGR_STS_NM     -- 이송진행단계
      , A.PACT_ID                                       PACT_ID              -- 접수ID 
      , A.PT_NO						                                   PT_NO                -- 환자번호
      , A.PT_NM                                         PT_NM                -- 환자이름
      , B.SEX_TP_CD                                     SEX_TP_CD            -- 성별
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH             -- 생년월일
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE               -- 나이
      , (SELECT DEPT_NM
           FROM PDEDBMSM
          WHERE MED_DEPT_CD =  C.MED_DEPT_CD )          DEPT_NM              -- 진료과
      , '홍길동'                                            ANDR_NM
      , DECODE(A.PT_NO ,'88888885' ,'Duodenal perforation', '88888886' ,'Gastric ulcar' ,'Acute pancreatitis')  AS DGNS_NM 
--      , ''                                              DGNS_NM              -- 진단명
      , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD,'CDNM')		HSP_NM            -- 의뢰요청병원
      , A.SEQ									                                		SEQ                   -- 순번  
      , IF_FN_CODE_SEL('STATUS_STS_CD',A.STATUS_STS_CD )        STATUS_STS_CD          --등록상태(이송종료, 협진완료, 이송불가, 취소)
      
      , A.EQUIP_YN                                      EQUIP_YN             -- 물품동반여부
      , A.EQUIP_NM                                      EQUIP_NM             -- 물품명
      , A.CO_TREAT_REASON                               CO_TREAT_REASON      -- 협진등록사유
      , A.CO_TREAT_RMK                                  CO_TREAT_RMK         -- 협진등록비고
      , A.XFER_REF_MEMO                                 XFER_REF_MEMO        -- 이송참고메모
      , A.MED_STAFF_ACCOMP_YN                           MED_STAFF_ACCOMP_YN  -- 의료진동반여부
--      , A.MED_STAFF_ACCOMP_ID                           MED_STAFF_ACCOMP_ID  -- 동반의료진사번
--      , A.MED_STAFF_ACCOMP_NM                           MED_STAFF_ACCOMP_ID  -- 동반의료진이름
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT       -- 협진등록일시
      , A.CO_TREAT_PROGRESS_DT                          CO_TREAT_PROGRESS_DT -- 협진진행일시
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT     -- 이송여부결정일시
      , A.REFERRAL_DOC_REG_DT                           REFERRAL_DOC_REG_DT  -- 진료의뢰서전달일시
      , A.XFER_INFO_REG_DT                              XFER_INFO_REG_DT     -- 이송정보등록일시
      , A.XFER_START_DT                                 XFER_START_DT        -- 이송시작일시 
      , A.XFER_ARVL_PLAN_DT                             XFER_ARVL_PLAN_DT    -- 이송도착예정일시
      , A.XFER_ARVL_DT                                  XFER_ARVL_DT         -- 이송도착시간
      , A.XFER_END_DT                                   XFER_END_DT          -- 이송종료일시
      
      , A.TARGET_HSP_CD                                 TARGET_HSP_CD        -- 협진의뢰병원코드
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM        -- 협진의뢰병원명
      , A.TARGET_DEPT_NM                                TARGET_DEPT_NM       -- 협진의뢰진료과명
      , A.CANCEL_REASON                                 CANCEL_REASON        -- 협진의뢰최소사유
      , A.FSR_DTM                                       FSR_DTM              -- 최초등록일시
      , A.FSR_IP_ADDR                                   FSR_IP_ADDR          -- 최초접속자IP
      , A.FSR_STF_NO                                    FSR_STF_NO           -- 최초등록자ID
      , A.FSR_STF_NM                                    FSR_STF_NM           -- 최초등록자성명
      , A.FSR_PRGM_NM                                   FSR_PRGM_NM          -- 최초변경프로그램명
      , A.LSH_DTM                                       LSH_DTM              -- 최종등록일시
      , A.LSH_IP_ADDR                                   LSH_IP_ADDR          -- 최종접속자IP
      , A.LSH_STF_NO                                    LSH_STF_NO           -- 최종등록자ID
      , A.LSH_STF_NM                                    LSH_STF_NM           -- 최종등록자성명
      , A.LSH_PRGM_NM                                   LSH_PRGM_NM          -- 최종변경프로그램명  
      , A.NO_TRNF_REF_MEMO				                          NO_TRNF_REF_MEMO     -- 협진완료 및 이송보류 사유 
      
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRAAM C

WHERE 1=1
  AND A.HSP_TP_CD = IN_HSPTID
  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')--     , (
--        SELECT *
--        FROM (
--            SELECT D.*
--                 , ROW_NUMBER() OVER (
--                      PARTITION BY D.PACT_ID
--                      ORDER BY D.CTG_DTM DESC, D.WRT_SEQ DESC
--                   ) AS RN
--              FROM MOPPCCFD D
--        )
--        WHERE RN = 1
--     ) D
  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
--  AND A.PACT_ID = D.PACT_ID
  AND A.STATUS_STS_CD NOT IN ('A','D')


UNION ALL

SELECT  A.TRNF_PRGR_STS_CD                                     TRNF_PRGR_STS_CD     -- 이송진행상태코드 
      , IF_FN_CODE_SEL('TRNF_PRGR_STS_CD',A.TRNF_PRGR_STS_CD)  TRNF_PRGR_STS_NM     -- 이송진행단계
      , A.PACT_ID                                       PACT_ID              -- 접수ID 
      , A.PT_NO						                                   PT_NO                -- 환자번호
      , A.PT_NM                                         PT_NM                -- 환자이름
      , B.SEX_TP_CD                                     SEX_TP_CD            -- 성별
      , TO_CHAR(PT_BRDY_DT, 'YYYYMMDD')                 PT_BIRTH             -- 생년월일
      , FLOOR(MONTHS_BETWEEN(SYSDATE, PT_BRDY_DT) / 12) PT_AGE               -- 나이
      , (SELECT DEPT_NM
           FROM PDEDBMSM
          WHERE MED_DEPT_CD =  C.MED_DEPT_CD )                                    DEPT_NM              -- 진료과 
      ,  '홍길동'                                            ANDR_NM
--      , C.MEDR_SID                                      ANDR_NM              -- 주치의
      , 'Acute myocardial infaraction'               AS DGNS_NM
      , IF_FN_CODE_SEL('HSP_TP_CD',A.HSP_TP_CD,'CDNM')		HSP_NM            -- 병원구분코드(의뢰요청한병원)
      , A.SEQ									                                		SEQ                   -- 순번  
      , IF_FN_CODE_SEL('STATUS_STS_CD',A.STATUS_STS_CD )        STATUS_STS_CD          --등록상태(이송종료, 협진완료, 이송불가, 취소)
      
      , A.EQUIP_YN                                      EQUIP_YN             -- 물품동반여부
      , A.EQUIP_NM                                      EQUIP_NM             -- 물품명
      , A.CO_TREAT_REASON                               CO_TREAT_REASON      -- 협진등록사유
      , A.CO_TREAT_RMK                                  CO_TREAT_RMK         -- 협진등록비고
      , A.XFER_REF_MEMO                                 XFER_REF_MEMO        -- 이송참고메모
      , A.MED_STAFF_ACCOMP_YN                           MED_STAFF_ACCOMP_YN  -- 의료진동반여부
--      , A.MED_STAFF_ACCOMP_ID                           MED_STAFF_ACCOMP_ID  -- 동반의료진사번
--      , A.MED_STAFF_ACCOMP_NM                           MED_STAFF_ACCOMP_ID  -- 동반의료진이름
      , A.CONSULT_REQ_DT                                CONSULT_REQ_DT       -- 협진등록일시
      , A.CO_TREAT_PROGRESS_DT                          CO_TREAT_PROGRESS_DT -- 협진진행일시
      , A.XFER_DECISION_DT					                         XFER_DECISION_DT     -- 이송여부결정일시
      , A.REFERRAL_DOC_REG_DT                           REFERRAL_DOC_REG_DT  -- 진료의뢰서전달일시
      , A.XFER_INFO_REG_DT                              XFER_INFO_REG_DT     -- 이송정보등록일시
      , A.XFER_START_DT                                 XFER_START_DT        -- 이송시작일시 
      , A.XFER_ARVL_PLAN_DT                             XFER_ARVL_PLAN_DT    -- 이송도착예정일시
      , A.XFER_ARVL_DT                                  XFER_ARVL_DT         -- 이송도착시간
      , A.XFER_END_DT                                   XFER_END_DT          -- 이송종료일시
      
      , A.TARGET_HSP_CD                                 TARGET_HSP_CD        -- 협진의뢰병원코드
      , A.TARGET_HSP_NM                                 TARGET_HSP_NM        -- 협진의뢰병원명
      , A.TARGET_DEPT_NM                                TARGET_DEPT_NM       -- 협진의뢰진료과명
      , A.CANCEL_REASON                                 CANCEL_REASON        -- 협진의뢰취소사유
      , A.FSR_DTM                                       FSR_DTM              -- 최초등록일시
      , A.FSR_IP_ADDR                                   FSR_IP_ADDR          -- 최초접속자IP
      , A.FSR_STF_NO                                    FSR_STF_NO           -- 최초등록자ID
      , A.FSR_STF_NM                                    FSR_STF_NM           -- 최초등록자성명
      , A.FSR_PRGM_NM                                   FSR_PRGM_NM          -- 최초변경프로그램명
      , A.LSH_DTM                                       LSH_DTM              -- 최종등록일시
      , A.LSH_IP_ADDR                                   LSH_IP_ADDR          -- 최종접속자IP
      , A.LSH_STF_NO                                    LSH_STF_NO           -- 최종등록자ID
      , A.LSH_STF_NM                                    LSH_STF_NM           -- 최종등록자성명
      , A.LSH_PRGM_NM                                   LSH_PRGM_NM          -- 최종변경프로그램명
      , A.NO_TRNF_REF_MEMO				                          NO_TRNF_REF_MEMO     -- 협진완료 및 이송보류 사유 
  FROM ARPA_PT_LIST A
     , PCTPCPAM_DAMO B
     , ACPPRETM C      
     
WHERE 1=1
  AND A.HSP_TP_CD = IN_HSPTID
  AND A.CONSULT_REQ_DT >= TO_DATE(IN_START_DT, 'YYYYMMDD')
  AND A.CONSULT_REQ_DT < TO_DATE(IN_END_DT, 'YYYYMMDD') + 1
  AND A.PT_NO = B.PT_NO
  AND A.PACT_ID = C.PACT_ID
  AND A.STATUS_STS_CD NOT IN ('A','D')




ORDER BY CONSULT_REQ_DT DESC ;


END IF_TRNF_DETAIL_END_SEL;
 

/**********************************************************************************************
*    SERVICENAME    : IF_PT_SMRY_INFO_SEL
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 환자 요약 정보 조회  조회
*    Change History : 2025.07.16, 장인수, 최초작성
											2025.08.19, 윤재림, XFER_START_DT 추가
**********************************************************************************************/
PROCEDURE IF_PT_SMRY_INFO_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
                          , IN_HSP_TP_CD  IN  VARCHAR2      -- 병원구분코드  
																							   , IN_SEQ  			   IN  NUMBER      -- 순번 
																							   , IN_PT_NO      IN  VARCHAR2      -- 환자번호
																							   , IN_PACT_ID  	IN  VARCHAR2     -- 접수번호
 
                          , OUT_CURSOR    OUT SYS_REFCURSOR  -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
            SELECT A.HSP_TP_CD
             , A.PT_NO
             , A.PACT_ID
             , T.HSP_NM
             , T.PT_NM
             , T.PT_BIRTH
             , T.PT_AGE
             , T.PT_BLOOD_TYPE
             , T.SEX_TP_CD
             , T.DEPT_CD
             , T.DEPT_NM
             , T.WARD_CD
             , T.WARD_NM
             , T.ROOM_NO
             , T.BED_NO
             , T.CUR_WARD_CD
             , T.CUR_WARD_NM
             , T.CUR_ROOM_NO
             , T.CUR_BED_NO
             , T.CSFM_WRT_YN
             , T.PAST_HISTORY
             , T.PT_HEIGHT
             , T.PT_WEIGHT
             , T.PT_WAIST_CIRC
             , T.DGNS_NM
             , T.MAIN_SYMPTOM
             , T.VISIT_REASON
             , T.INFECTIOUS_DISEASE
             , T.RECENT_SURGERY_YN
             , T.SURGERY_NM
             , T.SURGERY_DT
             , T.POST_SURGERY_DGNS_NM
             , T.POST_SURGERY_COMPLICATION
             , T.OXYGEN_NEED_YN
             , T.OXYGEN_FLOW_RATE
             , T.OXYGEN_DELIVERY_METHOD
             , T.SPO2
             , T.SPECIAL_NOTE
             , T.MEDICAL_DEVICE_YN
             , T.MEDICAL_DEVICE_NM
             , T.CENTRAL_LINE
             , T.IV_LINE
             , T.OTHER_LINE_DESC
             , T.BEDSORES_YN
             , T.BEDSORES_LOCATION
             , T.BEDSORES_STAGE
             , T.MOTOR_POWER_GRADE_R_L
        FROM XICU.PT_SMRY_INFO_TEST T
             , ARPA_PT_LIST A
        WHERE A.HSP_TP_CD = IN_HSP_TP_CD
          AND A.PT_NO     = IN_PT_NO
          AND A.PACT_ID 	= IN_PACT_ID
          AND A.SEQ = IN_SEQ ;
END IF_PT_SMRY_INFO_SEL;
  

/***********************************************************************************
 *    서비스이름  : IF_PT_SMRY_VTSG_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION : 환자요약정보 활력징후 조회
 ***********************************************************************************/
PROCEDURE IF_PT_SMRY_VTSG_SEL( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN  VARCHAR2
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
	 SELECT
        S.HSP_NM,
        A.PT_NM,
        S.VITAL_SIGN_TIME,
				S.SBP,
				S.DBP,
				S.PR,
				S.RR,
				S.BT
    FROM PT_SMRY_VTSG_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE 1=1
      AND A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.SEQ       = IN_SEQ
      AND A.PT_NO  = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.VITAL_SIGN_TIME >= (
        SELECT MAX(VITAL_SIGN_TIME)
        FROM PT_SMRY_VTSG_SEL
        ) - 3
--			AND S.VITAL_SIGN_TIME >= TRUNC(SYSDATE) - 2
--			AND S.VITAL_SIGN_TIME < TRUNC(SYSDATE) + 1   
    ORDER BY VITAL_SIGN_TIME ;
END;
 
/***********************************************************************************
 *    서비스이름  : IF_PT_SMRY_INO_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :   환자요약정보 IO 조회
 ***********************************************************************************/
PROCEDURE IF_PT_SMRY_INO_SEL(
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
                          , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NM,
        S.IO_RECORD_TIME,
				S.INTAKE_AMT,
				S.OUTPUT_AMT
    FROM PT_SMRY_INO_SEL	S,
    		 ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID     
      AND A.SEQ = IN_SEQ 
      AND S.IO_RECORD_TIME >= (
        SELECT MAX(IO_RECORD_TIME)
        FROM PT_SMRY_INO_SEL
        WHERE A.HSP_TP_CD = IN_HSP_TP_CD
          AND A.PT_NO = IN_PT_NO
          AND A.PACT_ID = IN_PACT_ID 
        ) - 3
--			AND S.IO_RECORD_TIME >= TRUNC(SYSDATE) - 2
--			AND S.IO_RECORD_TIME < TRUNC(SYSDATE) + 1   
    ORDER BY S.IO_RECORD_TIME desc;
END;



/***********************************************************************************
 *    서비스이름  : IF_PT_SMRY_DGSF_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :     환자요약정보 약물
 ***********************************************************************************/
PROCEDURE IF_PT_SMRY_DGSF_SEL(  
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NM,
        S.ORDER_DTM,
        S.ATC_CODE_NM,
        S.DRUG_NM,
        S.DRUG_UNIT,
        S.DOSE_PER_TIME,
        S.DOSE_FREQ,
        S.DOSE_DAYS,
        S.DOSING_METHOD
    FROM PT_SMRY_DGSF_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.ORDER_DTM >= (
        SELECT MAX(ORDER_DTM)
        FROM PT_SMRY_DGSF_SEL
        ) - 3
--			AND ORDER_DTM >= TRUNC(SYSDATE) - 2
--			AND ORDER_DTM < TRUNC(SYSDATE) + 1   
      AND A.SEQ = IN_SEQ
 ORDER BY ORDER_DTM DESC;
END;

/***********************************************************************************
 *    서비스이름  : IF_PT_SMRY_EXM_CNT_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :     환자요약정보 검사건수
 ***********************************************************************************/
PROCEDURE IF_PT_SMRY_EXM_CNT_SEL(
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
		    A.PT_NO,
        A.PT_NM,
        S.SPE_EXAM_CNT,
				S.PAT_EXAM_CNT,
				S.RAD_EXAM_CNT,
				S.FUN_EXAM_CNT
    FROM PT_SMRY_EXM_CNT_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO 	  = IN_PT_NO
      AND A.PACT_ID	  = IN_PACT_ID
      AND A.SEQ 		  = IN_SEQ;

END;

/***********************************************************************************
 *    서비스이름  : IF_PT_SMRY_EXM_CNT_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :   환자요약정보 검사결과
 ***********************************************************************************/
PROCEDURE IF_PT_SMRY_EXM_SEL ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	      IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , IN_EXAM_CD          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT
        S.HSP_NM,
        A.PT_NO,
        A.PT_NM,
        S.EXAM_DT,
        S.EXAM_ITEM_NM,
        S.EXAM_NM,
        S.EXAM_RESULT_VAL,
        S.EXAM_REF_RANGE
    FROM PT_SMRY_EXM_SEL	S
    	 , ARPA_PT_LIST	A
    WHERE A.HSP_TP_CD = IN_HSP_TP_CD
      AND A.PT_NO = IN_PT_NO
      AND A.PACT_ID = IN_PACT_ID
      AND S.EXAM_CD = IN_EXAM_CD
      AND S.EXAM_DT >= (
        SELECT MAX(EXAM_DT)
        FROM PT_SMRY_EXM_SEL
        ) - 3
--			AND S.EXAM_DT >= TRUNC(SYSDATE) - 2
--			AND S.EXAM_DT < TRUNC(SYSDATE) + 1   
      AND A.SEQ = IN_SEQ
		ORDER BY EXAM_DT DESC;
END;


/**********************************************************************************************
*    SERVICENAME    : IF_TRNF_STS_UPD
*    CREATEDATE     : 2025.08.16
*    AUTHOR         : 장인수
*    DESCRIPTION    : EICU 이송환자 이송여부결정
*    CHANGE HISTORY : 2025.09.06, 장인수, 검증 함수 반영
**********************************************************************************************/    
PROCEDURE IF_TRNF_STS_UPD (  
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD IN  VARCHAR2
																							   , IN_XFER_DECISION_DT IN  VARCHAR2
																							   , IN_STATUS_STS_CD    IN  VARCHAR2  
--																							   , IN_NO_TRNF_REF_MEMO IN  VARCHAR2
																							   , IN_LSH_DTM          IN  VARCHAR2
																							   , IN_LSH_IP_ADDR      IN  VARCHAR2
																							   , IN_LSH_STF_NO       IN  VARCHAR2
																							   , IN_LSH_STF_NM       IN  VARCHAR2
																							   , IN_LSH_PRGM_NM      IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
IS_SUCCESS VARCHAR2(1);
ERROR_MSG  VARCHAR2(1000); 
    V_TRNF_PRGR_STS_CD VARCHAR2(2);
    V_STATUS_STS_CD VARCHAR2(1);
    V_CANCEL_REASON VARCHAR2(1000);
   

BEGIN
    BEGIN         
    
	  SELECT TRNF_PRGR_STS_CD 
	         , STATUS_STS_CD  
	         , NVL(CANCEL_REASON,'')
	      INTO V_TRNF_PRGR_STS_CD
	         , V_STATUS_STS_CD 
	         , V_CANCEL_REASON
	      FROM ARPA_PT_LIST
	     WHERE HSP_TP_CD = IN_HSP_TP_CD
	       AND SEQ       = IN_SEQ
	       AND PT_NO     = IN_PT_NO; 
	       
	    IF V_STATUS_STS_CD = 'A' AND V_TRNF_PRGR_STS_CD = '20' THEN   
          -- 정상 업데이트
				    UPDATE ARPA_PT_LIST
				       SET TRNF_PRGR_STS_CD  = IN_TRNF_PRGR_STS_CD
				         , XFER_DECISION_DT  = TO_DATE(IN_XFER_DECISION_DT  , 'YYYY-MM-DD HH24:MI:SS')   
				         , STATUS_STS_CD     = IN_STATUS_STS_CD              
--				         , NO_TRNF_REF_MEMO  = IN_NO_TRNF_REF_MEMO
				         , LSH_DTM           = TO_DATE(IN_LSH_DTM,'YYYY-MM-DD HH24:MI:SS')
				         , LSH_IP_ADDR       = IN_LSH_IP_ADDR
				         , LSH_STF_NO        = IN_LSH_STF_NO
				         , LSH_STF_NM        = IN_LSH_STF_NM
				         , LSH_PRGM_NM       = IN_LSH_PRGM_NM
				     WHERE HSP_TP_CD = IN_HSP_TP_CD
				       AND SEQ       = IN_SEQ
				       AND PT_NO     = IN_PT_NO
				       AND PACT_ID   = IN_PACT_ID; 
				       
				       
				   	 IS_SUCCESS := 'Y';
										ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
				 
				 ELSIF V_STATUS_STS_CD = 'D' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 등록삭제된 환자입니다.'; 
								  
				 ELSIF V_STATUS_STS_CD = 'C' THEN  
									 IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진취소된 환자입니다. 사유 : ' || V_CANCEL_REASON ;   
								  
     ELSIF V_STATUS_STS_CD = 'E' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송종료된 환자입니다.';        
								  
 		  ELSIF V_STATUS_STS_CD = 'N' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 이송불가한 환자입니다.';     
								  
					ELSIF V_STATUS_STS_CD = 'Y' THEN 
          IS_SUCCESS := 'N';
								  ERROR_MSG  := '해당 환자는 협진완료된 환자입니다.'; 	
								  
								  		  
     ELSE IS_SUCCESS := 'N';
          ERROR_MSG  := '이송결정단계 작업이 진행되었습니다. 화면 재조회 해주세요.';
                    
							END IF;
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG  := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;
END;
  
  
  
    
/***********************************************************************************
 *    서비스이름  : IF_MED_RFFM_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION : 진료의뢰서 조회
 ***********************************************************************************/
PROCEDURE IF_MED_RFFM_SEL( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       	     	IN  NUMBER
																							   , IN_PT_NO     	      IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
    SELECT A.HSP_TP_CD
		 , A.PT_NO
		 , A.PACT_ID
		 , S.HSP_NM
		 , A.PT_NM
		 , S.PHONE_NO
		 , S.RRN_MASKED
		 , S.PT_AGE
		 , S.SEX_TP_CD
		 , S.PT_ADDR
		 , S.TREAT_START_DT
		 , S.TREAT_END_DT
		 , S.TREAT_TYPE
		 , S.HSP_DR_NAME
		 , S.HSP_DEPT_NM
		 , S.HSP_ADDR
		 , S.TARGET_HSP_NM
		 , S.TARGET_DR_NAME
		 , S.TARGET_DEPT_NM
		 , S.TARGET_HSP_ADDR
		 , S.CLINICAL_NOTE   
		 , A.CO_TREAT_REASON
      FROM MED_RFFM_SEL	S
      	 , ARPA_PT_LIST	A
	  WHERE A.HSP_TP_CD = IN_HSP_TP_CD
        AND A.PT_NO   = IN_PT_NO
        AND A.PACT_ID = IN_PACT_ID
      	AND A.SEQ 		= IN_SEQ;
END IF_MED_RFFM_SEL;
   

/***********************************************************************************
 *    서비스이름  : IF_DGNS_PTCL_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :  진료의뢰서 진단내역
 ***********************************************************************************/
PROCEDURE IF_DGNS_PTCL_SEL ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2      -- 병원구분코드
																							   , IN_SEQ       	      IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2      -- 환자번호  
																							   , IN_PACT_ID          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
      SELECT DIAGNOSIS_DT   -- 진단일 (YYYYMMDD)
           , DIAGNOSIS_CD   -- 상병코드
           , DGNS_NM        -- 진단명
        FROM DGNS_PTCL_SEL
        WHERE DIAGNOSIS_DT >= (
        SELECT MAX(DIAGNOSIS_DT)
        FROM DGNS_PTCL_SEL
        ) - 3   
--				WHERE DIAGNOSIS_DT >= TRUNC(SYSDATE) - 2
--				AND DIAGNOSIS_DT < TRUNC(SYSDATE) + 1   
       ORDER BY DIAGNOSIS_DT DESC;
END IF_DGNS_PTCL_SEL;


/***********************************************************************************
 *    서비스이름  : IF_ALRG_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :  진료의뢰서 알러지및부작용
 ***********************************************************************************/
PROCEDURE IF_ALRG_SEL (    
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2      -- 병원구분코드
																							   , IN_SEQ       	      IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2      -- 환자번호  
																							   , IN_PACT_ID          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
      SELECT S.REG_DT
           , S.ALLERGY_SOURCE
           , S.ALLERGY_NM
           , S.ALLERGY_REACTION
        FROM ALRG_SEL	S
        	 , ARPA_PT_LIST	A
       WHERE A.HSP_TP_CD = IN_HSP_TP_CD
         AND A.PT_NO     = IN_PT_NO
      	 AND A.SEQ = IN_SEQ
--      	 AND S.REG_DT >= TRUNC(SYSDATE) - 2
--				 AND S.REG_DT < TRUNC(SYSDATE) + 1      
    ORDER BY S.REG_DT DESC;
END IF_ALRG_SEL;
  
/***********************************************************************************
 *    서비스이름  : IF_OP_HST_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :    진료의뢰서 수술력
 ***********************************************************************************/
PROCEDURE IF_OP_HST_SEL (   
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN VARCHAR2      -- 병원구분코드
																							   , IN_SEQ       	      IN NUMBER
																							   , IN_PT_NO            IN VARCHAR2      -- 환자번호   
																							   , IN_PACT_ID          IN VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
      SELECT S.SURGERY_DT
           , S.SURGERY_NM
        FROM OP_HST_SEL	S
        	 , ARPA_PT_LIST	A
       WHERE A.HSP_TP_CD = IN_HSP_TP_CD
         AND A.PT_NO     = IN_PT_NO
      	 AND A.SEQ = IN_SEQ
--      	 AND S.SURGERY_DT >= TRUNC(SYSDATE) - 2
--			 	 AND S.SURGERY_DT < TRUNC(SYSDATE) + 1  
			   AND S.SURGERY_DT >= TRUNC(SYSDATE) - 2
		   	 AND S.SURGERY_DT < TRUNC(SYSDATE) + 1   
		ORDER BY S.SURGERY_DT DESC;
END IF_OP_HST_SEL;
 


/***********************************************************************************
 *    서비스이름  : IF_TRNF_REG_INFO_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION : 이송등록정보 조회
 ***********************************************************************************/
PROCEDURE IF_TRNF_REG_INFO_SEL ( 
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          -- IN_HSPTID          IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ              IN  NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																							   , IN_PACT_ID          IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR -- 결과 커서
)
IS
BEGIN
    OPEN OUT_CURSOR FOR
SELECT
    T.HSP_NM
  , T.PT_NM
  , T.PT_BIRTH
  , T.PT_AGE
  , T.SEX_TP_CD
  , T.DEPT_NM
  , T.DEPT_CD
  , CASE
       WHEN A.XFER_START_DT IS NULL THEN SYSDATE
       ELSE A.XFER_START_DT
     END AS XFER_START_DT
	, CASE
	    WHEN A.XFER_ARVL_PLAN_DT IS NULL THEN
	         SYSDATE
	       + NUMTODSINTERVAL(
	             TO_NUMBER(
	               NVL(REGEXP_SUBSTR(IF_FN_CODE_SEL('HSP_TRAN_TIME', A.HSP_TP_CD, 'CDDES1'), '^-?\d+'), '0')
	             )
	         , 'MINUTE')
	    ELSE A.XFER_ARVL_PLAN_DT
	  END AS XFER_ARVL_PLAN_DT
	, CASE
	    WHEN A.XFER_ARVL_DT IS NULL THEN
	         SYSDATE
	       + NUMTODSINTERVAL(
	             TO_NUMBER(
	               NVL(REGEXP_SUBSTR(IF_FN_CODE_SEL('HSP_TRAN_TIME', A.HSP_TP_CD, 'CDDES1'), '^-?\d+'), '0')
	             )
	         , 'MINUTE')
	    ELSE A.XFER_ARVL_DT
	  END AS XFER_ARVL_DT
  , A.MED_STAFF_ACCOMP_YN
  , A.EQUIP_YN	 PT_EQUIP_YN
  , A.EQUIP_NM		EQUIP_NM
  , A.XFER_REF_MEMO
FROM TRNF_REG_INFO T
   , ARPA_PT_LIST   A
WHERE A.HSP_TP_CD = IN_HSP_TP_CD
  AND A.SEQ       = IN_SEQ
  AND A.PT_NO     = IN_PT_NO
  AND A.PACT_ID     = IN_PACT_ID;
END IF_TRNF_REG_INFO_SEL;

 

/***********************************************************************************
 *    서비스이름  : IF_TRNF_INFO_UPD
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :        이송정보 등록
 ***********************************************************************************/
PROCEDURE IF_TRNF_INFO_UPD (  
                            IN_VNDR                IN  VARCHAR2
                          , IN_CLNTIP              IN  VARCHAR2
                          , IN_USERID              IN  VARCHAR2
                          -- IN_HSPTID             IN  VARCHAR2
																							   , IN_HSP_TP_CD           IN  VARCHAR2
																							   , IN_SEQ                 IN  NUMBER
																							   , IN_PT_NO               IN  VARCHAR2
																							   , IN_PACT_ID             IN  VARCHAR2 
																							   , IN_TRNF_PRGR_STS_CD    IN  VARCHAR2
																							   , IN_XFER_START_DT       IN  VARCHAR2   -- 'YYYYMMDDHH24MISS'
																							   , IN_XFER_ARVL_PLAN_DT   IN  VARCHAR2   -- 'YYYYMMDDHH24MISS'
																							   , IN_XFER_ARVL_DT        IN  VARCHAR2   -- 'YYYYMMDDHH24MISS'
																							   , IN_MED_STAFF_ACCOMP_YN IN  VARCHAR2
																							   , IN_MEDICAL_DEVICE_YN   IN  VARCHAR2
																							   , IN_MEDICAL_DEVICE_NM   IN  VARCHAR2
																							   , IN_XFER_REF_MEMO       IN  VARCHAR2
																							   , IN_XFER_REF_MEMOXFER_INFO_REG_DT IN VARCHAR2 -- 'YYYYMMDDHH24MISS'
																							   , IN_LSH_DTM             IN  VARCHAR2
																							   , IN_LSH_IP_ADDR         IN  VARCHAR2
																							   , IN_LSH_STF_NO          IN  VARCHAR2
																							   , IN_LSH_STF_NM          IN  VARCHAR2
																							   , IN_LSH_PRGM_NM         IN  VARCHAR2
																							   , OUT_CURSOR             OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);
BEGIN
    IS_SUCCESS := 'Y';
    ERROR_MSG  := '';

    UPDATE ARPA_PT_LIST
       SET XFER_START_DT     = TO_DATE(IN_XFER_START_DT, 'yyyy-mm-dd hh24:mi:ss')
         , XFER_ARVL_PLAN_DT  = TO_DATE(IN_XFER_ARVL_PLAN_DT  , 'yyyy-mm-dd hh24:mi:ss')
         , XFER_ARVL_DT       = TO_DATE(IN_XFER_ARVL_DT  , 'yyyy-mm-dd hh24:mi:ss')
         , TRNF_PRGR_STS_CD  = IN_TRNF_PRGR_STS_CD
         , MED_STAFF_ACCOMP_YN = IN_MED_STAFF_ACCOMP_YN
         , EQUIP_YN          = IN_MEDICAL_DEVICE_YN
         , EQUIP_NM          = IN_MEDICAL_DEVICE_NM
         , XFER_REF_MEMO     = IN_XFER_REF_MEMO
         , XFER_INFO_REG_DT  = TO_DATE(IN_XFER_REF_MEMOXFER_INFO_REG_DT, 'yyyy-mm-dd hh24:mi:ss')
         , LSH_DTM             = TO_DATE(IN_LSH_DTM,'yyyy-mm-dd hh24:mi:ss')
         , LSH_IP_ADDR         = IN_LSH_IP_ADDR
         , LSH_STF_NO          = IN_LSH_STF_NO
         , LSH_STF_NM          = IN_LSH_STF_NM
         , LSH_PRGM_NM         = IN_LSH_PRGM_NM
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
        ERROR_MSG  := '';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END IF_TRNF_INFO_UPD;




/**********************************************************************************************
*    SERVICENAME    : PC_MED_RFFM_UPD
*    CREATEDATE     : 2025.08.18
*    Author         : 윤재림
*    Description    : EICU 진료의뢰서 등록
*    Change History : 
**********************************************************************************************/ 
PROCEDURE IF_MED_RFFM_UPD (    
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
--                          , IN_HSPTID           IN  VARCHAR2
																							   , IN_HSP_TP_CD        IN  VARCHAR2
																							   , IN_SEQ       			   	IN NUMBER
																							   , IN_PT_NO            IN  VARCHAR2
																					     , IN_PACT_ID            	 IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD     IN  VARCHAR2
																							   , IN_REFERRAL_DOC_REG_DT  IN  VARCHAR2
																							   , IN_LSH_DTM             	IN  VARCHAR2
																							   , IN_LSH_IP_ADDR         	IN  VARCHAR2
																							   , IN_LSH_STF_NO           IN  VARCHAR2
																							   , IN_LSH_STF_NM           IN  VARCHAR2
																							   , IN_LSH_PRGM_NM          IN  VARCHAR2
																							   , OUT_CURSOR              OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(1000); 
    V_RESULT VARCHAR2(1000); 

BEGIN
    BEGIN 

  
       UPDATE ARPA_PT_LIST
          SET TRNF_PRGR_STS_CD 		= IN_TRNF_PRGR_STS_CD
					      	, REFERRAL_DOC_REG_DT = TO_DATE(IN_REFERRAL_DOC_REG_DT,'YYYY-MM-DD HH24:MI:SS')
					       , LSH_DTM             = TO_DATE(IN_LSH_DTM,'YYYY-MM-DD HH24:MI:SS')
	           , LSH_IP_ADDR         = IN_LSH_IP_ADDR
	           , LSH_STF_NO          = IN_LSH_STF_NO
	           , LSH_STF_NM          = IN_LSH_STF_NM
	           , LSH_PRGM_NM         = IN_LSH_PRGM_NM

     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ =  IN_SEQ
       AND PT_NO = IN_PT_NO
       AND PACT_ID = IN_PACT_ID;

      
  		   	 IS_SUCCESS := 'Y';
									ERROR_MSG  := '';  -- 성공일 때는 메시지 없음
				
				
        EXCEPTION 
        WHEN OTHERS THEN
            IS_SUCCESS := 'N';
            ERROR_MSG := SQLERRM;
            
    END;
    OPEN OUT_CURSOR FOR
    SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG
      FROM DUAL;

END;

/**********************************************************************************************
*    SERVICENAME    : PC_TRNF_STS_ARVL_UPD
*    CREATEDATE     : 2025.08.20
*    Author         : 윤재림
*    Description    : EICU 환자이송종료
*    Change History :
**********************************************************************************************/

PROCEDURE IF_TRNF_STS_ARVL_UPD (
                            IN_VNDR                IN  VARCHAR2
                          , IN_CLNTIP              IN  VARCHAR2
                          , IN_USERID              IN  VARCHAR2
                          -- IN_HSPTID             IN  VARCHAR2
																							   , IN_HSP_TP_CD           IN  VARCHAR2
																							   , IN_SEQ                 IN  NUMBER
																							   , IN_PT_NO               IN  VARCHAR2
																							   , IN_PACT_ID             IN  VARCHAR2
																							   , IN_XFER_END_DT    		   IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD    IN  VARCHAR2
																							   , IN_STATUS_STS_CD       IN  VARCHAR2
																							   , IN_LSH_DTM             IN  VARCHAR2
																							   , IN_LSH_IP_ADDR         IN  VARCHAR2
																							   , IN_LSH_STF_NO          IN  VARCHAR2
																							   , IN_LSH_STF_NM          IN  VARCHAR2
																							   , IN_LSH_PRGM_NM         IN  VARCHAR2
																							   , OUT_CURSOR             OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);

BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE ARPA_PT_LIST
       SET TRNF_PRGR_STS_CD    = IN_TRNF_PRGR_STS_CD
         , STATUS_STS_CD       = IN_STATUS_STS_CD
         , XFER_END_DT 				 = TO_DATE(IN_XFER_END_DT,'yyyy-mm-dd hh24:mi:ss')
         , LSH_DTM             = TO_DATE(IN_LSH_DTM,'yyyy-mm-dd hh24:mi:ss')
         , LSH_IP_ADDR         = IN_LSH_IP_ADDR
         , LSH_STF_NO          = IN_LSH_STF_NO
         , LSH_STF_NM          = IN_LSH_STF_NM
         , LSH_PRGM_NM         = IN_LSH_PRGM_NM
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
  

/**********************************************************************************************
*    SERVICENAME    : PC_PT_TRNF_INS
*    CREATEDATE     : 2025.07.16
*    Author         : 장인수
*    Description    : EICU 이송환자 요약지 등록
*    Change History : 2025.08.13, 윤재림
**********************************************************************************************/
PROCEDURE PC_SMRY_INFO_UPD (           
                            IN_VNDR                IN  VARCHAR2
                          , IN_CLNTIP              IN  VARCHAR2
                          , IN_USERID              IN  VARCHAR2
                          -- IN_HSPTID             IN  VARCHAR2
																							   , IN_HSP_TP_CD           IN  VARCHAR2
																							   , IN_SEQ                 IN  NUMBER
																							   , IN_PT_NO               IN  VARCHAR2
																							   , IN_PACT_ID             IN  VARCHAR2
																							   , IN_TRNF_PRGR_STS_CD    IN  VARCHAR2
																							   , IN_SUMMARY_INFO_REG_DT IN  VARCHAR2
																							   , IN_LSH_DTM             IN  VARCHAR2
																							   , IN_LSH_PRGM_NM         IN  VARCHAR2
																							   , OUT_CURSOR             OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);

BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE ARPA_PT_LIST
       SET TRNF_PRGR_STS_CD    = '3'
--         , SUMMARY_INFO_REG_DT = TO_DATE(IN_SUMMARY_INFO_REG_DT,'YYYYMMDDHH24:MI:SS')
         , LSH_DTM             = TO_DATE(IN_LSH_DTM,'YYYYMMDDHH24:MI:SS')
         , LSH_PRGM_NM         = IN_LSH_PRGM_NM
     WHERE HSP_TP_CD = IN_HSP_TP_CD
       AND SEQ       = IN_SEQ
       AND PT_NO     = IN_PT_NO
       AND PACT_ID   = IN_PACT_ID;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
      

/***********************************************************************************
 *    서비스이름  : IF_TRNF_TIME_SEL
 *    최초 작성일 : 2025.09.10
 *    최초 작성자 : EZCARETECH 장인수
 *    DESCRIPTION :      이송시간 조회
 ***********************************************************************************/
PROCEDURE IF_TRNF_TIME_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
																										,	IN_CDBS			          IN  VARCHAR2
																										,	OUT_CURSOR	         OUT SYS_REFCURSOR
	)
	IS
	BEGIN
		OPEN OUT_CURSOR FOR
			SELECT IF_FN_CODE_SEL('HSP_TRAN_TIME', IN_CDBS, 'CDDES1')    AS     CDDES1
			FROM DUAL;
	END;
  

/**********************************************************************************************
*    SERVICENAME    : IF_TRAN_TIME_UPD
*    CREATEDATE     : 2025.09.03
*    Author         : 윤재림
*    Description    : 이송시간 업데이트
*    Change History :
**********************************************************************************************/	
	PROCEDURE IF_TRNF_TIME_UPD (    
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID          IN  VARCHAR2
																							   , IN_CDBS           	 IN  VARCHAR2
																							   , IN_CDDES1           IN  VARCHAR2
																							   , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);

BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE ARPA_CD_LIST
       SET CDDES1    = IN_CDDES1
     WHERE COMKDCD 	 = 'HSP_TRAN_TIME'
       AND CDBS      = IN_CDBS;

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;
  

/**********************************************************************************************
*    SERVICENAME    : IF_PHONE_NUMBER_SEL
*    CREATEDATE     : 2025.09.03
*    Author         : 윤재림
*    Description    : 휴대번호 조회 
*    Change History :
**********************************************************************************************/
PROCEDURE IF_PHONE_NUMBER_SEL (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
	                        , IN_HSP_TP_CD		  	IN VARCHAR2
													, OUT_CURSOR					OUT SYS_REFCURSOR
	)
	IS
	BEGIN
		OPEN OUT_CURSOR FOR
	  SELECT
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_1' THEN COMN_CD_NM END) AS PHONE_NUMBER_1,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_2' THEN COMN_CD_NM END) AS PHONE_NUMBER_2,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_3' THEN COMN_CD_NM END) AS PHONE_NUMBER_3,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_4' THEN COMN_CD_NM END) AS PHONE_NUMBER_4,
	    MAX(CASE WHEN COMN_CD = 'PHONE_NUMBER_5' THEN COMN_CD_NM END) AS PHONE_NUMBER_5
		FROM HICU.UCCOCSTE
		WHERE COMN_GRP_CD = 'ICTEL'
		  AND COMN_CD IN (
		        'PHONE_NUMBER_1',
		        'PHONE_NUMBER_2',
		        'PHONE_NUMBER_3',
		        'PHONE_NUMBER_4',
		        'PHONE_NUMBER_5'
	  );
	END;

  
/**********************************************************************************************
*    SERVICENAME    : IF_PHONE_NUMBER_UPD
*    CREATEDATE     : 2025.09.03
*    Author         : 윤재림
*    Description    : 휴대번호 수정 
*    Change History :
**********************************************************************************************/
PROCEDURE IF_PHONE_NUMBER_UPD (
                            IN_VNDR             IN  VARCHAR2
                          , IN_CLNTIP           IN  VARCHAR2
                          , IN_USERID           IN  VARCHAR2
                          , IN_HSPTID           IN  VARCHAR2
											    , IN_COMN_CD          IN  VARCHAR2
											    , IN_HSP_TP_CD        IN  VARCHAR2
											    , IN_COMN_CD_NM       IN  VARCHAR2
											    , OUT_CURSOR          OUT SYS_REFCURSOR
)
AS
    IS_SUCCESS VARCHAR2(1);
    ERROR_MSG  VARCHAR2(200);

BEGIN
    IS_SUCCESS := 'N';
    ERROR_MSG  := NULL;

    UPDATE HICU.UCCOCSTE
       SET COMN_CD_NM	 = IN_COMN_CD_NM
     WHERE COMN_CD 	   = IN_COMN_CD
       AND HSP_TP_CD   = IN_HSP_TP_CD
       AND COMN_GRP_CD = 'ICTEL';

    IF SQL%ROWCOUNT > 0 THEN
        IS_SUCCESS := 'Y';
    ELSE
        IS_SUCCESS := 'N';
        ERROR_MSG  := '대상 행이 없습니다.';
    END IF;

    OPEN OUT_CURSOR FOR
        SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;

EXCEPTION
    WHEN OTHERS THEN
        IS_SUCCESS := 'N';
        ERROR_MSG  := SUBSTR(SQLERRM, 1, 200);
        OPEN OUT_CURSOR FOR
            SELECT IS_SUCCESS AS IS_SUCCESS, ERROR_MSG AS ERROR_MSG FROM DUAL;
END;

                              
  /*    통계-환자이송현황   R   PROC */
  PROCEDURE IF_STTS_TRNF_CRCCM_SEL (  
                        P_VNDR      IN VARCHAR2        --분당서울대학교병원
                       ,P_CLNTIP    IN VARCHAR2        --접속 아이피 
                       ,P_USERID    IN VARCHAR2        --사용자ID 
                       ,P_HSPTID    IN VARCHAR2        --병원ID  
                       ,P_STDT      IN VARCHAR2        --시작일자
                       ,P_ENDT      IN VARCHAR2        --종료일자  
                       ,OUT_CURSOR    OUT SYS_REFCURSOR  --결과커서    TRUE    결과 CURSOR
                              
                              )
								IS
								BEGIN
													    OPEN OUT_CURSOR FOR
							SELECT
												    IF_FN_CODE_SEL('HSP_TP_CD', HSP_TP_CD) AS HSP_NM,
												     HSP_TP_CD,
												    COUNT(CASE WHEN STATUS_STS_CD in('E') THEN 1 END) AS XFER_CNT,
												    COUNT(*) AS CO_TREAT_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'Y' THEN 1 END) AS HOLD_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'N' THEN 1 END) AS REJ_CNT,
												    COUNT(DISTINCT PT_NO) AS ICU_PT_CNT,
												    COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END) AS XFER_REQ_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'E' THEN 1 END) AS XFER_APPR_CNT,
												
												    ROUND(
												        COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END)
												        / NULLIF(COUNT(DISTINCT PT_NO), 0) * 100
												    , 1) AS XFER_REQ_RT,
												
												    ROUND(
												        COUNT(CASE WHEN STATUS_STS_CD = 'E' THEN 1 END)
												        / NULLIF(COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END), 0) * 100
												    , 1) AS XFER_APPR_RT,
												
												   ROUND(SUM(ABS((XFER_END_DT - CONSULT_REQ_DT) * 24 * 60)),0) AS XFER_TOT_TM,
											    ROUND(SUM(ABS((XFER_START_DT - XFER_DECISION_DT) * 24 * 60)), 0) AS XFER_D2S_TM,
											    ROUND(SUM(ABS((XFER_END_DT - XFER_DECISION_DT) * 24 * 60)), 0) AS XFER_D2E_TM,
											    ROUND(SUM(ABS((XFER_END_DT - XFER_START_DT) * 24 * 60)),0) AS XFER_S2E_TM,
												
												    COUNT(CASE WHEN XFER_END_DT IS NOT NULL THEN 1 END) AS XFER_END_CNT,
												    COUNT(CASE WHEN XFER_START_DT IS NOT NULL THEN 1 END) AS XFER_D2S_CNT
												
												FROM arpa_pt_list
												WHERE STATUS_STS_CD NOT IN('C','D','A') 
												  AND HSP_TP_CD = P_HSPTID       
												  and CONSULT_REQ_DT BETWEEN TRUNC( TO_DATE(P_STDT, 'YYYY-MM-DD HH24:MI:SS')) AND TRUNC( TO_DATE(P_ENDT, 'YYYY-MM-DD HH24:MI:SS')) + 0.99999
												GROUP BY
												    IF_FN_CODE_SEL('HSP_TP_CD', HSP_TP_CD)  , HSP_TP_CD
--											UNION ALL
--
---- 데이터 없을 때 강제로 1행 생성
--SELECT
--    IF_FN_CODE_SEL('HSP_TP_CD', P_HSPTID) AS HSP_NM,
--    P_HSPTID AS HSP_TP_CD,
--    0 AS CO_TREAT_CNT,
--    0 AS XFER_CNT,
--    0 AS HOLD_CNT,
--    0 AS REJ_CNT,
--    0 AS ICU_PT_CNT,
--    0 AS XFER_REQ_CNT,
--    0 AS XFER_APPR_CNT,
--    0 AS XFER_REQ_RT,
--    0 AS XFER_APPR_RT,
--    0 AS XFER_TOT_TM,
--    0 AS XFER_D2S_TM,
--    0 AS XFER_D2E_TM,
--    0 AS XFER_S2E_TM,
--    0 AS XFER_END_CNT,
--    0 AS XFER_D2S_CNT
--FROM dual
--WHERE NOT EXISTS (
--    SELECT 1
--    FROM arpa_pt_list
--    WHERE STATUS_STS_CD NOT IN ('C','D','A')
--       AND HSP_TP_CD = P_HSPTID
--
--)
;	

								END IF_STTS_TRNF_CRCCM_SEL;
								 
								                              
                              
                              
                              
                              
--  /*    통계-환자이송현황   R   PROC */
  PROCEDURE IF_STTS_DEPT_TRNF_CRCCM_SEL (  
                        P_VNDR      IN VARCHAR2        --분당서울대학교병원
                       ,P_CLNTIP    IN VARCHAR2        --접속 아이피 
                       ,P_USERID    IN VARCHAR2        --사용자ID 
                       ,P_HSPTID    IN VARCHAR2        --병원ID  
                       ,P_STDT      IN VARCHAR2        --시작일자
                       ,P_ENDT      IN VARCHAR2        --종료일자  
                       ,OUT_CURSOR    OUT SYS_REFCURSOR  --결과커서    TRUE    결과 CURSOR
                              )
                              	IS
								BEGIN
													    OPEN OUT_CURSOR FOR
												SELECT IF_FN_CODE_SEL('HSP_TP_CD',HSP_TP_CD )   AS HSP_NM
					     , COUNT(CASE
					             WHEN STATUS_STS_CD = 'A' THEN 1
					              END)                              AS XFER_CNT /* 협진 후 이송 건수 (이송종료 기준) */
					     , COUNT(*)                                 AS CO_TREAT_CNT     /* 총 협진 받은 건수 */
					     , COUNT(CASE
					             WHEN STATUS_STS_CD = 'Y' THEN 1
					              END)                              AS HOLD_CNT   /* 협진완료 건수 */
					     , COUNT(CASE
					             WHEN STATUS_STS_CD = 'N' THEN 1
					              END)                              AS REJ_CNT  /* 불가 건수 */
					     , COUNT(DISTINCT PT_NO)                    AS ICU_PT_CNT       /* ICU 전체 환자 수 (조건 필요 시 조정) */
					     , COUNT(CASE
					             WHEN XFER_DECISION_DT IS NOT NULL THEN 1
					              END)                              AS XFER_REQ_CNT  /* 이송 환자 의뢰 수 (이송 결정) */
					     , COUNT(CASE
					             WHEN STATUS_STS_CD = 'E' THEN 1
					             END)                              AS XFER_APPR_CNT  /* 이송 환자 승인 수 (이송 종료) */
					     , ROUND(
					       COUNT(CASE
					             WHEN XFER_DECISION_DT IS NOT NULL THEN 1
					              END)
					        / NULLIF(COUNT(DISTINCT PT_NO), 0) * 100
					     , 1)                                   AS XFER_REQ_RT     /* 이송 환자 의뢰율 (%) */
					     , ROUND(
					        COUNT(CASE
					                WHEN STATUS_STS_CD = 'E' THEN 1
					              END)
					        / NULLIF(COUNT(CASE
					                        WHEN XFER_DECISION_DT IS NOT NULL THEN 1
					                      END), 0) * 100
					     , 1)                                   AS XFER_APPR_RT    /* 이송 환자 승인율 (%) */
					     , ROUND(AVG(
					        (XFER_END_DT - CONSULT_REQ_DT) * 24 * 60
					        ), 1)                                  AS XFER_TOT_TM /* 이송종료 - 협진의뢰 시간(분) */
					    ,ROUND(AVG(
					        (XFER_START_DT - XFER_DECISION_DT) * 24 * 60
					    ), 1)                                  AS XFER_D2S_TM    /* 이송시작 - 이송결정 시간(분) */
					   , ROUND(AVG(
					        (XFER_END_DT - XFER_DECISION_DT) * 24 * 60
					    ), 1)                                  AS XFER_D2E_TM    /* 이송종료 - 이송결정 시간(분) */
					    , ROUND(AVG(
					        (XFER_END_DT - XFER_START_DT) * 24 * 60
					    ), 1)                                  AS XFER_S2E_TM    /* 이송종료 - 이송시작 시간(분) */
					   , COUNT(CASE
					            WHEN XFER_END_DT IS NOT NULL THEN 1
					          END)                              AS XFER_END_CNT /* 이송종료일시 등록 환자 수 */
					    ,COUNT(CASE
					            WHEN XFER_START_DT IS NOT NULL THEN 1
					          END)                              AS XFER_D2S_CNT   /* 이송시작일시 등록 환자 수 */
					
					FROM arpa_pt_list
					WHERE 1 = 1
					
					  -- AND CONSULT_REQ_DT BETWEEN :FROM_DT AND :TO_DT
					
					GROUP BY
					    HSP_TP_CD
					
					ORDER BY
					    HSP_TP_CD;
								END IF_STTS_DEPT_TRNF_CRCCM_SEL; 
  /*    통계-시간대별발생건수   R   PROC */
  PROCEDURE IF_STTS_TMZN_OCCUR_CNT_SEL (  
                        P_VNDR      IN VARCHAR2        --분당서울대학교병원
                       ,P_CLNTIP    IN VARCHAR2        --접속 아이피 
                       ,P_USERID    IN VARCHAR2        --사용자ID 
                       ,P_HSPTID    IN VARCHAR2        --병원ID  
                       ,P_STDT      IN VARCHAR2        --시작일자
                       ,P_ENDT      IN VARCHAR2        --종료일자  
                       ,OUT_CURSOR    OUT SYS_REFCURSOR  --결과커서    TRUE    결과 CURSOR
                              )	IS
								BEGIN
													    OPEN OUT_CURSOR FOR
													SELECT
												    IF_FN_CODE_SEL('HSP_TP_CD', HSP_TP_CD) AS HSP_NM,
												     HSP_TP_CD,
												    COUNT(CASE WHEN STATUS_STS_CD = 'A' THEN 1 END) AS XFER_CNT,
												    COUNT(*) AS CO_TREAT_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'Y' THEN 1 END) AS HOLD_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'N' THEN 1 END) AS REJ_CNT,
												    COUNT(DISTINCT PT_NO) AS ICU_PT_CNT,
												    COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END) AS XFER_REQ_CNT,
												    COUNT(CASE WHEN STATUS_STS_CD = 'E' THEN 1 END) AS XFER_APPR_CNT,
												
												    ROUND(
												        COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END)
												        / NULLIF(COUNT(DISTINCT PT_NO), 0) * 100
												    , 1) AS XFER_REQ_RT,
												
												    ROUND(
												        COUNT(CASE WHEN STATUS_STS_CD = 'E' THEN 1 END)
												        / NULLIF(COUNT(CASE WHEN XFER_DECISION_DT IS NOT NULL THEN 1 END), 0) * 100
												    , 1) AS XFER_APPR_RT,
												
												    ROUND(AVG((XFER_END_DT - CONSULT_REQ_DT) * 24 * 60), 1) AS XFER_TOT_TM,
												    ROUND(AVG((XFER_START_DT - XFER_DECISION_DT) * 24 * 60), 1) AS XFER_D2S_TM,
												    ROUND(AVG((XFER_END_DT - XFER_DECISION_DT) * 24 * 60), 1) AS XFER_D2E_TM,
												    ROUND(AVG((XFER_END_DT - XFER_START_DT) * 24 * 60), 1) AS XFER_S2E_TM,
												
												    COUNT(CASE WHEN XFER_END_DT IS NOT NULL THEN 1 END) AS XFER_END_CNT,
												    COUNT(CASE WHEN XFER_START_DT IS NOT NULL THEN 1 END) AS XFER_D2S_CNT
												
												FROM arpa_pt_list
												GROUP BY
												    IF_FN_CODE_SEL('HSP_TP_CD', HSP_TP_CD)  , HSP_TP_CD
												ORDER BY
												    HSP_NM;


								END IF_STTS_TMZN_OCCUR_CNT_SEL; 
--                              
--                                /* ICU환자상세조회    R   VIEW */
--  PROCEDURE PC_BSH_ICU_PT_DTL_ASK( 
--                                     IN_SQL_ID    IN VARCHAR2      -- SQL ID
--                                    ,IN_STF_NO    IN VARCHAR2      -- 직원번호
--                                    ,IN_IP_ADDR    IN VARCHAR2      -- IP ADDRESS 
--                                    ,IN_HSP_TP_CD      IN VARCHAR2       -- 병원코드
--                                    ,IN_PT_NO      IN VARCHAR2      -- 환자번호     
--                                    ,IN_PACT_ID    IN VARCHAR2      -- 원무접수ID   
--                                    ,OUT_DATA OUT SYS_REFCURSOR 
--                                    ) ;
--
--  /*    RRS 에서 사용하는 해당 환자정보 조회    R   VIEW */
--  PROCEDURE IF_IC_EM_NI_004 (  
--                      --  P_VNDR      IN VARCHAR2        --분당서울대학교병원
--                      -- ,P_CLNTIP    IN VARCHAR2        --접속 아이피 
--                      -- ,P_USERID    IN VARCHAR2        --사용자ID 
--                      -- ,P_HSTPID    IN VARCHAR2        --병원ID  
--                      -- ,P_STDT      IN VARCHAR2        --시작일자
--                      -- ,P_ENDT      IN VARCHAR2        --종료일자  
--                        OUT_DATA    OUT SYS_REFCURSOR  --결과커서    TRUE    결과 CURSOR
--                              ) ;
--
--
--
--  /*    RRS 환자 DNR 여부 조회  R   FUN */
--  FUNCTION IF_IC_EM_NI_FUN_001 (  
--                      --  P_VNDR      IN VARCHAR2        --분당서울대학교병원
--                      -- ,P_CLNTIP    IN VARCHAR2        --접속 아이피 
--                      -- ,P_USERID    IN VARCHAR2        --사용자ID 
--                        P_HSPTID    IN VARCHAR2        --병원ID  
--                       ,P_PATID     IN VARCHAR2        --환자번호
--                      --  OUT_DATA    OUT SYS_REFCURSOR  --결과커서    TRUE    결과 CURSOR
--                              ) RETURN VARCHAR2 ;
--                              
                               
END IFARPA_PACK;
