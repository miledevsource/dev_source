
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI002V" ("WD_DEPT_CD", "TOL_WD_CNT", "USE_WD_CNT", "EMPT_WD_CNT", "IN_WD_CNT", "OUT_WD_CNT") AS 
  SELECT A.WD_DEPT_CD                                  WD_DEPT_CD       --01. 격리병동부서코드
     , SUM(A.TOL_WD_CNT)                             TOL_WD_CNT       --02. 격리 병동의 병상 수(전체)
     , SUM(A.USE_WD_CNT)                             USE_WD_CNT       --03. 사용 병상 수
     , SUM(A.TOL_WD_CNT - A.USE_WD_CNT)              EMPT_WD_CNT      --04. 공 병상 수
     , SUM(A.IN_WD_CNT)                              IN_WD_CNT        --05. 입실예정 환자 수
     , SUM(A.OUT_WD_CNT)                             OUT_WD_CNT       --06. 퇴실예정 환자 수
  FROM ( SELECT A.WD_DEPT_CD                         WD_DEPT_CD       --01. 격리병동부서코드
              , COUNT(A.WD_DEPT_CD)                  TOL_WD_CNT       --02. 격리 병동의 병상 수(전체)
              , ( SELECT COUNT(*)
                    FROM ACPPRAAM
                   WHERE CLCTN_WD_DEPT_CD = A.WD_DEPT_CD
                     AND SIHS_YN = 'Y'
                     AND APCN_YN = 'N'
                 )                                   USE_WD_CNT       --03. 사용 병상 수
              , 0                                    EMPT_WD_CNT      --04. 공 병상 수
              , (
                    SELECT NVL(SUM(CASE WHEN T1.WD_DEPT_CD <> P1.CLCTN_WD_DEPT_CD THEN 1 ELSE 0 END), 0)  CNT
					  FROM ACPPETSH T1
					     , ACPPRAAM P1
					 WHERE T1.PT_NO          = P1.PT_NO (+)
					   AND T1.RPY_PACT_ID    = P1.PACT_ID (+)
					   AND T1.HSP_TP_CD      = P1.HSP_TP_CD (+)
					   AND T1.WD_DEPT_CD     = A.WD_DEPT_CD
					   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
					   AND NVL(PACT_YN, 'N') = 'N'
--					   AND T1.HSP_TP_CD      = A.HSP_TP_CD
					   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
					                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
					                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
					     			                               FROM ACPPETSH T2
					                                              WHERE T2.PT_NO             = T1.PT_NO
--					                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD    /* 부서조건 주석처리 */
					                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
					                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
					                                                AND NVL(T2.PACT_YN, 'N') = 'N'
					                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
					                                                AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* 이전병동과 신청병동이 다른 경우에만 조회 */
					                                              GROUP BY T2.RPY_PACT_ID
					                                            )
					   AND P1.SIHS_YN(+)     = 'Y'
					   AND P1.APCN_YN (+)    = 'N'
					   AND P1.APCN_DTM (+)   IS NULL
                )                                    IN_WD_CNT        --05. 입실예정 환자 수
              , (
                    SELECT NVL(SUM(CASE WHEN T1.WD_DEPT_CD <> P1.CLCTN_WD_DEPT_CD THEN 1 ELSE 0 END), 0)  CNT
					  FROM ACPPETSH T1
					     , ACPPRAAM P1
					 WHERE T1.PT_NO          = P1.PT_NO (+)
					   AND T1.RPY_PACT_ID    = P1.PACT_ID (+)
					   AND T1.HSP_TP_CD      = P1.HSP_TP_CD (+)
					   AND T1.FMR_WD_DEPT_CD = A.WD_DEPT_CD
					   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
					   AND NVL(PACT_YN, 'N') = 'N'
--					   AND T1.HSP_TP_CD      = A.HSP_TP_CD
					   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
					                                             SELECT /*+ INDEX(ACPPETSH ACPPETSH_SI01) */
					                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
					     			                               FROM ACPPETSH T2
					                                              WHERE T2.PT_NO             = T1.PT_NO
--					                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD   /* 부서조건 주석처리 */
					                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
					                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
					                                                AND NVL(T2.PACT_YN, 'N') = 'N'
					                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
					                                                AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* 이전병동과 신청병동이 다른 경우에만 조회 */
					                                              GROUP BY T2.RPY_PACT_ID
					                                            )
					   AND P1.SIHS_YN(+)     = 'Y'
					   AND P1.APCN_YN (+)    = 'N'
					   AND P1.APCN_DTM (+)   IS NULL   
					   AND P1.TDS_DTM (+)    IS NULL   /* 가퇴원환자 제외 */
                )                                    OUT_WD_CNT       --06. 퇴실예정 환자 수
           FROM ACPPERMM A
          WHERE WD_DEPT_CD = '039'
            AND APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD') --'99991231'
          GROUP BY WD_DEPT_CD
        ) A
 GROUP BY
       A.WD_DEPT_CD
 ORDER BY
       A.WD_DEPT_CD;