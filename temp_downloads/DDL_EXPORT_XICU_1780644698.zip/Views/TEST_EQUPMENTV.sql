
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."TEST_EQUPMENTV" ("EQUP_NM", "EQUP_USE_CNT", "EQUP_CNT") AS 
  SELECT 'ECMO'                       AS EQUP_NM  
		, '12'                AS EQUP_USE_CNT      
		, '123'                AS EQUP_CNT    
		FROM DUAL
UNION ALL
SELECT 'CRRT'                  AS EQUP_NM
     , '32'                AS EQUP_USE_CNT      
     , '321'                AS EQUP_CNT
  FROM DUAL;