
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EICU007V" ("HSP_CD", "WD_DEPT_CD", "PT_NO", "PT_NM", "PT_SEX", "PT_AGE", "PT_DEPT_CD", "PT_LOC", "PT_IO") AS 
  SELECT P1.HSP_TP_CD        HSP_CD
     , T1.WD_DEPT_CD       WD_DEPT_CD
     , P1.PT_NO            PT_NO
     , P2.PT_NM            PT_NM
     , P2.SEX_TP_CD        PT_SEX
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT) PT_AGE
     , P1.MED_DEPT_CD      PT_DEPT_CD
     , T1.FMR_WD_DEPT_CD   PT_LOC
     , 'I'                 PT_IO
  FROM ACPPETSH T1
     , ACPPRAAM P1
     , PCTPCPAM_DAMO P2
 WHERE T1.PT_NO          = P1.PT_NO
   AND T1.RPY_PACT_ID    = P1.PACT_ID
   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
   AND T1.PT_NO          = P2.PT_NO
   AND T1.WD_DEPT_CD     IN ('SICU', 'MICU', 'CICU', 'NCU', 'NICU', 'NICU2', 'EICU', 'EICU2')
   AND T1.WD_DEPT_CD     <> P1.CLCTN_WD_DEPT_CD
   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
   AND NVL(PACT_YN, 'N') = 'N'
   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
     			                               FROM ACPPETSH T2
                                              WHERE T2.PT_NO             = T1.PT_NO
                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD
                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
                                                AND NVL(T2.PACT_YN, 'N') = 'N'
                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                              GROUP BY T2.RPY_PACT_ID
                                            )
   AND P1.SIHS_YN        = 'Y'
   AND P1.APCN_YN        = 'N'
   AND P1.APCN_DTM       IS NULL
 UNION ALL
SELECT P1.HSP_TP_CD        HSP_CD
     , T1.FMR_WD_DEPT_CD   WD_DEPT_CD
     , P1.PT_NO            PT_NO
     , P2.PT_NM            PT_NM
     , P2.SEX_TP_CD        PT_SEX
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT) PT_AGE
     , P1.MED_DEPT_CD      PT_DEPT_CD
     , T1.WD_DEPT_CD       PT_LOC
     , 'O'                 PT_IO
  FROM ACPPETSH T1
     , ACPPRAAM P1
     , PCTPCPAM_DAMO P2
 WHERE T1.PT_NO          = P1.PT_NO
   AND T1.RPY_PACT_ID    = P1.PACT_ID
   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
   AND T1.PT_NO          = P2.PT_NO
   AND T1.FMR_WD_DEPT_CD IN ('SICU', 'MICU', 'CICU', 'NCU', 'NICU', 'NICU2', 'EICU', 'EICU2')
   AND T1.WD_DEPT_CD     <> P1.CLCTN_WD_DEPT_CD
   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
   AND NVL(PACT_YN, 'N') = 'N'
   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
     			                               FROM ACPPETSH T2
                                              WHERE T2.PT_NO             = T1.PT_NO
                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD
                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
                                                AND NVL(T2.PACT_YN, 'N') = 'N'
                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                              GROUP BY T2.RPY_PACT_ID
                                            )
   AND P1.SIHS_YN        = 'Y'
   AND P1.APCN_YN        = 'N'
   AND P1.APCN_DTM       IS NULL;