
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."UICIISPV" ("PACT_ID", "PT_NO", "ETRM_DTM", "HSP_TP_CD", "SEX_TP_CD", "AGE", "CHOT_DTM", "ETRM_WD_DEPT_CD", "ETRM_WD_DEPT_CD_NM", "INFC_MCB_TP_CD") AS 
  SELECT PACT_ID                      AS PACT_ID
     , PT_NO                        AS PT_NO
     , ETRM_DTM                     AS ETRM_DTM
     , HSP_TP_CD                    AS HSP_TP_CD
     , SEX_TP_CD                    AS SEX_TP_CD
     , AGE                          AS AGE
     , CHOT_DTM                     AS CHOT_DTM
     , ETRM_WD_DEPT_CD              AS ETRM_WD_DEPT_CD
     , ETRM_WD_DEPT_CD_NM           AS ETRM_WD_DEPT_CD_NM
     , INFC_MCB_TP_CD               AS INFC_MCB_TP_CD
  FROM HICU.UICIISPM;