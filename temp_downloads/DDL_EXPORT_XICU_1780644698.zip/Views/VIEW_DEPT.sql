
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."VIEW_DEPT" ("DEPT_CD", "DEPT_NM", "HSP_TP_CD") AS 
  SELECT '141'                           DEPT_CD
     , '소화기내과'                         DEPT_NM           
     , '1'                             HSP_TP_CD               
  FROM DUAL
UNION ALL                                                    
SELECT 'LIMR'                           DEPT_CD
     , '호흡기내과'                         DEPT_NM           
     , '1'                             HSP_TP_CD               
  FROM DUAL;