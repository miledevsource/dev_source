
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI011V" ("WD_DEPT_CD", "PRM_NO", "BED_NO", "APY_STR_DT", "HSP_TP_CD", "APY_END_DT", "BED_CNT", "FSR_DTM", "LSH_DTM") AS 
  SELECT WD_DEPT_CD     WD_DEPT_CD      --01. 병동부서코드
     , PRM_NO         PRM_NO          --02. 병실번호
     , BED_NO         BED_NO          --03. 병상번호
     , APY_STR_DT     APY_STR_DT      --04. 적용시작일자
     , HSP_TP_CD      HSP_TP_CD       --05. 병원구분코드
     , APY_END_DT     APY_END_DT      --06. 적용종료일자
     , BED_CNT        BED_CNT         --07. 병상수
     , FSR_DTM        FSR_DTM         --08. 최초등록일시
     , LSH_DTM        LSH_DTM         --09. 최종변경일시
  FROM ACPPERMM
 WHERE APY_END_DT = TO_DATE('99991231', 'YYYYMMDD');