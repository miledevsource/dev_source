
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMNI009V" ("PACT_ID", "HSP_TP_CD", "PT_NO", "NR_ITEM_ID", "NR_ITEM_NM", "ITEM_REC_DTM", "REC_CNTE", "LSH_STF_NO", "PT_CLCTN_DEPT_CD", "LSH_DTM") AS 
  SELECT A.PACT_ID                           PACT_ID             /* 원무접수번호 */
     , A.HSP_TP_CD                         HSP_TP_CD           /* 병원구분코드 */
     , A.PT_NO                             PT_NO               /* 환자번호 */
     , T.RRT_ITEM_CD                       NR_ITEM_ID          /* 항목코드 */
     , T.RRT_ITEM_NM                       NR_ITEM_NM          /* 항목명 */
     , T.UITM_DTM                           ITEM_REC_DTM        /* 항목기록일시 */
     , T.RRT_RSLT_VAL                      REC_CNTE            /* 항목 값 */
     , T.LSH_STF_NO                        LSH_STF_NO          /* 최종변경직원번호 */
     , A.CLCTN_WD_DEPT_CD                  PT_CLCTN_DEPT_CD    /* 환자현위치부서코드 */
     , T.LSH_DTM                           LSH_DTM             /* 항목최종변경일시 */
  FROM ACPPRAAM A
     , MOBRRSMT T
 WHERE A.PACT_ID          = T.PACT_ID
   AND A.PT_NO            = T.PT_NO
   AND A.HSP_TP_CD        = T.HSP_TP_CD
   AND A.SIHS_YN          = 'Y'
   AND A.APCN_YN          = 'N'
   AND A.APCN_DTM         IS NULL
   AND A.CLCTN_WD_DEPT_CD IN (SELECT COMN_CD
                                FROM CCCCCSTE
                               WHERE COMN_GRP_CD = 'N0000540'
                                 AND HSP_TP_CD   = A.HSP_TP_CD
                                 AND USE_YN      = 'Y')
   AND T.UITM_DTM          BETWEEN A.ADS_DT              AND NVL(A.DS_DTM, SYSDATE)
   AND T.UITM_DTM          BETWEEN SYSDATE - 1/24/60 * 5 AND SYSDATE  /* (1 시간 이내 -> 5분으로 변경 )중환자실 환자의 임상관찰 항목 결과(SBP, PR(HR), SP02 항목만 필요 */;