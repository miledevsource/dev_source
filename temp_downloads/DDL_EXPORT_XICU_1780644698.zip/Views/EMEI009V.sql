
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI009V" ("MDRC_ID", "MDRC_FOM_SEQ", "PT_NO", "LST_YN", "REC_DTM", "MDF_REC_DTM", "WRT_STF_NO", "MDFM_CLS_DTL_CD", "MDFM_CLS_DTL_CD_NM", "MDRC_WRT_STS_CD", "MDRC_WRT_STS_CD_NM", "MDRC_DC_TP_CD", "MDRC_DC_TP_CD_NM", "FST_WRT_DTM", "LST_CHG_DTM", "FST_LOD_DTM", "LST_LOD_DTM") AS 
  SELECT DISTINCT RECM.MDRC_ID                                            MDRC_ID
     , RECM.MDRC_FOM_SEQ                                                MDRC_FOM_SEQ
--     , RECM.HSP_TP_CD                                                   HSP_CD
     , RECM.PT_NO                                                       PT_NO
     , RECM.LST_YN                                                      LST_YN
     , RECM.REC_DTM                                                     REC_DTM
     , RECM.MDF_REC_DTM                                                 MDF_REC_DTM --수정기록일시
     , RECM.WRT_STF_NO                                                  WRT_STF_NO
     , RECM.MDFM_CLS_DTL_CD                                             MDFM_CLS_DTL_CD   --진료서식유형상세코드
     , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOZ' AND COMN_CD = RECM.MDFM_CLS_DTL_CD)           MDFM_CLS_DTL_CD_NM
     , RECM.MDRC_WRT_STS_CD                                             MDRC_WRT_STS_CD--진료기록작성상태코드
     , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOL' AND COMN_CD = RECM.MDRC_WRT_STS_CD)           MDRC_WRT_STS_CD_NM
     , RECM.MDRC_DC_TP_CD                                               MDRC_DC_TP_CD--진료기록중단구분코드
     , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOM' AND COMN_CD = RECM.MDRC_DC_TP_CD)             MDRC_DC_TP_CD_NM  --중환자실 입실 경로 유형 코드 명
     , RECM.FSR_DTM                                                     FST_WRT_DTM
     , RECM.LSH_DTM                                                     LST_CHG_DTM
     , SYSDATE                                                          FST_LOD_DTM
     , SYSDATE                                                          LST_LOD_DTM
  FROM MRDDRECM RECM                                                     -- 진료기록기본
WHERE RECM.MDFM_CLS_CD ='D032'
  AND RECM.MDFM_ID IN ('105', '132')                               -- DOCTORNOTE_TYPE_ID 진료서식유형코드
--  AND RECM.MDRC_DC_TP_CD = 'C'                               -- DC_YN 진료기록중단구분코드
  AND RECM.MDRC_WRT_STS_CD IN ('11','12')                              -- STATUS 진료기록작성상태코드
--  AND RECM.LST_YN = 'Y';