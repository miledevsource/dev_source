
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI012V" ("PT_NO", "PT_NM", "SEX_TP_CD", "AGE", "PACT_ID", "ADS_DT", "MED_DEPT_CD", "MED_DEPT_CD_NM", "PT_CUR_PSTN_CD", "PT_CUR_PSTN_NM", "SPCT_NM", "ANDR_NM", "NRS_NM", "MAIN_DGNS_DT", "MAIN_DGNS_CD", "MAIN_DGNS_NM", "FSR_DTM", "LSH_DTM", "UNTC_CSLT_YN", "HSP_TP_CD") AS 
  SELECT Z.PT_NO
     , Z.PT_NM
     , Z.SEX_TP_CD
     , Z.AGE,PACT_ID
     , Z.ADS_DT
     , Z.MED_DEPT_CD
     , Z.MED_DEPT_CD_NM
     , Z.PT_CUR_PSTN_CD
     , Z.PT_CUR_PSTN_NM
     , Z.SPCT_NM
     , Z.ANDR_NM
     , SUBSTR(Z.ASSIGNEDNURSE,INSTR(Z.ASSIGNEDNURSE,'@')+1,LENGTH(Z.ASSIGNEDNURSE) -INSTR(Z.ASSIGNEDNURSE,'@')) NRS_NM
     , Z.MAIN_DGNS_DT
     , Z.MAIN_DGNS_CD
     , Z.MAIN_DGNS_NM
     , Z.FSR_DTM
     , Z.LSH_DTM   
     , Z.UNTC_CSLT_YN
     , Z.HSP_TP_CD
  FROM (
		SELECT A.PT_NO                                       PT_NO
		     , P.PT_NM                                       PT_NM
		     , P.SEX_TP_CD                                   SEX_TP_CD
		     , XBIL.FT_PCT_AGE('AGE', SYSDATE, P.PT_BRDY_DT) AGE
		     , A.PACT_ID                                     PACT_ID
		     , A.ADS_DT                                      ADS_DT
		     , A.MED_DEPT_CD                                 MED_DEPT_CD
		     , B.DEPT_NM                                     MED_DEPT_CD_NM
		     , A.CLCTN_WD_DEPT_CD                            PT_CUR_PSTN_CD
		     , C.DEPT_NM                                     PT_CUR_PSTN_NM
		     ,(SELECT V.KOR_SRNM_NM
		         FROM CNLRRUSD V
		        WHERE V.STF_NO = NVL(A.NCDR_STF_NO
		                           , A.CHDR_STF_NO)
		        )                                            SPCT_NM
		     ,(SELECT V.KOR_SRNM_NM
		         FROM CNLRRUSD V
		        WHERE V.STF_NO = A.ANDR_STF_NO
		        )                                            ANDR_NM
		     , XMED.FT_MOM_ASSIGNEDNURSE(A.PACT_ID
		                               , 'I'
		                               , A.HSP_TP_CD)        ASSIGNEDNURSE
		     , Z.DGNS_REG_DT                                 MAIN_DGNS_DT
		     , Z.ICD10_CD                                    MAIN_DGNS_CD
		     , Z.CLDG_NM                                     MAIN_DGNS_NM
		     , NVL(Z.FSR_DTM, A.FSR_DTM)                     FSR_DTM
	       , NVL(Z.LSH_DTM, A.LSH_DTM)                     LSH_DTM 
		     , A.HSP_TP_CD                                   HSP_TP_CD
		     , CASE WHEN XMED.FT_MOM_FOCUS_TRTROOM_YN(A.CLCTN_WD_DEPT_CD, A.CLCTN_PRM_NO, A.HSP_TP_CD) = 'Y' AND A.CLCTN_WD_DEPT_CD = '086' THEN 'Y' 
		       ELSE 'N' 
		       END  UNTC_CSLT_YN  /* 2021-06-24, 김국경 :  e-icu 비대면협진여부추가(환자정보 현재병실이 집중치료실인지여부 ex.86병동) */
		  FROM ACPPRAAM A
		     , PCTPCPAM_DAMO P
		     , PDEDBMSM B
		     , PDEDBMSM C
		     ,(SELECT X.PT_NO
		            , X.MED_PACT_ID
		            , X.DGNS_REG_DT
		            , X.MED_DEPT_CD
		            , X.FSR_DTM
		            , X.LSH_DTM
		            , Y.CLDG_NM
		            , Y.ICD10_CD
		         FROM MOODIPCD X
		            , MOODIPAM Y
		        WHERE 1=1
		          AND X.DGNS_ID = Y.DGNS_ID
		          AND X.MAIN_SKNS_YN = 'Y'
		          AND NVL(X.DTMN_SKNS_YN, 'N') = 'Y'
		          AND NVL(X.TDY_DGNS_DEL_YN, 'N') = 'N'
		          AND NVL(X.DGNS_PSD_YN, 'N') = 'N'
		        ) Z
		 WHERE 1=1
		   AND A.SIHS_YN          = 'Y'
		   AND A.PT_NO            = P.PT_NO
		   AND A.MED_DEPT_CD      = B.DEPT_CD
		   AND A.CLCTN_WD_DEPT_CD = C.DEPT_CD
		   AND A.PT_NO            = Z.PT_NO(+)
		   AND A.PACT_ID          = Z.MED_PACT_ID(+)
		   AND A.MED_DEPT_CD      = Z.MED_DEPT_CD(+)
) Z;