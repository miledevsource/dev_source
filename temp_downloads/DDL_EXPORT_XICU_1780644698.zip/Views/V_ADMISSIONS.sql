
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."V_ADMISSIONS" ("HADM_ID", "SUBJECT_ID", "ADMITTIME", "DISCHTIME", "ADMISSION_LOCATION", "DISCHARGE_LOCATION", "INSURANCE", "EDREGTIME", "EDOUTTIME", "PROVIDER_ID", "ICU_EXPIRE_FLAG", "STAY_STATUS") AS 
  WITH PT_LIST AS (
    SELECT B.PACT_ID
      FROM MOMNMIOD A        --중환자실입실퇴실시간정보
         , ACPPRAAM B        --입원접수기본
     WHERE A.PACT_ID         = B.PACT_ID
       AND A.HSP_TP_CD       = B.HSP_TP_CD
       --AND A.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
       AND A.USE_YN          = 'Y'                     --사용여부
       AND A.LST_YN          = 'Y'                     --최종여부
       AND A.PACT_TP_CD      = 'I'                     --원무접수구분코드
       AND B.APCN_YN         = 'N'                     --접수취소여부
     GROUP BY B.PACT_ID
)
SELECT B.PACT_ID                                                                                AS HADM_ID             --수진ID
     , B.PT_NO                                                                                  AS SUBJECT_ID          --환자번호
     , B.ADS_DTM                                                                                AS ADMITTIME           --입원일시
     , B.DS_DTM                                                                                 AS DISCHTIME           --퇴원일시
     , NULL                                                                                     AS ADMISSION_LOCATION  --입원 전 장소
     , NULL                                                                                     AS DISCHARGE_LOCATION  --퇴원 후 장소
     , ( SELECT CASE WHEN X.COMN_CD_NM = '국민건강보험공단' THEN 'National Healthcare Insurance Service'
                     WHEN X.COMN_CD_NM = '임상시험센터' THEN 'clinical trial center'
                     WHEN X.COMN_CD_NM = '자비연구용' THEN 'self research'
                     WHEN X.COMN_CD_NM = '의료급여1종' THEN 'medical insurance 1'
                     WHEN X.COMN_CD_NM = '의료급여2종' THEN 'medical insurance 2'
                     WHEN X.COMN_CD_NM = '의료급여장애인' THEN 'medical insurance disabled'
                     WHEN X.COMN_CD_NM = '일반환자' THEN 'no insurance'
                     WHEN X.COMN_CD_NM = '학구환자' THEN 'research patient'
                     WHEN X.COMN_CD_NM = '자동차보험' THEN 'Automobile insurance'
                     ELSE NULL END
           FROM CCCCCSTE X
          WHERE X.COMN_GRP_CD ='356'
            AND X.COMN_CD = B.PME_CLS_CD
       )                                                                                        AS INSURANCE           --환자급종유형코드
     , C.EMRM_ARVL_DTM                                                                          AS EDREGTIME           --응급실도착일시
     , C.CHOT_DTM                                                                               AS EDOUTTIME           --응급실퇴실일시
     , B.CHDR_STF_NO                                                                            AS PROVIDER_ID         --지정의 직원ID
     , NULL                                                                                     AS ICU_EXPIRE_FLAG     --중환자실퇴실유형
     , B.SIHS_YN                                                                                AS STAY_STATUS         --재원상태
  FROM PT_LIST A
     , ACPPRAAM B
     , ACPPRETM C
 WHERE A.PACT_ID = B.PACT_ID
   AND B.EMRG_PACT_ID = C.PACT_ID(+);