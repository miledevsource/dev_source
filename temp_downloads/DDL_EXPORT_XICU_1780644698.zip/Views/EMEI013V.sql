
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI013V" ("HSP_TP_CD", "STF_IFY_ID", "STF_NO", "STF_NM", "AADP_CD", "AOA_DEPT_NM", "AOA_WRK_DEPT_CD", "AOA_WRK_DEPT_NM", "USE_GRP_CD", "OCTY_TP_CD", "OCTY_NM", "TEL_NO", "FSR_DTM", "LSH_DTM") AS 
  SELECT HSP_TP_CD     HSP_TP_CD       -- 병원구분코드
       , HIS_USR_SID STF_IFY_ID      -- HIS사용자직원식별ID
       , HIS_STF_NO  STF_NO          -- HIS직원번호
       , USR_NM      STF_NM          -- 사용자명
       , 'DO'        AADP_CD                                     -- 부서코드
       , USR_NM      AOA_DEPT_NM     -- 사용자명                  -- 발령근무부서이름
       , 'DO'        AOA_WRK_DEPT_CD -- 발령근무부서코드
       , USR_NM      AOA_WRK_DEPT_NM -- 사용자명                  -- 사용그룹코드
       , 'DO'        USE_GRP_CD       , NULL        OCTY_TP_CD  -- 직종구분코드
       , NULL        OCTY_NM

       , FSR_PRGM_NM  TEL_NO         -- 최초등록프로그램명
       , SYSDATE     FSR_DTM         -- 최초등록일시
       , SYSDATE     LSH_DTM         -- 최종변경일시
   FROM HICU.UCCOCUSM u
UNION ALL
/*20210407 Test용 임시 Dummy Data 끝 */

SELECT A.HSP_TP_CD                      HSP_TP_CD -- 병원구분코드
     , A.SID                            STF_IFY_ID -- 직원식별ID
     , A.STF_NO                         STF_NO     -- 직원번호
     , A.KOR_SRNM_NM                    STF_NM     -- 한글성명
     , A.AADP_CD                        AADP_CD    -- 발령부서코드
     , (SELECT DEPT_NM                            -- 부서명
          FROM PDEDBMSM X
         WHERE DEPT_CD = A.AADP_CD                -- 부서코드
           AND HSP_TP_CD = A.HSP_TP_CD )     AOA_DEPT_NM  --20251016 장인수 // 앱솔루션팀 이지온더콜 테스트 진행을 위해 HSP_TP_CD 조건 추가  -- 발령근무부서이름
     , A.AOA_WKDP_CD                    AOA_WRK_DEPT_CD -- 발령근무부서코드
     , (SELECT DEPT_NM
          FROM PDEDBMSM X
         WHERE DEPT_CD = A.AOA_WKDP_CD
          AND HSP_TP_CD = A.HSP_TP_CD )  AOA_WRK_DEPT_NM   --20251016 장인수 // 앱솔루션팀 이지온더콜 테스트 진행을 위해 HSP_TP_CD 조건 추가  -- 발령근무부서이름
     , A.USE_GRP_CD                     USE_GRP_CD  -- 사용그룹코드
     , A.OCTY_TP_CD                     OCTY_TP_CD  -- 직종구분코드
--     , XGAB.FT_RPP_CNLRCSTE_NM('005', A.OCTY_TP_CD, A.HSP_TP_CD) OCTY_NM
     , (SELECT COMN_CD_NM                -- 공통코드명
          FROM CNLRCSTE X
         WHERE X.COMN_GRP_CD = '005'     -- 공통그룹코드
           AND X.COMN_CD = A.OCTY_TP_CD  -- 공통코드
           AND HSP_TP_CD = A.HSP_TP_CD )    OCTY_NM  --20251016 장인수 // 앱솔루션팀 이지온더콜 테스트 진행을 위해 HSP_TP_CD 조건 추가
     , (SELECT TEL_NO
          FROM PDESDSTD X
         WHERE X.STF_NO = A.STF_NO
           AND X.CTAD_TP_CD = '01'
           AND X.AVL_END_DTM = TO_DATE('9999-12-31','YYYY-MM-DD')
           --AND X.HSP_TP_CD = A.HSP_TP_CD --20250828 본사 주석처리
           AND X.HSP_TP_CD = A.HSP_TP_CD --20251016 장인수 // 앱솔루션팀 이지온더콜 테스트를 위해 PDESDSTD 테이블에 HSP_TP_CD 컬럼 및 '01' 데이터 추가
           AND ROWNUM = 1)              TEL_NO
     , A.FSR_DTM                        FSR_DTM
     , A.LSH_DTM                        LSH_DTM
   FROM CNLRRUSD A
  WHERE (RTRM_DT IS NULL OR RTRM_DT >= TRUNC(SYSDATE));