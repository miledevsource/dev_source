
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMNI001V" ("HSP_CD", "HSP_NM", "ICU_CNT", "TOT_WD_CNT", "IN_CNT", "EMPT_WD_DNT", "ISLT_EMPT_WD_CNT", "NGPSSR_EMPT_WD_CNT", "TOT_VENT_PT_CNT", "ISLT_PT_CNT") AS 
  SELECT '08'                                          HSP_CD              --01. 권역별 병원 코드
     , '분당서울대학교병원  '                           HSP_NM              --02. 권영별 병원 명칭
     , SUM(A.ICU_CNT)                           ICU_CNT
--     ,(SELECT MAX(SCRN_MRK_SEQ)
--         FROM CCCCCSTE
--        WHERE COMN_GRP_CD = 'N0000160' -- 기존 N0000540
--          AND USE_YN      = 'Y'
--       )                                             ICU_CNT             --03. 중환자실 수
     , SUM(A.TOT_WD_CNT)                             TOT_WD_CNT          --04. 중환자실 전체 병상 수
     , SUM(A.IN_CNT)                                 IN_CNT              --05. 중환자실 전체 입원환자 수
     , SUM(A.TOT_WD_CNT - A.IN_CNT)                  EMPT_WD_DNT         --06. 중환자실 전체 공병상 수
     , SUM(A.ISLT_TOL_WD_CNT - A.ISLT_USE_WD_CNT)    ISLT_EMPT_WD_CNT    --07. 중환자실 전체 격리 공병상 수
     , SUM(A.NGPSSR_EMPT_WD_CNT)                     NGPSSR_EMPT_WD_CNT  --08. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
     , SUM(A.TOT_VENT_PT_CNT)                        TOT_VENT_PT_CNT     --09. 중환자실 내 인공호흡기 적용 환자 수
     , SUM(A.ISLT_PT_CNT)                            ISLT_PT_CNT         --10. 격리환자수
  FROM (
         SELECT A.WD_DEPT_CD                         WD_DEPT_CD          --01. 중환자실병동부서코드
              , COUNT(A.WD_DEPT_CD)                  TOT_WD_CNT          --02. 각 중환자실 병상 수(전체)
              , ( SELECT COUNT(*)
                    FROM ACPPRAAM
                   WHERE CLCTN_WD_DEPT_CD = A.WD_DEPT_CD
                     AND SIHS_YN = 'Y'
                     AND APCN_YN = 'N'
                     AND TDS_DTM IS NULL   /* 가퇴원환자 제외 */
                 )                                   IN_CNT              --03. 사용 병상 수
              , ( SELECT COUNT(*)
                    FROM ACPPERMM B
                   WHERE B.WD_DEPT_CD = A.WD_DEPT_CD
                     AND B.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
--                     AND B.PRM_NO = '00'
                     AND B.PRM_NO = (SELECT DECODE(DTRL1_NM, 'Y', '00', B.PRM_NO)
                                       FROM CCCCCSTE
                                      WHERE COMN_GRP_CD = 'N0000160'
                                        AND COMN_CD = B.WD_DEPT_CD
                                        AND USE_YN      = 'Y')
                     AND B.CIPT_ISLT_PSB_YN = 'Y'
                 )                                   ISLT_TOL_WD_CNT     --04. 중환자실 내 격리 병상 수(전체)
              , 0                                    ISLT_USE_WD_CNT     --05. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    NGPSSR_EMPT_WD_CNT  --06. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
              , 0                                    TOT_VENT_PT_CNT     --07. 중환자실 내 인공호흡기 적용 환자 수
              , 0                                    ISLT_PT_CNT         --    중환자실 수
              , ( SELECT COUNT(COMN_CD)
                    FROM CCCCCSTE
                   WHERE COMN_GRP_CD = 'N0000160'
                     AND USE_YN      = 'Y'
                 )                                   ICU_CNT             --03. 중환자실 수
           FROM ACPPERMM A
          WHERE (A.WD_DEPT_CD, A.PRM_NO)
                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                   FROM CCCCCSTE
                                  WHERE COMN_GRP_CD = 'N0000160'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD  본사테스트
                                    AND USE_YN      = 'Y')
--            AND A.PRM_NO = '00'
            AND A.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')

          GROUP BY A.WD_DEPT_CD

          UNION ALL

         SELECT A.CLCTN_WD_DEPT_CD                   WD_DEPT_CD          --01. 중환자실병동부서코드
              , 0                                    TOT_WD_CNT          --02. 각 중환자실 병상 수(전체)
              , 0                                    IN_CNT              --03. 사용 병상 수
              , 0                                    ISLT_TOL_WD_CNT     --04. 중환자실 내 격리 병상 수(전체)
              , COUNT(B.CIPT_ISLT_PSB_YN)            ISLT_USE_WD_CNT     --05. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    NGPSSR_EMPT_WD_CNT  --06. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
              , 0                                    TOT_VENT_PT_CNT     --07. 중환자실 내 인공호흡기 적용 환자 수
              , 0                                    ISLT_PT_CNT         --08. 격리환자수
              , 0                                    ICU_CNT             --    중환자실 수
           FROM ACPPRAAM A
              , ACPPERMM B
--          WHERE B.WD_DEPT_CD IN (SELECT COMN_CD
--                                   FROM CCCCCSTE
--                                  WHERE COMN_GRP_CD = 'N0000540'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD
--                                    AND USE_YN      = 'Y')
--            AND B.PRM_NO = '00'
          WHERE (B.WD_DEPT_CD, B.PRM_NO)
                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                   FROM CCCCCSTE
                                  WHERE COMN_GRP_CD = 'N0000160'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD  본사테스트
                                    AND USE_YN      = 'Y')
            AND B.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
            AND A.SIHS_YN = 'Y'
            AND A.APCN_YN = 'N'
            AND A.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
            AND A.CLCTN_WD_DEPT_CD = B.WD_DEPT_CD
            AND A.CLCTN_PRM_NO = B.PRM_NO
            AND A.CLCTN_BED_NO = B.BED_NO
          GROUP BY A.CLCTN_WD_DEPT_CD

          UNION ALL

         SELECT A.CLCTN_WD_DEPT_CD                   WD_DEPT_CD          --01. 중환자실병동부서코드
              , 0                                    TOT_WD_CNT          --02. 각 중환자실 병상 수(전체)
              , 0                                    IN_CNT              --03. 사용 병상 수
              , 0                                    ISLT_TOL_WD_CNT     --04. 중환자실 내 격리 병상 수(전체)
              , 0                                    ISLT_USE_WD_CNT     --05. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    NGPSSR_EMPT_WD_CNT  --06. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
              , 0                                    TOT_VENT_PT_CNT     --07. 중환자실 내 인공호흡기 적용 환자 수
              , NVL(SUM(CASE WHEN C.ISLT_PRM_RSN_CD IS NOT NULL AND C.ISLT_PRM_RSN_CD != '0' THEN 1
                        ELSE 0
                        END),0)                      ISLT_PT_CNT         --08. 격리환자수
              , 0                                    ICU_CNT             --    중환자실 수
           FROM ACPPRAAM A
              , ACPPERMM B
              , ACPPETSH C
--          WHERE B.WD_DEPT_CD           IN (SELECT COMN_CD
--                                             FROM CCCCCSTE
--                                            WHERE COMN_GRP_CD = 'N0000540'
--                                              AND HSP_TP_CD   = A.HSP_TP_CD
--                                              AND USE_YN      = 'Y')
--            AND B.PRM_NO               = '00'
          WHERE (B.WD_DEPT_CD, B.PRM_NO)
                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                   FROM CCCCCSTE
                                  WHERE COMN_GRP_CD = 'N0000160'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD 본사테스트
                                    AND USE_YN      = 'Y')
            AND B.APY_END_DT           = TO_DATE('9999-12-31', 'YYYY-MM-DD')
            AND B.CIPT_ISLT_PSB_YN     = 'Y'
            AND A.SIHS_YN              = 'Y'
            AND A.APCN_YN              = 'N'
            AND A.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
            AND A.CLCTN_WD_DEPT_CD     = B.WD_DEPT_CD
            AND A.CLCTN_PRM_NO         = B.PRM_NO
            AND A.CLCTN_BED_NO         = B.BED_NO
            AND A.CLCTN_WD_DEPT_CD     = C.WD_DEPT_CD
            AND A.CLCTN_PRM_NO         = C.PRM_NO
            AND A.CLCTN_BED_NO         = C.BED_NO
            AND A.PACT_ID              = C.RPY_PACT_ID
            AND A.PT_NO                = C.PT_NO
            AND (C.RPY_PACT_ID,C.APY_END_DTM) = (
                                                 SELECT C1.RPY_PACT_ID
                                                      , MAX(C1.APY_END_DTM)
                                                   FROM ACPPRAAM A1
                                                      , ACPPERMM B1
                                                      , ACPPETSH C1
--                                                  WHERE B1.WD_DEPT_CD           IN (SELECT COMN_CD
--                                                                                      FROM CCCCCSTE
--                                                                                     WHERE COMN_GRP_CD = 'N0000540'
--                                                                                       AND HSP_TP_CD   = A.HSP_TP_CD
--                                                                                       AND USE_YN      = 'Y')
--                                                    AND B1.PRM_NO               = '00'
                                                  WHERE (B1.WD_DEPT_CD, B1.PRM_NO) IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                                                                         FROM CCCCCSTE
                                                                                        WHERE COMN_GRP_CD = 'N0000160'
--                                                                                          AND HSP_TP_CD   = A.HSP_TP_CD   본사테스트
                                                                                          AND USE_YN      = 'Y')
                                                    AND B1.APY_END_DT           = TO_DATE('9999-12-31', 'YYYY-MM-DD')
                                                    AND B1.CIPT_ISLT_PSB_YN     = 'Y'
                                                    AND A1.SIHS_YN              = 'Y'
                                                    AND A1.APCN_YN              = 'N'
                                                    AND A1.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
                                                    AND A1.CLCTN_WD_DEPT_CD     = B1.WD_DEPT_CD
                                                    AND A1.CLCTN_PRM_NO         = B1.PRM_NO
                                                    AND A1.CLCTN_BED_NO         = B1.BED_NO
                                                    AND A1.CLCTN_WD_DEPT_CD     = C1.WD_DEPT_CD
                                                    AND A1.CLCTN_PRM_NO         = C1.PRM_NO
                                                    AND A1.CLCTN_BED_NO         = C1.BED_NO
                                                    AND A1.PACT_ID              = C1.RPY_PACT_ID
                                                    AND A1.PACT_ID              = A.PACT_ID
                                                    AND A1.PT_NO                = C1.PT_NO
                                                    AND A1.PT_NO                = A.PT_NO
                                                  GROUP BY C1.RPY_PACT_ID
                                             )
          GROUP BY A.CLCTN_WD_DEPT_CD

          UNION ALL

         SELECT A.CLCTN_WD_DEPT_CD                   WD_DEPT_CD          --01. 중환자실병동부서코드
              , 0                                    TOT_WD_CNT          --02. 각 중환자실 병상 수(전체)
              , 0                                    IN_CNT              --03. 사용 병상 수
              , 0                                    ISLT_TOL_WD_CNT     --04. 중환자실 내 격리 병상 수(전체)
              , 0                                    ISLT_USE_WD_CNT     --05. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    NGPSSR_EMPT_WD_CNT  --06. 중환자실 전체 격리 공병상 수 중 음압 공병상 수
              , COUNT(A.PT_NO)                       TOT_VENT_PT_CNT     --07. 중환자실 내 인공호흡기 적용 환자 수
              , 0                                    ISLT_PT_CNT         --08. 격리환자수
              , 0                                    ICU_CNT             --    중환자실 수
           FROM ACPPRAAM A
              , ACPPERMM B
--          WHERE B.WD_DEPT_CD IN (SELECT COMN_CD
--                                   FROM CCCCCSTE
--                                  WHERE COMN_GRP_CD = 'N0000540'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD
--                                    AND USE_YN      = 'Y')
--            AND B.PRM_NO = '00'
          WHERE (B.WD_DEPT_CD, B.PRM_NO)
                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                   FROM CCCCCSTE
                                  WHERE COMN_GRP_CD = 'N0000160'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD 본사테스트
                                    AND USE_YN      = 'Y')
            AND B.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
            AND A.SIHS_YN = 'Y'
            AND A.APCN_YN = 'N'
            AND A.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
            AND A.CLCTN_WD_DEPT_CD = B.WD_DEPT_CD
            AND A.CLCTN_PRM_NO = B.PRM_NO
            AND A.CLCTN_BED_NO = B.BED_NO
            AND EXISTS ( SELECT /*+ INDEX(B MRNNRVCD_SI01) */
                                'Y'
                           FROM MRNNRVCD Y            --환자별인터페이스장비사용정보
                          WHERE Y.PACT_ID         = A.PACT_ID
                            AND Y.PT_NO           = A.PT_NO
                            AND Y.LST_YN          = 'Y'
                            AND Y.USE_YN          = 'Y'
                            AND Y.HSP_TP_CD       = A.HSP_TP_CD
                            AND Y.INTF_EQUP_TP_CD = '01'
                            AND Y.EQUP_USE_DTM    IS NOT NULL
                            AND Y.EQUP_END_DTM    IS NULL
                            AND ROWNUM = 1
                        )
          GROUP BY A.CLCTN_WD_DEPT_CD
        ) A;