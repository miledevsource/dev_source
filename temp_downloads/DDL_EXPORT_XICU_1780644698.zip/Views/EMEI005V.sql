
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI005V" ("PT_NO", "DS_DT", "MED_DEPT_CD", "PACT_TP_CD", "DS_MED_DEPT_CD", "DS_MED_DEPT_CD_NM", "ADS_WD_DEPT_CD", "ADS_WD_DEPT_CD_NM", "DTH_TP_CD", "DTH_TP_CD_NM", "ICU_USE_TP_CD", "ICU_USE_TP_CD_NM", "DTH_DT", "FST_WRT_DTM", "LST_CHG_DTM") AS 
  SELECT A.PT_NO                                                    PT_NO
     , A.DS_DT                                                    DS_DT
     , A.MED_DEPT_CD                                              MED_DEPT_CD
     , 'I'                                                        PACT_TP_CD
     , A.DS_MED_DEPT_CD                                           DS_MED_DEPT_CD
     , P1.DEPT_NM                                                 DS_MED_DEPT_CD_NM
     , A.ADS_WD_DEPT_CD                                           ADS_WD_DEPT_CD
     , P2.DEPT_NM                                                 ADS_WD_DEPT_CD_NM
     , A.DTH_TP_CD                                                DTH_TP_CD
     , XCOM.FT_CCC_CODENAME(A.HSP_TP_CD, '702', A.DTH_TP_CD)      DTH_TP_CD_NM
     , A.ICU_USE_TP_CD                                            ICU_USE_TP_CD
     , XCOM.FT_CCC_CODENAME(A.HSP_TP_CD, 'MRZ', A.ICU_USE_TP_CD)  ICU_USE_TP_CD_NM
     , A.DTH_DT                                                   DTH_DT
     , A.FSR_DTM                                                  FST_WRT_DTM
     , A.LSH_DTM                                                  LST_CHG_DTM
  FROM MSMRAAND A            --진료분석정보
  LEFT OUTER JOIN PDEDBMSM P1
    ON A.DS_MED_DEPT_CD = P1.DEPT_CD
   AND A.HSP_TP_CD      = P1.HSP_TP_CD
  LEFT OUTER JOIN PDEDBMSM P2
    ON A.ADS_WD_DEPT_CD = P2.DEPT_CD
   AND A.HSP_TP_CD      = P2.HSP_TP_CD;