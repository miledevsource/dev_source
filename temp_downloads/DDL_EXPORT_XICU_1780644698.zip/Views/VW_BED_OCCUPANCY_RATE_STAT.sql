
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."VW_BED_OCCUPANCY_RATE_STAT" ("기준일", "총병상", "재원환자", "점유율_퍼센트") AS 
  WITH days AS (
    SELECT TRUNC(SYSDATE) - LEVEL + 1 AS d
      FROM dual
   CONNECT BY LEVEL <= 365  -- 최근 365일
),
tot_beds AS (
    SELECT COUNT(*) AS tot
      FROM ACPPERMM B
     WHERE B.APY_END_DT = DATE '9999-12-31'
       AND B.WD_DEPT_CD IN (
            SELECT COMN_CD
              FROM CCCCCSTE
             WHERE COMN_GRP_CD = 'N0000540'
               AND USE_YN = 'Y'
       )
)
SELECT
    d.d AS 기준일,
    t.tot AS 총병상,
    (SELECT COUNT(*)
       FROM ACPPRAAM A
      WHERE A.SIHS_YN = 'Y'
        AND A.APCN_YN = 'N'
        AND A.TDS_DTM IS NULL
        AND A.WD_ARVL_DTM < d.d + 1
        AND (A.DS_DTM IS NULL OR A.DS_DTM >= d.d)
    ) AS 재원환자,
    ROUND(
      (SELECT COUNT(*)
         FROM ACPPRAAM A
        WHERE A.SIHS_YN = 'Y'
          AND A.APCN_YN = 'N'
          AND A.TDS_DTM IS NULL
          AND A.WD_ARVL_DTM < d.d + 1
          AND (A.DS_DTM IS NULL OR A.DS_DTM >= d.d)
      ) / NULLIF(t.tot,0) * 100
    , 1) AS 점유율_퍼센트
FROM days d
CROSS JOIN tot_beds t;