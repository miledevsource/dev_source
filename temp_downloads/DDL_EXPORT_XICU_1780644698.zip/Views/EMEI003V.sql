
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI003V" ("CIPT_ETRM_CHOT_ID", "HST_SEQ", "USE_YN", "LST_YN", "PACT_ID", "PACT_TP_CD", "PT_NO", "MED_DEPT_CD", "MED_DEPT_CD_NM", "ETRM_DTM", "ETRM_WD_DEPT_CD", "ETRM_WD_DEPT_CD_NM", "ETRM_PRM_NO", "ETRM_BED_NO", "EMRG_BED_YN", "ISLT_BED_YN", "ICU_ETRM_PATH_CLS_CD", "ICU_ETRM_PATH_CLS_CD_NM", "CHOT_DTM", "ICU_CHOT_PLC_TP_CD", "ICU_CHOT_PLC_TP_CD_NM", "CHOT_WD_MTD_CD", "CHOT_WD_MTD_CD_NM", "FST_WRT_DTM", "LST_CHG_DTM", "PT_NM", "ADS_DT", "DS_EXPT_DT", "DS_DT", "SEX_TP_CD", "AGE", "AGE_MRK_NM", "ADS_PATH_CD", "ADS_PATH_CD_NM", "FST_ACP_DTM", "LST_ACP_DTM", "APCN_YN", "RPRN_MED_DEPT_CD", "RPRN_MED_DEPT_CD_NM") AS 
  SELECT A.ICU_ETRM_CHOT_ID                                                                          CIPT_ETRM_CHOT_ID
--     , A.HSP_TP_CD                                                                                 HSP_CD
	 , A.HST_SEQ                                                                                   HST_SEQ  --이력순번
	 , A.USE_YN                                                                                    USE_YN   --사용여부
     , A.LST_YN                                                                                    LST_YN   --최종여부
     , A.PACT_ID                                                                                   PACT_ID  --원무접수ID
	 , A.PACT_TP_CD                                                                                PACT_TP_CD --원무접수구분코드
	 , B.PT_NO                                                                                     PT_NO
	 , A.MED_DEPT_CD                                                                               MED_DEPT_CD
	 , C.DEPT_NM                                                                                   MED_DEPT_CD_NM --부서명
--	 , DECODE(C.UPR_DEPT_CD, 'PED', 'PED', C.MED_DEPT_CD)                                          RPRN_MED_DEPT_CD
--	 , (SELECT DEPT_NM FROM PDEDBMSM X WHERE X.DEPT_CD = DECODE(C.UPR_DEPT_CD, 'PED', 'PED', C.MED_DEPT_CD) AND X.HSP_TP_CD = C.HSP_TP_CD)  RPRN_MED_DEPT_CD_NM
	 , ETRM_DTM                                                     --입실일시
     , ETRM_WD_DEPT_CD                                              --입실병동부서코드
     , (SELECT DEPT_NM FROM PDEDBMSM X WHERE X.DEPT_CD = A.ETRM_WD_DEPT_CD AND X.HSP_TP_CD = A.HSP_TP_CD)  ETRM_WD_DEPT_CD_NM
     , A.ETRM_PRM_NO                                                                               ETRM_PRM_NO--입실병실번호
     , A.ETRM_BED_NO                                                                               ETRM_BED_NO--입실병상번호
     , ''                                                                                          EMRG_BED_YN
     , ''                                                                                          ISLT_BED_YN
     , ICU_ETRM_PATH_CLS_CD                                                                        ICU_ETRM_PATH_CLS_CD--중환자실입실경로유형코드
     , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'N0000061' AND COMN_CD = A.ICU_ETRM_PATH_CLS_CD)           ICU_ETRM_PATH_CLS_CD_NM  --중환자실 입실 경로 유형 코드 명
     , CHOT_DTM                                                                                    CHOT_DTM              --퇴실일시
     , ICU_CHOT_PLC_TP_CD                                                                          ICU_CHOT_PLC_TP_CD   --중환자실퇴실장소구분코드
     , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'N0000062' AND COMN_CD = A.ICU_CHOT_PLC_TP_CD)           ICU_CHOT_PLC_TP_CD_NM  --중환자실 입실 경로 유형 코드 명
     , ''                                                                                          CHOT_WD_MTD_CD         --퇴실 병동 진료과 코드
     , ''                                                                                          CHOT_WD_MTD_CD_NM      --퇴실 병동 진료과 코드 명
     , A.FSR_DTM                                                                                   FST_WRT_DTM
     , A.LSH_DTM                                                                                   LST_CHG_DTM
     , D.PT_NM                                                                                     PT_NM
     , B.ADS_DT                                                                                    ADS_DT
     , B.DS_EXPT_DT                                                                                DS_EXPT_DT
     , TRUNC(B.DS_DTM)                                                                             DS_DT
     , D.SEX_TP_CD                                                                                 SEX_TP_CD
     , XBIL.FT_PCT_AGE('AGE', SYSDATE, PT_BRDY_DT)                                                 AGE
     --, DECODE(XBIL.FT_PCT_AGE('AGE', SYSDATE, PT_BRDY_DT), '0', XBIL.FT_PCT_AGE('MONTH', SYSDATE, PT_BRDY_DT)) AGE_MRK_NM 
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT)                                                AGE_MRK_NM
     , B.ADS_PATH_TP_CD                                                                            ADS_PATH_CD
     ,(SELECT COMN_CD_NM
         FROM CCCCCSTE
        WHERE COMN_GRP_CD = '365'
          AND COMN_CD = B.ADS_PATH_TP_CD)                                                          ADS_PATH_CD_NM
--     , SYSDATE                                                                                     FST_LOD_DTM
--     , SYSDATE                                                                                     LST_LOD_DTM
     , B.FSR_DTM                                                                                   FST_ACP_DTM
     , B.LSH_DTM                                                                                   LST_ACP_DTM
     , B.APCN_YN                                                                                   APCN_YN
     , DECODE(C.HIRA_MTD_CD, '11', 'PED'
                                 , C.MED_DEPT_CD)                                                  RPRN_MED_DEPT_CD
     , F.DEPT_NM             		                                                               RPRN_MED_DEPT_CD_NM
  FROM MOMNMIOD A        --중환자실입실퇴실시간정보
     , ACPPRAAM B        --입원접수기본
     , PDEDBMSM C        --부서기본
     , PCTPCPAM_DAMO D
     , PDEDBMSM F
 WHERE A.PACT_ID         = B.PACT_ID               --원무접수ID
   AND A.HSP_TP_CD       = B.HSP_TP_CD
   AND A.HSP_TP_CD       = C.HSP_TP_CD
   AND B.PT_NO           = D.PT_NO
   AND A.ETRM_WD_DEPT_CD LIKE ('%CU%')--IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
--   AND A.USE_YN          = 'Y'                     --사용여부
--   AND A.LST_YN          = 'Y'                     --최종여부
   AND A.PACT_TP_CD      = 'I'                     --원무접수구분코드
--   AND B.APCN_YN         = 'N'                     --접수취소여부
   AND A.MED_DEPT_CD     = C.DEPT_CD
--   AND A.HSP_TP_CD       = :HIS_HSP_TP_CD          --병원구분코드
--   AND (A.ETRM_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--                       AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999                                               --조회기간 동안에 입실했거나
--	    OR A.CHOT_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--	                      AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999                                               --또는 조회기간 동안에 퇴실했거나
--	    OR (A.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND A.CHOT_DTM IS NULL)                                    --또는 입실시간이 조회기간의 시작시간보다 작고, 퇴실시간이 없는경우
--	    OR (A.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND A.CHOT_DTM > TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999) --또는 입실시간이 조회기간의 시작시간보다 작고, 퇴실시간이 조회기간의 종료시간보다 큰 경우
--     )
   AND F.DEPT_CD = DECODE(C.HIRA_MTD_CD, '11', 'PED', C.MED_DEPT_CD)
   AND F.USE_STOP_DT IS NULL;