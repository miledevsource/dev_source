
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI008V" ("PT_NO", "OP_EXPT_DT", "OP_EXPT_DT_SEQ", "AGPY_SEQ_CTG_CD", "AGPY_SEQ_CTG_CD_NM", "AOM_DTM", "PSD_YN", "ERAD_TP_CD", "FST_WRT_DTM", "LST_CHG_DTM", "AGDP_MRK_TP_CD") AS 
  SELECT A.PT_NO                                                     PT_NO
     , A.OP_EXPT_DT                                                OP_EXPT_DT
     , A.OP_EXPT_DT_SEQ                                            OP_EXPT_DT_SEQ
     , A.AGPY_SEQ_CTG_CD                                           AGPY_SEQ_CTG_CD
     , XCOM.FT_CCC_CODENAME(A.HSP_TP_CD, 'DR8', A.AGPY_SEQ_CTG_CD) AGPY_SEQ_CTG_CD_NM
     , A.AOM_DTM                                                   AOM_DTM
     , A.PSD_YN                                                    PSD_YN
     , A.ERAD_TP_CD                                                ERAD_TP_CD    /* H -> 심뇌혈관, B -> 혈관조영실 */
     , A.FSR_DTM                                                   FST_WRT_DTM
     , A.LSH_DTM                                                   LST_CHG_DTM 
     , A.AGDP_MRK_TP_CD                                            AGDP_MRK_TP_CD
 FROM MSERMROD A            --혈관조영시술일정정보;