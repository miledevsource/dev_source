
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMNI007V" ("HSP_CD", "WD_DEPT_CD", "PT_NO", "PT_NM", "PT_SEX", "PT_AGE", "PT_DEPT_CD", "PT_LOC", "PT_IO") AS 
  SELECT P1.HSP_TP_CD        HSP_CD
     , T1.WD_DEPT_CD       WD_DEPT_CD
     , P1.PT_NO            PT_NO
     , P2.PT_NM            PT_NM
     , P2.SEX_TP_CD        PT_SEX
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT) PT_AGE
     , P1.MED_DEPT_CD      PT_DEPT_CD
     , T1.FMR_WD_DEPT_CD   PT_LOC
     , 'I'                 PT_IO
  FROM ACPPETSH T1
     , ACPPRAAM P1
     , PCTPCPAM_DAMO P2
 WHERE T1.PT_NO          = P1.PT_NO
   AND T1.RPY_PACT_ID    = P1.PACT_ID
   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
   AND T1.PT_NO          = P2.PT_NO
   AND T1.WD_DEPT_CD     IN (SELECT COMN_CD
                               FROM CCCCCSTE
                               WHERE USE_YN = 'Y')
--                              WHERE COMN_GRP_CD = 'N0000540'        -- 20260408 주석 TEST YJR
--                                AND HSP_TP_CD   = P1.HSP_TP_CD      -- 20260408 주석 TEST YJR
--                                AND USE_YN      = 'Y')              -- 20260408 주석 TEST YJR
--   AND T1.WD_DEPT_CD     <> P1.CLCTN_WD_DEPT_CD                                 -- 20260408 주석 TEST YJR
--   AND T1.APY_STR_DT = TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD')    -- 20260408 주석 TEST YJR
--   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
--   AND NVL(PACT_YN, 'N') = 'N'
   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
     			                               FROM ACPPETSH T2
                                              WHERE T2.PT_NO             = T1.PT_NO
--                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD   /* 遺？?쒖“嫄?二쇱꽍泥섎━ */
                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
--                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
--                                                AND NVL(T2.PACT_YN, 'N') = 'N'
                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                                AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* ?댁쟾蹂묐룞怨??좎껌蹂묐룞???ㅻⅨ 寃쎌슦?먮쭔 議고쉶 */
                                              GROUP BY T2.RPY_PACT_ID
                                            )
   AND P1.SIHS_YN        = 'Y'
   AND P1.APCN_YN        = 'N'
   AND P1.APCN_DTM       IS NULL
   AND P1.TDS_DTM IS NULL   /* 媛？?댁썝?섏옄 ?쒖쇅 */
 UNION ALL
SELECT P1.HSP_TP_CD        HSP_CD
     , T1.FMR_WD_DEPT_CD   WD_DEPT_CD
     , P1.PT_NO            PT_NO
     , P2.PT_NM            PT_NM
     , P2.SEX_TP_CD        PT_SEX
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT) PT_AGE
     , P1.MED_DEPT_CD      PT_DEPT_CD
     , T1.WD_DEPT_CD       PT_LOC
     , 'O'                 PT_IO
  FROM ACPPETSH T1
     , ACPPRAAM P1
     , PCTPCPAM_DAMO P2
 WHERE T1.PT_NO          = P1.PT_NO
   AND T1.RPY_PACT_ID    = P1.PACT_ID
   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
   AND T1.PT_NO          = P2.PT_NO
   AND T1.FMR_WD_DEPT_CD IN (SELECT COMN_CD
                               FROM CCCCCSTE         
                               WHERE USE_YN = 'Y')
--                              WHERE COMN_GRP_CD = 'N0000540'             -- 20260408 주석 TEST YJR
--                                AND HSP_TP_CD   = P1.HSP_TP_CD           -- 20260408 주석 TEST YJR
--                                AND USE_YN      = 'Y')                   -- 20260408 주석 TEST YJR
--   AND T1.WD_DEPT_CD     <> P1.CLCTN_WD_DEPT_CD                                  -- 20260408 주석 TEST YJR
--   AND T1.APY_STR_DT = TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD')     -- 20260408 주석 TEST YJR
--   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
--   AND NVL(PACT_YN, 'N') = 'N'
   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
     			                               FROM ACPPETSH T2
                                              WHERE T2.PT_NO             = T1.PT_NO
--                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD   /* 遺？?쒖“嫄?二쇱꽍泥섎━ */
                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
--                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
--                                                AND NVL(T2.PACT_YN, 'N') = 'N'
                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                                AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* ?댁쟾蹂묐룞怨??좎껌蹂묐룞???ㅻⅨ 寃쎌슦?먮쭔 議고쉶 */
                                              GROUP BY T2.RPY_PACT_ID
                                            )
   AND P1.SIHS_YN        = 'Y'
   AND P1.APCN_YN        = 'N'
   AND P1.APCN_DTM       IS NULL
   AND P1.TDS_DTM        IS NULL   /* 媛？?댁썝?섏옄 ?쒖쇅 */;