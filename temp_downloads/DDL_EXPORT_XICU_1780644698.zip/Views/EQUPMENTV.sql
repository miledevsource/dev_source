
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EQUPMENTV" ("EQUP_NM", "EQUP_CNT", "EQUP_USE_CNT") AS 
  SELECT 'ECMO'                       AS EQUP_NM 
--     , MAX((SELECT TO_NUMBER(DTRL1_NM)           
     , MAX((SELECT COUNT(DTRL1_NM)  -- 본사 데이터는 COUNT로 해야 함
              FROM BCCCSCBE E
             WHERE E.CDSS_COMN_GRP_CD = 'DR000233'
               AND E.USE_YN = 'Y')) AS EQUP_CNT
     , COUNT (*)                    AS EQUP_USE_CNT
  FROM MRNNRVCD D            --환자별인터페이스장비사용정보
     , ACPPRAAM M
 WHERE D.PT_NO = M.PT_NO
   AND D.PACT_ID = M.PACT_ID
   AND M.SIHS_YN = 'Y'
   AND D.INTF_EQUP_TP_CD = '03'
   AND D.USE_YN = 'Y'
   AND D.LST_YN = 'Y'
   AND D.EQUP_USE_DTM IS NOT NULL
   AND D.EQUP_END_DTM IS NULL
UNION ALL
--SELECT 'CRRT'                  AS EQUP_NM
--     , COUNT(1)                AS EQUP_CNT
--  FROM CCCCCSTE
-- WHERE COMN_GRP_CD = 'DR00152'
--   AND USE_YN = 'Y'          
SELECT 'CRRT'                       AS EQUP_NM
     , MAX((SELECT COUNT(1)        
              FROM CCCCCSTE
             WHERE COMN_GRP_CD = 'DR00152'
               AND USE_YN = 'Y'))   AS EQUP_CNT 
     , COUNT(*)                     AS EQUP_USE_CNT 
  FROM ACPPRAAM I
     , MOOPTCRD R
 WHERE R.PT_NO = I.PT_NO
   AND R.PACT_ID = I.PACT_ID
   AND R.PACT_TP_CD = 'I'
   AND R.APY_CCLT_DTM IS NULL    --[적용해제일시]가 들어있는 컬럼은 종료된 데이터임
   AND R.APLC_CNCL_YN = 'N'      --[신청취소여부] N은 신청된 데이터를 삭제한것;