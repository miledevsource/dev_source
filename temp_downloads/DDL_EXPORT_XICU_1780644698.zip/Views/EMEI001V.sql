
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI001V" ("WD_DEPT_CD", "TOL_WD_CNT", "USE_WD_CNT", "EMPT_WD_CNT", "ISLT_TOL_WD_CNT", "ISLT_USE_WD_CNT", "ISLT_EMPT_WD_CNT", "IN_WD_CNT", "OUT_WD_CNT", "OP_CNT") AS 
  SELECT A.WD_DEPT_CD                                  WD_DEPT_CD       --01. 환자실병동부서코드'
     , SUM(A.TOL_WD_CNT)                             TOL_WD_CNT       --02. 각 중환자실 병상 수(전체)'
     , SUM(A.USE_WD_CNT)                             USE_WD_CNT       --03. 사용 병상 수
     , SUM(A.TOL_WD_CNT - A.USE_WD_CNT)              EMPT_WD_CNT      --04. 공 병상 수
     , SUM(A.ISLT_TOL_WD_CNT)                        ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)
     , SUM(A.ISLT_USE_WD_CNT)                        ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
     , SUM(A.ISLT_TOL_WD_CNT - A.ISLT_USE_WD_CNT)    ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
     , SUM(A.IN_WD_CNT)                              IN_WD_CNT        --08. 입실예정 환자 수
     , SUM(A.OUT_WD_CNT)                             OUT_WD_CNT       --09. 퇴실예정 환자 수
     , SUM(A.OP_CNT)                                 OP_CNT           --10. 수술 수
  FROM ( SELECT A.WD_DEPT_CD                         WD_DEPT_CD       --01. 환자실병동부서코드'
              , COUNT(A.WD_DEPT_CD)                  TOL_WD_CNT       --02. 각 중환자실 병상 수(전체)'
              , ( SELECT COUNT(*)
                    FROM ACPPRAAM
                   WHERE CLCTN_WD_DEPT_CD = A.WD_DEPT_CD
                     AND SIHS_YN = 'Y'
                     AND APCN_YN = 'N'
                     AND TDS_DTM IS NULL   /* 가퇴원환자 제외 */
                 )                                   USE_WD_CNT       --03. 사용 병상 수
              , 0                                    EMPT_WD_CNT      --04. 공 병상 수
              , ( SELECT COUNT(*)
                    FROM ACPPERMM B
                   WHERE B.WD_DEPT_CD = A.WD_DEPT_CD
                     AND B.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
--                     AND B.PRM_NO = '00'               

-- 2025-07-31 장인수 테스트를 위해 공통코드 조회 조건 주석처리 
--                     AND B.PRM_NO = (SELECT DECODE(DTRL1_NM, 'Y', '00', B.PRM_NO)
--                                       FROM CCCCCSTE
--                                      WHERE COMN_GRP_CD = 'N0000540'
--                                        AND COMN_CD = B.WD_DEPT_CD
--                                        AND USE_YN      = 'Y')
                     AND B.CIPT_ISLT_PSB_YN = 'Y'
                 )                                   ISLT_TOL_WD_CNT  --05. 중환자실 내 격리 병상 수(전체)'
              , 0                                    ISLT_USE_WD_CNT  --06. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    ISLT_EMPT_WD_CNT --07. 중환자실 내 격리 병상 중 공 병상 수
              , 0                                    IN_WD_CNT        --08. 입실예정 환자 수
              , 0                                    OUT_WD_CNT       --09. 퇴실예정 환자 수
              , 0                                    OP_CNT           --10. 수술 수
           FROM ACPPERMM A
--          WHERE A.WD_DEPT_CD IN ('SICU', 'MICU', 'CICU', 'NCU', 'NICU', 'NICU2', 'EICU', 'EICU2')
--            AND A.APY_END_DT = TO_DATE('99991231', 'YYYY-MM-DD')
          WHERE (A.WD_DEPT_CD, A.PRM_NO)
                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
                                   FROM CCCCCSTE
                                  WHERE COMN_GRP_CD = 'N0000540'
                                    AND HSP_TP_CD   = A.HSP_TP_CD
                                    AND USE_YN      = 'Y')
--            AND A.PRM_NO = '00'
            AND A.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
          GROUP BY A.WD_DEPT_CD

          UNION ALL

         SELECT A.CLCTN_WD_DEPT_CD                   WD_DEPT_CD       -- 01. 중환자실병동부서코드
              , 0                                    TOL_WD_CNT       -- 02. 각 중환자실 병상 수(전체)
              , 0                                    USE_WD_CNT       -- 03. 사용 병상 수
              , 0                                    EMPT_WD_CNT      -- 04. 공 병상 수
              , 0                                    ISLT_TOL_WD_CNT  -- 05. 중환자실 내 격리 병상 수(전체)
              , SUM(CASE WHEN B.CIPT_ISLT_PSB_YN = 'Y' THEN 1 ELSE 0 END) ISLT_USE_WD_CNT  -- 06. 중환자실 내 격리 병상 중 사용 병상 수
              , 0                                    ISLT_EMPT_WD_CNT -- 07. 중환자실 내 격리 병상 중 공 병상 수
              , (
                    SELECT NVL(SUM(CASE WHEN T1.WD_DEPT_CD <> P1.CLCTN_WD_DEPT_CD AND /* 전동일자 기준으로 당일로만 체크 */  T1.APY_STR_DT = TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD') THEN 1 ELSE 0 END), 0)  CNT
					  FROM ACPPETSH T1
					     , ACPPRAAM P1
					 WHERE T1.PT_NO          = P1.PT_NO
					   AND T1.RPY_PACT_ID    = P1.PACT_ID
					   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
					   AND T1.WD_DEPT_CD     = A.CLCTN_WD_DEPT_CD
--					   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
--					   AND NVL(PACT_YN, 'N') = 'N'
--					   AND T1.HSP_TP_CD      = A.HSP_TP_CD
					   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
					                                             SELECT /*+ INDEX(ACPPETSH T2_SI01) */
					                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
					     			                               FROM ACPPETSH T2
					                                              WHERE T2.PT_NO             = T1.PT_NO
--					                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD /* 부서조건 주석처리 */
					                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
--					                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
--					                                                AND NVL(T2.PACT_YN, 'N') = 'N'
					                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                                                    AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* 이전병동과 신청병동이 다른 경우에만 조회 */
					                                              GROUP BY T2.RPY_PACT_ID
					                                            )
					   AND P1.SIHS_YN    = 'Y'
					   AND P1.APCN_YN    = 'N'
					   AND P1.APCN_DTM   IS NULL
                )                                    IN_WD_CNT        --08. 입실예정 환자 수
              , (
                    SELECT NVL(SUM(CASE WHEN T1.WD_DEPT_CD <> P1.CLCTN_WD_DEPT_CD AND /* 전동일자 기준으로 당일로만 체크 */ T1.APY_STR_DT = TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD') THEN 1 ELSE 0 END), 0)  CNT
					  FROM ACPPETSH T1
					     , ACPPRAAM P1
					 WHERE T1.PT_NO          = P1.PT_NO
					   AND T1.RPY_PACT_ID    = P1.PACT_ID
					   AND T1.HSP_TP_CD      = P1.HSP_TP_CD
					   AND T1.FMR_WD_DEPT_CD = A.CLCTN_WD_DEPT_CD
--					   AND SYSDATE BETWEEN T1.APY_STR_DT AND T1.APY_END_DTM
--					   AND NVL(PACT_YN, 'N') = 'N'
--					   AND T1.HSP_TP_CD      = A.HSP_TP_CD
					   AND (T1.RPY_PACT_ID, T1.APY_END_DTM) IN (
					                                             SELECT /*+ INDEX(ACPPETSH ACPPETSH_SI01) */
					                                                    T2.RPY_PACT_ID, MAX(T2.APY_END_DTM)
					     			                               FROM ACPPETSH T2
					                                              WHERE T2.PT_NO             = T1.PT_NO
--					                                                AND T2.WD_DEPT_CD        = T1.WD_DEPT_CD /* 부서조건 주석처리 */
					                                                AND T2.RPY_PACT_ID       = T1.RPY_PACT_ID
--					                                                AND SYSDATE BETWEEN T2.APY_STR_DT AND T2.APY_END_DTM
--					                                                AND NVL(T2.PACT_YN, 'N') = 'N'
					                                                AND T2.HSP_TP_CD         = T1.HSP_TP_CD
                                                                    AND T2.FMR_WD_DEPT_CD   <> T2.WD_DEPT_CD /* 이전병동과 신청병동이 다른 경우에만 조회 */
					                                              GROUP BY T2.RPY_PACT_ID
					                                            )
					   AND P1.SIHS_YN     = 'Y'
					   AND P1.APCN_YN     = 'N'
					   AND P1.APCN_DTM    IS NULL
					   AND P1.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
                )                                    OUT_WD_CNT       --09. 퇴실예정 환자 수
              , (
                    SELECT COUNT(T1.PT_NO)
                      FROM ACPPRAAM P1
                         , MOOOPPAM T1
                     WHERE 1=1
                       AND P1.PT_NO                   = T1.PT_NO
					   AND P1.PACT_ID                 = T1.PACT_ID
					   AND P1.HSP_TP_CD               = T1.HSP_TP_CD
					   AND P1.CLCTN_WD_DEPT_CD        = A.CLCTN_WD_DEPT_CD
					   AND P1.SIHS_YN                 = 'Y'
					   AND P1.APCN_YN                 = 'N'
					   AND P1.APCN_DTM                IS NULL
                       AND NVL(T1.OP_DEL_YN, 'N')     = 'N'
                       AND T1.OP_DTMN_YN              = 'Y'--수술확정여부
                       AND T1.OP_CNCL_DTMN_YN         = 'N'
                       AND EXISTS (SELECT 'Y'
                                     FROM MOOOPPAM T2
                                        , MRNNROAD P2
                                    WHERE T2.OP_EXPT_REG_ID = T1.OP_EXPT_REG_ID
                                      AND T2.OP_EXPT_REG_ID = P2.OP_EXPT_REG_ID
                                      AND P2.USE_YN = 'Y'
                                      AND P2.LST_YN = 'Y'
                                      AND EXISTS(SELECT '1'
                                                   FROM MRNNROTE T3
                                                  WHERE T3.OP_EXPT_REG_ID = T2.OP_EXPT_REG_ID
                                                    AND TO_DATE(TO_CHAR(T3.ITEM_CB_OP_DTM, 'YYYY-MM-DD'), 'YYYY-MM-DD') = TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD')  -- 입실일자 기준으로 당일로만 체크
                                                    AND T3.OP_NREC_TM_TP_CD = '01'
                                                    AND T3.WRT_SEQ = P2.WRT_SEQ) --입실시간이 있는 환자
                                     AND NOT EXISTS(SELECT '1'
                                                      FROM MRNNROTE T3
                                                     WHERE T3.OP_EXPT_REG_ID = T2.OP_EXPT_REG_ID
                                                       AND T3.OP_NREC_TM_TP_CD = '08'
                                                       AND T3.WRT_SEQ = P2.WRT_SEQ) --퇴실시간 없는 환자
                                    )
                )                                    OP_CNT           --10. 수술 수
           FROM ACPPRAAM A
              , ACPPERMM B
--          WHERE B.WD_DEPT_CD IN (SELECT COMN_CD
--                                   FROM CCCCCSTE
--                                  WHERE COMN_GRP_CD = 'N0000540'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD
--                                    AND USE_YN      = 'Y')
--            AND B.PRM_NO = '00'
--          WHERE (B.WD_DEPT_CD, B.PRM_NO)    -- 2025-07-31 장인수 테스트를 위해 공통코드 조회 조건 주석처리   
--                             IN (SELECT COMN_CD, DECODE(DTRL1_NM, 'Y', '00', A.PRM_NO)
--                                   FROM CCCCCSTE
--                                  WHERE COMN_GRP_CD = 'N0000540'
--                                    AND HSP_TP_CD   = A.HSP_TP_CD
--                                    AND USE_YN      = 'Y')   
           WHERE 1=1 
            AND B.APY_END_DT = TO_DATE('9999-12-31', 'YYYY-MM-DD')
            AND A.SIHS_YN = 'Y'
            AND A.APCN_YN = 'N'
            AND A.TDS_DTM IS NULL   /* 가퇴원환자 제외 */
            AND A.CLCTN_WD_DEPT_CD = B.WD_DEPT_CD
            AND A.CLCTN_PRM_NO = B.PRM_NO
            AND A.CLCTN_BED_NO = B.BED_NO

          GROUP BY A.CLCTN_WD_DEPT_CD
        ) A
 GROUP BY
       A.WD_DEPT_CD
 ORDER BY
       A.WD_DEPT_CD;