
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."VW_ICU_BED_OCCUPANCY_RATE_DAILY" ("기준일", "총병상", "재원환자", "점유율_퍼센트") AS 
  WITH
-- ICU 병동 목록
icu_dept AS (
    SELECT COMN_CD AS WD_DEPT_CD
      FROM CCCCCSTE
     WHERE COMN_GRP_CD = 'N0000540'
       AND USE_YN = 'Y'
),
-- 병상 데이터가 존재(유효)하기 시작한 최소 날짜: ICU 병상 중 가장 이른 적용시작일
min_day AS (
    SELECT TRUNC(MIN(b.apy_str_dt)) AS d
      FROM ACPPERMM b
      JOIN icu_dept i
        ON i.WD_DEPT_CD = b.WD_DEPT_CD
     WHERE b.bed_no IS NOT NULL
),
-- 날짜 생성: min_day ~ 오늘
days AS (
    SELECT (SELECT d FROM min_day) + LEVEL - 1 AS d
      FROM dual
   CONNECT BY (SELECT d FROM min_day) + LEVEL - 1 <= TRUNC(SYSDATE)
)
SELECT
    d.d AS 기준일,

    -- 기준일에 유효한 총병상(이력/중복 대비 DISTINCT)
    ( SELECT COUNT(DISTINCT b.wd_dept_cd || '|' || b.prm_no || '|' || b.bed_no)
        FROM ACPPERMM b
        JOIN icu_dept i
          ON i.WD_DEPT_CD = b.WD_DEPT_CD
       WHERE b.apy_str_dt < d.d + 1
         AND NVL(b.apy_end_dt, DATE '9999-12-31') >= d.d
         AND b.bed_no IS NOT NULL
    ) AS 총병상,

    -- 기준일 재원환자(병동 도착~퇴실 기준)
    ( SELECT COUNT(*)
        FROM ACPPRAAM a
       WHERE a.sihs_yn = 'Y'
         AND a.apcn_yn = 'N'
         AND a.tds_dtm IS NULL
         AND a.wd_arvl_dtm < d.d + 1
         AND (a.ds_dtm IS NULL OR a.ds_dtm >= d.d)
         AND a.clctn_wd_dept_cd IN (SELECT wd_dept_cd FROM icu_dept)
    ) AS 재원환자,

    -- 점유율(%)
    ROUND(
      ( SELECT COUNT(*)
          FROM ACPPRAAM a
         WHERE a.sihs_yn = 'Y'
           AND a.apcn_yn = 'N'
           AND a.tds_dtm IS NULL
           AND a.wd_arvl_dtm < d.d + 1
           AND (a.ds_dtm IS NULL OR a.ds_dtm >= d.d)
           AND a.clctn_wd_dept_cd IN (SELECT wd_dept_cd FROM icu_dept)
      )
      /
      NULLIF(
        ( SELECT COUNT(DISTINCT b.wd_dept_cd || '|' || b.prm_no || '|' || b.bed_no)
            FROM ACPPERMM b
            JOIN icu_dept i
              ON i.WD_DEPT_CD = b.WD_DEPT_CD
           WHERE b.apy_str_dt < d.d + 1
             AND NVL(b.apy_end_dt, DATE '9999-12-31') >= d.d
             AND b.bed_no IS NOT NULL
        ),
      0) * 100
    , 1) AS 점유율_퍼센트

FROM days d
-- 총병상이 0인 날은 제외 (원하신 “총병상 0 아닌 날부터”)
WHERE
  ( SELECT COUNT(*)
      FROM ACPPERMM b
      JOIN icu_dept i
        ON i.WD_DEPT_CD = b.WD_DEPT_CD
     WHERE b.apy_str_dt < d.d + 1
       AND NVL(b.apy_end_dt, DATE '9999-12-31') >= d.d
       AND b.bed_no IS NOT NULL
  ) > 0
ORDER BY d.d;