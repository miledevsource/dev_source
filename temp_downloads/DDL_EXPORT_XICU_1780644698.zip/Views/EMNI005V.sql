
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMNI005V" ("MDRC_ID", "MDRC_FOM_SEQ", "HSP_CD", "PT_NO", "LST_YN", "REC_DTM", "MDF_REC_DTM", "WRT_STF_NO", "MDFM_CLS_DTL_CD", "MDFM_CLS_DTL_CD_NM", "MDRC_WRT_STS_CD", "MDRC_WRT_STS_CD_NM", "MDRC_DC_TP_CD", "MDRC_DC_TP_CD_NM", "FST_WRT_DTM", "LST_CHG_DTM", "FST_LOD_DTM", "LST_LOD_DTM") AS 
  WITH SDATA AS (
                SELECT DISTINCT
                       B.PACT_ID                                                                                   PACT_ID
                     , B.HSP_TP_CD                                                                                 HSP_CD
                     , B.PT_NO                                                                                     PT_NO
                     , C.PT_NM                                                                                     PT_NM
                     , B.ADS_DT                                                                                    ADS_DT
                     , TRUNC(DS_DTM)                                                                               DT_EXPT_DT
                     , C.SEX_TP_CD                                                                                 SEX_TP_CD
                     , TRUNC(TRUNC(MONTHS_BETWEEN(B.ADS_DT,C.PT_BRDY_DT))/ 12,0)                                   AGE
                     , B.ADS_PATH_TP_CD                                                                            ADS_PATH_CD
                     ,(SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = '365' AND COMN_CD = B.ADS_PATH_TP_CD)  ADS_PATH_CD_NM
                     , B.FSR_DTM                                                                                   FST_WRT_DTM
                     , B.LSH_DTM                                                                                   LST_CHG_DTM
                     , SYSDATE                                                                                     FST_LOD_DTM
                     , SYSDATE                                                                                     LST_LOD_DTM
                  FROM MOMNMIOD A        --중환자실입실퇴실시간정보
                     , ACPPRAAM B        --입원접수기본
                     , PCTPCPAM_DAMO C
                 WHERE A.PACT_ID         = B.PACT_ID               --원무접수ID
                   AND A.HSP_TP_CD       = B.HSP_TP_CD
                   AND B.PT_NO           = C.PT_NO
                   AND A.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
                   AND A.USE_YN          = 'Y'                     --사용여부
                   AND A.LST_YN          = 'Y'                     --최종여부
                   AND A.PACT_TP_CD      = 'I'                     --원무접수구분코드
                   AND B.APCN_YN         = 'N'                     --접수취소여부
--                   AND A.HSP_TP_CD       = :HIS_HSP_TP_CD          --병원구분코드
--                   AND (A.ETRM_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--                                       AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999                                                  --조회기간 동안에 입실했거나
--                	    OR A.CHOT_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--                	                      AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999                                               --또는 조회기간 동안에 퇴실했거나
--                	    OR (A.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND A.CHOT_DTM IS NULL)                                    --또는 입실시간이 조회기간의 시작시간보다 작고, 퇴실시간이 없는경우
--                	    OR (A.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND A.CHOT_DTM > TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999) --또는 입실시간이 조회기간의 시작시간보다 작고, 퇴실시간이 조회기간의 종료시간보다 큰 경우
--                     )
               )
 SELECT DISTINCT
        RECM.MDRC_ID                                                     MDRC_ID
      , RECM.MDRC_FOM_SEQ                                                MDRC_FOM_SEQ
      , RECM.HSP_TP_CD                                                   HSP_CD
      , RECM.PT_NO                                                       PT_NO
      , RECM.LST_YN                                                      LST_YN
      , RECM.REC_DTM                                                     REC_DTM
      , RECM.MDF_REC_DTM                                                 MDF_REC_DTM --수정기록일시
      , RECM.WRT_STF_NO                                                  WRT_STF_NO
      , RECM.MDFM_CLS_DTL_CD                                             MDFM_CLS_DTL_CD   --진료서식유형상세코드
      , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOZ' AND COMN_CD = RECM.MDFM_CLS_DTL_CD)           MDFM_CLS_DTL_CD_NM
      , RECM.MDRC_WRT_STS_CD                                             MDRC_WRT_STS_CD--진료기록작성상태코드
      , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOL' AND COMN_CD = RECM.MDRC_WRT_STS_CD)           MDRC_WRT_STS_CD_NM
      , RECM.MDRC_DC_TP_CD                                               MDRC_DC_TP_CD--진료기록중단구분코드
      , (SELECT COMN_CD_NM FROM CCCCCSTE  WHERE COMN_GRP_CD = 'RDOM' AND COMN_CD = RECM.MDRC_DC_TP_CD)             MDRC_DC_TP_CD_NM  --중환자실 입실 경로 유형 코드 명
      , RECM.FSR_DTM                                                     FST_WRT_DTM
      , RECM.LSH_DTM                                                     LST_CHG_DTM
      , SYSDATE                                                          FST_LOD_DTM
      , SYSDATE                                                          LST_LOD_DTM
   FROM SDATA Z9
      , MRDDRECM RECM                                                    -- 진료기록기본
 WHERE RECM.PT_NO = Z9.PT_NO
   AND RECM.MDFM_CLS_CD ='D032'
   AND RECM.MDFM_CLS_DTL_CD IN ('00105', '00132')                        -- DOCTORNOTE_TYPE_ID 진료서식유형코드
   AND NVL(RECM.MDRC_DC_TP_CD, 'C') = 'C'                                -- DC_YN 진료기록중단구분코드
   AND TO_NUMBER(RECM.MDRC_WRT_STS_CD) > 10                              -- STATUS 진료기록작성상태코드
   AND RECM.LST_YN = 'Y';