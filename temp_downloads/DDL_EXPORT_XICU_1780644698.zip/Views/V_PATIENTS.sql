
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."V_PATIENTS" ("HADM_ID", "SUBJECT_ID", "SUBJECT_NM", "SEX", "PT_BRDY_DT", "BIRTH_DATETIME", "DOD", "COUNTRY", "RACE", "STAY_STATUS", "DISCHTIME") AS 
  WITH PT_LIST AS (
    SELECT B.PACT_ID
         , MIN(B.PT_NO)                   AS PT_NO
         , MIN(B.SIHS_YN)                 AS SIHS_YN
         , MIN(B.DS_DTM)                  AS DS_DTM
      FROM MOMNMIOD A        --중환자실입실퇴실시간정보
         , ACPPRAAM B        --입원접수기본
     WHERE A.PACT_ID         = B.PACT_ID
       AND A.HSP_TP_CD       = B.HSP_TP_CD
       --AND A.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
       AND A.USE_YN          = 'Y'                     --사용여부
       AND A.LST_YN          = 'Y'                     --최종여부
       AND A.PACT_TP_CD      = 'I'                     --원무접수구분코드
       AND B.APCN_YN         = 'N'                     --접수취소여부
     GROUP BY B.PACT_ID
)
SELECT A.PACT_ID                          AS HADM_ID             --수진ID
     , B.PT_NO                            AS SUBJECT_ID          --환자번호
     , B.PT_NM                            AS SUBJECT_NM          --환자명
     , B.SEX_TP_CD                        AS SEX                 --성별
     , B.PT_BRDY_DT                       AS PT_BRDY_DT          --환자생일
     , NULL                               AS BIRTH_DATETIME      --환자출생일시
     , B.DTH_DTM                          AS DOD                 --사망일시
     , ( SELECT X.COMN_CD_EXPL
           FROM CCCCCSTE X
          WHERE X.COMN_GRP_CD ='347'
            AND X.COMN_CD = B.OOC_NTN_CD
       )                                  AS COUNTRY             --국가
     , NULL                               AS RACE                --인종
     , SIHS_YN                            AS STAY_STATUS         --재원상태
     , DS_DTM                             AS DISCHTIME           --퇴원일시
  FROM PT_LIST A
     , PCTPCPAM_DAMO B
 WHERE A.PT_NO = B.PT_NO;