
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMNI004V" ("HSP_CD", "PACT_ID", "PT_NO", "PT_NM", "SEX_TP_CD", "PT_AGE", "ENT_DUR_DT_CNT", "OP_DUR_DT_CNT", "WD_DEPT_CD", "BED_NO", "MED_DEPT_CD", "MED_DEPT_NM", "ANDR_STF_NO", "ANDR_KOR_NM", "DIAG_NM", "DIAG_CD", "EQIP_KIND_CD", "SVRT_SCR_NO") AS 
  SELECT P1.HSP_TP_CD        HSP_CD
     , P1.PACT_ID          PACT_ID
     , P1.PT_NO            PT_NO
     , P2.PT_NM            PT_NM
     , P2.SEX_TP_CD        SEX_TP_CD
     , XBIL.FT_PCT_AGE('AUTO', SYSDATE, PT_BRDY_DT) PT_AGE
     ,(NVL(TRUNC(P1.DS_DTM), TRUNC(SYSDATE)) - P1.ADS_DT + 1)  ENT_DUR_DT_CNT
     , XMED.FT_MOO_GET_POD(P1.PT_NO , P1.HSP_TP_CD , '1', P1.MED_DEPT_CD) OP_DUR_DT_CNT
     , P1.CLCTN_WD_DEPT_CD WD_DEPT_CD
     , P1.CLCTN_BED_NO     BED_NO
     , P1.MED_DEPT_CD      MED_DEPT_CD
     , P3.DEPT_NM          MED_DEPT_NM
     , NVL(P1.CHDR_STF_NO, P1.NCDR_STF_NO) ANDR_STF_NO
     , P4.KOR_SRNM_NM      ANDR_KOR_NM
     , P7.CLDG_NM          DIAG_NM
     , P7.ICD10_CD         DIAG_CD
     , (
           SELECT  /*+ INDEX(B MRNNRVCD_SI01) */
                  LISTAGG(
                  CASE WHEN B.INTF_EQUP_TP_CD = '01' THEN 'V'   /*Ventilator*/
                       WHEN B.INTF_EQUP_TP_CD = '02' THEN 'C'   /*CRRT*/
                       WHEN B.INTF_EQUP_TP_CD = '03' THEN 'E'   /*ECMO*/
                       WHEN B.INTF_EQUP_TP_CD = '04' THEN 'I'   /*IABP*/
                  END,'/') WITHIN GROUP(ORDER BY B.PT_NO ASC, B.INTF_EQUP_TP_CD)
             FROM MRNNRVCD B
            WHERE B.PACT_ID         = P1.PACT_ID
              AND B.PT_NO           = P1.PT_NO
              AND B.LST_YN          = 'Y'
              AND B.USE_YN          = 'Y'
              AND B.HSP_TP_CD       = P1.HSP_TP_CD
              AND B.INTF_EQUP_TP_CD IN ('01','02','03','04')
              AND B.EQUP_USE_DTM    IS NOT NULL
              AND B.EQUP_END_DTM    IS NULL
         )                 EQIP_KIND_CD
     , (
          SELECT MAX(PT_SILLM_CTG_GRP_CD)  -- 위험군으로 표출하고자 하는 경우 PT_SILLM_CTG_GRP_CD
            FROM MOPPCCFD A
           WHERE A.PT_NO                = P1.PT_NO
             AND A.PACT_ID              = P1.PACT_ID
             AND A.HSP_TP_CD            = P1.HSP_TP_CD
             AND (A.PT_SILLM_CTG_REC_ID, A.WRT_SEQ) = (
			                                             SELECT MAX(A1.PT_SILLM_CTG_REC_ID), MAX(WRT_SEQ)
			                                               FROM MOPPCCFD A1
			                                              WHERE A1.PT_NO     = P1.PT_NO
			                                                AND A1.PACT_ID   = P1.PACT_ID
			                                                AND A1.HSP_TP_CD = P1.HSP_TP_CD
			                                                AND A1.USE_YN    = 'Y'
			                                                AND A1.LST_YN    = 'Y'
			                                                AND A1.CTG_DTM   = (
			                                                                     SELECT MAX(CTG_DTM)
			                                                                       FROM MOPPCCFD
			                                                                      WHERE PT_NO     = A1.PT_NO
			                                                                        AND PACT_ID   = A1.PACT_ID
			                                                                        AND HSP_TP_CD = A1.HSP_TP_CD
			                                                                        AND USE_YN    = 'Y'
			                                                                        AND LST_YN    = 'Y'
			                                                                  )
                                          			 )
             AND A.USE_YN               = 'Y'
             AND A.LST_YN               = 'Y'
        )                  SVRT_SCR_NO
  FROM ACPPRAAM P1
     , PCTPCPAM_DAMO P2
     , PDEDBMSM P3
     , CNLRRUSD P4
     ,(SELECT P5.PT_NO
            , P5.MED_PACT_ID
            , P6.CLDG_NM
            , P6.ICD10_CD
         FROM MOODIPCD P5
            , MOODIPAM P6
        WHERE 1=1
          AND P5.DGNS_ID = P6.DGNS_ID
          AND P5.MAIN_SKNS_YN = 'Y'
          AND NVL(P5.DTMN_SKNS_YN, 'N') = 'Y'
          AND NVL(P5.TDY_DGNS_DEL_YN, 'N') = 'N'
          AND NVL(P5.DGNS_PSD_YN, 'N') = 'N'
       )        P7
 WHERE 1=1
   AND P1.SIHS_YN = 'Y'
   AND P1.CLCTN_WD_DEPT_CD IN ('SICU', 'MICU', 'CICU', 'NCU', 'NICU', 'NICU2', 'EICU', 'EICU2')
   AND P1.PT_NO = P2.PT_NO
   AND P1.MED_DEPT_CD = P3.DEPT_CD
   AND NVL(P1.CHDR_STF_NO, P1.NCDR_STF_NO) = P4.STF_NO
   AND P1.PT_NO = P7.PT_NO(+)
   AND P1.PACT_ID = P7.MED_PACT_ID(+);