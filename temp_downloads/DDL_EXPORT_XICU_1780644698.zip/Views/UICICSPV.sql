
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."UICICSPV" ("CIPT_ETRM_CHOT_ID", "HSP_TP_CD", "PACT_ID", "SEX_TP_CD", "AGE", "RPRN_MED_DEPT_CD", "RPRN_MED_DEPT_CD_NM", "ETRM_DTM", "ETRM_DT", "ETRM_WD_DEPT_CD", "ETRM_WD_DEPT_CD_NM", "CHOT_DTM", "CHOT_DT", "APCS_SUM_SCR", "AGPY_AOM_CNT", "AGPY_AOM_EMRG_CNT") AS 
  SELECT A.CIPT_ETRM_CHOT_ID                 AS CIPT_ETRM_CHOT_ID                  --중환자입실퇴실ID
        , A.HSP_TP_CD                         AS HSP_TP_CD                          --병원구분코드
        , A.PACT_ID                           AS PACT_ID                            --원무접수ID
        , A.SEX_TP_CD                         AS SEX_TP_CD                          --성별구분코드
        , A.AGE                               AS AGE                                --연령
        , A.RPRN_MED_DEPT_CD                  AS RPRN_MED_DEPT_CD                   --대표진료부서코드
        , A.RPRN_MED_DEPT_CD_NM               AS RPRN_MED_DEPT_CD_NM                --대표진료부서코드명
        , A.ETRM_DTM                          AS ETRM_DTM                           --입실일시
        , TRUNC(A.ETRM_DTM)                   AS ETRM_DT
        , A.ETRM_WD_DEPT_CD                   AS ETRM_WD_DEPT_CD                    --입실병동부서코드
        , A.ETRM_WD_DEPT_CD_NM                AS ETRM_WD_DEPT_CD_NM                 --입실병동부터코드명
        , A.CHOT_DTM                          AS CHOT_DTM                           --퇴실일시
        , TRUNC(A.CHOT_DTM)                   AS CHOT_DT
        , A.APCS_SUM_SCR                      AS APCS_SUM_SCR                       --아파치 점수 
        , A.AGPY_AOM_CNT                      AS AGPY_AOM_CNT                       --혈관조영시술수
        , A.AGPY_AOM_EMRG_CNT                 AS AGPY_AOM_EMRG_CNT                  --혈관조영시술응급수

     FROM HICU.UICICSPM A --중환자실환자지표기본;