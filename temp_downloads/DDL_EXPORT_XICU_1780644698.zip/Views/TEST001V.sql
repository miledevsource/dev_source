
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."TEST001V" ("HSP_CD", "ICU_CNT", "TOT_WD_CNT", "IN_CNT", "EMPT_WD_DNT", "ISLT_EMPT_WD_CNT", "NGPSSR_EMPT_WD_CNT", "WORKING_PER", "ISLT_PT_CNT", "TOT_VENT_PT_CNT") AS 
  SELECT '1' AS HSP_CD     
			     , 1 AS ICU_CNT            
			     , 10 AS TOT_WD_CNT      
			     , 2  AS IN_CNT         
			     , 6 AS EMPT_WD_DNT      
			     , 3 AS ISLT_EMPT_WD_CNT    
			     , 0 AS NGPSSR_EMPT_WD_CNT  
			     , ROUND( ((2 / 10 ) * 100), 2)as  WORKING_PER  
			     , 33 as ISLT_PT_CNT
			     , 55 as TOT_VENT_PT_CNT
			     FROM DUAL;