
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI014V" ("DT_CD", "DT_NM", "YMD_CD", "YY_CD", "YY_NM", "HTERM_CD", "HTERM_NM", "QUT_CD", "QUT_NM", "YYMM_CD", "YYMM_NM", "YMW_CD", "YMW_NM", "DOW_NM", "DAY_CD", "DAY_NM", "HLDY_YN", "FSR_DTM", "LSH_DTM") AS 
  SELECT WK_DT                                                                            DT_CD
     , TO_CHAR(WK_DT,'YYYY')||'년 '||TO_CHAR(WK_DT,'MM')||'월 '||TO_CHAR(WK_DT,'DD')||'일' DT_NM
     , TO_CHAR(WK_DT,'YYYY')||'-'||TO_CHAR(WK_DT,'MM')||'-'||TO_CHAR(WK_DT,'DD')        YMD_CD
     , TO_CHAR(WK_DT,'YYYY')                                                            YY_CD
     , TO_CHAR(WK_DT,'YYYY')||'년'                                                       YY_NM
     , CASE WHEN TO_CHAR(WK_DT,'MM') < 7 THEN TO_CHAR(WK_DT,'YYYY') || '-1'
            WHEN TO_CHAR(WK_DT,'MM') >= 7 THEN TO_CHAR(WK_DT,'YYYY') || '-2'
       END                                                                              HTERM_CD
     , TO_CHAR(WK_DT,'YYYY')||'년'||
       (CASE WHEN TO_CHAR(WK_DT,'Q') IN ('1','2') THEN ' 상'
             WHEN TO_CHAR(WK_DT,'Q') IN ('3','4') THEN ' 하'
        END)||'반기'                                                                      HTERM_NM
     , SUBSTR(TO_CHAR(WK_DT,'YYYYQ'),1,4)||'-'||SUBSTR(TO_CHAR(WK_DT,'YYYYQ'),5,1)      QUT_CD
     , TO_CHAR(WK_DT,'YYYY')||'년 '||TO_CHAR(WK_DT,'Q')||'분기'                            QUT_NM
     , TO_CHAR(WK_DT,'YYYY')||'-'||TO_CHAR(WK_DT,'MM')                                  YYMM_CD
     , TO_CHAR(WK_DT,'YYYY')||'년 '||TO_CHAR(WK_DT,'MM')||'월'                            YYMM_NM
     , TO_CHAR(WK_DT,'YYYY')||'-'||TO_CHAR(WK_DT,'MM')||'-'|| ((TRUNC (WK_DT, 'D') - TRUNC (TRUNC (WK_DT, 'MM'), 'D')) / 7 + 1)     
                                                                                        YMW_CD
     , TO_CHAR(WK_DT,'YYYY') ||'년 ' || TO_CHAR(WK_DT,'MM') ||'월 ' || ((TRUNC (WK_DT, 'D') - TRUNC (TRUNC (WK_DT, 'MM'), 'D')) / 7 + 1) || '주' 
                                                                                        YMW_NM
     , TO_CHAR(WK_DT, 'DY', 'NLS_DATE_LANGUAGE=KOREAN')                                 DOW_NM
     , TO_CHAR(WK_DT,'DD')                                                              DAY_CD
     , TO_CHAR(WK_DT,'DD') || '일'                                                       DAY_NM
     , (SELECT DECODE(COUNT(Z.HDY_DT),0,NULL,'Y')
          FROM CCCCCHOD  Z
         WHERE Z.HDY_DT = D.WK_DT)                                                     HLDY_YN
     , NVL((SELECT FSR_DTM
          FROM CCCCCHOD  Z
         WHERE Z.HDY_DT = D.WK_DT),  D.FSR_DTM )                                                     FSR_DTM   -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경 - 20210408 임정립 팀장 요청으로 공휴일 정보로 변경
     , NVL((SELECT LSH_DTM
          FROM CCCCCHOD  Z
         WHERE Z.HDY_DT = D.WK_DT),  D.LSH_DTM )                                                     LSH_DTM   -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경 - 20210408 임정립 팀장 요청으로 공휴일 정보로 변경
--     , D.FSR_DTM                                                                       FSR_DTM -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경
--     , D.LSH_DTM                                                                       LSH_DTM -- 20210321 임정립 팀장 요청으로 공휴일 정보로 변경
  FROM ACPPRWDD  D;