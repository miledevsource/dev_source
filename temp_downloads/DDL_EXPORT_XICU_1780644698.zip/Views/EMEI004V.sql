
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI004V" ("PT_NO", "PACT_ID", "HSP_CD", "PACT_TP_CD", "INPT_DTM", "WD_DEPT_CD", "WD_DEPT_CD_NM", "WRT_SEQ", "USE_YN", "LST_YN", "ICU_ETRM_DTM", "APCS_PT_STS_CD", "APCS_PT_STS_CD_NM", "SUM_SCR", "FST_WRT_DTM", "LST_CHG_DTM", "FST_LOD_DTM", "LST_LOD_DTM") AS 
  WITH APACHE_SDATA AS (
SELECT ABD.*
  FROM
--      MOMNMIOD M  --중환자실입실퇴실시간정보
--    , ACPPRAAM B  --입원접수기본
      MOPPCABD ABD  --아파치스코어기록정보
 WHERE 1=1
--   AND M.PACT_ID         = B.PACT_ID
--   AND M.HSP_TP_CD       = B.HSP_TP_CD
--   AND M.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
----   AND M.USE_YN          = 'Y'
----   AND M.LST_YN          = 'Y'
--   AND M.PACT_TP_CD      = 'I'
----   AND B.APCN_YN         = 'N'
--   AND M.PACT_ID         = ABD.PACT_ID
--   AND M.ETRM_WD_DEPT_CD = ABD.WD_DEPT_CD
--   AND ABD.WD_DEPT_CD LIKE ('%CU%') --IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')   --제외한 이유는 apache score는 중환자실만 작성한다고 해서 제외하자는 의견에 따름
--   AND ABD.INPT_DTM BETWEEN TRUNC(M.ETRM_DTM) AND TRUNC(NVL(M.CHOT_DTM, SYSDATE))
--   AND ABD.USE_YN        = 'Y'
--   AND ABD.LST_YN        = 'Y'
--   AND M.HSP_TP_CD       = :HIS_HSP_TP_CD
--   AND (M.ETRM_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--                       AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999              --중환자실 입실시간
--     OR M.CHOT_DTM BETWEEN TO_DATE(:FROM_DTM, 'YYYY-MM-DD')
--			           AND TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999           --중환자실 퇴실시간
--     OR (M.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND M.CHOT_DTM IS NULL)  --입실시간이 < FROMDATE, 퇴실시간이 NULL일 경우
--     OR (M.ETRM_DTM < TO_DATE(:FROM_DTM, 'YYYY-MM-DD') AND M.CHOT_DTM > TO_DATE(:TO_DTM, 'YYYY-MM-DD') + 0.99999 )  --입실시간이 < FROMDATE, 퇴실시간이 > TODATE
--        )
-- ORDER BY M.PACT_ID, M.ETRM_DTM, M.CHOT_DTM, ABD.INPT_DTM
 ORDER BY ABD.INPT_DTM
			                         )


SELECT DISTINCT X.PT_NO
     , X.PACT_ID
     , X.HSP_TP_CD                                             HSP_CD
     , X.PACT_TP_CD
     , X.INPT_DTM
     , X.WD_DEPT_CD
     , NVL((SELECT DEPT_NM
		      FROM PDEDBMSM
		     WHERE DEPT_CD = X.WD_DEPT_CD
		       AND USE_YN  = 'Y'), NULL)                       WD_DEPT_CD_NM
     , X.WRT_SEQ
     , X.USE_YN
     , X.LST_YN
     , X.ICU_ETRM_DTM
     , X.APCS_PT_STS_CD
     , NVL((SELECT COMN_CD_NM
		      FROM CCCCCSTE
		     WHERE COMN_GRP_CD = 'N0000106'
		       AND COMN_CD     = X.APCS_PT_STS_CD) , NULL)     APCS_PT_STS_CD_NM
     , X.SUM_SCR
     , X.FSR_DTM              FST_WRT_DTM
     , X.LSH_DTM              LST_CHG_DTM
     , SYSDATE                FST_LOD_DTM
     , SYSDATE                LST_LOD_DTM
  FROM APACHE_SDATA X
 ORDER BY X.PACT_ID, X.ICU_ETRM_DTM, X.INPT_DTM, X.WRT_SEQ;