
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."EMEI006V" ("PT_SILLM_CTG_REC_ID", "PT_SILLM_CTG_REC_WRT_SEQ", "PT_NO", "PT_SILLM_CTG_DTM", "PT_SILLM_CTG_TL_ID", "PT_SILLM_CTG_TL_NM", "PACT_ID", "PACT_TP_CD", "WD_DEPT_CD", "WD_DEPT_CD_NM", "PT_SILLM_CTG_TP_CD", "PT_SILLM_CTG_TP_CD_NM", "PT_SILLM_CTG_GRP_CD", "PT_SILLM_CTG_GRP_CD_NM", "PT_SILLM_CTG_SCR_SUM", "USE_YN", "LST_YN", "FST_LOD_DTM", "LST_LOD_DTM") AS 
  SELECT A1.PT_SILLM_CTG_REC_ID                                                PT_SILLM_CTG_REC_ID          /* 환자중증도분류기록ID */
     , A1.WRT_SEQ                                                            PT_SILLM_CTG_REC_WRT_SEQ     /* 환자중증도분류기록작성순번 */
     , P.PT_NO                                                               PT_NO                        /* 환자번호(등록번호) */
     , A1.CTG_DTM                                                            PT_SILLM_CTG_DTM             /* 분류일시 */
     , A1.PT_SILLM_CTG_TL_ID                                                 PT_SILLM_CTG_TL_ID           /* 환자중증도분류도구ID */
     , D.PT_SILLM_TL_NM                                                      PT_SILLM_CTG_TL_NM           /* 환자중증도도구명 */
--     , C.PT_SILLM_CTG_NM                                                     PT_SILLM_CTG_NM            /* 환자중증도분류도구명 */
     , P.PACT_ID                                                             PACT_ID                      /* 원무접수ID */
     , A1.PACT_TP_CD                                                         PACT_TP_CD                   /* 원무접수구분코드 */
     , A1.WD_DEPT_CD                                                         WD_DEPT_CD                   /* 병동부서코드 */
     , XCOM.FT_PDE_SELDEPTNM(A1.WD_DEPT_CD, A1.HSP_TP_CD)                    WD_DEPT_CD_NM                /* 병동부서코드명 */
     , A1.PT_SILLM_CTG_TP_CD                                                 PT_SILLM_CTG_TP_CD           /* 환자중증도분류구분코드 */
     , XCOM.FT_CCC_CODENAME(A1.HSP_TP_CD, 'N0000126', A1.PT_SILLM_CTG_TP_CD) PT_SILLM_CTG_TP_CD_NM        /* 환자중증도분류구분코드명 ex> 병동, 중환자실, 정신건강,,,*/
     , A1.PT_SILLM_CTG_GRP_CD                                                 PT_SILLM_CTG_GRP_CD          /* 환자중증도분류그룹코드 */
     , XCOM.FT_CCC_CODENAME(A1.HSP_TP_CD, 'N0000134', A1.PT_SILLM_CTG_GRP_CD) PT_SILLM_CTG_GRP_CD_NM       /* 환자중증도분류그룹코드명 ex> 1군, 2군, 3군,,,*/
     , A1.PT_SILLM_CTG_SCR_SUM                                               PT_SILLM_CTG_SCR_SUM         /* 환자중증도분류점수합계 */
     , A1.USE_YN                                                             USE_YN
     , A1.LST_YN                                                             LST_YN
     , A1.FSR_DTM                                                            FST_LOD_DTM                  /* 최종작성일시 */
     , A1.LSH_DTM                                                            LST_LOD_DTM                  /* 최종변경일시 */
  FROM ACPPRAAM P
--     , MOMNMIOD M
     , MOPPCCFD A1
--	 , MOPPCCFE A2
--	 , MOPPCCED B
--   , MOPPCCDD C
     , MOPPCCAD D
 WHERE 1=1
--   AND P.PACT_ID               = M.PACT_ID
--   AND P.HSP_TP_CD             = M.HSP_TP_CD
--   AND (M.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU') OR M.ETRM_WD_DEPT_CD = '039')
--   AND M.PACT_TP_CD            = 'I'
--   AND M.USE_YN                = 'Y'
--   AND M.LST_YN                = 'Y'
--   AND P.CLCTN_WD_DEPT_CD IN ('SICU', 'MICU', 'CICU', 'NCU', 'NICU', 'NICU2', 'EICU', 'EICU2', '039') --(SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU') OR P.CLCTN_WD_DEPT_CD = '039') /*ODS 적재시, 현위치 정보 제외요청*/
   AND P.PACT_ID               = A1.PACT_ID
   AND P.PT_NO                 = A1.PT_NO
   AND P.HSP_TP_CD             = A1.HSP_TP_CD
--   AND P.HSP_TP_CD             = A2.HSP_TP_CD
--   AND P.HSP_TP_CD             = B.HSP_TP_CD
--   AND P.HSP_TP_CD             = C.HSP_TP_CD
   AND P.HSP_TP_CD             = D.HSP_TP_CD
--   AND P.SIHS_YN               = 'Y'      -- 재원중인 환자만 조회할지 확인 (Q)
   AND P.APCN_YN               = 'N'
   AND P.APCN_DTM              IS NULL
--   AND A1.PT_SILLM_CTG_TL_ID   = C.PT_SILLM_CTG_TL_ID
--   AND A1.PT_SILLM_CTG_REC_ID  = A2.PT_SILLM_CTG_REC_ID
--   AND A1.WRT_SEQ              = A2.WRT_SEQ
--   AND A1.PT_SILLM_CTG_TL_ID   = C.PT_SILLM_CTG_TL_ID
   AND A1.PT_SILLM_CTG_TL_ID   = D.PT_SILLM_CTG_TL_ID
   AND A1.PT_SILLM_CTG_TP_CD   = D.PT_SILLM_CTG_TP_CD
   AND A1.PT_SILLM_CTG_TP_CD   IN ('1', '2')     -- 중환자실만 체크할지 확인 (1:병동 2:중환자실)
--   AND A1.USE_YN               = 'Y'
--   AND A1.LST_YN               = 'Y'
--   AND A2.PT_SILLM_CTG_ITEM_ID = B.PT_SILLM_CTG_ITEM_ID
--   AND B.PT_SILLM_CTG_ID       = C.PT_SILLM_CTG_ID
   AND D.AVL_END_DTM           = TO_DATE('9999-12-31', 'YYYY-MM-DD')
 ORDER BY P.PT_NO
        , A1.PT_SILLM_CTG_REC_ID
        , A1.WRT_SEQ;