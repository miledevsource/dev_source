
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "XICU"."V_TRANSFERS" ("TRANSFER_ID", "SUBJECT_ID", "HADM_ID", "EVENTTYPE", "CAREUNIT", "CURR_SERVICE", "INTIME", "OUTTIME", "PROVIDER_ID", "ROOM_ID", "BED_ID", "STAY_STATUS", "DISCHTIME") AS 
  WITH PT_LIST AS (
    SELECT B.PACT_ID              AS PACT_ID
         , MIN(B.EMRG_PACT_ID)    AS EMRG_PACT_ID
         , MIN(C.EMRM_ARVL_DTM)   AS EMRM_ARVL_DTM
         , MIN(C.CHOT_DTM)        AS CHOT_DTM
         , MIN(B.DS_DTM)          AS DS_DTM
         , MIN(B.SIHS_YN)         AS SIHS_YN
      FROM MOMNMIOD A        --중환자실입실퇴실시간정보
         , ACPPRAAM B        --입원접수기본
         , ACPPRETM C
     WHERE A.PACT_ID         = B.PACT_ID
       AND A.HSP_TP_CD       = B.HSP_TP_CD
       AND B.EMRG_PACT_ID    = C.PACT_ID(+)
       --AND A.ETRM_WD_DEPT_CD IN (SELECT DEPT_CD  FROM PDEDBMSM  WHERE UPR_DEPT_CD = 'ICU')
       AND A.USE_YN          = 'Y'                     --사용여부
       AND A.LST_YN          = 'Y'                     --최종여부
       AND A.PACT_TP_CD      = 'I'                     --원무접수구분코드
       AND B.APCN_YN         = 'N'                     --접수취소여부
     GROUP BY B.PACT_ID
)
SELECT A.PACT_ID || '000'                                                                               AS TRANSFER_ID         --환자이동ID
     , B.PT_NO                                                                                          AS SUBJECT_ID          --환자번호
     , A.PACT_ID                                                                                        AS HADM_ID             --수진ID
     , 'ed'                                                                                             AS EVENTTYPE           --이동구분
     , NULL                                                                                             AS CAREUNIT            --병동코드
     , B.EMRG_MAIN_MED_DEPT_CD                                                                          AS CURR_SERVICE        --진료과코드
     , B.EMRM_ARVL_DTM                                                                                  AS INTIME              --적용시작일시
     , B.CHOT_DTM                                                                                       AS OUTTIME             --적용종료일시
     , B.MEDR_STF_NO                                                                                    AS PROVIDER_ID         --주치의
     , NULL                                                                                             AS ROOM_ID             --병실번호
     , NULL                                                                                             AS BED_ID              --병상번호
     , A.SIHS_YN                                                                                        AS STAY_STATUS         --재원상태
     , A.DS_DTM                                                                                         AS DISCHTIME           --퇴원일시
  FROM PT_LIST A
     , ACPPRETM B
 WHERE A.EMRG_PACT_ID = B.PACT_ID
   AND A.EMRG_PACT_ID IS NOT NULL

 UNION

SELECT B.RPY_PACT_ID || LPAD(ROW_NUMBER() OVER (PARTITION BY B.RPY_PACT_ID ORDER BY B.APY_STR_DT),3,'0')AS TRANSFER_ID         --환자이동ID
     , B.PT_NO                                                                                          AS SUBJECT_ID          --환자번호
     , A.PACT_ID                                                                                        AS HADM_ID             --수진ID
     , CASE WHEN ROW_NUMBER() OVER (PARTITION BY B.RPY_PACT_ID ORDER BY B.APY_STR_DT) = 1 THEN 'admit'
            ELSE 'transfer' END                                                                         AS EVENTTYPE           --이동구분
     , B.WD_DEPT_CD                                                                                     AS CAREUNIT            --병동코드
     , B.MED_DEPT_CD                                                                                    AS CURR_SERVICE        --진료과코드
     , CASE WHEN A.CHOT_DTM IS NOT NULL AND ROW_NUMBER() OVER (PARTITION BY B.RPY_PACT_ID ORDER BY B.APY_STR_DT) = 1 THEN A.CHOT_DTM + (1/86400)
            ELSE TRUNC(B.APY_STR_DT)
        END                                                                                             AS INTIME              --적용시작일시
     , CASE WHEN TRUNC(A.DS_DTM) = B.APY_END_DT THEN A.DS_DTM - (1/86400)
            ELSE TO_DATE(TO_CHAR(B.APY_END_DT, 'YYYY-MM-DD') || ' 23:59:59', 'YYYY-MM-DD HH24:MI:SS')
        END                                                                                             AS OUTTIME             --적용종료일시
     , B.ANDR_STF_NO                                                                                    AS PROVIDER_ID         --주치의
     , B.PRM_NO                                                                                         AS ROOM_ID             --병실번호
     , B.BED_NO                                                                                         AS BED_ID              --병상번호
     , A.SIHS_YN                                                                                        AS STAY_STATUS         --재원상태
     , A.DS_DTM                                                                                         AS DISCHTIME           --퇴원일시
  FROM PT_LIST A
     , ACPPRTSD B
 WHERE A.PACT_ID = B.RPY_PACT_ID

 UNION

SELECT B.PACT_ID || '999'                                                                               AS TRANSFER_ID         --환자이동ID
     , B.PT_NO                                                                                          AS SUBJECT_ID          --환자번호
     , B.PACT_ID                                                                                        AS HADM_ID             --수진ID
     , 'discharge'                                                                                      AS EVENTTYPE           --이동구분
     , NULL                                                                                             AS CAREUNIT            --병동코드
     , B.MED_DEPT_CD                                                                                    AS CURR_SERVICE        --진료과코드
     , B.DS_DTM                                                                                         AS INTIME              --적용시작일시
     , NULL                                                                                             AS OUTTIME             --적용종료일시
     , B.ANDR_STF_NO                                                                                    AS PROVIDER_ID         --주치의
     , NULL                                                                                             AS ROOM_ID             --병실번호
     , NULL                                                                                             AS BED_ID              --병상번호
     , A.SIHS_YN                                                                                        AS STAY_STATUS         --재원상태
     , A.DS_DTM                                                                                         AS DISCHTIME           --퇴원일시
  FROM PT_LIST A
     , ACPPRAAM B
 WHERE A.PACT_ID = B.PACT_ID
   AND A.DS_DTM IS NOT NULL
ORDER BY TRANSFER_ID;